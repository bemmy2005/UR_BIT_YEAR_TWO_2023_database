-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 11:52 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ishimwe`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertWorker` (IN `p_names` VARCHAR(225), IN `p_email` VARCHAR(200), IN `p_phone_number` VARCHAR(10), IN `p_nationality` VARCHAR(40), IN `p_experience` VARCHAR(255), IN `p_certificate` VARCHAR(40))   BEGIN
    INSERT INTO worker (Names, Email, Phone_number, nationality, experience, certificate)
    VALUES (p_names, p_email, p_phone_number, p_nationality, p_experience, p_certificate);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `application_id` int(11) NOT NULL,
  `Date` date DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `cover_letter` varchar(50) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `worker_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`application_id`, `Date`, `status`, `cover_letter`, `job_id`, `worker_id`) VALUES
(1, '2023-09-01', 'Pending', 'I am excited about this opportunity.', 1, 1),
(2, '2023-09-02', 'Rejected', 'Unfortunately, we selected another candidate.', 2, 2),
(3, '2023-09-03', 'Pending', 'Looking forward to discussing further.', 3, 3),
(4, '2023-09-04', 'Accepted', 'I am thrilled to join your team!', 4, 4),
(5, '2023-09-05', 'Pending', 'I believe I am a good fit for this role.', 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE `employer` (
  `employer_id` int(11) NOT NULL,
  `Names` varchar(225) NOT NULL,
  `identity_number` varchar(10) DEFAULT NULL,
  `Phone_number` varchar(10) DEFAULT NULL,
  `Email` varchar(200) NOT NULL,
  `Address` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employer`
--

INSERT INTO `employer` (`employer_id`, `Names`, `identity_number`, `Phone_number`, `Email`, `Address`) VALUES
(1, 'ABC Corporation', '1234567890', '5555555555', 'abc@example.com', '789 Oak Street'),
(2, 'XYZ Ltd.', '9876543210', '2222222222', 'xyz@example.com', '456 Elm Avenue'),
(3, 'LMN Enterprises', '5555555555', '3333333333', 'lmn@example.com', '789 Oak Road'),
(4, 'PQR Inc.', '1111111111', '4444444444', 'pqr@example.com', '101 Maple Lane'),
(5, 'EFG Industries', '9999999999', '5555555555', 'efg@example.com', '222 Birch Boulevard');

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `experience_id` int(11) NOT NULL,
  `job_title` varchar(50) NOT NULL,
  `duration` varchar(50) NOT NULL,
  `reference` varchar(50) NOT NULL,
  `worker_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`experience_id`, `job_title`, `duration`, `reference`, `worker_id`) VALUES
(1, 'Senior Software Engineer', '4 years', 'John Smith, IT Manager', 1),
(2, 'Data Analyst', '2 years', 'Jane Doe, Data Director', 2),
(3, 'Marketing Specialist', '4 years', 'Michael Johnson, Marketing Manager', 3),
(4, 'Accountant', '5 years', 'Emily Davis, Finance Director', 4),
(5, 'Sales Representative', '2 years', 'David Wilson, Sales Manager', 5);

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `job_id` int(11) NOT NULL,
  `location` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `skills` varchar(50) NOT NULL,
  `compansation` varchar(50) NOT NULL,
  `employer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`job_id`, `location`, `description`, `skills`, `compansation`, `employer_id`) VALUES
(1, 'New York', 'Software Developer', 'Java, Python, SQL', '$80,000 per year', 1),
(2, 'San Francisco', 'Data Analyst', 'Data Analysis, Python, Excel', '$75,000 per year', 2),
(3, 'Los Angeles', 'Marketing Manager', 'Marketing, SEO, Social Media', '$90,000 per year', 3),
(4, 'Chicago', 'Accountant', 'Accounting, Finance, QuickBooks', '$70,000 per year', 4),
(5, 'Dallas', 'Sales Representative', 'Sales, Customer Service', '$60,000 per year', 5);

-- --------------------------------------------------------

--
-- Table structure for table `jobpreference`
--

CREATE TABLE `jobpreference` (
  `jobpreference_id` int(11) NOT NULL,
  `job_type` varchar(50) NOT NULL,
  `work_schedule` varchar(50) NOT NULL,
  `compansation` varchar(50) NOT NULL,
  `mobility` varchar(255) NOT NULL,
  `worker_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobpreference`
--

INSERT INTO `jobpreference` (`jobpreference_id`, `job_type`, `work_schedule`, `compansation`, `mobility`, `worker_id`) VALUES
(1, 'Software Developer', 'Full-time', '$90,000 per year', 'Willing to relocate', 1),
(2, 'Data Analyst', 'Part-time', '$60,000 per year', 'Open to travel', 2),
(3, 'Marketing Manager', 'Full-time', '$100,000 per year', 'No mobility restrictions', 3),
(4, 'Accountant', 'Full-time', '$80,000 per year', 'Limited mobility within the region', 4),
(5, 'Sales Representative', 'Full-time', '$70,000 per year', 'Willing to travel extensively', 5);

-- --------------------------------------------------------

--
-- Table structure for table `worker`
--

CREATE TABLE `worker` (
  `worker_id` int(11) NOT NULL,
  `Names` varchar(225) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Phone_number` varchar(10) DEFAULT NULL,
  `nationality` varchar(40) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `certificate` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `worker`
--

INSERT INTO `worker` (`worker_id`, `Names`, `Email`, `Phone_number`, `nationality`, `experience`, `certificate`) VALUES
(1, 'John Doe', 'john.doe@email.com', '1234567891', 'USA', '6 years', 'Certified Worker'),
(2, 'Jane Smith', 'jane.smith@email.com', '9876543210', 'Canada', '3 years', 'Certified Worker'),
(3, 'Michael Johnson', 'michael.johnson@email.com', '5555555555', 'UK', '7 years', 'Master Worker'),
(4, 'Emily Davis', 'emily.davis@email.com', '1111111111', 'Australia', '2 years', 'Certified Worker'),
(5, 'David Wilson', 'david.wilson@email.com', '9999999999', 'New Zealand', '4 years', 'Master Worker');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`application_id`),
  ADD KEY `job_id` (`job_id`),
  ADD KEY `worker_id` (`worker_id`);

--
-- Indexes for table `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`employer_id`);

--
-- Indexes for table `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`experience_id`),
  ADD KEY `worker_id` (`worker_id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`job_id`),
  ADD KEY `employer_id` (`employer_id`);

--
-- Indexes for table `jobpreference`
--
ALTER TABLE `jobpreference`
  ADD PRIMARY KEY (`jobpreference_id`),
  ADD KEY `worker_id` (`worker_id`);

--
-- Indexes for table `worker`
--
ALTER TABLE `worker`
  ADD PRIMARY KEY (`worker_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `application_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `employer`
--
ALTER TABLE `employer`
  MODIFY `employer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `experience`
--
ALTER TABLE `experience`
  MODIFY `experience_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jobpreference`
--
ALTER TABLE `jobpreference`
  MODIFY `jobpreference_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `worker`
--
ALTER TABLE `worker`
  MODIFY `worker_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `application`
--
ALTER TABLE `application`
  ADD CONSTRAINT `application_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`),
  ADD CONSTRAINT `application_ibfk_2` FOREIGN KEY (`worker_id`) REFERENCES `worker` (`worker_id`);

--
-- Constraints for table `experience`
--
ALTER TABLE `experience`
  ADD CONSTRAINT `experience_ibfk_1` FOREIGN KEY (`worker_id`) REFERENCES `worker` (`worker_id`);

--
-- Constraints for table `job`
--
ALTER TABLE `job`
  ADD CONSTRAINT `job_ibfk_1` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`employer_id`);

--
-- Constraints for table `jobpreference`
--
ALTER TABLE `jobpreference`
  ADD CONSTRAINT `jobpreference_ibfk_1` FOREIGN KEY (`worker_id`) REFERENCES `worker` (`worker_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
