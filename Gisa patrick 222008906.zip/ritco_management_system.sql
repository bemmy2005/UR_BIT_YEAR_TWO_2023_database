-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ritco_management_system
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bus_class`
--

DROP TABLE IF EXISTS `bus_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus_class` (
  `bus_id` int(11) NOT NULL,
  `bus_name` text DEFAULT NULL,
  `bus_plate_number` varchar(100) DEFAULT NULL,
  `bus_seat_number` int(100) DEFAULT NULL,
  `ticket_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`bus_id`),
  KEY `ticket_id` (`ticket_id`),
  CONSTRAINT `bus_class_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `ticket_class` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_class`
--

LOCK TABLES `bus_class` WRITE;
/*!40000 ALTER TABLE `bus_class` DISABLE KEYS */;
INSERT INTO `bus_class` VALUES (1,'toyota','RAE816H',29,NULL);
/*!40000 ALTER TABLE `bus_class` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER bus
AFTER INSERT ON bus_class
FOR EACH ROW
BEGIN
    INSERT INTO bus_class (bus_id, bus_name, bus_plate_number,bus_seat_number)
    VALUES (1, 'INSERT', NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER AfterUpdatecustomer
AFTER UPDATE ON bus_class
FOR EACH ROW
BEGIN
    INSERT INTO bus_class (bus_id, bus_name, bus_plate_number,bus_seat_number) 
    VALUES (NEW.bus_id, 'UPDATE', NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `bus_view`
--

DROP TABLE IF EXISTS `bus_view`;
/*!50001 DROP VIEW IF EXISTS `bus_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `bus_view` AS SELECT
 1 AS `bus_id`,
  1 AS `bus_name`,
  1 AS `bus_plate_number`,
  1 AS `bus_seat_number` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `customer_class`
--

DROP TABLE IF EXISTS `customer_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_class` (
  `customer_id` int(50) NOT NULL,
  `customer_name` text DEFAULT NULL,
  `customer_mobile` int(12) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_class`
--

LOCK TABLES `customer_class` WRITE;
/*!40000 ALTER TABLE `customer_class` DISABLE KEYS */;
INSERT INTO `customer_class` VALUES (1,'gatete',788449384,'gatete567@gmail.com','nyagatare');
/*!40000 ALTER TABLE `customer_class` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER customer
AFTER INSERT ON customer_class
FOR EACH ROW
BEGIN
    INSERT INTO customer_class (customer_id,
customer_name,
customer_mobile,
customer_email,
customer_address
)
    VALUES (1, 'INSERT', NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER AfterUpdatebus
AFTER UPDATE ON customer_class
FOR EACH ROW
BEGIN
    INSERT INTO customer_class (customer_id,customer_name,
customer_mobile,
customer_email,
customer_address)
    VALUES (NEW.customer_id, 'UPDATE', NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER customer_class
AFTER DELETE ON customer_class
FOR EACH ROW
BEGIN
   INSERT INTO customer_class (customer_id,
customer_name,
customer_mobile,
customer_email,
customer_address
)

    VALUES (customer_id, 'DELETE', NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `customer_view`
--

DROP TABLE IF EXISTS `customer_view`;
/*!50001 DROP VIEW IF EXISTS `customer_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customer_view` AS SELECT
 1 AS `customer_id`,
  1 AS `customer_name`,
  1 AS `customer_mobile`,
  1 AS `customer_email`,
  1 AS `customer_address` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `driver_class`
--

DROP TABLE IF EXISTS `driver_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `driver_class` (
  `Driver_id` int(50) NOT NULL,
  `Driver_name` varchar(50) DEFAULT NULL,
  `Driver_mobile` int(50) DEFAULT NULL,
  `Driver_email` varchar(50) DEFAULT NULL,
  `Driver_address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Driver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver_class`
--

LOCK TABLES `driver_class` WRITE;
/*!40000 ALTER TABLE `driver_class` DISABLE KEYS */;
INSERT INTO `driver_class` VALUES (1,'emmy',0,'788449384','emmy5678@yahoo.com'),(2,'james',78852202,'james200@gmail.com','kigali');
/*!40000 ALTER TABLE `driver_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `driver_view`
--

DROP TABLE IF EXISTS `driver_view`;
/*!50001 DROP VIEW IF EXISTS `driver_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `driver_view` AS SELECT
 1 AS `driver_id`,
  1 AS `driver_name`,
  1 AS `driver_address`,
  1 AS `driver_mobile`,
  1 AS `driver_email` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission` (
  `Username` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES ('kagaba','123');
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `permission_view`
--

DROP TABLE IF EXISTS `permission_view`;
/*!50001 DROP VIEW IF EXISTS `permission_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `permission_view` AS SELECT
 1 AS `username`,
  1 AS `password` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `ticket_class`
--

DROP TABLE IF EXISTS `ticket_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_class` (
  `ticket_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `bus_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `ticket_from` varchar(100) DEFAULT NULL,
  `ticket_to` varchar(100) DEFAULT NULL,
  `ticket_date` date DEFAULT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `driver_id` (`driver_id`),
  KEY `bus_id` (`bus_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `ticket_class_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `driver_class` (`Driver_id`),
  CONSTRAINT `ticket_class_ibfk_2` FOREIGN KEY (`bus_id`) REFERENCES `bus_class` (`bus_id`),
  CONSTRAINT `ticket_class_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customer_class` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_class`
--

LOCK TABLES `ticket_class` WRITE;
/*!40000 ALTER TABLE `ticket_class` DISABLE KEYS */;
INSERT INTO `ticket_class` VALUES (1,1,1,1,'nyagatare','kigali','2023-09-12');
/*!40000 ALTER TABLE `ticket_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `ticket_view`
--

DROP TABLE IF EXISTS `ticket_view`;
/*!50001 DROP VIEW IF EXISTS `ticket_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `ticket_view` AS SELECT
 1 AS `ticket_id`,
  1 AS `customer_id`,
  1 AS `bus_id`,
  1 AS `driver_id`,
  1 AS `ticket_from`,
  1 AS `ticket_to`,
  1 AS `ticket_date` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `bus_view`
--

/*!50001 DROP VIEW IF EXISTS `bus_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bus_view` AS select `bus_class`.`bus_id` AS `bus_id`,`bus_class`.`bus_name` AS `bus_name`,`bus_class`.`bus_plate_number` AS `bus_plate_number`,`bus_class`.`bus_seat_number` AS `bus_seat_number` from `bus_class` where `bus_class`.`bus_id` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customer_view`
--

/*!50001 DROP VIEW IF EXISTS `customer_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customer_view` AS select `customer_class`.`customer_id` AS `customer_id`,`customer_class`.`customer_name` AS `customer_name`,`customer_class`.`customer_mobile` AS `customer_mobile`,`customer_class`.`customer_email` AS `customer_email`,`customer_class`.`customer_address` AS `customer_address` from `customer_class` where `customer_class`.`customer_id` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `driver_view`
--

/*!50001 DROP VIEW IF EXISTS `driver_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `driver_view` AS select `driver_class`.`Driver_id` AS `driver_id`,`driver_class`.`Driver_name` AS `driver_name`,`driver_class`.`Driver_address` AS `driver_address`,`driver_class`.`Driver_mobile` AS `driver_mobile`,`driver_class`.`Driver_email` AS `driver_email` from `driver_class` where `driver_class`.`Driver_id` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `permission_view`
--

/*!50001 DROP VIEW IF EXISTS `permission_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `permission_view` AS select `permission`.`Username` AS `username`,`permission`.`Password` AS `password` from `permission` group by `permission`.`Password` = 123 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ticket_view`
--

/*!50001 DROP VIEW IF EXISTS `ticket_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ticket_view` AS select `ticket_class`.`ticket_id` AS `ticket_id`,`ticket_class`.`customer_id` AS `customer_id`,`ticket_class`.`bus_id` AS `bus_id`,`ticket_class`.`driver_id` AS `driver_id`,`ticket_class`.`ticket_from` AS `ticket_from`,`ticket_class`.`ticket_to` AS `ticket_to`,`ticket_class`.`ticket_date` AS `ticket_date` from `ticket_class` where `ticket_class`.`ticket_id` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-18  9:31:55
