-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 03:48 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ruth_muhawenayo_222007339`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteFromItems` (IN `item_idparam` INT)   BEGIN
 delete from items where 
item_id=item_idParam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteFromOwners` (IN `Owner_idParam` INT)   BEGIN
 delete from owners where 
name=owner_idParam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAdminData` ()   BEGIN
SELECT * FROM admins;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetCategoryData` ()   BEGIN
SELECT * FROM categories;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetFinderData` ()   BEGIN
SELECT * FROM finders;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetItemsData` ()   BEGIN
SELECT * FROM items;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetItemsWithOwners` (IN `addressparam` VARCHAR(255))   BEGIN
 SELECT Item_id,
              Item_name,
               Lost_date,
               owner_id
         FROM items
         WHERE owner_id IN (SELECT owner_id FROM owners WHERE address=addressparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetLocationData` ()   BEGIN
SELECT * FROM locations;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetOwnersData` ()   BEGIN
SELECT * FROM owners;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetStatusData` ()   BEGIN
SELECT * FROM status;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertAdmin` (IN `admin_idparam` INT, IN `nameparam` VARCHAR(255), IN `emailparam` VARCHAR(255))   BEGIN
insert into admins values(admin_idparam,nameparam,emailparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertCategory` (IN `category_idparam` INT, IN `category_nameparam` VARCHAR(255))   BEGIN
insert into categories values(category_idparam,category_nameparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertFinder` (IN `finder_idparam` INT, IN `nameparam` VARCHAR(255), IN `addressparam` VARCHAR(255), IN `found_dateparam` VARCHAR(255), IN `admin_idparam` INT)   BEGIN
insert into finders values(finder_idparam,nameparam,addressparam,found_dateparam,admin_idparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertItems` (IN `item_idparam` INT, IN `item_nameparam` VARCHAR(255), IN `lost_dateparam` DATE, IN `owner_idparam` INT, IN `category_idparam` INT, IN `location_idparam` INT, IN `finder_idparam` INT, IN `status_idparam` INT)   BEGIN
insert into items values(item_idparam,item_nameparam,lost_dateparam,owner_idparam,category_idparam,location_idparam,finder_idparam,status_idparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertLocation` (IN `location_idparam` INT, IN `location_nameparam` VARCHAR(255))   BEGIN
insert into locations values(location_idparam,location_nameparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertOwners` (IN `owner_idparam` INT, IN `nameparam` VARCHAR(255), IN `emailparam` VARCHAR(255), IN `phone_numberparam` VARCHAR(20), IN `addressparam` VARCHAR(255))   BEGIN
insert into owners values(owner_idparam,nameparam,emailparam,phone_numberparam,addressparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertStatus` (IN `status_idparam` INT, IN `status_nameparam` VARCHAR(255))   BEGIN
insert into status values(status_idparam,status_nameparam);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateAdmin` (IN `admin_idparam` INT)   BEGIN update admins set name='Kabera Kelly',
                        email='kaberakelly003@email'
    where admin_id=admin_idparam;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateOwners` (IN `owner_idparam` INT)   BEGIN update owners set phone_number='0723004212',
                        address='Rwezamenyo'
    where owner_id=owner_idparam;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `name`, `email`) VALUES
(1, 'Nkaka Andy', 'nkaka322@email.com'),
(2, 'Hirwa David', 'hirwadolph@email.com'),
(3, 'Kaza Ritha', 'kazaritha@email.com'),
(4, 'Kabera Kelly', 'kaberakelly003@email');

-- --------------------------------------------------------

--
-- Stand-in structure for view `admin_view`
-- (See below for the actual view)
--
CREATE TABLE `admin_view` (
`admin_id` int(11)
,`name` varchar(255)
,`email` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(1, 'electronics'),
(2, 'jewerly'),
(3, 'musical instruments'),
(4, 'Book'),
(5, 'clothes');

--
-- Triggers `categories`
--
DELIMITER $$
CREATE TRIGGER `after_category_update` AFTER UPDATE ON `categories` FOR EACH ROW BEGIN  
      UPDATE categories
      SET category_name=NEW.category_name
      WHERE category_id=old.category_id;
UPDATE items
SET item_name=CONCAT(item_name,NEW.category_id)
 WHERE category_id=OLD.category_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `category_view`
-- (See below for the actual view)
--
CREATE TABLE `category_view` (
`category_id` int(11)
,`category_name` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `finders`
--

CREATE TABLE `finders` (
  `finder_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `found_date` date DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `finders`
--

INSERT INTO `finders` (`finder_id`, `name`, `address`, `found_date`, `admin_id`) VALUES
(1, 'Nishimwe Aliane', 'Kimironko', '2023-01-14', 1),
(2, 'Kagabo Gustave', 'Nyabugogo', '2023-02-20', 2),
(4, 'Ganza peter', 'kimisange', '2022-08-25', 4),
(5, 'Ghandi Alnave', 'Gisozi', '2023-11-20', 3);

-- --------------------------------------------------------

--
-- Stand-in structure for view `finder_view`
-- (See below for the actual view)
--
CREATE TABLE `finder_view` (
`finder_id` int(11)
,`name` varchar(255)
,`address` varchar(255)
,`found_date` date
,`admin_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `lost_date` date DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `finder_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_name`, `lost_date`, `owner_id`, `category_id`, `location_id`, `finder_id`, `status_id`) VALUES
(2, 'diamond necklace', '2022-07-15', 2, 2, 2, 2, 1),
(4, 'book', '2022-09-20', 4, 4, 4, 4, 2),
(5, 'T shirt', '2022-11-30', 5, 5, 5, 5, 1),
(6, '', NULL, 6, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `items_view`
-- (See below for the actual view)
--
CREATE TABLE `items_view` (
`item_id` int(11)
,`item_name` varchar(255)
,`lost_date` date
,`owner_id` int(11)
,`category_id` int(11)
,`location_id` int(11)
,`finder_id` int(11)
,`status_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `items_with_owners_view`
-- (See below for the actual view)
--
CREATE TABLE `items_with_owners_view` (
`item_id` int(11)
,`item_name` varchar(255)
,`lost_date` date
,`owner_name` varchar(255)
,`address` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `location_id` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`location_id`, `location_name`) VALUES
(1, 'Nyakabanda'),
(2, 'Remera'),
(3, 'kicukiro'),
(4, 'Nyarugenge'),
(5, 'Gasabo');

-- --------------------------------------------------------

--
-- Stand-in structure for view `location_view`
-- (See below for the actual view)
--
CREATE TABLE `location_view` (
`location_id` int(11)
,`location_name` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

CREATE TABLE `owners` (
  `owner_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`owner_id`, `name`, `email`, `phone_number`, `address`) VALUES
(1, 'Kundwa Ade', 'kundwade@email.com', '0788843555', 'kicukiro'),
(2, 'Gwiza Anne', 'gwizane@email.com', '0788234543', 'Gisagara'),
(3, 'Kaze Elvin', 'kazelvin23@email.com', '0798234568', 'Bugesera'),
(4, 'Sugira Aime', 'sugiraime@email.com', '0723004212', 'Rwezamenyo'),
(5, 'Rwema Lily', 'rwemalily002@email.com', '0798321141', 'Rwarutabura'),
(6, 'Mutima Flower', 'mutimaflower025@email.com', '', 'Kamonyi');

--
-- Triggers `owners`
--
DELIMITER $$
CREATE TRIGGER `after_owners_insert` AFTER INSERT ON `owners` FOR EACH ROW BEGIN
INSERT INTO items(owner_id)
VALUES (new.owner_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `owners_view`
-- (See below for the actual view)
--
CREATE TABLE `owners_view` (
`owner_id` int(11)
,`name` varchar(255)
,`email` varchar(255)
,`phone_number` varchar(20)
,`address` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`status_id`, `status_name`) VALUES
(1, 'lost'),
(2, 'lost');

-- --------------------------------------------------------

--
-- Stand-in structure for view `status_view`
-- (See below for the actual view)
--
CREATE TABLE `status_view` (
`status_id` int(11)
,`status_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Structure for view `admin_view`
--
DROP TABLE IF EXISTS `admin_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `admin_view`  AS SELECT `admins`.`admin_id` AS `admin_id`, `admins`.`name` AS `name`, `admins`.`email` AS `email` FROM `admins` ;

-- --------------------------------------------------------

--
-- Structure for view `category_view`
--
DROP TABLE IF EXISTS `category_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `category_view`  AS SELECT `categories`.`category_id` AS `category_id`, `categories`.`category_name` AS `category_name` FROM `categories` ;

-- --------------------------------------------------------

--
-- Structure for view `finder_view`
--
DROP TABLE IF EXISTS `finder_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `finder_view`  AS SELECT `finders`.`finder_id` AS `finder_id`, `finders`.`name` AS `name`, `finders`.`address` AS `address`, `finders`.`found_date` AS `found_date`, `finders`.`admin_id` AS `admin_id` FROM `finders` ;

-- --------------------------------------------------------

--
-- Structure for view `items_view`
--
DROP TABLE IF EXISTS `items_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `items_view`  AS SELECT `items`.`item_id` AS `item_id`, `items`.`item_name` AS `item_name`, `items`.`lost_date` AS `lost_date`, `items`.`owner_id` AS `owner_id`, `items`.`category_id` AS `category_id`, `items`.`location_id` AS `location_id`, `items`.`finder_id` AS `finder_id`, `items`.`status_id` AS `status_id` FROM `items` ;

-- --------------------------------------------------------

--
-- Structure for view `items_with_owners_view`
--
DROP TABLE IF EXISTS `items_with_owners_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `items_with_owners_view`  AS SELECT `items`.`item_id` AS `item_id`, `items`.`item_name` AS `item_name`, `items`.`lost_date` AS `lost_date`, (select `owners`.`name` from `owners` where `owners`.`owner_id` = `items`.`owner_id`) AS `owner_name`, (select `owners`.`address` from `owners` where `owners`.`owner_id` = `items`.`owner_id`) AS `address` FROM `items` ;

-- --------------------------------------------------------

--
-- Structure for view `location_view`
--
DROP TABLE IF EXISTS `location_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `location_view`  AS SELECT `locations`.`location_id` AS `location_id`, `locations`.`location_name` AS `location_name` FROM `locations` ;

-- --------------------------------------------------------

--
-- Structure for view `owners_view`
--
DROP TABLE IF EXISTS `owners_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `owners_view`  AS SELECT `owners`.`owner_id` AS `owner_id`, `owners`.`name` AS `name`, `owners`.`email` AS `email`, `owners`.`phone_number` AS `phone_number`, `owners`.`address` AS `address` FROM `owners` ;

-- --------------------------------------------------------

--
-- Structure for view `status_view`
--
DROP TABLE IF EXISTS `status_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `status_view`  AS SELECT `status`.`status_id` AS `status_id`, `status`.`status_name` AS `status_name` FROM `status` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `finders`
--
ALTER TABLE `finders`
  ADD PRIMARY KEY (`finder_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `owner_id` (`owner_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `finder_id` (`finder_id`),
  ADD KEY `status_id` (`status_id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `owners`
--
ALTER TABLE `owners`
  ADD PRIMARY KEY (`owner_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`status_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `finders`
--
ALTER TABLE `finders`
  MODIFY `finder_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `owners`
--
ALTER TABLE `owners`
  MODIFY `owner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `finders`
--
ALTER TABLE `finders`
  ADD CONSTRAINT `finders_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`admin_id`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `owners` (`owner_id`),
  ADD CONSTRAINT `items_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`),
  ADD CONSTRAINT `items_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `locations` (`location_id`),
  ADD CONSTRAINT `items_ibfk_4` FOREIGN KEY (`finder_id`) REFERENCES `finders` (`finder_id`),
  ADD CONSTRAINT `items_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `status` (`status_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
