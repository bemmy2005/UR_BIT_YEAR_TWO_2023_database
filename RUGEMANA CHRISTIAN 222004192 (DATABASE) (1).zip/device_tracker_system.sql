-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2023 at 08:20 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `device_tracker_system`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_information`
-- (See below for the actual view)
--
CREATE TABLE `all_information` (
`id` int(11)
,`name` varchar(255)
,`email_address` varchar(255)
,`password` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_devices_on`
-- (See below for the actual view)
--
CREATE TABLE `delete_devices_on` (
`id` int(11)
,`name` varchar(255)
,`location` varchar(255)
,`status` varchar(255)
,`battery_level` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `device`
--

CREATE TABLE `device` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `battery_level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `device`
--

INSERT INTO `device` (`id`, `name`, `location`, `status`, `battery_level`) VALUES
(1, 'joshua', 'Office', 'On', 80),
(2, 'Laptop', 'Office', 'On', 50),
(3, 'james', 'huye', 'on', 0);

-- --------------------------------------------------------

--
-- Stand-in structure for view `devices_in_office_with_battery_level_above_80`
-- (See below for the actual view)
--
CREATE TABLE `devices_in_office_with_battery_level_above_80` (
`id` int(11)
,`name` varchar(255)
,`location` varchar(255)
,`status` varchar(255)
,`battery_level` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `device_tracker_log`
-- (See below for the actual view)
--
CREATE TABLE `device_tracker_log` (
`id` int(11)
,`name` varchar(255)
,`location` varchar(255)
,`status` varchar(255)
,`battery_level` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  `device_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `type`, `timestamp`, `device_id`) VALUES
(1, 'Moved', '2023-09-05 12:00:00', 1),
(2, 'Powered On', '2023-09-05 13:00:00', 2);

-- --------------------------------------------------------

--
-- Stand-in structure for view `event_log`
-- (See below for the actual view)
--
CREATE TABLE `event_log` (
`id` int(11)
,`type` varchar(255)
,`timestamp` datetime
,`device_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `name`, `latitude`, `longitude`) VALUES
(1, 'Home', -1.283333, 3.133333),
(2, 'Office', 1.283333, 1.133333),
(3, 'kigali', -1.3233444, 1.2475367);

--
-- Triggers `location`
--
DELIMITER $$
CREATE TRIGGER `insert_location_trigger` AFTER INSERT ON `location` FOR EACH ROW BEGIN
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `location_log`
-- (See below for the actual view)
--
CREATE TABLE `location_log` (
`id` int(11)
,`name` varchar(255)
,`latitude` double
,`longitude` double
);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `timestamp` datetime NOT NULL,
  `events` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`id`, `timestamp`, `events`) VALUES
(1, '2023-09-05 14:00:00', '[1, 2]');

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatable_device_info`
-- (See below for the actual view)
--
CREATE TABLE `updatable_device_info` (
`id` int(11)
,`Name` varchar(255)
,`status` varchar(255)
,`location` varchar(255)
,`battery_level` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatable_user_info`
-- (See below for the actual view)
--
CREATE TABLE `updatable_user_info` (
`id` int(11)
,`name` varchar(255)
,`email_address` varchar(255)
,`password` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email_address`, `password`) VALUES
(1, 'John Doe', 'johndoe@example.com', 'password'),
(2, 'Jane Doe', 'emmyngabo40@gmail.com', 'password'),
(3, 'claude', 'claude@gmail.com', '12345670');

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_log`
-- (See below for the actual view)
--
CREATE TABLE `user_log` (
`id` int(11)
,`name` varchar(255)
,`email_address` varchar(255)
,`password` varchar(255)
);

-- --------------------------------------------------------

--
-- Structure for view `all_information`
--
DROP TABLE IF EXISTS `all_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`rugemana_christian`@`localhost` SQL SECURITY DEFINER VIEW `all_information`  AS SELECT `user`.`id` AS `id`, `user`.`name` AS `name`, `user`.`email_address` AS `email_address`, `user`.`password` AS `password` FROM `user`union all select `event`.`id` AS `id`,`event`.`type` AS `type`,`event`.`timestamp` AS `timestamp`,`event`.`device_id` AS `device_id` from `event`  ;

-- --------------------------------------------------------

--
-- Structure for view `delete_devices_on`
--
DROP TABLE IF EXISTS `delete_devices_on`;

CREATE ALGORITHM=UNDEFINED DEFINER=`rugemana_christian`@`localhost` SQL SECURITY DEFINER VIEW `delete_devices_on`  AS SELECT `device`.`id` AS `id`, `device`.`name` AS `name`, `device`.`location` AS `location`, `device`.`status` AS `status`, `device`.`battery_level` AS `battery_level` FROM `device` WHERE `device`.`status` = 'On' ;

-- --------------------------------------------------------

--
-- Structure for view `devices_in_office_with_battery_level_above_80`
--
DROP TABLE IF EXISTS `devices_in_office_with_battery_level_above_80`;

CREATE ALGORITHM=UNDEFINED DEFINER=`rugemana_christian`@`localhost` SQL SECURITY DEFINER VIEW `devices_in_office_with_battery_level_above_80`  AS SELECT `device`.`id` AS `id`, `device`.`name` AS `name`, `device`.`location` AS `location`, `device`.`status` AS `status`, `device`.`battery_level` AS `battery_level` FROM `device` WHERE `device`.`location` = 'Office' AND `device`.`battery_level` > 80 ;

-- --------------------------------------------------------

--
-- Structure for view `device_tracker_log`
--
DROP TABLE IF EXISTS `device_tracker_log`;

CREATE ALGORITHM=UNDEFINED DEFINER=`rugemana_christian`@`localhost` SQL SECURITY DEFINER VIEW `device_tracker_log`  AS SELECT `device`.`id` AS `id`, `device`.`name` AS `name`, `device`.`location` AS `location`, `device`.`status` AS `status`, `device`.`battery_level` AS `battery_level` FROM `device` WHERE `device`.`battery_level` = 80 ;

-- --------------------------------------------------------

--
-- Structure for view `event_log`
--
DROP TABLE IF EXISTS `event_log`;

CREATE ALGORITHM=UNDEFINED DEFINER=`rugemana_christian`@`localhost` SQL SECURITY DEFINER VIEW `event_log`  AS SELECT `event`.`id` AS `id`, `event`.`type` AS `type`, `event`.`timestamp` AS `timestamp`, `event`.`device_id` AS `device_id` FROM `event` ;

-- --------------------------------------------------------

--
-- Structure for view `location_log`
--
DROP TABLE IF EXISTS `location_log`;

CREATE ALGORITHM=UNDEFINED DEFINER=`rugemana_christian`@`localhost` SQL SECURITY DEFINER VIEW `location_log`  AS SELECT `location`.`id` AS `id`, `location`.`name` AS `name`, `location`.`latitude` AS `latitude`, `location`.`longitude` AS `longitude` FROM `location` ;

-- --------------------------------------------------------

--
-- Structure for view `updatable_device_info`
--
DROP TABLE IF EXISTS `updatable_device_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`rugemana_christian`@`localhost` SQL SECURITY DEFINER VIEW `updatable_device_info`  AS SELECT `device`.`id` AS `id`, `device`.`name` AS `Name`, `device`.`status` AS `status`, `device`.`location` AS `location`, `device`.`battery_level` AS `battery_level` FROM `device` ;

-- --------------------------------------------------------

--
-- Structure for view `updatable_user_info`
--
DROP TABLE IF EXISTS `updatable_user_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`rugemana_christian`@`localhost` SQL SECURITY DEFINER VIEW `updatable_user_info`  AS SELECT `user`.`id` AS `id`, `user`.`name` AS `name`, `user`.`email_address` AS `email_address`, `user`.`password` AS `password` FROM `user` ;

-- --------------------------------------------------------

--
-- Structure for view `user_log`
--
DROP TABLE IF EXISTS `user_log`;

CREATE ALGORITHM=UNDEFINED DEFINER=`rugemana_christian`@`localhost` SQL SECURITY DEFINER VIEW `user_log`  AS SELECT `user`.`id` AS `id`, `user`.`name` AS `name`, `user`.`email_address` AS `email_address`, `user`.`password` AS `password` FROM `user` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `device`
--
ALTER TABLE `device`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `device_id` (`device_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `device`
--
ALTER TABLE `device`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `event`
--
ALTER TABLE `event`
  ADD CONSTRAINT `event_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `device` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
