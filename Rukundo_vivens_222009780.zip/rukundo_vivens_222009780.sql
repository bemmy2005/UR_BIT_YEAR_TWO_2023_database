-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 11:23 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rukundo_vivens_222009780`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllAccessibility` ()   BEGIN
    SELECT * FROM Accessibility;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllEvents` ()   BEGIN
    SELECT * FROM Events;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllPayments` ()   BEGIN
    SELECT * FROM Payments;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllTransactions` ()   BEGIN
    SELECT * FROM Transactions;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllUsers` ()   BEGIN
    SELECT * FROM Users;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllVenues` ()   BEGIN
    SELECT * FROM Venues;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetEventsByOrganizer` (IN `p_OrganizerName` VARCHAR(100))   BEGIN
    SELECT E.EventName, E.EventDescription, E.EventLocation
    FROM Events AS E
    INNER JOIN Users AS U ON E.OrganizerID = U.UserID
    WHERE CONCAT(U.FirstName, ' ', U.LastName) = p_OrganizerName;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertAccessibility` (IN `p_EventID` INT, IN `p_AccessibilityFeatures` TEXT, IN `p_SpecialRequests` TEXT)   BEGIN
    INSERT INTO Accessibility (EventID, AccessibilityFeatures, SpecialRequests)
    VALUES (p_EventID, p_AccessibilityFeatures, p_SpecialRequests);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertEvent` (IN `p_EventName` VARCHAR(100), IN `p_EventDescription` TEXT, IN `p_EventDateTime` DATETIME, IN `p_EventLocation` VARCHAR(200), IN `p_OrganizerID` INT)   BEGIN
    INSERT INTO Events (EventName, EventDescription, EventDateTime, EventLocation, OrganizerID)
    VALUES (p_EventName, p_EventDescription, p_EventDateTime, p_EventLocation, p_OrganizerID);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertPayment` (IN `p_TransactionID` INT, IN `p_PaymentMethod` VARCHAR(50), IN `p_BillingInformation` TEXT, IN `p_PaymentConfirmation` VARCHAR(100))   BEGIN
    INSERT INTO Payments (TransactionID, PaymentMethod, BillingInformation, PaymentConfirmation)
    VALUES (p_TransactionID, p_PaymentMethod, p_BillingInformation, p_PaymentConfirmation);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertTicketType` (IN `p_TypeName` VARCHAR(50), IN `p_Price` DECIMAL(10,2), IN `p_Availability` INT, IN `p_SalesStartDate` DATETIME, IN `p_SalesEndDate` DATETIME, IN `p_EventID` INT)   BEGIN
    INSERT INTO TicketTypes (TypeName, Price, Availability, SalesStartDate, SalesEndDate, EventID)
    VALUES (p_TypeName, p_Price, p_Availability, p_SalesStartDate, p_SalesEndDate, p_EventID);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertUser` (IN `p_userID` INT, IN `p_firstName` VARCHAR(50), IN `p_lastName` VARCHAR(50), IN `p_email` VARCHAR(100), IN `p_password` VARCHAR(100), IN `p_userRole` VARCHAR(20))   BEGIN
    INSERT INTO Users (UserID, FirstName, LastName, Email, Password, UserRole)
    VALUES (p_userID, p_firstName, p_lastName, p_email, p_password, p_userRole);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertVenue` (IN `p_VenueName` VARCHAR(100), IN `p_VenueAddress` VARCHAR(200), IN `p_VenueCapacity` INT, IN `p_VenueDescription` TEXT)   BEGIN
    INSERT INTO Venues (VenueName, VenueAddress, VenueCapacity, VenueDescription)
    VALUES (p_VenueName, p_VenueAddress, p_VenueCapacity, p_VenueDescription);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateEventInfo` (IN `p_EventID` INT, IN `p_EventName` VARCHAR(100), IN `p_EventDescription` TEXT, IN `p_EventDateTime` DATETIME, IN `p_EventLocation` VARCHAR(200))   BEGIN
    UPDATE Events
    SET EventName = p_EventName,
        EventDescription = p_EventDescription,
        EventDateTime = p_EventDateTime,
        EventLocation = p_EventLocation
    WHERE EventID = p_EventID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateEventLocation` (IN `p_EventID` INT, IN `p_NewLocation` VARCHAR(200))   BEGIN
    UPDATE Events
    SET EventLocation = p_NewLocation
    WHERE EventID = p_EventID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `accessibility`
--

CREATE TABLE `accessibility` (
  `AccessibilityID` int(11) NOT NULL,
  `EventID` int(11) DEFAULT NULL,
  `AccessibilityFeatures` text DEFAULT NULL,
  `SpecialRequests` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accessibility`
--

INSERT INTO `accessibility` (`AccessibilityID`, `EventID`, `AccessibilityFeatures`, `SpecialRequests`) VALUES
(19, 5, 'Wheelchair accessible, Sign language interpreters available', 'None'),
(20, 6, 'Wheelchair accessible', 'Please provide braille materials for blind attendees.'),
(21, 5, 'Wheelchair accessible, Hearing loop', 'Dietary restrictions: Vegetarian meals required.');

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_users`
-- (See below for the actual view)
--
CREATE TABLE `all_users` (
`UserID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`Email` varchar(100)
,`UserRole` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `EventID` int(11) NOT NULL,
  `EventName` varchar(100) DEFAULT NULL,
  `EventDescription` text DEFAULT NULL,
  `EventDateTime` datetime DEFAULT NULL,
  `EventLocation` varchar(200) DEFAULT NULL,
  `OrganizerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`EventID`, `EventName`, `EventDescription`, `EventDateTime`, `EventLocation`, `OrganizerID`) VALUES
(4, 'Summer Music Festival', 'A three-day music festival with top artists.', '2023-07-21 18:00:00', 'Central Park', 1),
(5, 'Tech Conference', 'A conference on the latest technology trends.', '2023-08-15 09:00:00', 'gakenke city', 1),
(6, 'agapuruku', 'An evening of fundraising for a noble cause.', '2023-09-10 19:30:00', 'Grand Ballroom', 2);

--
-- Triggers `events`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteEvent` AFTER DELETE ON `events` FOR EACH ROW BEGIN
        INSERT INTO EventDeletionLog (EventID, EventName, DeletedDateTime)
    VALUES (OLD.EventID, OLD.EventName, NOW());
    
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertEvent` AFTER INSERT ON `events` FOR EACH ROW BEGIN
    
    INSERT INTO EventLog (EventName, EventDescription, EventDateTime, EventLocation, LogDateTime)
    VALUES (NEW.EventName, NEW.EventDescription, NEW.EventDateTime, NEW.EventLocation, NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateEvent` AFTER UPDATE ON `events` FOR EACH ROW BEGIN
               INSERT INTO EventHistory (EventID, EventName, EventDescription, UpdatedDateTime)
    VALUES (NEW.EventID, NEW.EventName, NEW.EventDescription, NOW());
        
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `eventticketing`
-- (See below for the actual view)
--
CREATE TABLE `eventticketing` (
`FirstName` varchar(50)
,`LastName` varchar(50)
,`Email` varchar(100)
,`UserRole` varchar(20)
,`EventName` varchar(100)
,`EventDescription` text
,`EventDateTime` datetime
,`EventLocation` varchar(200)
,`TypeName` varchar(50)
,`Price` decimal(10,2)
,`Availability` int(11)
,`SalesStartDate` datetime
,`SalesEndDate` datetime
,`TransactionDateTime` datetime
,`TicketQuantity` int(11)
,`TotalAmount` decimal(10,2)
,`PaymentStatus` varchar(20)
,`VenueName` varchar(100)
,`VenueAddress` varchar(200)
,`VenueCapacity` int(11)
,`VenueDescription` text
,`AccessibilityFeatures` text
,`SpecialRequests` text
);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `PaymentID` int(11) NOT NULL,
  `TransactionID` int(11) DEFAULT NULL,
  `PaymentMethod` varchar(50) DEFAULT NULL,
  `BillingInformation` text DEFAULT NULL,
  `PaymentConfirmation` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`PaymentID`, `TransactionID`, `PaymentMethod`, `BillingInformation`, `PaymentConfirmation`) VALUES
(16, 10, 'Credit Card', 'John Doe, 1234-5678-9012-3456, 05/25, 123', 'payment123'),
(17, 12, 'PayPal', 'Alice Smith, alice.smith@email.com', 'payment456'),
(18, 11, 'Credit Card', 'Bob Johnson, 9876-5432-1098-7654, 09/27, 456', 'payment789');

-- --------------------------------------------------------

--
-- Table structure for table `tickettypes`
--

CREATE TABLE `tickettypes` (
  `TicketTypeID` int(11) NOT NULL,
  `TypeName` varchar(50) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `Availability` int(11) DEFAULT NULL,
  `SalesStartDate` datetime DEFAULT NULL,
  `SalesEndDate` datetime DEFAULT NULL,
  `EventID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tickettypes`
--

INSERT INTO `tickettypes` (`TicketTypeID`, `TypeName`, `Price`, `Availability`, `SalesStartDate`, `SalesEndDate`, `EventID`) VALUES
(7, 'General Admission', '50.00', 500, '2023-07-01 00:00:00', '2023-07-20 23:59:59', 5),
(8, 'VIP Pass', '150.00', 100, '2023-07-01 00:00:00', '2023-07-20 23:59:59', 5),
(9, 'Standard', '200.00', 300, '2023-07-01 00:00:00', '2023-08-10 23:59:59', 6);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `TransactionID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `TicketTypeID` int(11) DEFAULT NULL,
  `TransactionDateTime` datetime DEFAULT NULL,
  `TicketQuantity` int(11) DEFAULT NULL,
  `TotalAmount` decimal(10,2) DEFAULT NULL,
  `PaymentStatus` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`TransactionID`, `UserID`, `TicketTypeID`, `TransactionDateTime`, `TicketQuantity`, `TotalAmount`, `PaymentStatus`) VALUES
(10, 1, 9, '2023-07-10 14:30:00', 5, '100.00', 'completed'),
(11, 2, 8, '2023-08-01 10:15:00', 1, '200.00', 'completed'),
(12, 3, 7, '2023-09-05 20:45:00', 4, '600.00', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `UserRole` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `FirstName`, `LastName`, `Email`, `Password`, `UserRole`) VALUES
(1, 'John', 'Doe', 'kalisa.emmy@email.com', 'hashed_password', 'organizer'),
(2, 'Alice', 'Smith', 'alice.smith@email.com', 'hashed_password', 'attendee'),
(3, 'Bob', 'Johnson', 'bob.johnson@email.com', 'hashed_password', 'admin'),
(23, 'fabby', 'lola', 'fabby.lola@email.com', 'karuganda', 'organizer');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteUser` AFTER DELETE ON `users` FOR EACH ROW BEGIN
    INSERT INTO UserDeletionLog (UserID, DeletedDateTime)
    VALUES (OLD.UserID, NOW());
    
    
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertUser` AFTER INSERT ON `users` FOR EACH ROW BEGIN
   INSERT INTO EmailQueue (RecipientEmail, Subject, Message, SendDateTime)
    VALUES (NEW.Email, 'Welcome to Our Events Ticketing System', 'Thank you for joining our system!', NOW());
    
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateUser` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
        INSERT INTO UserActivityLog (UserID, Action, UpdateDateTime)
    VALUES (NEW.UserID, 'Profile Updated', NOW());
    
  
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `venues`
--

CREATE TABLE `venues` (
  `VenueID` int(11) NOT NULL,
  `VenueName` varchar(100) DEFAULT NULL,
  `VenueAddress` varchar(200) DEFAULT NULL,
  `VenueCapacity` int(11) DEFAULT NULL,
  `VenueDescription` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `venues`
--

INSERT INTO `venues` (`VenueID`, `VenueName`, `VenueAddress`, `VenueCapacity`, `VenueDescription`) VALUES
(13, 'Central Park', '123 Park Ave, Cityville', 10000, 'Open-air venue with natural beauty.'),
(14, ' Convention Center', '456 Conference St, Townsville', 5000, 'Modern convention facility.'),
(15, ' Grand Ballroom', '789 Gala Blvd, Charitytown', 800, 'Elegant ballroom for special events.');

-- --------------------------------------------------------

--
-- Structure for view `all_users`
--
DROP TABLE IF EXISTS `all_users`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_users`  AS SELECT `users`.`UserID` AS `UserID`, `users`.`FirstName` AS `FirstName`, `users`.`LastName` AS `LastName`, `users`.`Email` AS `Email`, `users`.`UserRole` AS `UserRole` FROM `users``users`  ;

-- --------------------------------------------------------

--
-- Structure for view `eventticketing`
--
DROP TABLE IF EXISTS `eventticketing`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `eventticketing`  AS SELECT `users`.`FirstName` AS `FirstName`, `users`.`LastName` AS `LastName`, `users`.`Email` AS `Email`, `users`.`UserRole` AS `UserRole`, `events`.`EventName` AS `EventName`, `events`.`EventDescription` AS `EventDescription`, `events`.`EventDateTime` AS `EventDateTime`, `events`.`EventLocation` AS `EventLocation`, `tickettypes`.`TypeName` AS `TypeName`, `tickettypes`.`Price` AS `Price`, `tickettypes`.`Availability` AS `Availability`, `tickettypes`.`SalesStartDate` AS `SalesStartDate`, `tickettypes`.`SalesEndDate` AS `SalesEndDate`, `transactions`.`TransactionDateTime` AS `TransactionDateTime`, `transactions`.`TicketQuantity` AS `TicketQuantity`, `transactions`.`TotalAmount` AS `TotalAmount`, `transactions`.`PaymentStatus` AS `PaymentStatus`, `venues`.`VenueName` AS `VenueName`, `venues`.`VenueAddress` AS `VenueAddress`, `venues`.`VenueCapacity` AS `VenueCapacity`, `venues`.`VenueDescription` AS `VenueDescription`, `accessibility`.`AccessibilityFeatures` AS `AccessibilityFeatures`, `accessibility`.`SpecialRequests` AS `SpecialRequests` FROM (((((`users` join `events`) join `tickettypes`) join `transactions`) join `venues`) join `accessibility`)  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accessibility`
--
ALTER TABLE `accessibility`
  ADD PRIMARY KEY (`AccessibilityID`),
  ADD KEY `EventID` (`EventID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`EventID`),
  ADD KEY `OrganizerID` (`OrganizerID`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`PaymentID`),
  ADD UNIQUE KEY `TransactionID` (`TransactionID`);

--
-- Indexes for table `tickettypes`
--
ALTER TABLE `tickettypes`
  ADD PRIMARY KEY (`TicketTypeID`),
  ADD KEY `EventID` (`EventID`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`TransactionID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `TicketTypeID` (`TicketTypeID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `venues`
--
ALTER TABLE `venues`
  ADD PRIMARY KEY (`VenueID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accessibility`
--
ALTER TABLE `accessibility`
  ADD CONSTRAINT `accessibility_ibfk_1` FOREIGN KEY (`EventID`) REFERENCES `events` (`EventID`);

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`OrganizerID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`TransactionID`) REFERENCES `transactions` (`TransactionID`);

--
-- Constraints for table `tickettypes`
--
ALTER TABLE `tickettypes`
  ADD CONSTRAINT `tickettypes_ibfk_1` FOREIGN KEY (`EventID`) REFERENCES `events` (`EventID`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`),
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`TicketTypeID`) REFERENCES `tickettypes` (`TicketTypeID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
