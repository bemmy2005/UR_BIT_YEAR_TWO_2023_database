-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 11:28 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gatetem_yves_222002611`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deletereservation`(IN reservation_id INT)
BEGIN
DELETE FROM reservation
WHERE  reservation_id = reservation_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deletereservations`(IN reservation_id INT)
BEGIN
DELETE FROM reservations
WHERE  reservation_id = reservation_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `deletestaffrecord`(IN staff_id_param INT)
DELETE FROM staff
WHERE staff_id = staff_id_param;$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayitemsdata`()
BEGIN
SELECT* FROM items;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displaymenudata`()
BEGIN
SELECT* FROM menu;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayordersdata`()
BEGIN
SELECT* FROM orders;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayreservationsdata`()
BEGIN
SELECT* FROM reservations;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayrestaurantdata`()
BEGIN
SELECT* FROM restaurant;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayreviewsdata`()
BEGIN
SELECT* FROM reviews;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displaystaffdata`()
BEGIN
SELECT* FROM staff;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayusersdata`()
BEGIN
SELECT* FROM users;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertcustomers`(
IN First_name varchar(100),
IN Last_name varchar(100),
IN Email varchar(100),
IN Phone varchar(100),
IN Address varchar(100) 
)
BEGIN
INSERT INTO customers (first_name, last_name, email, phone, address)
VALUES
(customers_first_name, customers_last_name, customers_email, customers_phone, customers_address);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Inserthotel`(
IN Name varchar(100),
IN Address varchar(100),
IN City varchar(100),
IN Country varchar(100),
IN Phone varchar(100),
IN Email varchar(100)
)
BEGIN
INSERT INTO hotel (name, address, city, country, phone, email)
VALUES
(hotel_name, hotel_address, hotel_city, hotel_country, hotel_phone, hotel_email);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertitems`(
IN items_Quantity varchar(100),
IN items_Menu_id int,
IN items_Order_id int
)
BEGIN 
INSERT INTO items (quality, order_id, menu_id)
VALUES
(items_qaulity, items_order_id, items_menu_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertmenu`(
IN menu_name varchar(100),
IN menu_description varchar(100),
IN menu_price varchar(100),
IN menu_category varchar(100),
IN menu_restaurant_id int
)
BEGIN
INSERT INTO menu  (name, description, price, category, restaurant_id)
VALUES
(menu_name, menu_description, menu_price, menu_category, menu_restaurant_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertorders`(
IN orders_order_date varchar(100),
IN orders_total_amount varchar(100),
IN orders_status varchar(100),
IN orders_restaurant_id int,
IN orders_user_id int
)
BEGIN
INSERT INTO orders (order_date, total_amount, status, restaurant_id, user_id)
VALUES
(orders_order_date, orders_total_amount, orders_status, orders_restaurant_id, orders_user_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertreservations`(
IN reservations_Reservation_date varchar(100),
IN reservations_Reservation_time varchar(100),
IN reservations_Number_of_guests varchar(100),
IN reservations_Restaurant_id int,
IN reservations_User_id int
)
BEGIN
INSERT INTO reservations (reservation_date,reservation_time,number_of_guests,restaurant_id)
VALUES
(reservations_reservation_date, reservations_reservation_time, reservations_number_of_guests, reservations_restaurant_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertrestaurant`(
IN restaurant_name varchar(100),
IN restaurant_description varchar(100),
IN restaurant_address varchar(100),
IN restaurant_contact_number varchar(100)
)
BEGIN
INSERT INTO restaurant (name, description, address, contact_number)
VALUES
(restaurant_name, restaurant_description, restaurant_address, restaurant_contact_number);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertreviews`(
IN reviews_Rating varchar(100),
IN reviews_Review_text varchar(100),
IN reviews_Review_date varchar(100),
IN reviews_Restaurant_id int,
IN reviews_User_id int
)
BEGIN 
INSERT INTO reviews (rating, review_text, review_date, restaurant_id, user_id)
VALUES
(reviews_rating, reviews_review_text, reviews_review_date, reviews_restaurant_id, reviews_user_id); 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertrooms`(
IN Room_type varchar(100),
IN Price_per_night int,
IN Is_available varchar(100),
IN Hotel_id int
)
BEGIN
INSERT INTO rooms (room_type, price_per_night, is_available, hotel_id)
VALUES
(rooms_room_type, rooms_price_per_night, rooms_is_available, rooms_hotel_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertstaff`(
IN staff_Name varchar(100),
IN staff_Role varchar(100),
IN staff_Contact_number varchar(100),
IN staff_Email varchar(100),
IN staff_Restaurant_id int
)
BEGIN
INSERT INTO staff (name, role, contact_number, email, restaurant_id)
VALUES
(staff_name, staff_role, staff_contact_number, staff_email, staff_restaurant_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertusers`(
IN users_username varchar(100),
IN users_email varchar(100),
IN users_password varchar(100),
IN users_role varchar(100)
)
BEGIN
INSERT INTO users (username, email, password, role)
VALUES
(users_username, users_email, users_password, users_role);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updaterestaurant`(
IN t_restaurant_id int,
IN t_newname varchar (100), 
IN t_description varchar(100),
IN t_address varchar(100),
IN t_newcontact_number varchar (100)
)
BEGIN
UPDATE restaurant
SET 
name =t_newname,
description = t_newdescription,
address = t_newaddress,
contact_number =t_newcontact_number
WHERE
restaurant_id = t_restaurant_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateusers`(
IN t_user_id INT,
IN t_newemail VARCHAR(100),
IN t_newpassword VARCHAR(100),
IN t_newrole VARCHAR(100)
)
BEGIN
UPDATE users
SET
email =t_newemail,
password =t_newpassword, 
role=t_newrole
WHERE user_id = t_user_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `viewUsersOrders`(IN user_id INT)
BEGIN
SELECT order_id, order_date, total_amount
FROM orders
WHERE user_id = user_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_itemsview`
--
CREATE TABLE IF NOT EXISTS `insert_itemsview` (
`Item_id` int(11)
,`Quantity` varchar(100)
,`Menu_id` int(11)
,`Order_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_menuview`
--
CREATE TABLE IF NOT EXISTS `insert_menuview` (
`menu_id` int(11)
,`Name` varchar(100)
,`Description` varchar(100)
,`Price` varchar(100)
,`Category` varchar(100)
,`Restaurant_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_ordersview`
--
CREATE TABLE IF NOT EXISTS `insert_ordersview` (
`order_id` int(11)
,`order_date` varchar(100)
,`total_amount` varchar(100)
,`status` varchar(100)
,`restaurant_id` int(11)
,`user_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_reservationsview`
--
CREATE TABLE IF NOT EXISTS `insert_reservationsview` (
`reservation_id` int(11)
,`reservation_date` varchar(100)
,`reservation_time` varchar(100)
,`number_of_guests` varchar(100)
,`restaurant_id` int(11)
,`user_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_restaurantview`
--
CREATE TABLE IF NOT EXISTS `insert_restaurantview` (
`restaurant_id` int(11)
,`Name` varchar(100)
,`Description` varchar(100)
,`Address` varchar(100)
,`Contact_number` varchar(100)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_reviewview`
--
CREATE TABLE IF NOT EXISTS `insert_reviewview` (
`review_id` int(11)
,`rating` varchar(100)
,`review_text` varchar(100)
,`review_date` varchar(100)
,`restaurant_id` int(11)
,`user_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_staffview`
--
CREATE TABLE IF NOT EXISTS `insert_staffview` (
`staff_id` int(11)
,`Name` varchar(100)
,`Role` varchar(100)
,`Contact_number` varchar(100)
,`Email` varchar(100)
,`Restaurant_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_usersview`
--
CREATE TABLE IF NOT EXISTS `insert_usersview` (
`user_id` int(11)
,`username` varchar(100)
,`Email` varchar(100)
,`Password` varchar(100)
,`Role` varchar(100)
);
-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `Item_id` int(11) NOT NULL AUTO_INCREMENT,
  `Quantity` varchar(100) NOT NULL,
  `Menu_id` int(11) DEFAULT NULL,
  `Order_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`Item_id`, `Quantity`, `Menu_id`, `Order_id`) VALUES
(1, 'high', 76, 134),
(2, 'medium', 79, 135);

-- --------------------------------------------------------

--
-- Stand-in structure for view `items_view`
--
CREATE TABLE IF NOT EXISTS `items_view` (
`Item_id` int(11)
,`Quantity` varchar(100)
,`Menu_id` int(11)
,`Order_id` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Price` varchar(100) NOT NULL,
  `Category` varchar(100) NOT NULL,
  `Restaurant_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `Name`, `Description`, `Price`, `Category`, `Restaurant_id`) VALUES
(1, 'dish 1', 'description for dish 1', '1500', 'main course', 1),
(2, 'dish 2', 'description for dish 2', '3000', 'appetizer', 1);

--
-- Triggers `menu`
--
DROP TRIGGER IF EXISTS `AfterInsertmenu`;
DELIMITER //
CREATE TRIGGER `AfterInsertmenu` AFTER INSERT ON `menu`
 FOR EACH ROW BEGIN
INSERT INTO menu_audit(menu_id,action,action_date)
VALUES
(NEW.menu_id,'INSERT',NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `menu_view`
--
CREATE TABLE IF NOT EXISTS `menu_view` (
`menu_id` int(11)
,`Name` varchar(100)
,`Description` varchar(100)
,`Price` varchar(100)
,`Category` varchar(100)
,`Restaurant_id` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_date` varchar(100) NOT NULL,
  `total_amount` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `restaurant_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_date`, `total_amount`, `status`, `restaurant_id`, `user_id`) VALUES
(1, '023-08-11', '1000', 'completed', 1, 123),
(2, '023-08-12', '7500', 'processing', 1, 125);

--
-- Triggers `orders`
--
DROP TRIGGER IF EXISTS `AfterUpdateorders`;
DELIMITER //
CREATE TRIGGER `AfterUpdateorders` AFTER INSERT ON `orders`
 FOR EACH ROW BEGIN
INSERT INTO orders_audit(order_id,action,action_date)
VALUES
(NEW. order_id,'UPDATE',NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `orders_view`
--
CREATE TABLE IF NOT EXISTS `orders_view` (
`order_id` int(11)
,`order_date` varchar(100)
,`total_amount` varchar(100)
,`status` varchar(100)
,`restaurant_id` int(11)
,`user_id` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE IF NOT EXISTS `reservations` (
  `reservation_id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_date` varchar(100) NOT NULL,
  `reservation_time` varchar(100) NOT NULL,
  `number_of_guests` varchar(100) NOT NULL,
  `restaurant_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`reservation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `reservation_view`
--
CREATE TABLE IF NOT EXISTS `reservation_view` (
`reservation_id` int(11)
,`user_id` int(11)
,`restaurant_id` int(11)
,`reservation_date` varchar(100)
,`number_of_guests` varchar(100)
,`total_price` double
);
-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE IF NOT EXISTS `restaurant` (
  `restaurant_id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Contact_number` varchar(100) NOT NULL,
  PRIMARY KEY (`restaurant_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`restaurant_id`, `Name`, `Description`, `Address`, `Contact_number`) VALUES
(1, 'newsolution', 'a great place to dinner out', 'huye cumpus', '0788890765');

--
-- Triggers `restaurant`
--
DROP TRIGGER IF EXISTS `AfterDeleterestaurant`;
DELIMITER //
CREATE TRIGGER `AfterDeleterestaurant` AFTER DELETE ON `restaurant`
 FOR EACH ROW BEGIN
INSERT INTO restaurant_audit(restaurant_id,action,action_date)
VALUES
(OLD. restaurant_id,'DELETE',NOW());
END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `AfterUpdaterestaurant`;
DELIMITER //
CREATE TRIGGER `AfterUpdaterestaurant` AFTER UPDATE ON `restaurant`
 FOR EACH ROW BEGIN
INSERT INTO restaurant_audit(restaurant_id,action,action_date)
VALUES
(NEW. restaurant_id,'UPDATE',NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `restaurant_view`
--
CREATE TABLE IF NOT EXISTS `restaurant_view` (
`restaurant_id` int(11)
,`Name` varchar(100)
,`Description` varchar(100)
,`Address` varchar(100)
,`Contact_number` varchar(100)
);
-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `rating` varchar(100) NOT NULL,
  `review_text` varchar(100) NOT NULL,
  `review_date` varchar(100) NOT NULL,
  `restaurant_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`review_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`review_id`, `rating`, `review_text`, `review_date`, `restaurant_id`, `user_id`) VALUES
(1, '5', 'excellent food and services', '023-09-01', 1, 75),
(2, '4.5', 'great food and atmosphere', '023-08-01', 1, 90);

--
-- Triggers `reviews`
--
DROP TRIGGER IF EXISTS `AfterDeletereviews`;
DELIMITER //
CREATE TRIGGER `AfterDeletereviews` AFTER DELETE ON `reviews`
 FOR EACH ROW BEGIN
INSERT INTO reviews_audit(review_id,action,action_date)
VALUES
(OLD. review_id,'DELETE',NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Role` varchar(100) NOT NULL,
  `Contact_number` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Restaurant_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `Name`, `Role`, `Contact_number`, `Email`, `Restaurant_id`) VALUES
(1, 'aline', 'chef', '0793571208', 'diany@gmail.com', 1),
(2, 'sarah', 'bartender', '0722267830', 'sarah10@gmail.com', 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `staff_view`
--
CREATE TABLE IF NOT EXISTS `staff_view` (
`staff_id` int(11)
,`Name` varchar(100)
,`Role` varchar(100)
,`Contact_number` varchar(100)
,`Email` varchar(100)
,`Restaurant_id` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Role` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `Email`, `Password`, `Role`) VALUES
(2, 'john', 'mjohn123@gmail.com', 'Johnny11!', 'payors');

--
-- Triggers `users`
--
DROP TRIGGER IF EXISTS `AfterInsertusers`;
DELIMITER //
CREATE TRIGGER `AfterInsertusers` AFTER INSERT ON `users`
 FOR EACH ROW BEGIN
INSERT INTO users_audit(user_id,action,action_date)
VALUES
(NEW.user_id,'INSERT',NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `users_view`
--
CREATE TABLE IF NOT EXISTS `users_view` (
`user_id` int(11)
,`username` varchar(100)
,`Email` varchar(100)
,`Password` varchar(100)
,`Role` varchar(100)
);
-- --------------------------------------------------------

--
-- Structure for view `insert_itemsview`
--
DROP TABLE IF EXISTS `insert_itemsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_itemsview` AS select `items`.`Item_id` AS `Item_id`,`items`.`Quantity` AS `Quantity`,`items`.`Menu_id` AS `Menu_id`,`items`.`Order_id` AS `Order_id` from `items` where (`items`.`Item_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_menuview`
--
DROP TABLE IF EXISTS `insert_menuview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_menuview` AS select `menu`.`menu_id` AS `menu_id`,`menu`.`Name` AS `Name`,`menu`.`Description` AS `Description`,`menu`.`Price` AS `Price`,`menu`.`Category` AS `Category`,`menu`.`Restaurant_id` AS `Restaurant_id` from `menu` where (`menu`.`menu_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_ordersview`
--
DROP TABLE IF EXISTS `insert_ordersview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_ordersview` AS select `orders`.`order_id` AS `order_id`,`orders`.`order_date` AS `order_date`,`orders`.`total_amount` AS `total_amount`,`orders`.`status` AS `status`,`orders`.`restaurant_id` AS `restaurant_id`,`orders`.`user_id` AS `user_id` from `orders` where (`orders`.`order_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_reservationsview`
--
DROP TABLE IF EXISTS `insert_reservationsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_reservationsview` AS select `reservations`.`reservation_id` AS `reservation_id`,`reservations`.`reservation_date` AS `reservation_date`,`reservations`.`reservation_time` AS `reservation_time`,`reservations`.`number_of_guests` AS `number_of_guests`,`reservations`.`restaurant_id` AS `restaurant_id`,`reservations`.`user_id` AS `user_id` from `reservations` where (`reservations`.`reservation_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_restaurantview`
--
DROP TABLE IF EXISTS `insert_restaurantview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_restaurantview` AS select `restaurant`.`restaurant_id` AS `restaurant_id`,`restaurant`.`Name` AS `Name`,`restaurant`.`Description` AS `Description`,`restaurant`.`Address` AS `Address`,`restaurant`.`Contact_number` AS `Contact_number` from `restaurant` where (`restaurant`.`restaurant_id` = 1);

-- --------------------------------------------------------

--
-- Structure for view `insert_reviewview`
--
DROP TABLE IF EXISTS `insert_reviewview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_reviewview` AS select `reviews`.`review_id` AS `review_id`,`reviews`.`rating` AS `rating`,`reviews`.`review_text` AS `review_text`,`reviews`.`review_date` AS `review_date`,`reviews`.`restaurant_id` AS `restaurant_id`,`reviews`.`user_id` AS `user_id` from `reviews` where (`reviews`.`review_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_staffview`
--
DROP TABLE IF EXISTS `insert_staffview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_staffview` AS select `staff`.`staff_id` AS `staff_id`,`staff`.`Name` AS `Name`,`staff`.`Role` AS `Role`,`staff`.`Contact_number` AS `Contact_number`,`staff`.`Email` AS `Email`,`staff`.`Restaurant_id` AS `Restaurant_id` from `staff` where (`staff`.`staff_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_usersview`
--
DROP TABLE IF EXISTS `insert_usersview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_usersview` AS select `users`.`user_id` AS `user_id`,`users`.`username` AS `username`,`users`.`Email` AS `Email`,`users`.`Password` AS `Password`,`users`.`Role` AS `Role` from `users` where (`users`.`user_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `items_view`
--
DROP TABLE IF EXISTS `items_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `items_view` AS select `items`.`Item_id` AS `Item_id`,`items`.`Quantity` AS `Quantity`,`items`.`Menu_id` AS `Menu_id`,`items`.`Order_id` AS `Order_id` from `items`;

-- --------------------------------------------------------

--
-- Structure for view `menu_view`
--
DROP TABLE IF EXISTS `menu_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `menu_view` AS select `menu`.`menu_id` AS `menu_id`,`menu`.`Name` AS `Name`,`menu`.`Description` AS `Description`,`menu`.`Price` AS `Price`,`menu`.`Category` AS `Category`,`menu`.`Restaurant_id` AS `Restaurant_id` from `menu`;

-- --------------------------------------------------------

--
-- Structure for view `orders_view`
--
DROP TABLE IF EXISTS `orders_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `orders_view` AS select `orders`.`order_id` AS `order_id`,`orders`.`order_date` AS `order_date`,`orders`.`total_amount` AS `total_amount`,`orders`.`status` AS `status`,`orders`.`restaurant_id` AS `restaurant_id`,`orders`.`user_id` AS `user_id` from `orders`;

-- --------------------------------------------------------

--
-- Structure for view `reservation_view`
--
DROP TABLE IF EXISTS `reservation_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reservation_view` AS select `r`.`reservation_id` AS `reservation_id`,`r`.`user_id` AS `user_id`,`r`.`restaurant_id` AS `restaurant_id`,`r`.`reservation_date` AS `reservation_date`,`r`.`number_of_guests` AS `number_of_guests`,coalesce(sum(`m`.`Price`),0) AS `total_price` from (`reservations` `r` left join `menu` `m` on((`r`.`restaurant_id` = `m`.`Restaurant_id`))) group by `r`.`reservation_id`,`r`.`user_id`,`r`.`restaurant_id`,`r`.`reservation_date`,`r`.`number_of_guests`;

-- --------------------------------------------------------

--
-- Structure for view `restaurant_view`
--
DROP TABLE IF EXISTS `restaurant_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `restaurant_view` AS select `restaurant`.`restaurant_id` AS `restaurant_id`,`restaurant`.`Name` AS `Name`,`restaurant`.`Description` AS `Description`,`restaurant`.`Address` AS `Address`,`restaurant`.`Contact_number` AS `Contact_number` from `restaurant`;

-- --------------------------------------------------------

--
-- Structure for view `staff_view`
--
DROP TABLE IF EXISTS `staff_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `staff_view` AS select `staff`.`staff_id` AS `staff_id`,`staff`.`Name` AS `Name`,`staff`.`Role` AS `Role`,`staff`.`Contact_number` AS `Contact_number`,`staff`.`Email` AS `Email`,`staff`.`Restaurant_id` AS `Restaurant_id` from `staff`;

-- --------------------------------------------------------

--
-- Structure for view `users_view`
--
DROP TABLE IF EXISTS `users_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_view` AS select `users`.`user_id` AS `user_id`,`users`.`username` AS `username`,`users`.`Email` AS `Email`,`users`.`Password` AS `Password`,`users`.`Role` AS `Role` from `users`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
