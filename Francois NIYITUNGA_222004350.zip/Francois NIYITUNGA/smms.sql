-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 08:51 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smms`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CourseWithStudentCount` ()   BEGIN
    SELECT c.courseid, c.coursename, c.credits,
           (SELECT COUNT(*) FROM student s WHERE s.courseid = c.courseid) AS student_count
    FROM course c;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteStudentsByCondition` ()   BEGIN
    DELETE FROM student
    WHERE date_of_birth < '1990-01-01';
    DELETE FROM course
    WHERE courseid NOT IN (SELECT DISTINCT courseid FROM student);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllSMMSData` ()   BEGIN
    SELECT * FROM student;
    SELECT * FROM course;
    SELECT * FROM lecturer;
    SELECT * FROM department;
    SELECT * FROM hod;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateStudentAddress` (IN `student_id` INT, IN `new_address` TEXT)   BEGIN
    UPDATE student
    SET address = new_address
    WHERE Id = student_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `courseid` int(11) NOT NULL,
  `coursename` varchar(255) DEFAULT NULL,
  `credits` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`courseid`, `coursename`, `credits`) VALUES
(101, 'Mathematics', 10);

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_students`
-- (See below for the actual view)
--
CREATE TABLE `delete_students` (
`Id` int(11)
,`name` varchar(255)
,`contact` varchar(15)
,`date_of_birth` date
,`gender` enum('Male','Female','Other')
,`address` text
);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `departmentid` int(11) NOT NULL,
  `departmentname` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`departmentid`, `departmentname`) VALUES
(301, 'Math Department');

-- --------------------------------------------------------

--
-- Table structure for table `hod`
--

CREATE TABLE `hod` (
  `hodid` int(11) NOT NULL,
  `hodname` varchar(255) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `departmentid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hod`
--

INSERT INTO `hod` (`hodid`, `hodname`, `contact`, `email`, `departmentid`) VALUES
(401, 'Prof. Smith', '555-555-5555', 'smith@example.com', 301);

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `lecturerid` int(11) NOT NULL,
  `lecturername` varchar(255) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `courseid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`lecturerid`, `lecturername`, `contact`, `email`, `courseid`) VALUES
(201, 'Jane Smith', '987-654-3210', 'jane@example.com', 101);

--
-- Triggers `lecturer`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteLecturer` AFTER DELETE ON `lecturer` FOR EACH ROW BEGIN
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertLecturer` AFTER INSERT ON `lecturer` FOR EACH ROW BEGIN
 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateLecturer` AFTER UPDATE ON `lecturer` FOR EACH ROW BEGIN
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Id`, `name`, `contact`, `date_of_birth`, `gender`, `address`) VALUES
(1, 'John Doe', '123-456-7890', '2000-01-01', 'Male', '456 Elm St');

--
-- Triggers `student`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteStudent` AFTER DELETE ON `student` FOR EACH ROW BEGIN
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_student_info`
-- (See below for the actual view)
--
CREATE TABLE `update_student_info` (
`Id` int(11)
,`name` varchar(255)
,`contact` varchar(15)
,`date_of_birth` date
,`gender` enum('Male','Female','Other')
,`address` text
);

-- --------------------------------------------------------

--
-- Structure for view `delete_students`
--
DROP TABLE IF EXISTS `delete_students`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `delete_students`  AS SELECT `student`.`Id` AS `Id`, `student`.`name` AS `name`, `student`.`contact` AS `contact`, `student`.`date_of_birth` AS `date_of_birth`, `student`.`gender` AS `gender`, `student`.`address` AS `address` FROM `student` WHERE `student`.`date_of_birth` < '1990-01-01' ;

-- --------------------------------------------------------

--
-- Structure for view `update_student_info`
--
DROP TABLE IF EXISTS `update_student_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_student_info`  AS SELECT `student`.`Id` AS `Id`, `student`.`name` AS `name`, `student`.`contact` AS `contact`, `student`.`date_of_birth` AS `date_of_birth`, `student`.`gender` AS `gender`, `student`.`address` AS `address` FROM `student` WHERE `student`.`date_of_birth` > '2000-01-01' ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`courseid`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`departmentid`);

--
-- Indexes for table `hod`
--
ALTER TABLE `hod`
  ADD PRIMARY KEY (`hodid`),
  ADD KEY `departmentid` (`departmentid`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`lecturerid`),
  ADD KEY `courseid` (`courseid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hod`
--
ALTER TABLE `hod`
  ADD CONSTRAINT `hod_ibfk_1` FOREIGN KEY (`departmentid`) REFERENCES `department` (`departmentid`);

--
-- Constraints for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD CONSTRAINT `lecturer_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `course` (`courseid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
