-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2023 at 01:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete data` (IN `int` INT)   BEGIN
    DELETE FROM customers_table
    WHERE customer-id = customer_id;

    DELETE FROM orders
    WHERE customer_id = customer_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `display data` (IN `int` INT)   SELECT * FROM restaurant_table
UNION
SELECT * FROM orders_table
UNION
SELECT * FROM customers_table
UNION
SELECT * FROM delivery_personneltable
UNION
SELECT * FROM payment_transactionstable$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert data` (IN `int` INT ZEROFILL)   INSERT INTO `customers_table` (`customer-id`, `name`, `email`, `phone`, `address`) VALUES ('1233', 'fabio', 'fff@gg.cm', '0788888', 'butar')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `subquery data` (IN `int` INT)   BEGIN
    SELECT order_id, customer_name, total_amount
    FROM orders_table
    WHERE order_id = order_id;

    SELECT item_name, quantity
    FROM customers_table
    WHERE order_id = order_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update` (IN `int` INT)   BEGIN
    UPDATE customers_table
    SET customer_status = new_status
    WHERE customers_id = customer-id;

    UPDATE orders
    SET order_status = new_status
    WHERE id = order_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customers_table`
--

CREATE TABLE `customers_table` (
  `customer-id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `phone` int(11) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `customers_table`
--

INSERT INTO `customers_table` (`customer-id`, `name`, `email`, `phone`, `address`) VALUES
(12, 'fab', 'shh@gg.cm', 788888, 'butar'),
(1233, 'fabio', 'fff@gg.cm', 788888, 'butar');

--
-- Triggers `customers_table`
--
DELIMITER $$
CREATE TRIGGER `after_delete_customers` AFTER DELETE ON `customers_table` FOR EACH ROW BEGIN
    -- Trigger logic here
    -- You can perform actions or execute SQL statements using the OLD alias
    
    -- Example: Insert a record into a log table after deleting from customers_table
    INSERT INTO customers_log (customer_id, action, timestamp)
    VALUES (customers_table.customer_id, 'Deleted', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `delivery_personneltable`
--

CREATE TABLE `delivery_personneltable` (
  `delivery-person-id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `phone` int(11) NOT NULL,
  `availability` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `delivery_personneltable`
--

INSERT INTO `delivery_personneltable` (`delivery-person-id`, `name`, `email`, `phone`, `availability`) VALUES
(123, 'jess', 'jess@mm.cn', 788888888, 'available');

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_view` (
`order-id` int(11)
,`customer-id` int(11)
,`order-date` date
,`total-amount` int(11)
,`payment-status` text
);

-- --------------------------------------------------------

--
-- Table structure for table `menu_itemstable`
--

CREATE TABLE `menu_itemstable` (
  `item-id` int(11) NOT NULL,
  `name` text NOT NULL,
  `price` int(11) NOT NULL,
  `availability` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Triggers `menu_itemstable`
--
DELIMITER $$
CREATE TRIGGER `after_insert_menu_items` AFTER INSERT ON `menu_itemstable` FOR EACH ROW BEGIN
    -- Trigger logic here
    -- You can perform actions or execute SQL statements using the NEW alias

    -- Example: Update the availability status of the menu item in another table
    UPDATE menu_availability
    SET availability = 'Available'
    WHERE item_id = item_id.item_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_update_menu_items` AFTER UPDATE ON `menu_itemstable` FOR EACH ROW BEGIN
    -- Trigger logic here
    -- You can perform actions or execute SQL statements using the NEW and OLD aliases

    -- Example: Update the availability status of the menu item in another table
    UPDATE menu_availability
    SET availability = 'Available'
    WHERE item_id = customers_table.item_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `orders_table`
--

CREATE TABLE `orders_table` (
  `order-id` int(11) NOT NULL,
  `customer-id` int(11) NOT NULL,
  `order-date` date NOT NULL,
  `total-amount` int(11) NOT NULL,
  `payment-status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders_table`
--

INSERT INTO `orders_table` (`order-id`, `customer-id`, `order-date`, `total-amount`, `payment-status`) VALUES
(12343232, 12, '2023-09-01', 56, 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `payment_transactionstable`
--

CREATE TABLE `payment_transactionstable` (
  `transaction-id` int(11) NOT NULL,
  `transaction-date` date NOT NULL,
  `amount` int(11) NOT NULL,
  `payment-method` text NOT NULL,
  `transaction-status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `payment_transactionstable`
--

INSERT INTO `payment_transactionstable` (`transaction-id`, `transaction-date`, `amount`, `payment-method`, `transaction-status`) VALUES
(123, '2023-09-01', 4, 'visa', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_table`
--

CREATE TABLE `restaurant_table` (
  `Restaurant-id` int(11) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `number` int(11) NOT NULL,
  `cuisine type` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `restaurant_table`
--

INSERT INTO `restaurant_table` (`Restaurant-id`, `name`, `address`, `number`, `cuisine type`) VALUES
(12354432, 'delicius restaurant', 'kn 400 st', 7899999, 'italian');

-- --------------------------------------------------------

--
-- Table structure for table `reviews_table`
--

CREATE TABLE `reviews_table` (
  `review-id` int(11) NOT NULL,
  `customer-id` int(11) NOT NULL,
  `order-id` int(11) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `reviews_table`
--

INSERT INTO `reviews_table` (`review-id`, `customer-id`, `order-id`, `comment`) VALUES
(1, 12, 12343232, 'delicius food and service and i left the tip too!');

-- --------------------------------------------------------

--
-- Stand-in structure for view `show data all`
-- (See below for the actual view)
--
CREATE TABLE `show data all` (
`Restaurant-id` int(11)
,`name` text
,`address` text
,`number` text
,`cuisine type` text
);

-- --------------------------------------------------------

--
-- Structure for view `insert_data_view`
--
DROP TABLE IF EXISTS `insert_data_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_view`  AS SELECT `orders_table`.`order-id` AS `order-id`, `orders_table`.`customer-id` AS `customer-id`, `orders_table`.`order-date` AS `order-date`, `orders_table`.`total-amount` AS `total-amount`, `orders_table`.`payment-status` AS `payment-status` FROM `orders_table` ;

-- --------------------------------------------------------

--
-- Structure for view `show data all`
--
DROP TABLE IF EXISTS `show data all`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `show data all`  AS SELECT `restaurant_table`.`Restaurant-id` AS `Restaurant-id`, `restaurant_table`.`name` AS `name`, `restaurant_table`.`address` AS `address`, `restaurant_table`.`number` AS `number`, `restaurant_table`.`cuisine type` AS `cuisine type` FROM `restaurant_table`union select `orders_table`.`order-id` AS `order-id`,`orders_table`.`customer-id` AS `customer-id`,`orders_table`.`order-date` AS `order-date`,`orders_table`.`total-amount` AS `total-amount`,`orders_table`.`payment-status` AS `payment-status` from `orders_table` union select `customers_table`.`customer-id` AS `customer-id`,`customers_table`.`name` AS `name`,`customers_table`.`email` AS `email`,`customers_table`.`phone` AS `phone`,`customers_table`.`address` AS `address` from `customers_table` union select `delivery_personneltable`.`delivery-person-id` AS `delivery-person-id`,`delivery_personneltable`.`name` AS `name`,`delivery_personneltable`.`email` AS `email`,`delivery_personneltable`.`phone` AS `phone`,`delivery_personneltable`.`availability` AS `availability` from `delivery_personneltable` union select `payment_transactionstable`.`transaction-id` AS `transaction-id`,`payment_transactionstable`.`transaction-date` AS `transaction-date`,`payment_transactionstable`.`amount` AS `amount`,`payment_transactionstable`.`payment-method` AS `payment-method`,`payment_transactionstable`.`transaction-status` AS `transaction-status` from `payment_transactionstable`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers_table`
--
ALTER TABLE `customers_table`
  ADD PRIMARY KEY (`customer-id`);

--
-- Indexes for table `delivery_personneltable`
--
ALTER TABLE `delivery_personneltable`
  ADD PRIMARY KEY (`delivery-person-id`);

--
-- Indexes for table `orders_table`
--
ALTER TABLE `orders_table`
  ADD PRIMARY KEY (`order-id`),
  ADD KEY `customer-id` (`customer-id`);

--
-- Indexes for table `payment_transactionstable`
--
ALTER TABLE `payment_transactionstable`
  ADD PRIMARY KEY (`transaction-id`);

--
-- Indexes for table `restaurant_table`
--
ALTER TABLE `restaurant_table`
  ADD PRIMARY KEY (`Restaurant-id`);

--
-- Indexes for table `reviews_table`
--
ALTER TABLE `reviews_table`
  ADD PRIMARY KEY (`review-id`),
  ADD KEY `customer-id` (`customer-id`),
  ADD KEY `order-id` (`order-id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders_table`
--
ALTER TABLE `orders_table`
  ADD CONSTRAINT `foreign key` FOREIGN KEY (`customer-id`) REFERENCES `customers_table` (`customer-id`);

--
-- Constraints for table `reviews_table`
--
ALTER TABLE `reviews_table`
  ADD CONSTRAINT `reviews_table_ibfk_1` FOREIGN KEY (`customer-id`) REFERENCES `customers_table` (`customer-id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `reviews_table_ibfk_2` FOREIGN KEY (`order-id`) REFERENCES `orders_table` (`order-id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
