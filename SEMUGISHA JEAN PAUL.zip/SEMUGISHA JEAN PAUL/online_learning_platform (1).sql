-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 05:55 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_learning_platform`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `course`
-- (See below for the actual view)
--
CREATE TABLE `course` (
`course_id` int(11)
,`course_name` varchar(100)
,`creadit_hours` int(11)
,`lecturer_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `creadit_hours` int(11) DEFAULT NULL,
  `lecturer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `creadit_hours`, `lecturer_id`) VALUES
(1, 'economics', 15, 212),
(2, 'computer sciences', 20, 214),
(3, 'business functions', 15, 213);

--
-- Triggers `courses`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteCourse` AFTER DELETE ON `courses` FOR EACH ROW BEGIN
    UPDATE lecturers
    SET course_count = course_count - 1
    WHERE lecturer_id = OLD.lecturer_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateCourse` AFTER UPDATE ON `courses` FOR EACH ROW BEGIN
    UPDATE courses
    SET modified_timestamp = NOW()
    WHERE course_id = NEW.course_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_students`
-- (See below for the actual view)
--
CREATE TABLE `delete_students` (
`student_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`age` int(11)
,`email` varchar(100)
,`enrollement_data` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `economics_lecturers`
-- (See below for the actual view)
--
CREATE TABLE `economics_lecturers` (
`lecturer_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`email` varchar(70)
,`specialization` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `exam_id` int(11) NOT NULL,
  `exam_name` varchar(50) NOT NULL,
  `exam_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`exam_id`, `exam_name`, `exam_date`) VALUES
(1, 'computer sciences', '2023-05-12'),
(2, 'economics', '2023-06-12');

-- --------------------------------------------------------

--
-- Stand-in structure for view `exams`
-- (See below for the actual view)
--
CREATE TABLE `exams` (
`exam_id` int(11)
,`exam_name` varchar(50)
,`exam_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_courses`
-- (See below for the actual view)
--
CREATE TABLE `insert_courses` (
`course_id` binary(0)
,`lecturer_id` binary(0)
,`course_name` binary(0)
,`credit_hours` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_exam`
-- (See below for the actual view)
--
CREATE TABLE `insert_exam` (
`exam_id` binary(0)
,`exam_name` binary(0)
,`exam_date` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_lecturers`
-- (See below for the actual view)
--
CREATE TABLE `insert_lecturers` (
`lecturer_id` binary(0)
,`first_name` binary(0)
,`last_name` binary(0)
,`email` binary(0)
,`specialization` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_students`
-- (See below for the actual view)
--
CREATE TABLE `insert_students` (
`student_id` binary(0)
,`first_name` binary(0)
,`last_name` binary(0)
,`age` binary(0)
,`email` binary(0)
,`enrollment_date` binary(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `lecturer`
-- (See below for the actual view)
--
CREATE TABLE `lecturer` (
`lecturer_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`email` varchar(70)
,`specialization` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `lecturers`
--

CREATE TABLE `lecturers` (
  `lecturer_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `specialization` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lecturers`
--

INSERT INTO `lecturers` (`lecturer_id`, `first_name`, `last_name`, `email`, `specialization`) VALUES
(212, 'evariste', 'manirakiza', 'evariste@gmail.com', 'ecenomics'),
(213, 'noel', 'muhire', 'noelmuhire@gmail.com', 'business functions'),
(214, 'clement', 'irakoze', 'irakozeclementgmail.com', 'computer sciences');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `enrollement_data` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `first_name`, `last_name`, `age`, `email`, `enrollement_data`) VALUES
(112, 'UpdatedBella', 'UpdatedIshimwe', 21, 'updatedbella@gmail.com', NULL),
(113, 'UpdatedDidie', 'UpdatedNguweneza', 24, 'updateddidie@gmail.com', NULL),
(114, 'UpdatedGad', 'UpdatedRuremesha', 22, 'updatedgad@gmail.com', NULL);

--
-- Triggers `students`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteStudent` AFTER DELETE ON `students` FOR EACH ROW BEGIN
    INSERT INTO deleted_student_log(student_id, first_name, last_name, age, email, deleted_date)
    VALUES (OLD.student_id, OLD.first_name, OLD.last_name, OLD.age, OLD.email, NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertStudent` AFTER INSERT ON `students` FOR EACH ROW BEGIN
    INSERT INTO student_log(student_id, action, action_date)
    VALUES (NEW.student_id, 'INSERT', NOW());
    
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateStudent` AFTER UPDATE ON `students` FOR EACH ROW BEGIN
    INSERT INTO student_log(student_id, action, action_date)
    VALUES (NEW.student_id, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_students`
-- (See below for the actual view)
--
CREATE TABLE `update_students` (
`student_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`age` int(11)
,`email` varchar(100)
,`enrollement_data` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_students`
-- (See below for the actual view)
--
CREATE TABLE `view_students` (
`student_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`age` int(11)
,`email` varchar(100)
,`enrollement_data` date
);

-- --------------------------------------------------------

--
-- Structure for view `course`
--
DROP TABLE IF EXISTS `course`;

CREATE ALGORITHM=UNDEFINED DEFINER=`JEANPAUL_SEMUGISHA_222009902`@`localhost` SQL SECURITY DEFINER VIEW `course`  AS SELECT `courses`.`course_id` AS `course_id`, `courses`.`course_name` AS `course_name`, `courses`.`creadit_hours` AS `creadit_hours`, `courses`.`lecturer_id` AS `lecturer_id` FROM `courses` ;

-- --------------------------------------------------------

--
-- Structure for view `delete_students`
--
DROP TABLE IF EXISTS `delete_students`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `delete_students`  AS SELECT `students`.`student_id` AS `student_id`, `students`.`first_name` AS `first_name`, `students`.`last_name` AS `last_name`, `students`.`age` AS `age`, `students`.`email` AS `email`, `students`.`enrollement_data` AS `enrollement_data` FROM `students` WHERE `students`.`student_id` = 114 ;

-- --------------------------------------------------------

--
-- Structure for view `economics_lecturers`
--
DROP TABLE IF EXISTS `economics_lecturers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `economics_lecturers`  AS SELECT `lecturers`.`lecturer_id` AS `lecturer_id`, `lecturers`.`first_name` AS `first_name`, `lecturers`.`last_name` AS `last_name`, `lecturers`.`email` AS `email`, `lecturers`.`specialization` AS `specialization` FROM `lecturers` WHERE `lecturers`.`specialization` = 'economics' ;

-- --------------------------------------------------------

--
-- Structure for view `exams`
--
DROP TABLE IF EXISTS `exams`;

CREATE ALGORITHM=UNDEFINED DEFINER=`JEANPAUL_SEMUGISHA_222009902`@`localhost` SQL SECURITY DEFINER VIEW `exams`  AS SELECT `exam`.`exam_id` AS `exam_id`, `exam`.`exam_name` AS `exam_name`, `exam`.`exam_date` AS `exam_date` FROM `exam` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_courses`
--
DROP TABLE IF EXISTS `insert_courses`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_courses`  AS SELECT NULL AS `course_id`, NULL AS `lecturer_id`, NULL AS `course_name`, NULL AS `credit_hours` FROM `courses` WHERE 1 = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_exam`
--
DROP TABLE IF EXISTS `insert_exam`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_exam`  AS SELECT NULL AS `exam_id`, NULL AS `exam_name`, NULL AS `exam_date` FROM `exam` WHERE 1 = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_lecturers`
--
DROP TABLE IF EXISTS `insert_lecturers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_lecturers`  AS SELECT NULL AS `lecturer_id`, NULL AS `first_name`, NULL AS `last_name`, NULL AS `email`, NULL AS `specialization` FROM `lecturers` WHERE 1 = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_students`
--
DROP TABLE IF EXISTS `insert_students`;

CREATE ALGORITHM=UNDEFINED DEFINER=`JEANPAUL_SEMUGISHA_222009902`@`localhost` SQL SECURITY DEFINER VIEW `insert_students`  AS SELECT NULL AS `student_id`, NULL AS `first_name`, NULL AS `last_name`, NULL AS `age`, NULL AS `email`, NULL AS `enrollment_date` FROM `students` WHERE 1 = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `lecturer`
--
DROP TABLE IF EXISTS `lecturer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`JEANPAUL_SEMUGISHA_222009902`@`localhost` SQL SECURITY DEFINER VIEW `lecturer`  AS SELECT `lecturers`.`lecturer_id` AS `lecturer_id`, `lecturers`.`first_name` AS `first_name`, `lecturers`.`last_name` AS `last_name`, `lecturers`.`email` AS `email`, `lecturers`.`specialization` AS `specialization` FROM `lecturers` ;

-- --------------------------------------------------------

--
-- Structure for view `update_students`
--
DROP TABLE IF EXISTS `update_students`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_students`  AS SELECT `students`.`student_id` AS `student_id`, `students`.`first_name` AS `first_name`, `students`.`last_name` AS `last_name`, `students`.`age` AS `age`, `students`.`email` AS `email`, `students`.`enrollement_data` AS `enrollement_data` FROM `students` WHERE `students`.`student_id` = 112 ;

-- --------------------------------------------------------

--
-- Structure for view `view_students`
--
DROP TABLE IF EXISTS `view_students`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_students`  AS SELECT `students`.`student_id` AS `student_id`, `students`.`first_name` AS `first_name`, `students`.`last_name` AS `last_name`, `students`.`age` AS `age`, `students`.`email` AS `email`, `students`.`enrollement_data` AS `enrollement_data` FROM `students` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `lecturer_id` (`lecturer_id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `lecturers`
--
ALTER TABLE `lecturers`
  ADD PRIMARY KEY (`lecturer_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
  MODIFY `exam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lecturers`
--
ALTER TABLE `lecturers`
  MODIFY `lecturer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=215;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`lecturer_id`) REFERENCES `lecturers` (`lecturer_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
