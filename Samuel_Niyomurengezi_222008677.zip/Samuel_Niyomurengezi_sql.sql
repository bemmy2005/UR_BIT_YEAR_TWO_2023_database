-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 16, 2023 at 09:26 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `government_revenue_management_system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CreateAmountAboveAverageView` ()   BEGIN
SET @sql ='CREATE OR REPLACE VIEW RevenueAboveAverageView AS
SELECT r.Revenue_id,r.Amount,r.Revenue_type
FROM Amount r
WHERE r.Amount > (
SELECT AVG(u.Amount)
FROM Revenue u
WHERE u.Amount = r.Amount
);
';
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delete data` (IN `int` INT)   BEGIN
    DELETE FROM customers_table
    WHERE customer-id = customer_id;

    DELETE FROM orders
    WHERE customer_id = customer_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteAddressByUser` (IN `p_Address` VARCHAR(100))   BEGIN
DELETE FROM User
WHERE Address = p_Address;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteRevenueByAmount` (IN `p_Amount` INT)   BEGIN
DELETE FROM Revenue
WHERE Amount = p_Amount;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `display data` (IN `int` INT)   SELECT * FROM restaurant_table
UNION
SELECT * FROM orders_table
UNION
SELECT * FROM customers_table
UNION
SELECT * FROM delivery_personneltable
UNION
SELECT * FROM payment_transactionstable$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_Admin_Data` ()   BEGIN
SET @sql = 'SELECT * FROM Admin';
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_Agent_Data` ()   BEGIN
SELECT * FROM Agent;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_Manager_Data` ()   BEGIN
SELECT * FROM Manager;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_Revenue_Data` ()   BEGIN
SELECT * FROM Revenue;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_Transaction_Data` ()   BEGIN
SELECT * FROM Transaction;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_User_Data` ()   BEGIN
SELECT * FROM User;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert data` (IN `int` INT ZEROFILL)   INSERT INTO `customers_table` (`customer-id`, `name`, `email`, `phone`, `address`) VALUES ('1233', 'fabio', 'fff@gg.cm', '0788888', 'butar')$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insert_Admin` (IN `p_First_name` VARCHAR(50), IN `p_Last_name` VARCHAR(50), IN `p_Gender` VARCHAR(50), IN `p_Address` VARCHAR(60), IN `p_Email` VARCHAR(100), IN `p_Tel_number` INT)   BEGIN
INSERT INTO Admin (First_name,Last_name,Gender,Address,Email,Tel_number)
VALUES (p_First_name,p_Last_name,p_Gender,p_Address,p_Email,p_Tel_number);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insert_Agent` (IN `P_First_name` VARCHAR(60), IN `P_Last_name` VARCHAR(60), IN `P_Email` VARCHAR(100), IN `P_Tel_number` INT, IN `p_Admin_id` INT, IN `p_Manager_id` INT)   BEGIN
INSERT INTO Agent (First_name,Last_name,Email,Tel_number,Admin_id,Manager_id)
VALUES (P_First_name,P_Last_name,P_Email,P_Tel_number,p_Admin_id,p_Manager_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insert_Manager` (IN `P_First_name` VARCHAR(60), IN `P_Last_name` VARCHAR(60), IN `P_Gender` VARCHAR(65), IN `P_Address` VARCHAR(65), IN `P_Specialization` VARCHAR(100))   BEGIN
INSERT INTO Manager (First_name,Last_name,Gender,Address,Specialization)
VALUES (P_First_name,P_Last_name,P_Gender,P_Address,P_Specialization);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insert_Revenue` (IN `p_Amount` INT, IN `p_Revenue_type` VARCHAR(80))   BEGIN
INSERT INTO Revenue (Amount,Revenue_type)
VALUES (p_Amount,p_Revenue_type);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insert_Transaction` (IN `p_User_id` INT, IN `p_Revenue_id` INT)   BEGIN
INSERT INTO Transaction (User_id,Revenue_id)
VALUES (p_User_id,p_Revenue_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insert_User` (IN `p_First_name` VARCHAR(70), IN `p_Last_name` VARCHAR(70), IN `p_Tin_number` INT, IN `p_Age` INT, IN `p_Address` VARCHAR(100), IN `p_Email` VARCHAR(100), IN `p_Registration_date` DATE, IN `p_Agent_id` INT)   BEGIN
INSERT INTO User (First_name,Last_name,Tin_number,Age,Address,Email,Registration_date,Agent_id)
VALUES (p_First_name,p_Last_name,p_Tin_number,p_Age,p_Address,p_Email,p_Registration_date,p_Agent_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `subquery data` (IN `int` INT)   BEGIN
    SELECT order_id, customer_name, total_amount
    FROM orders_table
    WHERE order_id = order_id;

    SELECT item_name, quantity
    FROM customers_table
    WHERE order_id = order_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update` (IN `int` INT)   BEGIN
    UPDATE customers_table
    SET customer_status = new_status
    WHERE customers_id = customer-id;

    UPDATE orders
    SET order_status = new_status
    WHERE id = order_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_Agent` (IN `p_Agent_id` INT, IN `p_New_Email` VARCHAR(100), IN `p_New_Tel_number` INT)   BEGIN
UPDATE Agent
SET Email = p_Agent_id,Email = p_New_Email,Tel_number = p_New_Tel_number
WHERE Agent_id = p_Agent_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_User` (IN `p_User_id` INT, IN `p_New_Email` VARCHAR(100), IN `p_New_Age` INT, IN `p_New_Address` VARCHAR(100))   BEGIN
UPDATE User
SET Email = p_New_Email, Age = p_New_Age, Address = p_New_Address
WHERE User_id = p_User_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `above_average_revenue`
-- (See below for the actual view)
--
CREATE TABLE `above_average_revenue` (
`Revenue_id` int(11)
,`Revenue_type` varchar(80)
);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_id` int(11) NOT NULL,
  `First_name` varchar(50) NOT NULL,
  `Last_name` varchar(50) NOT NULL,
  `Gender` varchar(50) DEFAULT NULL,
  `Address` varchar(60) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Tel_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_id`, `First_name`, `Last_name`, `Gender`, `Address`, `Email`, `Tel_number`) VALUES
(1, 'Ineza', 'Diane', 'Female', 'Huye', 'inezadiane12@gmail.com', 788201445),
(3, 'Isaac', 'Mugisha', 'Male', 'Gasabo', 'iscmugisha@gmail.com', 788540269),
(4, 'Abias', 'Ndayishimye', 'Male', 'Nyabihu', 'ndayiabias55@gmail.com', 788965101),
(5, 'Hertier', 'Mugisha', 'Male', 'Musanze', 'mghshher225@gmail.com', 781056109),
(6, 'Ishimwe', 'Moise', 'Male', 'Huye', 'ishimweamoise@gmail.com', 2147483647),
(7, 'Samuel', 'Niyomurengezi', 'Male', 'Mhanga_Kabgayi', 'niyomurengezisamu04@gmail.com', 2147483647);

-- --------------------------------------------------------

--
-- Stand-in structure for view `admin_view`
-- (See below for the actual view)
--
CREATE TABLE `admin_view` (
`Admin_id` int(11)
,`First_name` varchar(50)
,`Last_name` varchar(50)
,`Gender` varchar(50)
,`Address` varchar(60)
,`Email` varchar(100)
,`Tel_number` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `agent`
--

CREATE TABLE `agent` (
  `Agent_id` int(11) NOT NULL,
  `First_name` varchar(60) NOT NULL,
  `Last_name` varchar(60) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Tel_number` int(11) DEFAULT NULL,
  `Admin_id` int(11) DEFAULT NULL,
  `Manager_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `agent`
--

INSERT INTO `agent` (`Agent_id`, `First_name`, `Last_name`, `Email`, `Tel_number`, `Admin_id`, `Manager_id`) VALUES
(1, 'Celeste', 'Ukwigize', 'celesteukwi53@gmail.com', 788546573, 3, 1),
(2, 'Daniel', 'Ukwigize', 'ukwigdaniel44@gmail.com', 787849608, 5, 2),
(3, 'Boniface', 'Kamanzi', 'kamaanzi4@gmail.com', 790462974, 3, 3),
(4, 'Eduard', 'Nezerwa', 'eduardnnez@gmail.com', 784529506, 1, 2),
(5, 'Rafiki', 'Aimee', 'newemail@eamnple.com', 783537485, 1, 2),
(6, 'Jack', 'Chan', 'jackchan5@gmail.com', 788886593, 4, 1);

--
-- Triggers `agent`
--
DELIMITER $$
CREATE TRIGGER `Agent` AFTER DELETE ON `agent` FOR EACH ROW BEGIN
INSERT INTO Agent (Agent_id,Email,Tel_number)
VALUES (Agent_id, 'DELETE',NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `agent_view`
-- (See below for the actual view)
--
CREATE TABLE `agent_view` (
`Agent_id` int(11)
,`First_name` varchar(60)
,`Last_name` varchar(60)
,`Email` varchar(100)
,`Tel_number` int(11)
,`Admin_id` int(11)
,`Manager_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_information`
-- (See below for the actual view)
--
CREATE TABLE `all_information` (
`Table_name` varchar(11)
,`Admin_id` int(11)
,`First_name` varchar(70)
,`Last_name` varchar(80)
,`Gender` varchar(65)
,`Address` varchar(100)
,`Email` varchar(100)
,`Tel_number` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `customers_table`
--

CREATE TABLE `customers_table` (
  `customer-id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `phone` int(11) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers_table`
--

INSERT INTO `customers_table` (`customer-id`, `name`, `email`, `phone`, `address`) VALUES
(12, 'fab', 'shh@gg.cm', 788888, 'butar'),
(1233, 'fabio', 'fff@gg.cm', 788888, 'butar');

--
-- Triggers `customers_table`
--
DELIMITER $$
CREATE TRIGGER `after_delete_customers` AFTER DELETE ON `customers_table` FOR EACH ROW BEGIN
    -- Trigger logic here
    -- You can perform actions or execute SQL statements using the OLD alias
    
    -- Example: Insert a record into a log table after deleting from customers_table
    INSERT INTO customers_log (customer_id, action, timestamp)
    VALUES (customers_table.customer_id, 'Deleted', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `delivery_personneltable`
--

CREATE TABLE `delivery_personneltable` (
  `delivery-person-id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `phone` int(11) NOT NULL,
  `availability` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_personneltable`
--

INSERT INTO `delivery_personneltable` (`delivery-person-id`, `name`, `email`, `phone`, `availability`) VALUES
(123, 'jess', 'jess@mm.cn', 788888888, 'available');

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_data_view` (
`order-id` int(11)
,`customer-id` int(11)
,`order-date` date
,`total-amount` int(11)
,`payment-status` text
);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `Manager_id` int(11) NOT NULL,
  `First_name` varchar(60) NOT NULL,
  `Last_name` varchar(60) NOT NULL,
  `Gender` varchar(65) DEFAULT NULL,
  `Address` varchar(65) DEFAULT NULL,
  `Specialization` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`Manager_id`, `First_name`, `Last_name`, `Gender`, `Address`, `Specialization`) VALUES
(1, 'Prof.Samuel', 'Mugisha', 'Male', 'Kayonza', 'Management'),
(2, 'Dr.Mucyo', 'Annet', 'Female', 'Nyarugenge', 'Finance'),
(3, 'Prof.Audile', 'Uwase', 'Female', 'Kicukiro', 'Accounting');

--
-- Triggers `manager`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertManager` AFTER INSERT ON `manager` FOR EACH ROW BEGIN
INSERT INTO Manager_audit (Manager_id,Address,Specialization)
VALUES (NEW.Manager_id, 'INSERT',NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateManager` AFTER UPDATE ON `manager` FOR EACH ROW BEGIN
INSERT INTO Manager_audit (Manager_id,Address,Specialization)
VALUES (NEW.Manager_id,'UPDATE',NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `manager_view`
-- (See below for the actual view)
--
CREATE TABLE `manager_view` (
`Manager_id` int(11)
,`First_name` varchar(60)
,`Last_name` varchar(60)
,`Gender` varchar(65)
,`Address` varchar(65)
,`Specialization` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `menu_itemstable`
--

CREATE TABLE `menu_itemstable` (
  `item-id` int(11) NOT NULL,
  `name` text NOT NULL,
  `price` int(11) NOT NULL,
  `availability` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `menu_itemstable`
--
DELIMITER $$
CREATE TRIGGER `after_insert_menu_items` AFTER INSERT ON `menu_itemstable` FOR EACH ROW BEGIN
    -- Trigger logic here
    -- You can perform actions or execute SQL statements using the NEW alias

    -- Example: Update the availability status of the menu item in another table
    UPDATE menu_availability
    SET availability = 'Available'
    WHERE item_id = item_id.item_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_update_menu_items` AFTER UPDATE ON `menu_itemstable` FOR EACH ROW BEGIN
    -- Trigger logic here
    -- You can perform actions or execute SQL statements using the NEW and OLD aliases

    -- Example: Update the availability status of the menu item in another table
    UPDATE menu_availability
    SET availability = 'Available'
    WHERE item_id = customers_table.item_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `orders_table`
--

CREATE TABLE `orders_table` (
  `order-id` int(11) NOT NULL,
  `customer-id` int(11) NOT NULL,
  `order-date` date NOT NULL,
  `total-amount` int(11) NOT NULL,
  `payment-status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_table`
--

INSERT INTO `orders_table` (`order-id`, `customer-id`, `order-date`, `total-amount`, `payment-status`) VALUES
(12343232, 12, '2023-09-01', 56, 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `payment_transactionstable`
--

CREATE TABLE `payment_transactionstable` (
  `transaction-id` int(11) NOT NULL,
  `transaction-date` date NOT NULL,
  `amount` int(11) NOT NULL,
  `payment-method` text NOT NULL,
  `transaction-status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_transactionstable`
--

INSERT INTO `payment_transactionstable` (`transaction-id`, `transaction-date`, `amount`, `payment-method`, `transaction-status`) VALUES
(123, '2023-09-01', 4, 'visa', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_table`
--

CREATE TABLE `restaurant_table` (
  `Restaurant-id` int(11) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `number` int(11) NOT NULL,
  `cuisine type` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant_table`
--

INSERT INTO `restaurant_table` (`Restaurant-id`, `name`, `address`, `number`, `cuisine type`) VALUES
(12354432, 'delicius restaurant', 'kn 400 st', 7899999, 'italian');

-- --------------------------------------------------------

--
-- Table structure for table `revenue`
--

CREATE TABLE `revenue` (
  `Revenue_id` int(11) NOT NULL,
  `Amount` int(11) NOT NULL,
  `Revenue_type` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `revenue`
--

INSERT INTO `revenue` (`Revenue_id`, `Amount`, `Revenue_type`) VALUES
(1, 100000000, 'TVA'),
(2, 4500000, 'Income tax'),
(3, 12000000, 'Personal tax'),
(4, 5250000, 'Rental tax'),
(5, 1260000, 'Property tax');

--
-- Triggers `revenue`
--
DELIMITER $$
CREATE TRIGGER `Revenue` AFTER DELETE ON `revenue` FOR EACH ROW BEGIN
INSERT INTO Revenue (Revenue_id,Amount,Revenue_type)
VALUES (Revenue_id, 'DELETE',NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `RevenueAfterInsert` AFTER INSERT ON `revenue` FOR EACH ROW BEGIN
IF NEW.Amount >= 50000 THEN
UPDATE Revenue
SET Revenue_type = 'Monthly_tax'
WHERE Revenue_id = NEW.Revenue_id;
END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `revenue_view`
-- (See below for the actual view)
--
CREATE TABLE `revenue_view` (
`Revenue_id` int(11)
,`Amount` int(11)
,`Revenue_type` varchar(80)
);

-- --------------------------------------------------------

--
-- Table structure for table `reviews_table`
--

CREATE TABLE `reviews_table` (
  `review-id` int(11) NOT NULL,
  `customer-id` int(11) NOT NULL,
  `order-id` int(11) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews_table`
--

INSERT INTO `reviews_table` (`review-id`, `customer-id`, `order-id`, `comment`) VALUES
(1, 12, 12343232, 'delicius food and service and i left the tip too!');

-- --------------------------------------------------------

--
-- Stand-in structure for view `show data all`
-- (See below for the actual view)
--
CREATE TABLE `show data all` (
`Restaurant-id` int(11)
,`name` text
,`address` text
,`number` text
,`cuisine type` text
);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `Transaction_id` int(11) NOT NULL,
  `User_id` int(11) DEFAULT NULL,
  `Revenue_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`Transaction_id`, `User_id`, `Revenue_id`) VALUES
(1, 1, 1),
(2, 4, 3),
(3, 4, 2),
(4, 2, 2),
(5, 5, 3),
(6, 1, 3),
(7, 6, 4);

-- --------------------------------------------------------

--
-- Stand-in structure for view `transaction_view`
-- (See below for the actual view)
--
CREATE TABLE `transaction_view` (
`Transaction_id` int(11)
,`User_id` int(11)
,`Revenue_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_admin_view`
-- (See below for the actual view)
--
CREATE TABLE `update_admin_view` (
`First_name` varchar(50)
,`Last_name` varchar(50)
,`Gender` varchar(50)
,`Address` varchar(60)
,`Email` varchar(100)
,`Tel_number` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User_id` int(11) NOT NULL,
  `First_name` varchar(70) NOT NULL,
  `Last_name` varchar(70) NOT NULL,
  `Tin_number` int(11) NOT NULL,
  `Age` int(11) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Registration_date` date DEFAULT NULL,
  `Agent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_id`, `First_name`, `Last_name`, `Tin_number`, `Age`, `Address`, `Email`, `Registration_date`, `Agent_id`) VALUES
(1, 'Ndizeye', 'Aimable', 101736686, 45, 'Kicukiro', 'ndizeyeaimable543@gmail.com', '2022-06-30', 3),
(2, 'Mutoni', 'Alice', 110154346, 25, 'New User Address', 'newemail@gmail.com', '2022-11-25', 4),
(3, 'Bwiza', 'Alice', 111006357, 28, 'Rubavu', 'bwizaalice12@gmail.com', '2023-01-12', 2),
(4, 'Bwuzu', 'Aline', 110053726, 30, 'Muhanga', 'bwuzualine0025@gmail.com', '2023-04-27', 1),
(5, 'Ntwari', 'Fideli', 116385627, 65, 'Ruhango', 'ntwarifide5@gmail.com', '2022-08-12', 5),
(6, 'Eric', 'Nsabimana', 1011548490, 23, 'Nyanza', 'ericnsabi15@gmail.com', '2023-08-12', 6);

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertUser` AFTER INSERT ON `user` FOR EACH ROW BEGIN
INSERT INTO User_audit (User_id,Tin_number,Age,Registration_date)
VALUES (NEW.User_id, 'INSERT',NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateUser` AFTER UPDATE ON `user` FOR EACH ROW BEGIN
INSERT INTO User_audit (User_id,Address,Specialization)
VALUES (NEW.User_id,'UPDATE',NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_view`
-- (See below for the actual view)
--
CREATE TABLE `user_view` (
`User_id` int(11)
,`First_name` varchar(70)
,`Last_name` varchar(70)
,`Tin_number` int(11)
,`Age` int(11)
,`Address` varchar(100)
,`Email` varchar(100)
,`Registration_date` date
,`Agent_id` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `above_average_revenue`
--
DROP TABLE IF EXISTS `above_average_revenue`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `above_average_revenue`  AS SELECT `revenue`.`Revenue_id` AS `Revenue_id`, `revenue`.`Revenue_type` AS `Revenue_type` FROM `revenue` WHERE `revenue`.`Amount` > (select avg(`revenue`.`Amount`) from `revenue`)  ;

-- --------------------------------------------------------

--
-- Structure for view `admin_view`
--
DROP TABLE IF EXISTS `admin_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `admin_view`  AS SELECT `admin`.`Admin_id` AS `Admin_id`, `admin`.`First_name` AS `First_name`, `admin`.`Last_name` AS `Last_name`, `admin`.`Gender` AS `Gender`, `admin`.`Address` AS `Address`, `admin`.`Email` AS `Email`, `admin`.`Tel_number` AS `Tel_number` FROM `admin` WHERE `admin`.`Admin_id` = 33  ;

-- --------------------------------------------------------

--
-- Structure for view `agent_view`
--
DROP TABLE IF EXISTS `agent_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `agent_view`  AS SELECT `agent`.`Agent_id` AS `Agent_id`, `agent`.`First_name` AS `First_name`, `agent`.`Last_name` AS `Last_name`, `agent`.`Email` AS `Email`, `agent`.`Tel_number` AS `Tel_number`, `agent`.`Admin_id` AS `Admin_id`, `agent`.`Manager_id` AS `Manager_id` FROM `agent` WHERE `agent`.`Agent_id` = 55  ;

-- --------------------------------------------------------

--
-- Structure for view `all_information`
--
DROP TABLE IF EXISTS `all_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_information`  AS SELECT 'Admin' AS `Table_name`, `admin`.`Admin_id` AS `Admin_id`, `admin`.`First_name` AS `First_name`, `admin`.`Last_name` AS `Last_name`, `admin`.`Gender` AS `Gender`, `admin`.`Address` AS `Address`, `admin`.`Email` AS `Email`, `admin`.`Tel_number` AS `Tel_number` FROM `admin` union all select 'Manager' AS `Manager`,`manager`.`Manager_id` AS `Manager_id`,`manager`.`First_name` AS `First_name`,`manager`.`Last_name` AS `Last_name`,`manager`.`Gender` AS `Gender`,`manager`.`Address` AS `Address`,NULL AS `NULL`,`manager`.`Specialization` AS `Specialization` from `manager` union all select 'Agent' AS `Agent`,`agent`.`Agent_id` AS `Agent_id`,`agent`.`First_name` AS `First_name`,`agent`.`Last_name` AS `Last_name`,NULL AS `NULL`,NULL AS `NULL`,`agent`.`Email` AS `Email`,`agent`.`Tel_number` AS `Tel_number` from `agent` union all select 'User' AS `User`,`user`.`User_id` AS `User_id`,`user`.`First_name` AS `First_name`,`user`.`Last_name` AS `Last_name`,`user`.`Tin_number` AS `Tin_number`,`user`.`Address` AS `Address`,`user`.`Email` AS `Email`,`user`.`Registration_date` AS `Registration_date` from `user` union all select 'Transaction' AS `Transaction`,`transaction`.`Transaction_id` AS `Transaction_id`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL` from `transaction` union all select 'Revenue' AS `Revenue`,`revenue`.`Revenue_id` AS `Revenue_id`,`revenue`.`Amount` AS `Amount`,`revenue`.`Revenue_type` AS `Revenue_type`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL` from `revenue`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data_view`
--
DROP TABLE IF EXISTS `insert_data_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data_view`  AS SELECT `orders_table`.`order-id` AS `order-id`, `orders_table`.`customer-id` AS `customer-id`, `orders_table`.`order-date` AS `order-date`, `orders_table`.`total-amount` AS `total-amount`, `orders_table`.`payment-status` AS `payment-status` FROM `orders_table``orders_table`  ;

-- --------------------------------------------------------

--
-- Structure for view `manager_view`
--
DROP TABLE IF EXISTS `manager_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `manager_view`  AS SELECT `manager`.`Manager_id` AS `Manager_id`, `manager`.`First_name` AS `First_name`, `manager`.`Last_name` AS `Last_name`, `manager`.`Gender` AS `Gender`, `manager`.`Address` AS `Address`, `manager`.`Specialization` AS `Specialization` FROM `manager` WHERE `manager`.`Manager_id` = 22  ;

-- --------------------------------------------------------

--
-- Structure for view `revenue_view`
--
DROP TABLE IF EXISTS `revenue_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `revenue_view`  AS SELECT `revenue`.`Revenue_id` AS `Revenue_id`, `revenue`.`Amount` AS `Amount`, `revenue`.`Revenue_type` AS `Revenue_type` FROM `revenue` WHERE `revenue`.`Revenue_id` = 44  ;

-- --------------------------------------------------------

--
-- Structure for view `show data all`
--
DROP TABLE IF EXISTS `show data all`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `show data all`  AS SELECT `restaurant_table`.`Restaurant-id` AS `Restaurant-id`, `restaurant_table`.`name` AS `name`, `restaurant_table`.`address` AS `address`, `restaurant_table`.`number` AS `number`, `restaurant_table`.`cuisine type` AS `cuisine type` FROM `restaurant_table` union select `orders_table`.`order-id` AS `order-id`,`orders_table`.`customer-id` AS `customer-id`,`orders_table`.`order-date` AS `order-date`,`orders_table`.`total-amount` AS `total-amount`,`orders_table`.`payment-status` AS `payment-status` from `orders_table` union select `customers_table`.`customer-id` AS `customer-id`,`customers_table`.`name` AS `name`,`customers_table`.`email` AS `email`,`customers_table`.`phone` AS `phone`,`customers_table`.`address` AS `address` from `customers_table` union select `delivery_personneltable`.`delivery-person-id` AS `delivery-person-id`,`delivery_personneltable`.`name` AS `name`,`delivery_personneltable`.`email` AS `email`,`delivery_personneltable`.`phone` AS `phone`,`delivery_personneltable`.`availability` AS `availability` from `delivery_personneltable` union select `payment_transactionstable`.`transaction-id` AS `transaction-id`,`payment_transactionstable`.`transaction-date` AS `transaction-date`,`payment_transactionstable`.`amount` AS `amount`,`payment_transactionstable`.`payment-method` AS `payment-method`,`payment_transactionstable`.`transaction-status` AS `transaction-status` from `payment_transactionstable`  ;

-- --------------------------------------------------------

--
-- Structure for view `transaction_view`
--
DROP TABLE IF EXISTS `transaction_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `transaction_view`  AS SELECT `transaction`.`Transaction_id` AS `Transaction_id`, `transaction`.`User_id` AS `User_id`, `transaction`.`Revenue_id` AS `Revenue_id` FROM `transaction` WHERE `transaction`.`Transaction_id` = 66  ;

-- --------------------------------------------------------

--
-- Structure for view `update_admin_view`
--
DROP TABLE IF EXISTS `update_admin_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_admin_view`  AS SELECT `admin`.`First_name` AS `First_name`, `admin`.`Last_name` AS `Last_name`, `admin`.`Gender` AS `Gender`, `admin`.`Address` AS `Address`, `admin`.`Email` AS `Email`, `admin`.`Tel_number` AS `Tel_number` FROM `admin``admin`  ;

-- --------------------------------------------------------

--
-- Structure for view `user_view`
--
DROP TABLE IF EXISTS `user_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `user_view`  AS SELECT `user`.`User_id` AS `User_id`, `user`.`First_name` AS `First_name`, `user`.`Last_name` AS `Last_name`, `user`.`Tin_number` AS `Tin_number`, `user`.`Age` AS `Age`, `user`.`Address` AS `Address`, `user`.`Email` AS `Email`, `user`.`Registration_date` AS `Registration_date`, `user`.`Agent_id` AS `Agent_id` FROM `user` WHERE `user`.`User_id` = 55  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_id`);

--
-- Indexes for table `agent`
--
ALTER TABLE `agent`
  ADD PRIMARY KEY (`Agent_id`),
  ADD KEY `Admin_id` (`Admin_id`),
  ADD KEY `Manager_id` (`Manager_id`);

--
-- Indexes for table `customers_table`
--
ALTER TABLE `customers_table`
  ADD PRIMARY KEY (`customer-id`);

--
-- Indexes for table `delivery_personneltable`
--
ALTER TABLE `delivery_personneltable`
  ADD PRIMARY KEY (`delivery-person-id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`Manager_id`);

--
-- Indexes for table `orders_table`
--
ALTER TABLE `orders_table`
  ADD PRIMARY KEY (`order-id`),
  ADD KEY `customer-id` (`customer-id`);

--
-- Indexes for table `payment_transactionstable`
--
ALTER TABLE `payment_transactionstable`
  ADD PRIMARY KEY (`transaction-id`);

--
-- Indexes for table `restaurant_table`
--
ALTER TABLE `restaurant_table`
  ADD PRIMARY KEY (`Restaurant-id`);

--
-- Indexes for table `revenue`
--
ALTER TABLE `revenue`
  ADD PRIMARY KEY (`Revenue_id`);

--
-- Indexes for table `reviews_table`
--
ALTER TABLE `reviews_table`
  ADD PRIMARY KEY (`review-id`),
  ADD KEY `customer-id` (`customer-id`),
  ADD KEY `order-id` (`order-id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`Transaction_id`),
  ADD KEY `User_id` (`User_id`),
  ADD KEY `Revenue_id` (`Revenue_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_id`),
  ADD KEY `Agent_id` (`Agent_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `agent`
--
ALTER TABLE `agent`
  MODIFY `Agent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `Manager_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `revenue`
--
ALTER TABLE `revenue`
  MODIFY `Revenue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `Transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `agent`
--
ALTER TABLE `agent`
  ADD CONSTRAINT `agent_ibfk_1` FOREIGN KEY (`Admin_id`) REFERENCES `admin` (`Admin_id`),
  ADD CONSTRAINT `agent_ibfk_2` FOREIGN KEY (`Manager_id`) REFERENCES `manager` (`Manager_id`);

--
-- Constraints for table `orders_table`
--
ALTER TABLE `orders_table`
  ADD CONSTRAINT `foreign key` FOREIGN KEY (`customer-id`) REFERENCES `customers_table` (`customer-id`);

--
-- Constraints for table `reviews_table`
--
ALTER TABLE `reviews_table`
  ADD CONSTRAINT `reviews_table_ibfk_1` FOREIGN KEY (`customer-id`) REFERENCES `customers_table` (`customer-id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `reviews_table_ibfk_2` FOREIGN KEY (`order-id`) REFERENCES `orders_table` (`order-id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`User_id`) REFERENCES `user` (`User_id`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`Revenue_id`) REFERENCES `revenue` (`Revenue_id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`Agent_id`) REFERENCES `agent` (`Agent_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
