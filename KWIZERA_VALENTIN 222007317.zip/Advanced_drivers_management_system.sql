-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: advanced_drivers_management_system
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accountants`
--

DROP TABLE IF EXISTS `accountants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accountants` (
  `accountant_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `payment_code` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`accountant_id`),
  KEY `order_id` (`order_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `accountants_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`Order_id`),
  CONSTRAINT `accountants_ibfk_2` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountants`
--

LOCK TABLES `accountants` WRITE;
/*!40000 ALTER TABLE `accountants` DISABLE KEYS */;
/*!40000 ALTER TABLE `accountants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `check_average_totalamounts_from_payments`
--

DROP TABLE IF EXISTS `check_average_totalamounts_from_payments`;
/*!50001 DROP VIEW IF EXISTS `check_average_totalamounts_from_payments`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `check_average_totalamounts_from_payments` AS SELECT
 1 AS `payment_id`,
  1 AS `customer_id`,
  1 AS `order_id`,
  1 AS `payment_code`,
  1 AS `amount_perhour`,
  1 AS `total_amount`,
  1 AS `time`,
  1 AS `date` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `Customer_Id` int(11) NOT NULL AUTO_INCREMENT,
  `First_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `Car_Categories` varchar(50) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Customer_Id`),
  UNIQUE KEY `location` (`location`),
  KEY `driver_id` (`driver_id`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`driver_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'john','mucyo','kigali','B','0788449384','mucyo11@gmail.com',1),(2,'jessy','uwase','muhanga','B','78905523','jessyuwa45@gmail.com',2),(3,'jessy','uwase','huye','B','78905523','jessyuwa45@gmail.com',2),(4,'joella','keza','kamonyi','B','78907893','joellakez75@gmail.com',1);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER AfterInsertcustomers
AFTER INSERT ON customers
FOR EACH ROW
BEGIN
   INSERT INTO customers_audit (customer_id, commandimg, commanding_date)
    VALUES (NEW.customer_id, 'INSERT', NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER AfterUpdatecustomers
AFTER UPDATE ON customers
FOR EACH ROW
BEGIN
    INSERT INTO customers_audit (customer_id, commanding, commanding_date)
VALUES (NEW.customer_id, 'UPDATE', NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `customers_to_delete`
--

DROP TABLE IF EXISTS `customers_to_delete`;
/*!50001 DROP VIEW IF EXISTS `customers_to_delete`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customers_to_delete` AS SELECT
 1 AS `Customer_Id`,
  1 AS `First_Name`,
  1 AS `Last_Name`,
  1 AS `location`,
  1 AS `Car_Categories`,
  1 AS `phone_number`,
  1 AS `email`,
  1 AS `driver_id` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `customers_view`
--

DROP TABLE IF EXISTS `customers_view`;
/*!50001 DROP VIEW IF EXISTS `customers_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `customers_view` AS SELECT
 1 AS `Customer_Id`,
  1 AS `First_Name`,
  1 AS `Last_Name`,
  1 AS `location`,
  1 AS `Car_Categories`,
  1 AS `phone_number`,
  1 AS `email`,
  1 AS `driver_id` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `displayalldataview`
--

DROP TABLE IF EXISTS `displayalldataview`;
/*!50001 DROP VIEW IF EXISTS `displayalldataview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `displayalldataview` AS SELECT
 1 AS `driver_ID`,
  1 AS `first_Name`,
  1 AS `last_Name`,
  1 AS `phone_number`,
  1 AS `email`,
  1 AS `address`,
  1 AS `license_category`,
  1 AS `license_Number` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `drivers`
--

DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drivers` (
  `driver_ID` int(11) NOT NULL AUTO_INCREMENT,
  `first_Name` varchar(50) DEFAULT NULL,
  `last_Name` varchar(50) DEFAULT NULL,
  `phone_number` int(10) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `license_category` varchar(7) NOT NULL,
  `license_Number` int(16) NOT NULL,
  PRIMARY KEY (`driver_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drivers`
--

LOCK TABLES `drivers` WRITE;
/*!40000 ALTER TABLE `drivers` DISABLE KEYS */;
INSERT INTO `drivers` VALUES (1,'valatine','mugisha',78845451,'mugisha200@gmail.com','kg122','B.C.D',111200),(2,'ngabo','emmanuel',78255525,'emmyngabo40@gmail.com','kg122','B.C.D.D',111300);
/*!40000 ALTER TABLE `drivers` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER AfterInsertdrivers
AFTER INSERT ON drivers
FOR EACH ROW
BEGIN
    INSERT INTO drivers_audit (driver_id, action, action_date)
    VALUES (NEW.driver_id, 'INSERT', NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER AfterUpdatedrivers
AFTER UPDATE ON drivers
FOR EACH ROW
BEGIN
    INSERT INTO drivers_audit (driver_id, action, action_date)
    VALUES (NEW.driver_id, 'UPDATE', NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `drivers_customers`
--

DROP TABLE IF EXISTS `drivers_customers`;
/*!50001 DROP VIEW IF EXISTS `drivers_customers`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `drivers_customers` AS SELECT
 1 AS `driver_ID`,
  1 AS `first_Name`,
  1 AS `last_Name`,
  1 AS `phone_number`,
  1 AS `email`,
  1 AS `address`,
  1 AS `license_category`,
  1 AS `license_Number` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `drivers_view`
--

DROP TABLE IF EXISTS `drivers_view`;
/*!50001 DROP VIEW IF EXISTS `drivers_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `drivers_view` AS SELECT
 1 AS `driver_ID`,
  1 AS `first_Name`,
  1 AS `last_Name`,
  1 AS `phone_number`,
  1 AS `email`,
  1 AS `address`,
  1 AS `license_category`,
  1 AS `license_Number` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `accountant_id` int(11) NOT NULL,
  `feedback_text` varchar(100) NOT NULL,
  `feedback_rating` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`Customer_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (1,1,1,'seccussful','grade1'),(2,2,1,'excellent','grade1'),(3,3,1,'verygood','grade2'),(4,1,1,'excellent','grade2');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `feedback_view`
--

DROP TABLE IF EXISTS `feedback_view`;
/*!50001 DROP VIEW IF EXISTS `feedback_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `feedback_view` AS SELECT
 1 AS `feedback_id`,
  1 AS `customer_id`,
  1 AS `accountant_id`,
  1 AS `feedback_text`,
  1 AS `feedback_rating` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `Order_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `location` varchar(100) NOT NULL,
  `Starting_Point` varchar(100) DEFAULT NULL,
  `Ending_Point` varchar(100) DEFAULT NULL,
  `Estimated_Time` time NOT NULL,
  `Order_time` time DEFAULT NULL,
  `Order_Date` date DEFAULT NULL,
  PRIMARY KEY (`Order_id`),
  KEY `customer_id` (`customer_id`),
  KEY `driver_id` (`driver_id`),
  KEY `location` (`location`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`Customer_Id`),
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`driver_ID`),
  CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`location`) REFERENCES `customers` (`location`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,1,1,'kigali','kg122','kg783','00:00:03','00:30:00','2023-08-12'),(2,2,2,'muhanga','muh212','muh143','00:00:02','11:30:00','2023-08-13'),(3,3,2,'huye','huy212','huy343','00:00:04','06:30:00','2023-08-03'),(4,4,1,'kamonyi','kmy512','kmy143','00:00:03','06:00:00','2023-06-03');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `orders_to_delete`
--

DROP TABLE IF EXISTS `orders_to_delete`;
/*!50001 DROP VIEW IF EXISTS `orders_to_delete`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `orders_to_delete` AS SELECT
 1 AS `order_id`,
  1 AS `location` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `orders_view`
--

DROP TABLE IF EXISTS `orders_view`;
/*!50001 DROP VIEW IF EXISTS `orders_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `orders_view` AS SELECT
 1 AS `Order_id`,
  1 AS `customer_id`,
  1 AS `driver_id`,
  1 AS `location`,
  1 AS `Starting_Point`,
  1 AS `Ending_Point`,
  1 AS `Estimated_Time`,
  1 AS `Order_time`,
  1 AS `Order_Date` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_code` int(11) NOT NULL,
  `amount_perhour` int(11) NOT NULL,
  `total_amount` int(11) DEFAULT NULL,
  `time` time DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `customer_id` (`customer_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`Customer_Id`),
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`Order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,1,1,23456,5000,15000,'00:40:00','2023-08-12'),(2,2,2,23456,5000,10000,'11:30:00','2023-08-13'),(3,3,3,23456,5000,20000,'06:35:00','2023-08-03'),(4,4,4,23456,5000,15000,'06:05:00','2023-06-03');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER payments
AFTER DELETE ON payments
FOR EACH ROW
BEGIN
   INSERT INTO orders (payment_id, action, action_date)
    VALUES (payment_id, 'DELETE', NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER AfterDeletepayments
AFTER DELETE ON payments
FOR EACH ROW
BEGIN
  UPDATE club SET total_amount = total_amount - 1 WHERE payment_id = payment_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `payments_view`
--

DROP TABLE IF EXISTS `payments_view`;
/*!50001 DROP VIEW IF EXISTS `payments_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `payments_view` AS SELECT
 1 AS `payment_id`,
  1 AS `customer_id`,
  1 AS `order_id`,
  1 AS `payment_code`,
  1 AS `amount_perhour`,
  1 AS `total_amount`,
  1 AS `time`,
  1 AS `date` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `updatable_customers_info`
--

DROP TABLE IF EXISTS `updatable_customers_info`;
/*!50001 DROP VIEW IF EXISTS `updatable_customers_info`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `updatable_customers_info` AS SELECT
 1 AS `customer_id`,
  1 AS `First_Name`,
  1 AS `Last_Name`,
  1 AS `location`,
  1 AS `Car_Categories`,
  1 AS `phone_number`,
  1 AS `email` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `updatable_drivers_info`
--

DROP TABLE IF EXISTS `updatable_drivers_info`;
/*!50001 DROP VIEW IF EXISTS `updatable_drivers_info`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `updatable_drivers_info` AS SELECT
 1 AS `driver_id`,
  1 AS `First_name`,
  1 AS `Last_name`,
  1 AS `phone_number`,
  1 AS `email`,
  1 AS `address`,
  1 AS `license_category`,
  1 AS `license_Number` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `check_average_totalamounts_from_payments`
--

/*!50001 DROP VIEW IF EXISTS `check_average_totalamounts_from_payments`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `check_average_totalamounts_from_payments` AS select `payments`.`payment_id` AS `payment_id`,`payments`.`customer_id` AS `customer_id`,`payments`.`order_id` AS `order_id`,`payments`.`payment_code` AS `payment_code`,`payments`.`amount_perhour` AS `amount_perhour`,`payments`.`total_amount` AS `total_amount`,`payments`.`time` AS `time`,`payments`.`date` AS `date` from `payments` where `payments`.`total_amount` > (select avg(`payments`.`total_amount`) from `payments`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customers_to_delete`
--

/*!50001 DROP VIEW IF EXISTS `customers_to_delete`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customers_to_delete` AS select `customers`.`Customer_Id` AS `Customer_Id`,`customers`.`First_Name` AS `First_Name`,`customers`.`Last_Name` AS `Last_Name`,`customers`.`location` AS `location`,`customers`.`Car_Categories` AS `Car_Categories`,`customers`.`phone_number` AS `phone_number`,`customers`.`email` AS `email`,`customers`.`driver_id` AS `driver_id` from `customers` where `customers`.`Customer_Id` = 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customers_view`
--

/*!50001 DROP VIEW IF EXISTS `customers_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customers_view` AS select `customers`.`Customer_Id` AS `Customer_Id`,`customers`.`First_Name` AS `First_Name`,`customers`.`Last_Name` AS `Last_Name`,`customers`.`location` AS `location`,`customers`.`Car_Categories` AS `Car_Categories`,`customers`.`phone_number` AS `phone_number`,`customers`.`email` AS `email`,`customers`.`driver_id` AS `driver_id` from `customers` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `displayalldataview`
--

/*!50001 DROP VIEW IF EXISTS `displayalldataview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `displayalldataview` AS select `drivers`.`driver_ID` AS `driver_ID`,`drivers`.`first_Name` AS `first_Name`,`drivers`.`last_Name` AS `last_Name`,`drivers`.`phone_number` AS `phone_number`,`drivers`.`email` AS `email`,`drivers`.`address` AS `address`,`drivers`.`license_category` AS `license_category`,`drivers`.`license_Number` AS `license_Number` from `drivers` union all select `customers`.`Customer_Id` AS `Customer_Id`,`customers`.`First_Name` AS `First_Name`,`customers`.`Last_Name` AS `Last_Name`,`customers`.`location` AS `location`,`customers`.`Car_Categories` AS `Car_Categories`,`customers`.`phone_number` AS `phone_number`,`customers`.`email` AS `email`,`customers`.`driver_id` AS `driver_id` from `customers` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `drivers_customers`
--

/*!50001 DROP VIEW IF EXISTS `drivers_customers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `drivers_customers` AS select `drivers`.`driver_ID` AS `driver_ID`,`drivers`.`first_Name` AS `first_Name`,`drivers`.`last_Name` AS `last_Name`,`drivers`.`phone_number` AS `phone_number`,`drivers`.`email` AS `email`,`drivers`.`address` AS `address`,`drivers`.`license_category` AS `license_category`,`drivers`.`license_Number` AS `license_Number` from `drivers` union all select `customers`.`Customer_Id` AS `Customer_Id`,`customers`.`First_Name` AS `First_Name`,`customers`.`Last_Name` AS `Last_Name`,`customers`.`location` AS `location`,`customers`.`Car_Categories` AS `Car_Categories`,`customers`.`phone_number` AS `phone_number`,`customers`.`email` AS `email`,`customers`.`driver_id` AS `driver_id` from `customers` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `drivers_view`
--

/*!50001 DROP VIEW IF EXISTS `drivers_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `drivers_view` AS select `drivers`.`driver_ID` AS `driver_ID`,`drivers`.`first_Name` AS `first_Name`,`drivers`.`last_Name` AS `last_Name`,`drivers`.`phone_number` AS `phone_number`,`drivers`.`email` AS `email`,`drivers`.`address` AS `address`,`drivers`.`license_category` AS `license_category`,`drivers`.`license_Number` AS `license_Number` from `drivers` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `feedback_view`
--

/*!50001 DROP VIEW IF EXISTS `feedback_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `feedback_view` AS select `feedback`.`feedback_id` AS `feedback_id`,`feedback`.`customer_id` AS `customer_id`,`feedback`.`accountant_id` AS `accountant_id`,`feedback`.`feedback_text` AS `feedback_text`,`feedback`.`feedback_rating` AS `feedback_rating` from `feedback` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `orders_to_delete`
--

/*!50001 DROP VIEW IF EXISTS `orders_to_delete`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `orders_to_delete` AS select `orders`.`Order_id` AS `order_id`,`orders`.`location` AS `location` from `orders` where `orders`.`Order_id` = 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `orders_view`
--

/*!50001 DROP VIEW IF EXISTS `orders_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `orders_view` AS select `orders`.`Order_id` AS `Order_id`,`orders`.`customer_id` AS `customer_id`,`orders`.`driver_id` AS `driver_id`,`orders`.`location` AS `location`,`orders`.`Starting_Point` AS `Starting_Point`,`orders`.`Ending_Point` AS `Ending_Point`,`orders`.`Estimated_Time` AS `Estimated_Time`,`orders`.`Order_time` AS `Order_time`,`orders`.`Order_Date` AS `Order_Date` from `orders` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `payments_view`
--

/*!50001 DROP VIEW IF EXISTS `payments_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `payments_view` AS select `payments`.`payment_id` AS `payment_id`,`payments`.`customer_id` AS `customer_id`,`payments`.`order_id` AS `order_id`,`payments`.`payment_code` AS `payment_code`,`payments`.`amount_perhour` AS `amount_perhour`,`payments`.`total_amount` AS `total_amount`,`payments`.`time` AS `time`,`payments`.`date` AS `date` from `payments` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `updatable_customers_info`
--

/*!50001 DROP VIEW IF EXISTS `updatable_customers_info`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `updatable_customers_info` AS select `customers`.`Customer_Id` AS `customer_id`,`customers`.`First_Name` AS `First_Name`,`customers`.`Last_Name` AS `Last_Name`,`customers`.`location` AS `location`,`customers`.`Car_Categories` AS `Car_Categories`,`customers`.`phone_number` AS `phone_number`,`customers`.`email` AS `email` from `customers` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `updatable_drivers_info`
--

/*!50001 DROP VIEW IF EXISTS `updatable_drivers_info`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `updatable_drivers_info` AS select `drivers`.`driver_ID` AS `driver_id`,`drivers`.`first_Name` AS `First_name`,`drivers`.`last_Name` AS `Last_name`,`drivers`.`phone_number` AS `phone_number`,`drivers`.`email` AS `email`,`drivers`.`address` AS `address`,`drivers`.`license_category` AS `license_category`,`drivers`.`license_Number` AS `license_Number` from `drivers` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-18 13:43:02
