-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2023 at 01:44 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online exam test`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `a stored procedure to display  data into your tables` (IN `int` INT)   SELECT * FROM assignment$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `a stored procedure to insert data into your tables` (IN `int` TEXT)   INSERT INTO course (coursename, teacher_id) VALUES (fb, 56)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `get_student_grades` (IN `student_id` INT)   BEGIN
  SELECT s.username, a.assignmentname, e.examname, g.score
  FROM user s
  JOIN grade g ON s.user_id = g.user_id
  JOIN assignment a ON g.assignment_id = a.assignment_id
  JOIN exam e ON g.exam_id = e.exam_id
  WHERE s.user_id = student_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_data` (IN `assignment_id` INT, IN `assignmentname` VARCHAR(255), IN `course_id` INT, IN `assignmenttittle` TEXT, IN `deadline` DATE, IN `maximumscore` INT)   BEGIN
  UPDATE assignment
  SET assignmentname = assignmentname,
      course_id = course_id,
      assignmenttittle = assignmenttittle,
      deadline = deadline,
      maximumscore = maximumscore
  WHERE assignment_id = assignment_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_datachoice` (IN `assignment_id` INT, IN `assignmentname` VARCHAR(255), IN `course_id` INT, IN `assignmenttittle` TEXT, IN `deadline` DATE, IN `maximumscore` INT)   BEGIN
  UPDATE assignment
  SET assignmentname = assignmentname,
      course_id = course_id,
      assignmenttittle = assignmenttittle,
      deadline = deadline,
      maximumscore = maximumscore
  WHERE assignment_id = assignment_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `assignment_id` int(11) NOT NULL,
  `assignmentname` text NOT NULL,
  `course_id` int(11) NOT NULL,
  `assignmenttittle` text NOT NULL,
  `deadline` date NOT NULL,
  `maximumscore` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`assignment_id`, `assignmentname`, `course_id`, `assignmenttittle`, `deadline`, `maximumscore`) VALUES
(0, 'Assignment 1', 1, 'This is the first assignment', '2023-03-15', 100);

--
-- Triggers `assignment`
--
DELIMITER $$
CREATE TRIGGER `1.	Create after inserting triggers for any two tables of your ch` BEFORE INSERT ON `assignment` FOR EACH ROW UPDATE customers
  SET customer_id = customer_id
  WHERE customer_id = customer_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL,
  `coursename` text NOT NULL,
  `teacher_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `coursename`, `teacher_id`) VALUES
(0, 'Course 1', 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_view`
-- (See below for the actual view)
--
CREATE TABLE `delete_view` (
`assignment_id` int(11)
,`assignmentname` text
,`course_id` int(11)
,`assignmenttittle` text
,`deadline` date
,`maximumscore` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_viewww`
-- (See below for the actual view)
--
CREATE TABLE `delete_viewww` (
`assignment_id` int(11)
,`assignmentname` text
,`course_id` int(11)
,`assignmenttittle` text
,`deadline` date
,`maximumscore` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

CREATE TABLE `enrollment` (
  `enrollment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `enrollment`
--

INSERT INTO `enrollment` (`enrollment_id`, `user_id`, `course_id`) VALUES
(0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `exam_id` int(11) NOT NULL,
  `examname` text NOT NULL,
  `course_id` int(11) NOT NULL,
  `starttime` datetime NOT NULL,
  `endtime` datetime NOT NULL,
  `examtitle` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`exam_id`, `examname`, `course_id`, `starttime`, `endtime`, `examtitle`) VALUES
(0, 'Exam 1', 1, '2023-03-15 09:00:00', '2023-03-15 10:00:00', 'This is the first exam');

-- --------------------------------------------------------

--
-- Table structure for table `examsubmission`
--

CREATE TABLE `examsubmission` (
  `submission_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `submissiontime` datetime NOT NULL,
  `score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `examsubmission`
--

INSERT INTO `examsubmission` (`submission_id`, `user_id`, `exam_id`, `submissiontime`, `score`) VALUES
(2345, 0, 0, '2023-09-15 11:38:05', 0);

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE `grade` (
  `grade_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `assignment_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `student_grades`
-- (See below for the actual view)
--
CREATE TABLE `student_grades` (
`username` text
,`assignmentname` text
,`examname` text
);

-- --------------------------------------------------------

--
-- Table structure for table `submission`
--

CREATE TABLE `submission` (
  `submission_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `assignment_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `submissiontime` date NOT NULL,
  `score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_view`
-- (See below for the actual view)
--
CREATE TABLE `update_view` (
`assignment_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_vieww`
-- (See below for the actual view)
--
CREATE TABLE `update_vieww` (
`assignment_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` text NOT NULL,
  `userpassword` text NOT NULL,
  `useremail` text NOT NULL,
  `role` text NOT NULL DEFAULT 'student,teacher,admin'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `delete_data trigger` AFTER DELETE ON `user` FOR EACH ROW INSERT INTO user (user_id)
  VALUES (hhh)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure for view `delete_view`
--
DROP TABLE IF EXISTS `delete_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `delete_view`  AS SELECT `assignment`.`assignment_id` AS `assignment_id`, `assignment`.`assignmentname` AS `assignmentname`, `assignment`.`course_id` AS `course_id`, `assignment`.`assignmenttittle` AS `assignmenttittle`, `assignment`.`deadline` AS `deadline`, `assignment`.`maximumscore` AS `maximumscore` FROM `assignment` WHERE `assignment`.`deadline` < '2023-03-15' ;

-- --------------------------------------------------------

--
-- Structure for view `delete_viewww`
--
DROP TABLE IF EXISTS `delete_viewww`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `delete_viewww`  AS SELECT `assignment`.`assignment_id` AS `assignment_id`, `assignment`.`assignmentname` AS `assignmentname`, `assignment`.`course_id` AS `course_id`, `assignment`.`assignmenttittle` AS `assignmenttittle`, `assignment`.`deadline` AS `deadline`, `assignment`.`maximumscore` AS `maximumscore` FROM `assignment` WHERE `assignment`.`deadline` < '2023-03-15' ;

-- --------------------------------------------------------

--
-- Structure for view `student_grades`
--
DROP TABLE IF EXISTS `student_grades`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `student_grades`  AS SELECT `s`.`username` AS `username`, `a`.`assignmentname` AS `assignmentname`, `e`.`examname` AS `examname` FROM (((`user` `s` join `grade` `g` on(`s`.`user_id` = `g`.`user_id`)) join `assignment` `a` on(`g`.`assignment_id` = `a`.`assignment_id`)) join `exam` `e` on(`g`.`exam_id` = `e`.`exam_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `update_view`
--
DROP TABLE IF EXISTS `update_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_view`  AS SELECT `assignment`.`assignment_id` AS `assignment_id` FROM `assignment`union select `course`.`course_id` AS `course_id` from `course`  ;

-- --------------------------------------------------------

--
-- Structure for view `update_vieww`
--
DROP TABLE IF EXISTS `update_vieww`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_vieww`  AS SELECT `assignment`.`assignment_id` AS `assignment_id` FROM `assignment`union select `course`.`course_id` AS `course_id` from `course`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `examsubmission`
--
ALTER TABLE `examsubmission`
  ADD PRIMARY KEY (`submission_id`),
  ADD KEY `exam_id` (`exam_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `score` (`score`);

--
-- Indexes for table `grade`
--
ALTER TABLE `grade`
  ADD PRIMARY KEY (`grade_id`);

--
-- Indexes for table `submission`
--
ALTER TABLE `submission`
  ADD PRIMARY KEY (`submission_id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`assignment_id`,`exam_id`),
  ADD UNIQUE KEY `user_id_2` (`user_id`,`assignment_id`,`exam_id`),
  ADD KEY `exam_id` (`exam_id`),
  ADD KEY `assignment_id` (`assignment_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `examsubmission`
--
ALTER TABLE `examsubmission`
  ADD CONSTRAINT `examsubmission_ibfk_1` FOREIGN KEY (`exam_id`) REFERENCES `assignment` (`assignment_id`),
  ADD CONSTRAINT `examsubmission_ibfk_2` FOREIGN KEY (`exam_id`) REFERENCES `course` (`course_id`),
  ADD CONSTRAINT `examsubmission_ibfk_3` FOREIGN KEY (`score`) REFERENCES `exam` (`exam_id`),
  ADD CONSTRAINT `examsubmission_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `exam` (`exam_id`),
  ADD CONSTRAINT `examsubmission_ibfk_5` FOREIGN KEY (`score`) REFERENCES `assignment` (`assignment_id`);

--
-- Constraints for table `submission`
--
ALTER TABLE `submission`
  ADD CONSTRAINT `submission_ibfk_1` FOREIGN KEY (`exam_id`) REFERENCES `exam` (`exam_id`),
  ADD CONSTRAINT `submission_ibfk_2` FOREIGN KEY (`assignment_id`) REFERENCES `assignment` (`assignment_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
