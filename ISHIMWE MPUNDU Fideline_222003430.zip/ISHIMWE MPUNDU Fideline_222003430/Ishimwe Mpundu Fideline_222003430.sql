-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 01:37 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_management_system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteLanguage` (IN `p_LanguageID` INT(11), IN `p_LanguageName` VARCHAR(50), IN `p_CountryOfOrigin` VARCHAR(50))   BEGIN
    DELETE FROM languages
    WHERE language_id = p_language_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteReview` (IN `p_ReviewID` INT(11), IN `p_UserID` INT(11), IN `p_BookID` INT(11), IN `p_Rating` INT(11), IN `p_ReviewText` TEXT, IN `p_ReviewDate` DATE)   BEGIN
    DELETE FROM reviews
    WHERE
        review_id = p_review_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAuthors` ()   BEGIN
    SELECT * FROM authors;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayBooks` ()   BEGIN
    SELECT * FROM books;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayBorrowings` ()   BEGIN
    SELECT * FROM borrowings;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayFormats` ()   BEGIN
    SELECT * FROM formats;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayGenres` ()   BEGIN
    SELECT * FROM genres;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayLanguages` ()   BEGIN
    SELECT * FROM languages;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayPublishers` ()   BEGIN
    SELECT * FROM publishers;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayReservations` ()   BEGIN
    SELECT * FROM reservations;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayReviews` ()   BEGIN
    SELECT * FROM reviews;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayUsers` ()   BEGIN
    SELECT * FROM users;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetBooksByAuthor` (IN `p_author_name` VARCHAR(255))   BEGIN
    SELECT book_title
    FROM books
    WHERE author_id = (
        SELECT author_id
        FROM authors
        WHERE author_name = p_author_name
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertAuthor` (IN `p_firstname` VARCHAR(50), IN `p_lastname` VARCHAR(50), IN `p_biography` VARCHAR(100), IN `p_BirthDate` DATE, IN `p_deathdate` DATE)   BEGIN
    INSERT INTO Authors (firstname,lastname,biography, BirthDate,deathdate)
    VALUES (p_firstname,p_lastname,p_biography, p_BirthDate,p_deathdate);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertBook` (IN `p_Title` VARCHAR(200), IN `p_ISBN` VARCHAR(20), IN `p_PublicationYear` INT, IN `p_GenreID` INT, IN `p_LanguageID` INT, IN `p_PublisherID` INT, IN `p_FormatID` INT, IN `p_CopiesAvailable` INT, IN `p_CopiesTotal` INT, IN `P_AverageRating` DECIMAL(3,2), IN `p_Description` TEXT)   BEGIN
    INSERT INTO Books(Title,
ISBN,
PublicationYear,     
GenreID,     
LanguageID,
PublisherID,     
FormatID,     
CopiesAvailable,    
 CopiesTotal,  
AverageRating,        
 Description    )
    VALUES (p_Title,
p_ISBN,
p_PublicationYear,     
p_GenreID,     
p_LanguageID,
p_PublisherID,     
p_FormatID,     
p_CopiesAvailable,    
p_CopiesTotal,  
p_AverageRating,        
p_Description);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertBorrowing` (IN `p_BorrowingID` INT(11), IN `p_UserID` INT(11), IN `p_BookID` INT(11), IN `p_BorrowDate` DATE, IN `p_ReturnDate` DATE, IN `p_FineAmount` DECIMAL(8,2))   BEGIN
    INSERT INTO Borrowings (BorrowingID,     
UserID,     
BookID,     
BorrowDate,         
ReturnDate,         
FineAmount )
    VALUES (p_BorrowingID,     
p_UserID,     
p_BookID,     
p_BorrowDate,         
p_ReturnDate,         
p_FineAmount );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertFormat` (IN `p_FormatID` INT(11), IN `p_FormatName` VARCHAR(50), IN `p_FormatDescription` TEXT)   BEGIN
    INSERT INTO Formats (FormatID,     
FormatName, 
FormatDescription)
    VALUES (p_FormatID,     
p_FormatName, 
p_FormatDescription);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertGenre` (IN `p_GenreID` INT(11), IN `p_GenreName` VARCHAR(50), IN `p_Description` TEXT)   BEGIN
    INSERT INTO Genres (GenreID,    
GenreName, 
Description )
VALUES (p_GenreID,    
p_GenreName, 
p_Description);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertLanguage` (IN `p_LanguageID` INT(11), IN `p_LanguageName` VARCHAR(50), IN `p_CountryOfOrigin` VARCHAR(50))   BEGIN
    INSERT INTO Languages (LanguageID,   
LanguageName, 
CountryOfOrigin)
VALUES (p_LanguageID,   
p_LanguageName, 
p_CountryOfOrigin);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertPublisher` (IN `p_PublisherID` INT(11), IN `p_PublisherName` VARCHAR(100), IN `p_Address` VARCHAR(200), IN `p_ContactInfo` VARCHAR(100))   BEGIN
INSERT INTO Publishers (PublisherID,  
PublisherName, Address,
ContactInfo 
 )
VALUES (p_PublisherID,
   
p_PublisherName,p_Address,
p_ContactInfo );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertReservation` (IN `p_ReservationID` INT(11), IN `p_UserID` INT(11), IN `p_BookID` INT(11), IN `p_ReservationDATE` DATE, IN `p_Statu` VARCHAR(20))   BEGIN
    INSERT INTO Reservations (ReservationID,     
UserID,     
BookID,     
ReservationDATE,      
Statu)
VALUES (P_ReservationID,     
P_UserID,     
P_BookID,     
P_ReservationDATE,      
P_Statu);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertReview` (IN `p_ReviewID` INT(11), IN `p_UserID` INT(11), IN `p_BookID` INT(11), IN `p_Rating` INT(11), IN `p_ReviewText` TEXT, IN `p_ReviewDate` DATE)   BEGIN
    INSERT INTO reviews (ReviewID, 
UserID, 
BookID, 
Rating, 
ReviewText, 
ReviewDate   
)
VALUES (p_ReviewID, 
p_UserID, 
p_BookID, 
p_Rating, 
p_ReviewText, 
p_ReviewDate );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertUser` (IN `p_UserID` INT(11), IN `p_FirstName` VARCHAR(50), IN `p_LastName` VARCHAR(50), IN `p_DateOfBirth` DATE, IN `p_Address` VARCHAR(200), IN `p_ContactInfo` VARCHAR(100))   BEGIN
    INSERT INTO users (UserID,
FirstName,    
LastName, 
DateOfBirth, 
Address, 
Contact
)
    VALUES (p_UserID,
p_FirstName,    
p_LastName, 
p_DateOfBirth, 
p_Address, 
p_Contact);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateFormat` (IN `p_FormatID` INT(11), IN `p_FormatName` VARCHAR(50), IN `p_FormatDescription` TEXT)   BEGIN
    UPDATE formats
    SET
        formatName = p_new_formatName,
        FormatDescription = p_new_FormatDescription
    WHERE
        formatID= p_formatID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateLanguage` (IN `p_LanguageID` INT(11), IN `p_LanguageName` VARCHAR(50), IN `p_CountryOfOrigin` VARCHAR(50))   BEGIN
    UPDATE languages
    SET
        languageName = p_new_languageName,
        CountryOfOrigin = p_new_CountryOfOrigin 
        
    WHERE
        languageID = p_languageID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `AuthorID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Biography` text DEFAULT NULL,
  `BirthDate` date DEFAULT NULL,
  `DeathDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`AuthorID`, `FirstName`, `LastName`, `Biography`, `BirthDate`, `DeathDate`) VALUES
(10, 'lydie', 'ishimwe', 'author', '1990-01-01', '2050-03-19'),
(11, 'emma', 'cyiza', 'author', '1987-01-09', '2060-12-23'),
(12, 'abby', 'keza', 'author', '1987-12-10', '2070-12-10');

--
-- Triggers `authors`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertAuthor` AFTER INSERT ON `authors` FOR EACH ROW BEGIN

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `authors_view`
-- (See below for the actual view)
--
CREATE TABLE `authors_view` (
`AuthorID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`Biography` text
,`BirthDate` date
,`DeathDate` date
);

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `BookID` int(11) NOT NULL,
  `Title` varchar(200) DEFAULT NULL,
  `ISBN` varchar(20) DEFAULT NULL,
  `PublicationYear` int(11) DEFAULT NULL,
  `GenreID` int(11) DEFAULT NULL,
  `LanguageID` int(11) DEFAULT NULL,
  `PublisherID` int(11) DEFAULT NULL,
  `FormatID` int(11) DEFAULT NULL,
  `CopiesAvailable` int(11) DEFAULT NULL,
  `CopiesTotal` int(11) DEFAULT NULL,
  `AverageRating` decimal(3,2) DEFAULT NULL,
  `Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`BookID`, `Title`, `ISBN`, `PublicationYear`, `GenreID`, `LanguageID`, `PublisherID`, `FormatID`, `CopiesAvailable`, `CopiesTotal`, `AverageRating`, `Description`) VALUES
(203, 'math', '560-001-789', 1789, 17, 111, 14, 20, 345, 2000, '9.99', 'good'),
(204, 'chemistry', '123-323', 1432, 18, 101, 13, 120, 2890, 23445, '9.99', 'clear');

-- --------------------------------------------------------

--
-- Stand-in structure for view `booksview`
-- (See below for the actual view)
--
CREATE TABLE `booksview` (
`BookID` int(11)
,`Title` varchar(200)
,`Author` varchar(101)
,`Genre` varchar(50)
,`ISBN` varchar(20)
,`PublicationYear` int(11)
,`Language` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `books_view`
-- (See below for the actual view)
--
CREATE TABLE `books_view` (
`BookID` int(11)
,`Title` varchar(200)
,`ISBN` varchar(20)
,`PublicationYear` int(11)
,`GenreID` int(11)
,`LanguageID` int(11)
,`PublisherID` int(11)
,`FormatID` int(11)
,`CopiesAvailable` int(11)
,`CopiesTotal` int(11)
,`AverageRating` decimal(3,2)
,`Description` text
);

-- --------------------------------------------------------

--
-- Table structure for table `borrowings`
--

CREATE TABLE `borrowings` (
  `BorrowingID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `BookID` int(11) DEFAULT NULL,
  `BorrowDate` date DEFAULT NULL,
  `ReturnDate` date DEFAULT NULL,
  `FineAmount` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `borrowings`
--

INSERT INTO `borrowings` (`BorrowingID`, `UserID`, `BookID`, `BorrowDate`, `ReturnDate`, `FineAmount`) VALUES
(501, 302, 204, '0000-00-00', '0000-00-00', '999999.99');

-- --------------------------------------------------------

--
-- Stand-in structure for view `borrowings_view`
-- (See below for the actual view)
--
CREATE TABLE `borrowings_view` (
`BorrowingID` int(11)
,`UserID` int(11)
,`BookID` int(11)
,`BorrowDate` date
,`ReturnDate` date
,`FineAmount` decimal(8,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `formats`
--

CREATE TABLE `formats` (
  `FormatID` int(11) NOT NULL,
  `FormatName` varchar(50) DEFAULT NULL,
  `FormatDescription` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `formats`
--

INSERT INTO `formats` (`FormatID`, `FormatName`, `FormatDescription`) VALUES
(20, 'x', 'organise'),
(120, 'y', 'satsfied');

-- --------------------------------------------------------

--
-- Stand-in structure for view `formats_view`
-- (See below for the actual view)
--
CREATE TABLE `formats_view` (
`FormatID` int(11)
,`FormatName` varchar(50)
,`FormatDescription` text
);

-- --------------------------------------------------------

--
-- Table structure for table `genres`
--

CREATE TABLE `genres` (
  `GenreID` int(11) NOT NULL,
  `GenreName` varchar(50) DEFAULT NULL,
  `Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `genres`
--

INSERT INTO `genres` (`GenreID`, `GenreName`, `Description`) VALUES
(17, 'drama', 'good'),
(18, 'novels', 'cute');

-- --------------------------------------------------------

--
-- Stand-in structure for view `genres_view`
-- (See below for the actual view)
--
CREATE TABLE `genres_view` (
`GenreID` int(11)
,`GenreName` varchar(50)
,`Description` text
);

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `LanguageID` int(11) NOT NULL,
  `LanguageName` varchar(50) DEFAULT NULL,
  `CountryOfOrigin` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`LanguageID`, `LanguageName`, `CountryOfOrigin`) VALUES
(101, 'kinyarwanda', 'america'),
(111, 'english', 'Rwanda');

--
-- Triggers `languages`
--
DELIMITER $$
CREATE TRIGGER `AfterUpdateLanguage` AFTER UPDATE ON `languages` FOR EACH ROW BEGIN
    -- Insert code for your desired actions here
    -- For example, you might want to log the update or update related records
    -- You can reference NEW.column_name and OLD.column_name to access the new and old language data
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `languages_view`
-- (See below for the actual view)
--
CREATE TABLE `languages_view` (
`LanguageID` int(11)
,`LanguageName` varchar(50)
,`CountryOfOrigin` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `publishers`
--

CREATE TABLE `publishers` (
  `PublisherID` int(11) NOT NULL,
  `PublisherName` varchar(100) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `ContactInfo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `publishers`
--

INSERT INTO `publishers` (`PublisherID`, `PublisherName`, `Address`, `ContactInfo`) VALUES
(13, 'kamanzi', 'huye', '0788888907'),
(14, 'karabo', 'gasabo', '0788888999'),
(15, 'kinazi', 'gicumbi', '07988888880');

-- --------------------------------------------------------

--
-- Stand-in structure for view `publishers_view`
-- (See below for the actual view)
--
CREATE TABLE `publishers_view` (
`PublisherID` int(11)
,`PublisherName` varchar(100)
,`Address` varchar(200)
,`ContactInfo` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `ReservationID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `BookID` int(11) DEFAULT NULL,
  `ReservationDate` date DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`ReservationID`, `UserID`, `BookID`, `ReservationDate`, `Status`) VALUES
(600, 301, 203, '0000-00-00', 'document'),
(601, 302, 204, '0000-00-00', 'imformation of user');

-- --------------------------------------------------------

--
-- Stand-in structure for view `reservations_view`
-- (See below for the actual view)
--
CREATE TABLE `reservations_view` (
`ReservationID` int(11)
,`UserID` int(11)
,`BookID` int(11)
,`ReservationDate` date
,`Status` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `ReviewID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `BookID` int(11) DEFAULT NULL,
  `Rating` int(11) DEFAULT NULL,
  `ReviewText` text DEFAULT NULL,
  `ReviewDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`ReviewID`, `UserID`, `BookID`, `Rating`, `ReviewText`, `ReviewDate`) VALUES
(400, 301, 203, 12, 'erros writting', '0000-00-00'),
(401, 302, 204, 123, 'fault', '0000-00-00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `reviews_view`
-- (See below for the actual view)
--
CREATE TABLE `reviews_view` (
`ReviewID` int(11)
,`UserID` int(11)
,`BookID` int(11)
,`Rating` int(11)
,`ReviewText` text
,`ReviewDate` date
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `ContactInfo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `FirstName`, `LastName`, `DateOfBirth`, `Address`, `ContactInfo`) VALUES
(301, 'lydie', 'cyusa', '0000-00-00', 'huye', '78899909'),
(302, 'ella', 'cyirabo', '0000-00-00', 'rubavu', '78299909');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertUser` AFTER INSERT ON `users` FOR EACH ROW BEGIN
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateUser` AFTER UPDATE ON `users` FOR EACH ROW BEGIN

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `users_view`
-- (See below for the actual view)
--
CREATE TABLE `users_view` (
`UserID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`DateOfBirth` date
,`Address` varchar(200)
,`ContactInfo` varchar(100)
);

-- --------------------------------------------------------

--
-- Structure for view `authors_view`
--
DROP TABLE IF EXISTS `authors_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `authors_view`  AS SELECT `authors`.`AuthorID` AS `AuthorID`, `authors`.`FirstName` AS `FirstName`, `authors`.`LastName` AS `LastName`, `authors`.`Biography` AS `Biography`, `authors`.`BirthDate` AS `BirthDate`, `authors`.`DeathDate` AS `DeathDate` FROM `authors``authors`  ;

-- --------------------------------------------------------

--
-- Structure for view `booksview`
--
DROP TABLE IF EXISTS `booksview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `booksview`  AS SELECT `b`.`BookID` AS `BookID`, `b`.`Title` AS `Title`, concat(`a`.`FirstName`,' ',`a`.`LastName`) AS `Author`, `g`.`GenreName` AS `Genre`, `b`.`ISBN` AS `ISBN`, `b`.`PublicationYear` AS `PublicationYear`, `l`.`LanguageName` AS `Language` FROM (((`books` `b` join `authors` `a` on(`b`.`BookID` = `a`.`AuthorID`)) join `genres` `g` on(`b`.`GenreID` = `g`.`GenreID`)) join `languages` `l` on(`b`.`LanguageID` = `l`.`LanguageID`))  ;

-- --------------------------------------------------------

--
-- Structure for view `books_view`
--
DROP TABLE IF EXISTS `books_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `books_view`  AS SELECT `books`.`BookID` AS `BookID`, `books`.`Title` AS `Title`, `books`.`ISBN` AS `ISBN`, `books`.`PublicationYear` AS `PublicationYear`, `books`.`GenreID` AS `GenreID`, `books`.`LanguageID` AS `LanguageID`, `books`.`PublisherID` AS `PublisherID`, `books`.`FormatID` AS `FormatID`, `books`.`CopiesAvailable` AS `CopiesAvailable`, `books`.`CopiesTotal` AS `CopiesTotal`, `books`.`AverageRating` AS `AverageRating`, `books`.`Description` AS `Description` FROM `books``books`  ;

-- --------------------------------------------------------

--
-- Structure for view `borrowings_view`
--
DROP TABLE IF EXISTS `borrowings_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `borrowings_view`  AS SELECT `borrowings`.`BorrowingID` AS `BorrowingID`, `borrowings`.`UserID` AS `UserID`, `borrowings`.`BookID` AS `BookID`, `borrowings`.`BorrowDate` AS `BorrowDate`, `borrowings`.`ReturnDate` AS `ReturnDate`, `borrowings`.`FineAmount` AS `FineAmount` FROM `borrowings``borrowings`  ;

-- --------------------------------------------------------

--
-- Structure for view `formats_view`
--
DROP TABLE IF EXISTS `formats_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `formats_view`  AS SELECT `formats`.`FormatID` AS `FormatID`, `formats`.`FormatName` AS `FormatName`, `formats`.`FormatDescription` AS `FormatDescription` FROM `formats``formats`  ;

-- --------------------------------------------------------

--
-- Structure for view `genres_view`
--
DROP TABLE IF EXISTS `genres_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `genres_view`  AS SELECT `genres`.`GenreID` AS `GenreID`, `genres`.`GenreName` AS `GenreName`, `genres`.`Description` AS `Description` FROM `genres``genres`  ;

-- --------------------------------------------------------

--
-- Structure for view `languages_view`
--
DROP TABLE IF EXISTS `languages_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `languages_view`  AS SELECT `languages`.`LanguageID` AS `LanguageID`, `languages`.`LanguageName` AS `LanguageName`, `languages`.`CountryOfOrigin` AS `CountryOfOrigin` FROM `languages``languages`  ;

-- --------------------------------------------------------

--
-- Structure for view `publishers_view`
--
DROP TABLE IF EXISTS `publishers_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `publishers_view`  AS SELECT `publishers`.`PublisherID` AS `PublisherID`, `publishers`.`PublisherName` AS `PublisherName`, `publishers`.`Address` AS `Address`, `publishers`.`ContactInfo` AS `ContactInfo` FROM `publishers``publishers`  ;

-- --------------------------------------------------------

--
-- Structure for view `reservations_view`
--
DROP TABLE IF EXISTS `reservations_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reservations_view`  AS SELECT `reservations`.`ReservationID` AS `ReservationID`, `reservations`.`UserID` AS `UserID`, `reservations`.`BookID` AS `BookID`, `reservations`.`ReservationDate` AS `ReservationDate`, `reservations`.`Status` AS `Status` FROM `reservations``reservations`  ;

-- --------------------------------------------------------

--
-- Structure for view `reviews_view`
--
DROP TABLE IF EXISTS `reviews_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reviews_view`  AS SELECT `reviews`.`ReviewID` AS `ReviewID`, `reviews`.`UserID` AS `UserID`, `reviews`.`BookID` AS `BookID`, `reviews`.`Rating` AS `Rating`, `reviews`.`ReviewText` AS `ReviewText`, `reviews`.`ReviewDate` AS `ReviewDate` FROM `reviews``reviews`  ;

-- --------------------------------------------------------

--
-- Structure for view `users_view`
--
DROP TABLE IF EXISTS `users_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `users_view`  AS SELECT `users`.`UserID` AS `UserID`, `users`.`FirstName` AS `FirstName`, `users`.`LastName` AS `LastName`, `users`.`DateOfBirth` AS `DateOfBirth`, `users`.`Address` AS `Address`, `users`.`ContactInfo` AS `ContactInfo` FROM `users``users`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`AuthorID`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`BookID`);

--
-- Indexes for table `borrowings`
--
ALTER TABLE `borrowings`
  ADD PRIMARY KEY (`BorrowingID`);

--
-- Indexes for table `formats`
--
ALTER TABLE `formats`
  ADD PRIMARY KEY (`FormatID`);

--
-- Indexes for table `genres`
--
ALTER TABLE `genres`
  ADD PRIMARY KEY (`GenreID`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`LanguageID`);

--
-- Indexes for table `publishers`
--
ALTER TABLE `publishers`
  ADD PRIMARY KEY (`PublisherID`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`ReservationID`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`ReviewID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
