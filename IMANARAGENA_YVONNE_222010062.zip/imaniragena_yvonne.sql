-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 11:40 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imaniragena_yvonne`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteProduct` (IN `ProductID` INT)   BEGIN
    DELETE FROM products
    WHERE ProductID = ProductID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayCategory` ()   BEGIN
    SELECT * FROM category;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayProducts` ()   BEGIN
    SELECT * FROM products;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GET_category` (IN `CategoryID` INT, OUT `CategoryName` VARCHAR(20), OUT `ParentCategoryID` INT)   BEGIN
    SELECT CategoryName, ParentCategoryID 
    INTO CategoryName,ParentCategoryID
    FROM category
    WHERE CategoryID = CategoryID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GET_PRODUCT` (IN `ProductID` INT, OUT `Name` VARCHAR(20), OUT `Description` VARCHAR(20))   BEGIN
    SELECT Name, Description 
    INTO Name, Description
    FROM product 
    WHERE ProductID = ProductID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GET_supplier` (IN `SupplierID` INT, OUT `SupplierName` VARCHAR(20), OUT `ContactName` VARCHAR(20), OUT `Phone` VARCHAR(20))   BEGIN
    SELECT SupplierName, ContactName,Phone 
    INTO SupplierName, ContactName,Phone
    FROM supplier
    WHERE SupplierID = SupplierID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertProduct` (IN `ProductName` VARCHAR(255), IN `ProductDescription` TEXT, IN `ProductPrice` DECIMAL(10,2))   BEGIN
    INSERT INTO products (ProductName, ProductDescription, ProductPrice)
    VALUES ("RICE", "STOCK", "1000");
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateProduct` (IN `ProductID` INT, IN `NewProductName` VARCHAR(255), IN `NewProductDescription` TEXT, IN `NewProductPrice` DECIMAL(10,2))   BEGIN
    UPDATE products
    SET
        ProductName = NewProductName,
        ProductDescription = NewProductDescription,
        ProductPrice = NewProductPrice
    WHERE
        ProductID = ProductID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(100) NOT NULL,
  `ParentCategoryID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CategoryID`, `CategoryName`, `ParentCategoryID`) VALUES
(1, 'Electronics', NULL),
(2, 'Clothing', NULL),
(3, 'Laptops', 1),
(4, 'Smartphones', 1),
(5, 'Men\'s', 2),
(6, 'Women\'s', 2);

-- --------------------------------------------------------

--
-- Stand-in structure for view `onlinestoreview`
-- (See below for the actual view)
--
CREATE TABLE `onlinestoreview` (
`OrderID` int(11)
,`OrderDate` datetime
,`ShippingAddress` varchar(255)
,`paymentMethod` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `orderitem`
--

CREATE TABLE `orderitem` (
  `OrderItemID` int(11) NOT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `Quantity` int(11) NOT NULL,
  `PricePerUnit` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderitem`
--

INSERT INTO `orderitem` (`OrderItemID`, `OrderID`, `ProductID`, `Quantity`, `PricePerUnit`) VALUES
(20, 100, 121, 2, 699.99),
(21, 102, 122, 1, 1299.99),
(22, 101, 123, 3, 19.99),
(23, 100, 122, 2, 49.99);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `OrderDate` datetime DEFAULT current_timestamp(),
  `ShippingAddress` varchar(255) DEFAULT NULL,
  `PaymentMethod` varchar(100) DEFAULT NULL,
  `OrderStatus` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `UserID`, `OrderDate`, `ShippingAddress`, `PaymentMethod`, `OrderStatus`) VALUES
(100, 2, '2023-09-04 12:37:34', '789 Seller Ln', 'PayPal', 'Shipped'),
(101, 2, '2023-09-04 12:37:34', '456 Customer Ave', 'Credit Card', 'Delivered'),
(102, 4, '2023-09-04 12:37:34', '202 Seller Blvd', 'Credit Card', 'Processing'),
(103, 3, '2023-09-04 12:37:34', '101 Customer Rd', 'Credit Card', 'Processing');

-- --------------------------------------------------------

--
-- Table structure for table `paymenttransaction`
--

CREATE TABLE `paymenttransaction` (
  `TransactionID` int(11) NOT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `PaymentDate` datetime DEFAULT current_timestamp(),
  `Amount` decimal(10,2) NOT NULL,
  `PaymentStatus` varchar(50) DEFAULT NULL,
  `PaymentMethod` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paymenttransaction`
--

INSERT INTO `paymenttransaction` (`TransactionID`, `OrderID`, `PaymentDate`, `Amount`, `PaymentStatus`, `PaymentMethod`) VALUES
(11, 101, '2023-09-04 12:56:05', 1399.98, 'Success', 'Credit Card'),
(12, 102, '2023-09-04 12:56:05', 1299.99, 'Success', 'PayPal'),
(13, 103, '2023-09-04 12:56:05', 159.94, 'Success', 'Credit Card'),
(14, 100, '2023-09-04 12:56:05', 99.98, 'Success', 'Credit Card');

-- --------------------------------------------------------

--
-- Stand-in structure for view `popularproducts`
-- (See below for the actual view)
--
CREATE TABLE `popularproducts` (
`Name` varchar(255)
,`StockQuantity` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProductID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` text DEFAULT NULL,
  `Price` decimal(10,2) NOT NULL,
  `StockQuantity` int(11) NOT NULL,
  `CategoryID` int(11) DEFAULT NULL,
  `SupplierID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductID`, `Name`, `Description`, `Price`, `StockQuantity`, `CategoryID`, `SupplierID`) VALUES
(120, 'Smartphone Model A', 'High-end smartphone', 699.99, 100, 4, 1),
(121, 'Laptop Model X', 'Powerful laptop with great features', 1299.99, 50, 3, 2),
(122, 'T-shirt - Men\'s Small', 'Cotton T-shirt for men', 19.99, 200, 6, 3),
(123, 'Dress - Women\'s Medium', 'Elegant dress for women', 49.99, 150, 2, 1);

--
-- Triggers `product`
--
DELIMITER $$
CREATE TRIGGER `after_product_insert` AFTER INSERT ON `product` FOR EACH ROW BEGIN
    DECLARE p_name VARCHAR(20);
    DECLARE p_description VARCHAR(20);
    
    -- Call the GET_PRODUCT procedure to retrieve the data
    CALL GET_PRODUCT(NEW.ProductID, p_name, p_description);
    
    -- Update the Name and Description columns in the product table
    UPDATE product
    SET Name = p_name,
        Description = p_description
    WHERE ProductID = NEW.ProductID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_product_update` AFTER UPDATE ON `product` FOR EACH ROW BEGIN
    DECLARE p_name VARCHAR(20);
    DECLARE p_description VARCHAR(20);
    
    -- Call the GET_PRODUCT procedure to retrieve the updated data
    CALL GET_PRODUCT(NEW.ProductID, p_name, p_description);
    
    -- Update the Name and Description columns in the product table
    UPDATE product
    SET Name = p_name,
        Description = p_description
    WHERE ProductID = NEW.ProductID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_product_delete` BEFORE DELETE ON `product` FOR EACH ROW BEGIN
    -- You can perform any necessary actions before the row is deleted here.
    -- For example, you may want to log the deleted data or perform other cleanup tasks.
    
    -- Note: You can't use the GET_PRODUCT procedure to retrieve data in a DELETE trigger
    -- because the row is being deleted.
    
    -- This trigger is executed before the row is deleted, so you can perform any required actions.
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `promotion`
--

CREATE TABLE `promotion` (
  `PromotionID` int(11) NOT NULL,
  `CouponCode` varchar(50) NOT NULL,
  `DiscountAmount` decimal(10,2) NOT NULL,
  `ExpirationDate` date DEFAULT NULL,
  `ApplicableProducts` text DEFAULT NULL,
  `UsageLimits` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `promotion`
--

INSERT INTO `promotion` (`PromotionID`, `CouponCode`, `DiscountAmount`, `ExpirationDate`, `ApplicableProducts`, `UsageLimits`) VALUES
(1, 'SUMMER10', 10.00, '2023-09-30', '1,3,6', 100),
(2, 'FALLSALE', 15.00, '2023-10-15', '2,7', 50),
(3, 'WINTER20', 20.00, '2023-12-31', '4', 200);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `ReviewID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `Rating` int(11) NOT NULL,
  `ReviewText` text DEFAULT NULL,
  `ReviewDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`ReviewID`, `UserID`, `ProductID`, `Rating`, `ReviewText`, `ReviewDate`) VALUES
(40, 2, 120, 5, 'Great phone!', '2023-09-04 13:04:57'),
(41, 3, 122, 4, 'Impressive laptop', '2023-09-04 13:04:57'),
(42, 4, 123, 5, 'Comfortable T-shirt', '2023-09-04 13:04:57'),
(43, 2, 121, 4, 'Lovely dress', '2023-09-04 13:04:57');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `RoleID` int(11) NOT NULL,
  `RoleName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`RoleID`, `RoleName`) VALUES
(1, 'Admin'),
(2, 'Customer'),
(3, 'Seller');

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `ShippingID` int(11) NOT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `ShippingCarrier` varchar(100) DEFAULT NULL,
  `TrackingNumber` varchar(100) DEFAULT NULL,
  `EstimatedDeliveryDate` date DEFAULT NULL,
  `ShippingStatus` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`ShippingID`, `OrderID`, `ShippingCarrier`, `TrackingNumber`, `EstimatedDeliveryDate`, `ShippingStatus`) VALUES
(30, 101, 'UPS', '123456789', '2023-09-10', 'Shipped'),
(31, 102, 'FedEx', '987654321', '2023-09-12', 'Delivered'),
(32, 103, 'DHL', '555555555', '2023-09-15', 'Processing'),
(33, 100, 'USPS', '111111111', '2023-09-11', 'Shipped');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `StoreID` int(11) NOT NULL,
  `StoreName` varchar(100) NOT NULL,
  `Description` text DEFAULT NULL,
  `ContactInformation` varchar(255) DEFAULT NULL,
  `Logo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`StoreID`, `StoreName`, `Description`, `ContactInformation`, `Logo`) VALUES
(11, 'Store 1', 'Electronics and Gadgets', '123 Store St', 'store1.jpg'),
(12, 'Store 2', 'Fashion Boutique', '456 Store Ave', 'store2.jpg'),
(13, 'Store 3', 'Home Decor and Furniture', '789 Store Rd', 'store3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `SupplierID` int(11) NOT NULL,
  `SupplierName` varchar(100) NOT NULL,
  `ContactName` varchar(100) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`SupplierID`, `SupplierName`, `ContactName`, `Phone`, `Email`, `Address`) VALUES
(1, 'Supplier1 Co.', 'John Supplier', '+1111111111', 'supplier1@example.com', '123 Supplier St'),
(2, 'Supplier2 Inc.', 'Jane Supplier', '+2222222222', 'supplier2@example.com', '456 Supplier Ave'),
(3, 'Supplier3 Ltd.', 'Bob Supplier', '+3333333333', 'supplier3@example.com', '789 Supplier Rd');

-- --------------------------------------------------------

--
-- Table structure for table `user_inf`
--

CREATE TABLE `user_inf` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `RoleID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_inf`
--

INSERT INTO `user_inf` (`UserID`, `Username`, `Password`, `Email`, `FirstName`, `LastName`, `Phone`, `Address`, `RoleID`) VALUES
(1, 'admin_user', 'admin_password', 'admin@example.com', 'Admin', 'User', '+1234567890', '123 Admin St', 1),
(2, 'customer10', 'customer_password', 'customer1@example.com', 'yvonne', 'Doe', '+9876543210', '456 Customer Ave', 2),
(3, 'customer2', 'customer_password', 'customer2@example.com', 'Jane', 'Smith', '+1112233445', '789 Customer Rd', 2),
(4, 'seller1', 'seller_password', 'seller1@example.com', 'Seller', 'One', '+5556667777', '101 Seller Ln', 3),
(5, 'seller2', 'seller_password', 'seller2@example.com', 'Seller', 'Two', '+9998887777', '202 Seller Blvd', 3);

-- --------------------------------------------------------

--
-- Structure for view `onlinestoreview`
--
DROP TABLE IF EXISTS `onlinestoreview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `onlinestoreview`  AS SELECT `orders`.`OrderID` AS `OrderID`, `orders`.`OrderDate` AS `OrderDate`, `orders`.`ShippingAddress` AS `ShippingAddress`, `orders`.`PaymentMethod` AS `paymentMethod` FROM `orders` ;

-- --------------------------------------------------------

--
-- Structure for view `popularproducts`
--
DROP TABLE IF EXISTS `popularproducts`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `popularproducts`  AS SELECT `p`.`Name` AS `Name`, `p`.`StockQuantity` AS `StockQuantity` FROM (`product` `p` join (select `orderitem`.`ProductID` AS `ProductID`,`orderitem`.`Quantity` AS `QuantitySold` from `orderitem` group by `orderitem`.`ProductID` having sum(`orderitem`.`Quantity`) > 50) `o` on(`p`.`ProductID` = `o`.`ProductID`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CategoryID`),
  ADD KEY `ParentCategoryID` (`ParentCategoryID`);

--
-- Indexes for table `orderitem`
--
ALTER TABLE `orderitem`
  ADD PRIMARY KEY (`OrderItemID`),
  ADD KEY `OrderID` (`OrderID`),
  ADD KEY `ProductID` (`ProductID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `paymenttransaction`
--
ALTER TABLE `paymenttransaction`
  ADD PRIMARY KEY (`TransactionID`),
  ADD KEY `OrderID` (`OrderID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductID`),
  ADD KEY `CategoryID` (`CategoryID`),
  ADD KEY `SupplierID` (`SupplierID`);

--
-- Indexes for table `promotion`
--
ALTER TABLE `promotion`
  ADD PRIMARY KEY (`PromotionID`),
  ADD UNIQUE KEY `CouponCode` (`CouponCode`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`ReviewID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `ProductID` (`ProductID`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`RoleID`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`ShippingID`),
  ADD KEY `OrderID` (`OrderID`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`StoreID`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`SupplierID`);

--
-- Indexes for table `user_inf`
--
ALTER TABLE `user_inf`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `RoleID` (`RoleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `paymenttransaction`
--
ALTER TABLE `paymenttransaction`
  MODIFY `TransactionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `promotion`
--
ALTER TABLE `promotion`
  MODIFY `PromotionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_inf`
--
ALTER TABLE `user_inf`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `category`
--
ALTER TABLE `category`
  ADD CONSTRAINT `category_ibfk_1` FOREIGN KEY (`ParentCategoryID`) REFERENCES `category` (`CategoryID`);

--
-- Constraints for table `orderitem`
--
ALTER TABLE `orderitem`
  ADD CONSTRAINT `orderitem_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`),
  ADD CONSTRAINT `orderitem_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user_inf` (`UserID`);

--
-- Constraints for table `paymenttransaction`
--
ALTER TABLE `paymenttransaction`
  ADD CONSTRAINT `paymenttransaction_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `category` (`CategoryID`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`SupplierID`) REFERENCES `supplier` (`SupplierID`);

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user_inf` (`UserID`),
  ADD CONSTRAINT `review_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`);

--
-- Constraints for table `shipping`
--
ALTER TABLE `shipping`
  ADD CONSTRAINT `shipping_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`);

--
-- Constraints for table `user_inf`
--
ALTER TABLE `user_inf`
  ADD CONSTRAINT `user_inf_ibfk_1` FOREIGN KEY (`RoleID`) REFERENCES `role` (`RoleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
