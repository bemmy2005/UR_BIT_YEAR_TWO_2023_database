-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2023 at 10:04 AM


--
-- Database: `kayihura_pio_222004477`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendee`
--

CREATE TABLE `attendee` (
  `attendee_id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendee`
--

INSERT INTO `attendee` (`attendee_id`, `event_id`, `user_id`) VALUES
(1, 7, 1),
(2, 8, 2),
(3, 9, 3);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `venue_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `event_name`, `date`, `venue_id`) VALUES
(7, 'summer concert', '2023-10-01', 4),
(8, 'feasssa tournment', '2023-09-21', 5),
(9, 'sport tournment', '2023-09-30', 6);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_event_e`
-- (See below for the actual view)
--
CREATE TABLE `insert_event_e` (
`event_id` int(11)
,`event_name` varchar(255)
,`date` date
,`venue_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_user_p`
-- (See below for the actual view)
--
CREATE TABLE `insert_user_p` (
`user_id` int(11)
,`user_name` varchar(255)
,`email` varchar(255)
,`role` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `performer`
--

CREATE TABLE `performer` (
  `performer_id` int(11) NOT NULL,
  `performer_name` varchar(255) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `performer`
--

INSERT INTO `performer` (`performer_id`, `performer_name`, `type`) VALUES
(1, 'rock_band', 'band'),
(2, 'artist', 'speaker'),
(3, 'messi', 'foot'),
(4, 'rock_band', 'band'),
(5, 'artist', 'speaker'),
(6, 'footballer', 'foot'),
(7, 'rock_band', 'band'),
(8, 'artist', 'speaker'),
(9, 'messi', 'foot');

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `ticket_id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `ticket_type` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`ticket_id`, `event_id`, `ticket_type`, `price`) VALUES
(5, 7, 'VIP', 10000),
(6, 8, 'REGULAR', 5000),
(7, 9, 'GENERAL', 2000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `email`, `role`) VALUES
(1, 'kayihura', 'kayihura@gmail.com', 'event_organiser'),
(2, 'pio', 'pio@gmail.com', 'admin'),
(3, 'pierre', 'pierre@gmail.com', 'admin2');

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_p`
-- (See below for the actual view)
--
CREATE TABLE `user_p` (
`user_id` int(11)
,`user_name` varchar(255)
,`email` varchar(255)
,`role` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE `venue` (
  `venue_id` int(11) NOT NULL,
  `venue_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` (`venue_id`, `venue_name`, `address`, `capacity`) VALUES
(4, 'music hall', '123mainst', 1000),
(5, 'music hall', 'main auditorium', 5000),
(6, 'music hall', 'outdor main auditorium', 10000);

-- --------------------------------------------------------

--
-- Structure for view `insert_event_e`
--
DROP TABLE IF EXISTS `insert_event_e`;

CREATE ALGORITHM=UNDEFINED DEFINER=`KAYIHURA_PIO_222004477`@`localhost` SQL SECURITY DEFINER VIEW `insert_event_e`  AS SELECT `event`.`event_id` AS `event_id`, `event`.`event_name` AS `event_name`, `event`.`date` AS `date`, `event`.`venue_id` AS `venue_id` FROM `event` WHERE 1 = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_user_p`
--
DROP TABLE IF EXISTS `insert_user_p`;

CREATE ALGORITHM=UNDEFINED DEFINER=`KAYIHURA_PIO_222004477`@`localhost` SQL SECURITY DEFINER VIEW `insert_user_p`  AS SELECT `user`.`user_id` AS `user_id`, `user`.`user_name` AS `user_name`, `user`.`email` AS `email`, `user`.`role` AS `role` FROM `user` ;

-- --------------------------------------------------------

--
-- Structure for view `user_p`
--
DROP TABLE IF EXISTS `user_p`;

CREATE ALGORITHM=UNDEFINED DEFINER=`KAYIHURA_PIO_222004477`@`localhost` SQL SECURITY DEFINER VIEW `user_p`  AS SELECT `user`.`user_id` AS `user_id`, `user`.`user_name` AS `user_name`, `user`.`email` AS `email`, `user`.`role` AS `role` FROM `user` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendee`
--
ALTER TABLE `attendee`
  ADD PRIMARY KEY (`attendee_id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `venue_id` (`venue_id`);

--
-- Indexes for table `performer`
--
ALTER TABLE `performer`
  ADD PRIMARY KEY (`performer_id`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`ticket_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `venue`
--
ALTER TABLE `venue`
  ADD PRIMARY KEY (`venue_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendee`
--
ALTER TABLE `attendee`
  MODIFY `attendee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `performer`
--
ALTER TABLE `performer`
  MODIFY `performer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `venue`
--
ALTER TABLE `venue`
  MODIFY `venue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendee`
--
ALTER TABLE `attendee`
  ADD CONSTRAINT `attendee_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`),
  ADD CONSTRAINT `attendee_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `event`
--
ALTER TABLE `event`
  ADD CONSTRAINT `event_ibfk_1` FOREIGN KEY (`venue_id`) REFERENCES `venue` (`venue_id`);

--
-- Constraints for table `ticket`
--
ALTER TABLE `ticket`
  ADD CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`);
DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `CreateEventSummaryView`()
BEGIN
    
    CREATE OR REPLACE VIEW EventSummary AS
    SELECT
        e.event_id,
        e.event_name,
        e.date,
        v.venue_name,
        COUNT(a.attendee_id) AS total_attendees
    FROM
        events e
    JOIN
        venues v ON e.venue_id = v.venue_id
    LEFT JOIN
        attendees a ON e.event_id = a.event_id
    GROUP BY
        e.event_id;

    SELECT 'EventSummary view created successfully.' AS message;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `DeleteEventData`(
    IN p_event_name VARCHAR(255)
)
BEGIN
    DECLARE v_event_id INT;
    
    
    SELECT event_id INTO v_event_id FROM events WHERE event_name = p_event_name;
    
    
    DELETE FROM tickets WHERE event_id = v_event_id;
    
    
    DELETE FROM events WHERE event_id = v_event_id;
    
    SELECT CONCAT('Event "', p_event_name, '" and associated tickets deleted successfully.') AS message;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `DisplayAllData`()
BEGIN
    
    SELECT * FROM users;
    
    
    SELECT * FROM venues;
    
    
    SELECT * FROM events;
    
    
    SELECT * FROM performers;
    
    
    SELECT * FROM tickets;
    
    
    SELECT * FROM attendees;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `InsertAttendee`(
    IN p_event_id INT,
    IN p_user_id INT
)
BEGIN
    INSERT INTO attendees (event_id, user_id)
    VALUES (p_event_id, p_user_id);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `InsertEvent`(
    IN p_event_name VARCHAR(255),
    IN p_date DATE,
    IN p_venue_id INT
)
BEGIN
    INSERT INTO events (event_name, date, venue_id)
    VALUES (p_event_name, p_date, p_venue_id);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `InsertEventData`(
    IN p_user_name VARCHAR(255),
    IN p_email VARCHAR(255),
    IN p_role VARCHAR(255),
    IN p_event_name VARCHAR(255),
    IN p_date DATE,
    IN p_venue_name VARCHAR(255),
    IN p_address VARCHAR(255),
    IN p_capacity INT,
    IN p_performer_name VARCHAR(255),
    IN p_type VARCHAR(50),
    IN p_ticket_type VARCHAR(255),
    IN p_price INT
)
BEGIN
    DECLARE v_user_id INT;
    DECLARE v_event_id INT;
    DECLARE v_venue_id INT;
    DECLARE v_performer_id INT;
    DECLARE v_ticket_id INT;

    
    INSERT INTO users (user_name, email, role) VALUES (p_user_name, p_email, p_role);
    SET v_user_id = LAST_INSERT_ID();

    
    INSERT INTO venues (venue_name, address, capacity) VALUES (p_venue_name, p_address, p_capacity);
    SET v_venue_id = LAST_INSERT_ID();

    
    INSERT INTO events (event_name, date, venue_id) VALUES (p_event_name, p_date, v_venue_id);
    SET v_event_id = LAST_INSERT_ID();

    
    INSERT INTO performers (performer_name, type) VALUES (p_performer_name, p_type);
    SET v_performer_id = LAST_INSERT_ID();

    
    INSERT INTO tickets (event_id, ticket_type, price) VALUES (v_event_id, p_ticket_type, p_price);
    SET v_ticket_id = LAST_INSERT_ID();

    
    INSERT INTO attendees (event_id, user_id) VALUES (v_event_id, v_user_id);

    COMMIT;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `InsertPerformer`(
    IN p_performer_name VARCHAR(255),
    IN p_type VARCHAR(50)
)
BEGIN
    INSERT INTO performers (performer_name, type)
    VALUES (p_performer_name, p_type);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `InsertTicket`(
    IN p_event_id INT,
    IN p_ticket_type VARCHAR(255),
    IN p_price INT
)
BEGIN
    INSERT INTO tickets (event_id, ticket_type, price)
    VALUES (p_event_id, p_ticket_type, p_price);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `InsertUser`(
    IN p_user_name VARCHAR(255),
    IN p_email VARCHAR(255),
    IN p_role VARCHAR(255)
)
BEGIN
    INSERT INTO users (user_name, email, role)
    VALUES (p_user_name, p_email, p_role);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `InsertVenue`(
    IN p_venue_name VARCHAR(255),
    IN p_address VARCHAR(255),
    IN p_capacity INT
)
BEGIN
    INSERT INTO venues (venue_name, address, capacity)
    VALUES (p_venue_name, p_address, p_capacity);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`KAYIHURA_PIO_222004477`@`localhost` PROCEDURE `UpdateUserData`(
    IN p_user_id INT,
    IN p_new_user_name VARCHAR(255),
    IN p_new_email VARCHAR(255),
    IN p_new_role VARCHAR(255)
)
BEGIN
    
    DECLARE v_user_count INT;
    SELECT COUNT(*) INTO v_user_count FROM users WHERE user_id = p_user_id;
    
    
    IF v_user_count > 0 THEN
        UPDATE users
        SET user_name = p_new_user_name, email = p_new_email, role = p_new_role
        WHERE user_id = p_user_id;
        
        SELECT 'User information updated successfully.' AS message;
    ELSE
        SELECT 'User not found.' AS message;
    END IF;
END$$
DELIMITER ;
TRIGGERS
CREATE TRIGGER `after_attendee_delete` AFTER DELETE ON `attendee`
 FOR EACH ROW BEGIN
    
END

CREATE TRIGGER `after_event_insert` AFTER INSERT ON `event`
 FOR EACH ROW BEGIN
    
END

CREATE TRIGGER `after_performer_delete` AFTER DELETE ON `performer`
 FOR EACH ROW BEGIN
    
END

CREATE TRIGGER `after_ticket_insert` AFTER INSERT ON `ticket`
 FOR EACH ROW BEGIN
    
END

CREATE TRIGGER `after_user_update` AFTER UPDATE ON `user`
 FOR EACH ROW BEGIN
    
END

CREATE TRIGGER `after_venue_update` AFTER UPDATE ON `venue`
 FOR EACH ROW BEGIN
    
END



