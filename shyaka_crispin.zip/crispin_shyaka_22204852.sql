-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 16, 2023 at 12:56 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crispin_shyaka_22204852`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteuser` (`p_user_id` INT)   begin
delete from users
where
user_id = p_user_id;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `displayall` ()   begin
select * from users;
select * from ingredients;
select * from ratings;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertuser` (IN `p_first_name` VARCHAR(20), IN `p_emal` VARCHAR(100), IN `p_paword` VARCHAR(8))   begin
insert into users (first_name,emal,paword)
values (p_first_name,p_emal,p_paword);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatedat` (IN `p_user_id` INT, IN `p_new_name` VARCHAR(25), IN `p_new_cooking_level` VARCHAR(50))   begin
update users
set first_name = p_new_name,
cooking_level = p_new_cooking_level
where user_id = p_user_id;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatedata` (IN `p_user_id` INT, IN `p_new_name` VARCHAR(25), IN `p_new_cooking_level` VARCHAR(50))   begin
update users
set first_name = new_name,
cooking_level = new_cookng_level
where user_id = p_user_id;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatedatas` (IN `p_user_id` INT, IN `p_new_name` VARCHAR(25), IN `p_new_cooking_level` VARCHAR(50))   begin
update users
set first_name = p_new_name,
cooking_level = p_new_cookng_level
where user_id = p_user_id;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `userwithmostrecipe` ()   begin
select u.first_name,u.emal
from users u
join(
select user_id, count(*)
as savedrecipecount
from saved_recipes
group by user_id
order by savedrecipecount desc
limit 1
)
as subquery
on u.user_id = subquery.user_id;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `userwithmostrecipes` ()   begin
select u.first_name,u.emal
from user u
join(
select user_id, count(*)
as savedrecipecount
from saved_recipes
group by user_id
order by savedrecipecount desc
limit 1
)
as subquery
on u.user_id = subquery.user_id;
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `ingredentsview`
-- (See below for the actual view)
--
CREATE TABLE `ingredentsview` (
`ingredent_id` int(11)
,`name` varchar(15)
,`category` varchar(10)
,`nutrition_informaton` varchar(50)
,`avalability` varchar(18)
);

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `ingredent_id` int(11) NOT NULL,
  `name` varchar(15) NOT NULL,
  `category` varchar(10) DEFAULT NULL,
  `nutrition_informaton` varchar(50) DEFAULT NULL,
  `avalability` varchar(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`ingredent_id`, `name`, `category`, `nutrition_informaton`, `avalability`) VALUES
(1, 'Onion', 'carbo', NULL, 'yes'),
(2, 'pillaw_masala', 'spices', 'vitaminA', 'yes'),
(3, 'tea_masala', 'spicies', 'vitamins', 'yes');

--
-- Triggers `ingredients`
--
DELIMITER $$
CREATE TRIGGER `updateingredients` AFTER UPDATE ON `ingredients` FOR EACH ROW begin
insert into ingredientlog(ingredent_id,action,timestamp)
values (new.ingredent_id,'user_updated',now());
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertusers`
-- (See below for the actual view)
--
CREATE TABLE `insertusers` (
`user_id` int(11)
,`first_name` varchar(20)
,`last_name` varchar(15)
,`emal` varchar(30)
,`paword` varchar(8)
,`preferrences` varchar(20)
,`cooking_level` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `rating_id` int(11) NOT NULL,
  `recipe_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ratng_value` int(11) DEFAULT NULL,
  `revew` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`rating_id`, `recipe_id`, `user_id`, `ratng_value`, `revew`) VALUES
(1, 1, 2, 5, 'awesome');

-- --------------------------------------------------------

--
-- Table structure for table `recipelog`
--

CREATE TABLE `recipelog` (
  `log_id` int(11) NOT NULL,
  `recipe_id` int(11) DEFAULT NULL,
  `action` varchar(20) DEFAULT NULL,
  `timestamp` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `recipe_id` int(11) NOT NULL,
  `title` varchar(10) DEFAULT NULL,
  `ingredient_lst` varchar(100) DEFAULT NULL,
  `prepqraton_time` int(11) DEFAULT NULL,
  `cooking_time` int(11) DEFAULT NULL,
  `nutritional_info` varchar(100) DEFAULT NULL,
  `user_rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`recipe_id`, `title`, `ingredient_lst`, `prepqraton_time`, `cooking_time`, `nutritional_info`, `user_rating`) VALUES
(1, 'breakfast', 'meat_onions_eggs', NULL, 1, NULL, 20);

--
-- Triggers `recipes`
--
DELIMITER $$
CREATE TRIGGER `insertafterrecipe` AFTER INSERT ON `recipes` FOR EACH ROW Begin
Insert into recipelog(recipe_id,action,timestamp)
Values (new.recipe_id,'recipe_added',now());
End
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `recipestodelete`
-- (See below for the actual view)
--
CREATE TABLE `recipestodelete` (
`save_id` int(11)
,`user_id` int(11)
,`save_data` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `saved_recipes`
--

CREATE TABLE `saved_recipes` (
  `save_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `recipe_id` int(11) DEFAULT NULL,
  `save_data` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saved_recipes`
--

INSERT INTO `saved_recipes` (`save_id`, `user_id`, `recipe_id`, `save_data`) VALUES
(1, 1, 1, 'breakfast_great_recipe');

-- --------------------------------------------------------

--
-- Stand-in structure for view `userinsert`
-- (See below for the actual view)
--
CREATE TABLE `userinsert` (
`user_id` binary(0)
,`frist_name` char(0)
,`last_name` char(0)
,`emal` char(0)
,`paword` char(0)
,`preferrence` char(0)
,`cooking_level` char(0)
);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `timestamp` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`log_id`, `user_id`, `action`, `timestamp`) VALUES
(1, 6, 'user added', '2023-09-09'),
(2, 4, 'user_updated', '2023-09-09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(15) NOT NULL,
  `emal` varchar(30) DEFAULT NULL,
  `paword` varchar(8) DEFAULT NULL,
  `preferrences` varchar(20) DEFAULT NULL,
  `cooking_level` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `emal`, `paword`, `preferrences`, `cooking_level`) VALUES
(1, 'karangwa', 'umutoni', 'ritaumutogmail.com', 'rita@123', 'snacks', 'bad'),
(2, 'junior', 'johnson', 'junjo@gmail.com', 'jun123', 'sou', 'worst'),
(3, 'jean', 'shima', '12@gmail.com', 'jean12', 'spicy', 'bad'),
(4, 'cristelly', 'manzi', 'jeff@gmail.com', 'manzi12', 'drinks', 'yammy'),
(5, 'john_doe', '', 'john256@gmail.com', 'secure', NULL, NULL),
(6, 'jack', '', 'jac@gmal.com', 'cured', NULL, NULL);

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `deleteuser` AFTER DELETE ON `users` FOR EACH ROW begin
insert into userlog(user_id,action,timestamp)
values (old.user_id,'user_deleted',now());
end
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertafter` AFTER INSERT ON `users` FOR EACH ROW begin
insert into userlog(user_id,action,timestamp)
values(new.user_id,'user added',now());
 end
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateusers` AFTER UPDATE ON `users` FOR EACH ROW begin
insert into userlog(user_id,action,timestamp)
values (new.user_id,'user_updated',now());
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `usersavedrecipes`
-- (See below for the actual view)
--
CREATE TABLE `usersavedrecipes` (
`user_id` int(11)
,`first_name` varchar(20)
,`save_id` int(11)
,`savedrecipetitle` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `usersingredients`
-- (See below for the actual view)
--
CREATE TABLE `usersingredients` (
`first_name` varchar(20)
,`last_name` varchar(15)
,`ingredent_id` int(11)
,`name` varchar(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `login_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `password` varchar(8) DEFAULT NULL,
  `action_type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`login_id`, `user_id`, `password`, `action_type`) VALUES
(1, 1, 'rita@123', 'chief');

-- --------------------------------------------------------

--
-- Structure for view `ingredentsview`
--
DROP TABLE IF EXISTS `ingredentsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ingredentsview`  AS SELECT `ingredients`.`ingredent_id` AS `ingredent_id`, `ingredients`.`name` AS `name`, `ingredients`.`category` AS `category`, `ingredients`.`nutrition_informaton` AS `nutrition_informaton`, `ingredients`.`avalability` AS `avalability` FROM `ingredients` ;

-- --------------------------------------------------------

--
-- Structure for view `insertusers`
--
DROP TABLE IF EXISTS `insertusers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertusers`  AS SELECT `users`.`user_id` AS `user_id`, `users`.`first_name` AS `first_name`, `users`.`last_name` AS `last_name`, `users`.`emal` AS `emal`, `users`.`paword` AS `paword`, `users`.`preferrences` AS `preferrences`, `users`.`cooking_level` AS `cooking_level` FROM `users` ;

-- --------------------------------------------------------

--
-- Structure for view `recipestodelete`
--
DROP TABLE IF EXISTS `recipestodelete`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `recipestodelete`  AS SELECT `saved_recipes`.`save_id` AS `save_id`, `saved_recipes`.`user_id` AS `user_id`, `saved_recipes`.`save_data` AS `save_data` FROM `saved_recipes` WHERE `saved_recipes`.`user_id` = 3 ;

-- --------------------------------------------------------

--
-- Structure for view `userinsert`
--
DROP TABLE IF EXISTS `userinsert`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `userinsert`  AS SELECT NULL AS `user_id`, '' AS `frist_name`, '' AS `last_name`, '' AS `emal`, '' AS `paword`, '' AS `preferrence`, '' AS `cooking_level` ;

-- --------------------------------------------------------

--
-- Structure for view `usersavedrecipes`
--
DROP TABLE IF EXISTS `usersavedrecipes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `usersavedrecipes`  AS SELECT `u`.`user_id` AS `user_id`, `u`.`first_name` AS `first_name`, `sr`.`save_id` AS `save_id`, `r`.`title` AS `savedrecipetitle` FROM ((`users` `u` join `saved_recipes` `sr` on(`u`.`user_id` = `sr`.`save_id`)) join `recipes` `r` on(`sr`.`save_id` = `r`.`recipe_id`)) ;

-- --------------------------------------------------------

--
-- Structure for view `usersingredients`
--
DROP TABLE IF EXISTS `usersingredients`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `usersingredients`  AS SELECT `users`.`first_name` AS `first_name`, `users`.`last_name` AS `last_name`, `ingredients`.`ingredent_id` AS `ingredent_id`, `ingredients`.`name` AS `name` FROM (`ingredients` join `users` on(`users`.`user_id` = `ingredients`.`ingredent_id`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`ingredent_id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`rating_id`),
  ADD KEY `recipe_id` (`recipe_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `recipelog`
--
ALTER TABLE `recipelog`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `recipe_id` (`recipe_id`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`recipe_id`);

--
-- Indexes for table `saved_recipes`
--
ALTER TABLE `saved_recipes`
  ADD PRIMARY KEY (`save_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `recipe_id` (`recipe_id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`login_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `ingredent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `recipelog`
--
ALTER TABLE `recipelog`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `recipe_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `saved_recipes`
--
ALTER TABLE `saved_recipes`
  MODIFY `save_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`recipe_id`),
  ADD CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `recipelog`
--
ALTER TABLE `recipelog`
  ADD CONSTRAINT `recipelog_ibfk_1` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`recipe_id`);

--
-- Constraints for table `saved_recipes`
--
ALTER TABLE `saved_recipes`
  ADD CONSTRAINT `saved_recipes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `saved_recipes_ibfk_2` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`recipe_id`);

--
-- Constraints for table `userlog`
--
ALTER TABLE `userlog`
  ADD CONSTRAINT `userlog_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `user_login`
--
ALTER TABLE `user_login`
  ADD CONSTRAINT `user_login_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
