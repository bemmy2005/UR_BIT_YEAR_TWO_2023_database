-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 16, 2023 at 06:57 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ur_touch`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `Assignment_ID` varchar(10) NOT NULL,
  `Course_ID` varchar(10) DEFAULT NULL,
  `Due_Date` date DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `Submission_Status` varchar(100) DEFAULT NULL,
  `Grades` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`Assignment_ID`, `Course_ID`, `Due_Date`, `Description`, `Submission_Status`, `Grades`) VALUES
('A001', 'C001', '2023-09-20', 'Programming Assignment 1', 'Pending', 'Not Graded'),
('A002', 'C002', '2023-09-22', 'Calculus Homework 1', 'Submitted', 'B+'),
('A003', 'C003', '2023-09-25', 'History Essay', 'Submitted', 'A-');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `CourseID` varchar(9) NOT NULL,
  `Course_Name` varchar(100) DEFAULT NULL,
  `ProfessorID` varchar(100) DEFAULT NULL,
  `Schedule` date DEFAULT NULL,
  `Room` varchar(100) DEFAULT NULL,
  `Credits` varchar(100) DEFAULT NULL,
  `Syllabus` varchar(100) DEFAULT NULL,
  `Department_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`CourseID`, `Course_Name`, `ProfessorID`, `Schedule`, `Room`, `Credits`, `Syllabus`, `Department_ID`) VALUES
('C001', 'Introduction to Programming', 'I001', '2023-09-10', 'Room A101', '3', 'CS101 Syllabus.pdf', 'D001'),
('C002', 'Calculus I', 'I002', '2023-09-12', 'Room B201', '4', 'Math101 Syllabus.pdf', 'D002'),
('C003', 'World History', 'I003', '2023-09-14', 'Room C301', '3', 'Hist101 Syllabus.pdf', 'D003');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DepartmentID` varchar(10) NOT NULL,
  `DepartmentName` varchar(100) DEFAULT NULL,
  `Office` varchar(100) DEFAULT NULL,
  `ChairInstructorID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DepartmentID`, `DepartmentName`, `Office`, `ChairInstructorID`) VALUES
('D001', 'Computer Science', 'Science Building', 'I001'),
('D002', 'Mathematics', 'Math Building', 'I002'),
('D003', 'History', 'Arts Building', 'I003');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EmployeeID` varchar(100) NOT NULL,
  `FirstName` varchar(100) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `PhoneNumber` int(11) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `JobTitle` varchar(100) DEFAULT NULL,
  `DepartmentID` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EmployeeID`, `FirstName`, `LastName`, `DateOfBirth`, `Address`, `PhoneNumber`, `Email`, `JobTitle`, `DepartmentID`) VALUES
('Emp001', 'Emily', 'Anderson', '1980-03-12', '123 Admin St', 2147483647, 'emily.anderson@example.com', 'Administrator', 'D001'),
('Emp002', 'George', 'Clark', '1992-09-28', '456 Admin St', 2147483647, 'george.clark@example.com', 'Office Manager', 'D002'),
('Emp003', 'Olivia', 'Davis', '1985-06-15', '789 Admin St', 2147483647, 'olivia.davis@example.com', 'Registrar', 'D003');

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

CREATE TABLE `enrollment` (
  `EnrollmentID` varchar(10) NOT NULL,
  `StudentID` varchar(10) DEFAULT NULL,
  `CourseID` varchar(10) DEFAULT NULL,
  `EnrollmentDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enrollment`
--

INSERT INTO `enrollment` (`EnrollmentID`, `StudentID`, `CourseID`, `EnrollmentDate`) VALUES
('E001', 'S001', 'C001', '2023-09-06'),
('E002', 'S002', 'C002', '2023-09-07'),
('E003', 'S003', 'C003', '2023-09-08');

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

CREATE TABLE `instructor` (
  `InstructorID` varchar(10) NOT NULL,
  `FirstName` varchar(100) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `PhoneNumber` int(11) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `DepartmentID` varchar(10) DEFAULT NULL,
  `Rank` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor`
--

INSERT INTO `instructor` (`InstructorID`, `FirstName`, `LastName`, `DateOfBirth`, `Address`, `PhoneNumber`, `Email`, `DepartmentID`, `Rank`) VALUES
('I001', 'Dr. Smith', 'Johnson', '1970-05-25', '100 Faculty Ave', 2147483647, 'smith.johnson@example.com', 'D001', 'Professor'),
('I002', 'Prof. Mary', 'Williams', '1985-09-12', '200 Faculty Ave', 2147483647, 'mary.williams@example.com', 'D002', 'Associate Professor'),
('I003', 'Dr. James', 'Davis', '1978-11-30', '300 Faculty Ave', 2147483647, 'james.davis@example.com', 'D003', 'Professor');

-- --------------------------------------------------------

--
-- Table structure for table `librarybook`
--

CREATE TABLE `librarybook` (
  `BookID` varchar(10) NOT NULL,
  `Title` varchar(100) DEFAULT NULL,
  `Author` varchar(100) DEFAULT NULL,
  `Genre` varchar(100) DEFAULT NULL,
  `AvailabilityStatus` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `librarybook`
--

INSERT INTO `librarybook` (`BookID`, `Title`, `Author`, `Genre`, `AvailabilityStatus`) VALUES
('LB001', 'Introduction to Algorithms', 'Cormen, Leiserson, Rivest, and Stein', 'Computer Science', 'Available'),
('LB002', 'The Origin of Species', 'Charles Darwin', 'Science', 'Checked Out'),
('LB003', 'A People\'s History of the United States', 'Howard Zinn', 'History', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `librarycheckout`
--

CREATE TABLE `librarycheckout` (
  `CheckoutID` varchar(10) NOT NULL,
  `PatronID` varchar(10) DEFAULT NULL,
  `BookID` varchar(10) DEFAULT NULL,
  `CheckoutDate` date DEFAULT NULL,
  `DueDate` date DEFAULT NULL,
  `ReturnDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `librarycheckout`
--

INSERT INTO `librarycheckout` (`CheckoutID`, `PatronID`, `BookID`, `CheckoutDate`, `DueDate`, `ReturnDate`) VALUES
('LC001', 'P001', 'LB001', '2023-09-10', '2023-09-25', NULL),
('LC002', 'P002', 'LB002', '2023-09-12', '2023-09-27', '2023-09-20'),
('LC003', 'P003', 'LB003', '2023-09-14', '2023-09-29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `StudentID` varchar(50) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Gender` varchar(50) DEFAULT NULL,
  `Nationality` varchar(50) DEFAULT NULL,
  `Emergency_Contact` int(11) DEFAULT NULL,
  `PhoneNumber` int(11) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Major` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`StudentID`, `FirstName`, `LastName`, `DateOfBirth`, `Address`, `Gender`, `Nationality`, `Emergency_Contact`, `PhoneNumber`, `Email`, `Major`) VALUES
('S001', 'John', 'Doe', '2000-01-15', '123 Main St', 'Male', 'USA', 1234567890, 2147483647, 'john.doe@example.com', 'Computer Science'),
('S002', 'Jane', 'Smith', '1999-03-20', '456 Elm St', 'Female', 'Canada', 2147483647, 2147483647, 'jane.smith@example.com', 'Mathematics'),
('S003', 'Bob', 'Johnson', '2001-07-10', '789 Oak St', 'Male', 'UK', 2147483647, 2147483647, 'bob.johnson@example.com', 'Physics');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`Assignment_ID`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`CourseID`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`DepartmentID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EmployeeID`);

--
-- Indexes for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD PRIMARY KEY (`EnrollmentID`);

--
-- Indexes for table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`InstructorID`);

--
-- Indexes for table `librarybook`
--
ALTER TABLE `librarybook`
  ADD PRIMARY KEY (`BookID`);

--
-- Indexes for table `librarycheckout`
--
ALTER TABLE `librarycheckout`
  ADD PRIMARY KEY (`CheckoutID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`StudentID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
