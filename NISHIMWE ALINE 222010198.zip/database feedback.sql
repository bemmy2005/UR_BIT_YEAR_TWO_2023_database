-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 08, 2023 at 09:08 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `feedback`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeletecustomerById` (IN `p_customer_id` INT)  BEGIN
    DELETE FROM customer
    WHERE customer_id = p_customer_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteFeedbackById` (IN `p_feedback_id` INT)  BEGIN
    DELETE FROM Feedback
    WHERE feedback_id = p_feedback_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllCustomers` ()  BEGIN
    SELECT * FROM Customers;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetCertainId` ()  BEGIN
    SELECT Feedback_text
    FROM Customers c
    WHERE c.customer_id IN (
        SELECT f.customer_id
        FROM Feedback f
        WHERE f.feedback_id=1
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertCustomer` (IN `p_name` VARCHAR(255), IN `p_country` VARCHAR(255), IN `p_district` VARCHAR(20), IN `p_age` VARCHAR(255), IN `p_sex` VARCHAR(20))  BEGIN
    INSERT INTO Customers (name, country, district, age,sex)
    VALUES (p_name, p_country, p_district, p_age,p_sex);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateCustomerAddress` (IN `p_customer_id` INT, IN `p_new_address` VARCHAR(255))  BEGIN
    UPDATE Customers
    SET address = p_new_address
    WHERE customer_id = p_customer_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdatemanagerName` (IN `p_manager_id` INT, IN `p_new_name` VARCHAR(255))  BEGIN
    UPDATE manager
    SET name = p_new_name
    WHERE manager_id = p_manager_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE `attachments` (
  `Attachment_id` int(11) NOT NULL,
  `Feedback_id` int(11) DEFAULT NULL,
  `File_name` varchar(255) DEFAULT NULL,
  `File_type` varchar(50) DEFAULT NULL,
  `File_size` int(11) DEFAULT NULL,
  `Date_uploaded` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attachments`
--

INSERT INTO `attachments` (`Attachment_id`, `Feedback_id`, `File_name`, `File_type`, `File_size`, `Date_uploaded`) VALUES
(23, 1, 'bill', ',pdf', 32, '2023-09-12 22:41:14');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `Customer_id` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `district` varchar(20) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `sex` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`Customer_id`, `Name`, `country`, `district`, `age`, `sex`) VALUES
(1, 'aline', 'congo', 'HUYE', 32, ' F');

--
-- Triggers `customers`
--
DELIMITER $$
CREATE TRIGGER `FeedbackInsertion` AFTER INSERT ON `customers` FOR EACH ROW BEGIN
    INSERT INTO Feedback (Feedback_id, Customer_id, Reply, Feedback_text, replyManager_id)
    VALUES (‘INSERT’, NEW.customer_id, NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateFeedback` AFTER INSERT ON `customers` FOR EACH ROW BEGIN
    UPDATE Feedback
    SET replyManager_id = replyManager_id+ 1
    WHERE feedback_id = NEW.customer_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Feedback_id` int(11) NOT NULL,
  `Customer_id` int(11) DEFAULT NULL,
  `Reply` text DEFAULT NULL,
  `Feedback_text` text DEFAULT NULL,
  `replyManager_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Feedback_id`, `Customer_id`, `Reply`, `Feedback_text`, `replyManager_id`) VALUES
(1, 1, 'thank you for your feedback', 'Excellent service', 1);

--
-- Triggers `feedback`
--
DELIMITER $$
CREATE TRIGGER `DeleteReply` AFTER DELETE ON `feedback` FOR EACH ROW BEGIN
    DELETE FROM attachments
    WHERE Attachment_id = OLD.feedback_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateCustomer` AFTER UPDATE ON `feedback` FOR EACH ROW BEGIN
    IF NEW.feedback_id = 1 THEN
        UPDATE Customers
        SET sex = ‘m’
        WHERE customer_id = NEW.customer_id;
    ELSE
        UPDATE Customers
        SET sex = ‘f’
        WHERE customer_id = NEW.customer_id;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Updateattachment` AFTER UPDATE ON `feedback` FOR EACH ROW BEGIN
    IF NEW.feedback_id = 1 THEN
        UPDATE attachments
        SET Date_uploaded = ‘2020’
        WHERE Attachment_id = NEW.feedback_id;
    ELSE
        UPDATE attachments
        SET Date_uploaded = ‘2023’
        WHERE Attachment_id = NEW.feedback_id;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `customertriggaer` AFTER DELETE ON `feedback` FOR EACH ROW BEGIN
    DELETE FROM customers
    WHERE customer_id = OLD.feedback_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertview`
-- (See below for the actual view)
--
CREATE TABLE `insertview` (
`Attachment_id` int(11)
,`Feedback_id` int(11)
,`File_name` varchar(255)
,`File_type` varchar(50)
,`File_size` int(11)
,`Date_uploaded` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertview_customer`
-- (See below for the actual view)
--
CREATE TABLE `insertview_customer` (
`Customer_id` int(11)
,`Name` varchar(255)
,`country` varchar(255)
,`district` varchar(20)
,`age` int(3)
,`sex` varchar(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertview_feedack`
-- (See below for the actual view)
--
CREATE TABLE `insertview_feedack` (
`Feedback_id` int(11)
,`Customer_id` int(11)
,`Reply` text
,`Feedback_text` text
,`replyManager_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertview_manager`
-- (See below for the actual view)
--
CREATE TABLE `insertview_manager` (
`manager_id` int(11)
,`Username` varchar(50)
,`Password_hash` varchar(255)
,`Email` varchar(255)
,`Role` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `manager_id` int(11) NOT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password_hash` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Role` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`manager_id`, `Username`, `Password_hash`, `Email`, `Role`) VALUES
(1, 'manager_west', '2022', 'manager@gmail.com', 'branch manager'),
(3, 'manager_east', '74628', 'jazzy$gmail.com', 'branch manager');

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatecustomer`
-- (See below for the actual view)
--
CREATE TABLE `updatecustomer` (
`Customer_id` int(11)
,`Name` varchar(255)
,`country` varchar(255)
,`district` varchar(20)
,`age` int(3)
,`sex` varchar(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatemnager`
-- (See below for the actual view)
--
CREATE TABLE `updatemnager` (
`manager_id` int(11)
,`Username` varchar(50)
,`Password_hash` varchar(255)
,`Email` varchar(255)
,`Role` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_customers_with_certain_id`
-- (See below for the actual view)
--
CREATE TABLE `vw_customers_with_certain_id` (
`Feedback_text` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_display_attachements`
-- (See below for the actual view)
--
CREATE TABLE `vw_display_attachements` (
`Attachment_id` int(11)
,`Feedback_id` int(11)
,`File_name` varchar(255)
,`File_type` varchar(50)
,`File_size` int(11)
,`Date_uploaded` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_display_customers`
-- (See below for the actual view)
--
CREATE TABLE `vw_display_customers` (
`Customer_id` int(11)
,`Name` varchar(255)
,`country` varchar(255)
,`district` varchar(20)
,`age` int(3)
,`sex` varchar(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_display_feedback`
-- (See below for the actual view)
--
CREATE TABLE `vw_display_feedback` (
`Feedback_id` int(11)
,`Customer_id` int(11)
,`Reply` text
,`Feedback_text` text
,`replyManager_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_display_manager`
-- (See below for the actual view)
--
CREATE TABLE `vw_display_manager` (
`manager_id` int(11)
,`Username` varchar(50)
,`Password_hash` varchar(255)
,`Email` varchar(255)
,`Role` varchar(20)
);

-- --------------------------------------------------------

--
-- Structure for view `insertview`
--
DROP TABLE IF EXISTS `insertview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertview`  AS  select `attachments`.`Attachment_id` AS `Attachment_id`,`attachments`.`Feedback_id` AS `Feedback_id`,`attachments`.`File_name` AS `File_name`,`attachments`.`File_type` AS `File_type`,`attachments`.`File_size` AS `File_size`,`attachments`.`Date_uploaded` AS `Date_uploaded` from `attachments` where 1 = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `insertview_customer`
--
DROP TABLE IF EXISTS `insertview_customer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertview_customer`  AS  select `customers`.`Customer_id` AS `Customer_id`,`customers`.`Name` AS `Name`,`customers`.`country` AS `country`,`customers`.`district` AS `district`,`customers`.`age` AS `age`,`customers`.`sex` AS `sex` from `customers` where 1 = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `insertview_feedack`
--
DROP TABLE IF EXISTS `insertview_feedack`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertview_feedack`  AS  select `Feedback_id` AS `Feedback_id`,`Customer_id` AS `Customer_id`,`Reply` AS `Reply`,`Feedback_text` AS `Feedback_text`,`replyManager_id` AS `replyManager_id` from `feedback` where 1 = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `insertview_manager`
--
DROP TABLE IF EXISTS `insertview_manager`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertview_manager`  AS  select `manager`.`manager_id` AS `manager_id`,`manager`.`Username` AS `Username`,`manager`.`Password_hash` AS `Password_hash`,`manager`.`Email` AS `Email`,`manager`.`Role` AS `Role` from `manager` where 1 = 0 ;

-- --------------------------------------------------------

--
-- Structure for view `updatecustomer`
--
DROP TABLE IF EXISTS `updatecustomer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatecustomer`  AS  select `customers`.`Customer_id` AS `Customer_id`,`customers`.`Name` AS `Name`,`customers`.`country` AS `country`,`customers`.`district` AS `district`,`customers`.`age` AS `age`,`customers`.`sex` AS `sex` from `customers` where `customers`.`Customer_id` = 1 ;

-- --------------------------------------------------------

--
-- Structure for view `updatemnager`
--
DROP TABLE IF EXISTS `updatemnager`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatemnager`  AS  select `manager`.`manager_id` AS `manager_id`,`manager`.`Username` AS `Username`,`manager`.`Password_hash` AS `Password_hash`,`manager`.`Email` AS `Email`,`manager`.`Role` AS `Role` from `manager` where `manager`.`manager_id` = 1 ;

-- --------------------------------------------------------

--
-- Structure for view `vw_customers_with_certain_id`
--
DROP TABLE IF EXISTS `vw_customers_with_certain_id`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_customers_with_certain_id`  AS  select `f`.`Feedback_text` AS `Feedback_text` from (`customers` `c` join `feedback` `f` on(`c`.`Customer_id` = `f`.`Customer_id`)) where `f`.`replyManager_id` = 2 ;

-- --------------------------------------------------------

--
-- Structure for view `vw_display_attachements`
--
DROP TABLE IF EXISTS `vw_display_attachements`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_display_attachements`  AS  select `attachments`.`Attachment_id` AS `Attachment_id`,`attachments`.`Feedback_id` AS `Feedback_id`,`attachments`.`File_name` AS `File_name`,`attachments`.`File_type` AS `File_type`,`attachments`.`File_size` AS `File_size`,`attachments`.`Date_uploaded` AS `Date_uploaded` from `attachments` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_display_customers`
--
DROP TABLE IF EXISTS `vw_display_customers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_display_customers`  AS  select `customers`.`Customer_id` AS `Customer_id`,`customers`.`Name` AS `Name`,`customers`.`country` AS `country`,`customers`.`district` AS `district`,`customers`.`age` AS `age`,`customers`.`sex` AS `sex` from `customers` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_display_feedback`
--
DROP TABLE IF EXISTS `vw_display_feedback`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_display_feedback`  AS  select `Feedback_id` AS `Feedback_id`,`Customer_id` AS `Customer_id`,`Reply` AS `Reply`,`Feedback_text` AS `Feedback_text`,`replyManager_id` AS `replyManager_id` from `feedback` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_display_manager`
--
DROP TABLE IF EXISTS `vw_display_manager`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_display_manager`  AS  select `manager`.`manager_id` AS `manager_id`,`manager`.`Username` AS `Username`,`manager`.`Password_hash` AS `Password_hash`,`manager`.`Email` AS `Email`,`manager`.`Role` AS `Role` from `manager` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`Attachment_id`),
  ADD KEY `Feedback_id` (`Feedback_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`Customer_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`Feedback_id`),
  ADD KEY `Customer_id` (`Customer_id`),
  ADD KEY `replyManager_id` (`replyManager_id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`manager_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attachments`
--
ALTER TABLE `attachments`
  ADD CONSTRAINT `attachments_ibfk_1` FOREIGN KEY (`Feedback_id`) REFERENCES `feedback` (`Feedback_id`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`Customer_id`) REFERENCES `customers` (`Customer_id`),
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`replyManager_id`) REFERENCES `manager` (`manager_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
