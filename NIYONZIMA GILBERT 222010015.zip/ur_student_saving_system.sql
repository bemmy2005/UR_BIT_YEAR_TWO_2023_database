-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2023 at 01:36 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ur_student_saving_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountants`
--

CREATE TABLE `accountants` (
  `accountant_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `years_of_experience` int(11) NOT NULL,
  `specialization` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accountants`
--

INSERT INTO `accountants` (`accountant_id`, `first_name`, `last_name`, `email`, `phone_number`, `date_of_birth`, `years_of_experience`, `specialization`) VALUES
(1, 'John Doe', 'Smith', 'john.doe@example.com', '(123) 456-7890', '1990-01-01', 5, 'Tax Accounting'),
(2, 'John Doe', 'Smith', 'john.doe@example.com', '(123) 456-7890', '1990-01-01', 5, 'Tax Accounting');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `responsibilities` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `first_name`, `last_name`, `email`, `phone_number`, `date_of_birth`, `responsibilities`) VALUES
(1, 'John Doe', 'Smith', 'john.doe@example.com', '(123) 456-7890', '1990-01-01', 'System Administrator'),
(2, 'John Doe', 'Smith', 'john.doe@example.com', '(123) 456-7890', '1990-01-01', 'System Administrator');

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_accountant_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_accountant_view` (
`accountant_id` int(11)
,`first_name` varchar(255)
,`last_name` varchar(255)
,`email` varchar(255)
,`phone_number` varchar(255)
,`date_of_birth` date
,`years_of_experience` int(11)
,`specialization` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_manager_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_manager_view` (
`manager_id` int(11)
,`first_name` varchar(255)
,`last_name` varchar(255)
,`email` varchar(255)
,`phone_number` varchar(255)
,`date_of_birth` date
,`department` varchar(255)
,`years_of_experience` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_view` (
`student_id` int(11)
,`first_name` varchar(255)
,`last_name` varchar(255)
,`email` varchar(255)
,`phone_number` varchar(255)
,`date_of_birth` date
,`major` varchar(255)
,`GPA` float
,`year_in_school` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `managers`
--

CREATE TABLE `managers` (
  `manager_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `department` varchar(255) NOT NULL,
  `years_of_experience` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `managers`
--

INSERT INTO `managers` (`manager_id`, `first_name`, `last_name`, `email`, `phone_number`, `date_of_birth`, `department`, `years_of_experience`) VALUES
(1, 'John Doe', 'Smith', 'john.doe@example.com', '(123) 456-7890', '1990-01-01', 'Engineering', 5);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `major` varchar(255) NOT NULL,
  `GPA` float NOT NULL,
  `year_in_school` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `first_name`, `last_name`, `email`, `phone_number`, `date_of_birth`, `major`, `GPA`, `year_in_school`) VALUES
(1, 'John Doe', 'Smith', 'john.doe@example.com', '(123) 456-7890', '1990-01-01', 'Computer Science', 3.5, 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_accountant_view`
--
DROP TABLE IF EXISTS `insert_accountant_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`niyonzima`@`localhost` SQL SECURITY DEFINER VIEW `insert_accountant_view`  AS SELECT `accountants`.`accountant_id` AS `accountant_id`, `accountants`.`first_name` AS `first_name`, `accountants`.`last_name` AS `last_name`, `accountants`.`email` AS `email`, `accountants`.`phone_number` AS `phone_number`, `accountants`.`date_of_birth` AS `date_of_birth`, `accountants`.`years_of_experience` AS `years_of_experience`, `accountants`.`specialization` AS `specialization` FROM `accountants` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_manager_view`
--
DROP TABLE IF EXISTS `insert_manager_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`niyonzima`@`localhost` SQL SECURITY DEFINER VIEW `insert_manager_view`  AS SELECT `managers`.`manager_id` AS `manager_id`, `managers`.`first_name` AS `first_name`, `managers`.`last_name` AS `last_name`, `managers`.`email` AS `email`, `managers`.`phone_number` AS `phone_number`, `managers`.`date_of_birth` AS `date_of_birth`, `managers`.`department` AS `department`, `managers`.`years_of_experience` AS `years_of_experience` FROM `managers` ;

-- --------------------------------------------------------

--
-- Structure for view `insert_view`
--
DROP TABLE IF EXISTS `insert_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`niyonzima`@`localhost` SQL SECURITY DEFINER VIEW `insert_view`  AS SELECT `students`.`student_id` AS `student_id`, `students`.`first_name` AS `first_name`, `students`.`last_name` AS `last_name`, `students`.`email` AS `email`, `students`.`phone_number` AS `phone_number`, `students`.`date_of_birth` AS `date_of_birth`, `students`.`major` AS `major`, `students`.`GPA` AS `GPA`, `students`.`year_in_school` AS `year_in_school` FROM `students` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountants`
--
ALTER TABLE `accountants`
  ADD PRIMARY KEY (`accountant_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `managers`
--
ALTER TABLE `managers`
  ADD PRIMARY KEY (`manager_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accountants`
--
ALTER TABLE `accountants`
  MODIFY `accountant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `managers`
--
ALTER TABLE `managers`
  MODIFY `manager_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
