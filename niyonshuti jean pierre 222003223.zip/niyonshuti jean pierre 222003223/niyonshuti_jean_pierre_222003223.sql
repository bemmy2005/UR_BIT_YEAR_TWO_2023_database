-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 12:17 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `niyonshuti_jean_pierre_222003223`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteFromTables` ()   BEGIN
    DECLARE cityToDeleteFrom VARCHAR(30);
    DECLARE positionToDeleteFrom VARCHAR(20);

    
    SET cityToDeleteFrom = 'Some city';
    SET positionToDeleteFrom = 'Forward';

    
    DELETE FROM club WHERE city = cityToDeleteFrom;

    
    DELETE FROM player WHERE position = positionToDeleteFrom;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllTablesInfo` ()   BEGIN
    DECLARE table_name VARCHAR(50);
    DECLARE done INT DEFAULT 0;
    DECLARE cur CURSOR FOR SELECT table_name FROM information_schema.tables WHERE table_schema = 'your_database_name';

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO table_name;
        IF done THEN
            LEAVE read_loop;
        END IF;

        SET @sql = CONCAT('SELECT * FROM ', table_name);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END LOOP;

    CLOSE cur;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetClubsWithCoaches` ()   BEGIN
    SELECT c.club_name, c.district, (SELECT CONCAT(co.first_name, ' ', co.last_name) FROM coacher co WHERE co.club_id = c.club_id) AS coach_name
    FROM club c;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoBank` (IN `bankName` VARCHAR(20), IN `location` VARCHAR(30), IN `website` VARCHAR(30), IN `contact` VARCHAR(10), IN `bankAccount` VARCHAR(50))   BEGIN
    INSERT INTO bank (bank_name, location, website, contact, bank_account)
    VALUES (bankName, location, website, contact, bankAccount);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoClub` (IN `clubName` VARCHAR(50), IN `district` VARCHAR(30), IN `foundationYear` INT)   BEGIN
    INSERT INTO club (club_name, district, foundation_year)
    VALUES (clubName, district, foundationYear);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoCoacher` (IN `p_firstName` VARCHAR(40), IN `p_lastName` VARCHAR(20), IN `p_nationality` VARCHAR(20), IN `p_email` VARCHAR(100), IN `p_contact` VARCHAR(10), IN `p_clubId` INT)   BEGIN
    INSERT INTO coacher (first_name, last_name, nationality, email, contact, club_id)
    VALUES (p_firstName, p_lastName, p_nationality, p_email, p_contact, p_clubId);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoFunClub` (IN `name` VARCHAR(50), IN `description` VARCHAR(100), IN `contact` VARCHAR(10), IN `website` VARCHAR(50), IN `clubId` INT)   BEGIN
    INSERT INTO fun_club (name, description, contact, website, club_id)
    VALUES (name, description, contact, website, clubId);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoLeague` (IN `leagueName` VARCHAR(200), IN `country` VARCHAR(20), IN `season` VARCHAR(150), IN `startDate` DATE, IN `endDate` DATE, IN `numberClub` INT)   BEGIN
    INSERT INTO league (league_name, country, season, start_date, end_date, number_club)
    VALUES (leagueName, country, season, startDate, endDate, numberClub);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoManager` (IN `lastName` VARCHAR(20), IN `firstName` VARCHAR(20), IN `email` VARCHAR(50), IN `contact` VARCHAR(10), IN `clubId` INT)   BEGIN
    INSERT INTO manager (last_name, first_name, email, contact, club_id)
    VALUES (lastName, firstName, email, contact, clubId);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoMatchs` (IN `p_matchDate` DATE, IN `p_homeClub` VARCHAR(10), IN `p_awayClub` VARCHAR(10), IN `p_refereeNames` VARCHAR(50))   BEGIN
    INSERT INTO matchs (match_date, home_club, away_club, referee_names)
    VALUES (p_matchDate, p_homeClub, p_awayClub, p_refereeNames);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoPlayer` (IN `firstName` VARCHAR(30), IN `lastName` VARCHAR(30), IN `email` VARCHAR(50), IN `contact` VARCHAR(10), IN `position` VARCHAR(20), IN `dateOfBirth` DATE, IN `clubId` INT, IN `country` VARCHAR(20))   BEGIN
    INSERT INTO player (first_name, last_name, email, contact, position, date_of_birth, club_id, country)
    VALUES (firstName, lastName, email, contact, position, dateOfBirth, clubId, country);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoStadium` (IN `stadiumName` VARCHAR(30), IN `capacity` INT, IN `clubId` INT)   BEGIN
    INSERT INTO stadium (stadium_name, capacity, club_id)
    VALUES (stadiumName, capacity, clubId);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertIntoUserAdmin` (IN `lastName` VARCHAR(30), IN `firstName` VARCHAR(30), IN `email` VARCHAR(50), IN `password` VARCHAR(10), IN `contact` VARCHAR(10))   BEGIN
    INSERT INTO user_admin (last_name, first_name, email, password, contact)
    VALUES (lastName, firstName, email, password, contact);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateDataInTables` (IN `tableName` VARCHAR(50), IN `conditionColumn` VARCHAR(50), IN `conditionValue` VARCHAR(50), IN `updateColumn` VARCHAR(50), IN `updateValue` VARCHAR(50))   BEGIN
    SET @sql = CONCAT('UPDATE ', tableName, ' SET ', updateColumn, ' = ? WHERE ', conditionColumn, ' = ?');
    PREPARE stmt FROM @sql;
    EXECUTE stmt USING updateValue, conditionValue;
    DEALLOCATE PREPARE stmt;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_info`
-- (See below for the actual view)
--
CREATE TABLE `all_info` (
`playeer_id` int(11)
,`player_first_name` varchar(50)
,`player_last_name` varchar(50)
,`player_position` varchar(15)
,`player_date_of_birth` date
,`coacher_id` int(11)
,`coach_first_name` varchar(40)
,`coach_last_name` varchar(20)
,`club_id` int(11)
,`name` varchar(15)
,`club_stadium_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `bank_id` int(11) NOT NULL,
  `bank_name` varchar(20) NOT NULL,
  `location` varchar(30) NOT NULL,
  `website` varchar(30) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `bank_account` varchar(50) NOT NULL,
  `club_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `bank_name`, `location`, `website`, `contact`, `bank_account`, `club_id`) VALUES
(1, 'Rwanda National Bank', 'Kigali', 'www.rwandanationalbank.rw', '+250123456', 'RW1234567890', 28),
(2, 'Kigali Commercial Ba', 'Kigali', 'www.kigalicommercialbank.rw', '+250234567', 'KC4567890123', 29),
(3, 'Rubavu Savings Bank', 'Rubavu', 'www.rubavusavingsbank.rw', '+250345678', 'RSB5678901234', 30),
(4, 'Nyagatare Cooperativ', 'Nyagatare', 'www.nyagatarecoopbank.rw', '+250456789', 'NCB6789012345', 31),
(5, 'Huye Development Ban', 'Huye', 'www.huyedevelopmentbank.rw', '+250567890', 'HDB7890123456', 32);

-- --------------------------------------------------------

--
-- Stand-in structure for view `bank_info`
-- (See below for the actual view)
--
CREATE TABLE `bank_info` (
`bank_id` int(11)
,`bank_name` varchar(20)
,`location` varchar(30)
,`website` varchar(30)
,`contact` varchar(10)
,`bank_account` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `bank_informationview`
-- (See below for the actual view)
--
CREATE TABLE `bank_informationview` (
`bank_id` int(11)
,`bank_name` varchar(20)
,`location` varchar(30)
,`bank_account` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `club`
--

CREATE TABLE `club` (
  `club_id` int(11) NOT NULL,
  `name` varchar(15) NOT NULL,
  `city` varchar(20) NOT NULL,
  `league` varchar(15) NOT NULL,
  `stadium_name` varchar(50) NOT NULL,
  `league_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `club`
--

INSERT INTO `club` (`club_id`, `name`, `city`, `league`, `stadium_name`, `league_id`) VALUES
(28, 'APR FC', 'Kigali', 'rwanda primier ', 'Kigali pele studium', NULL),
(29, 'As Kigali FC', 'Kigali', 'rwanda primier ', 'Kigali pele studium', NULL),
(30, 'Police FC', 'Kigali', 'rwanda primier ', 'Kigali pele studium', NULL),
(31, 'Rayon Sport FC', 'kigali', 'rwanda primier ', 'Kigali pele studium', NULL),
(32, 'Etoil De l Est ', 'Ngoma', 'rwanda primier ', 'Ngoma stadium', NULL),
(33, 'Musanze FC', 'Musanze', 'rwanda primier ', 'UBWOROHERANE stadium', NULL),
(34, 'Gorilla FC', 'Kigali', 'rwanda primier ', 'Kigali pere stadium', NULL),
(35, 'Sunrise FC', 'Nyagatare', 'rwanda primier ', 'Nyagatare stadium', NULL),
(36, 'Gasogi FC', 'kigali', 'rwanda primier ', 'Kigali pele studium', NULL),
(37, 'Mukura FC', 'Huye', 'rwanda primier ', 'Huye stadium', NULL),
(38, 'Marine FC', 'Rubavu', 'rwanda primier ', 'Umuganda stadium', NULL),
(39, 'Bugesera FC', 'Bugesera', 'rwanda primier ', 'Bugesera stadium', NULL),
(40, 'Amagaju FC', 'Kigali', 'rwanda primier ', 'Kigali pere stadium', NULL),
(41, 'Muhazi United F', 'Ngoma', 'rwanda primier ', 'Ngoma stadium', NULL),
(42, 'Kiyovu FC', 'Kigali', 'rwanda primier ', 'Kigali pere stadium', NULL),
(43, 'Etincelles FC', 'Rubavu', 'rwanda primier ', 'Umuganda stadium', NULL);

--
-- Triggers `club`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteClub` AFTER DELETE ON `club` FOR EACH ROW BEGIN
    
    INSERT INTO club_audit (club_id, action, action_date)
    VALUES (OLD.club_id, 'DELETE', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertClub` AFTER INSERT ON `club` FOR EACH ROW BEGIN
    
    INSERT INTO club_audit (club_id, action, action_date)
    VALUES (NEW.club_id, 'INSERT', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateClub` AFTER UPDATE ON `club` FOR EACH ROW BEGIN
    
    INSERT INTO club_audit (club_id, action, action_date)
    VALUES (NEW.club_id, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `club_infoview`
-- (See below for the actual view)
--
CREATE TABLE `club_infoview` (
`club_id` int(11)
,`name` varchar(15)
,`city` varchar(20)
,`league` varchar(15)
,`stadium_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `coacher`
--

CREATE TABLE `coacher` (
  `coacher_id` int(11) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `first_name` varchar(40) NOT NULL,
  `nationality` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `club_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coacher`
--

INSERT INTO `coacher` (`coacher_id`, `last_name`, `first_name`, `nationality`, `email`, `contact`, `club_id`) VALUES
(1, 'Vencent', 'Mashami', 'Rwandan', 'john.smith@example.com', '+250123456', 30),
(2, 'Christian', 'Thiery Froger ', 'France', 'thieryfrogerchristian@example.com', '+245234567', 28),
(3, 'Vencent', 'Mashami', 'Rwandan', 'mashamivencent@gmail.com', '0786543987', 35);

-- --------------------------------------------------------

--
-- Stand-in structure for view `coacher_info`
-- (See below for the actual view)
--
CREATE TABLE `coacher_info` (
`coacher_id` int(11)
,`last_name` varchar(20)
,`first_name` varchar(40)
,`nationality` varchar(20)
,`email` varchar(100)
,`contact` varchar(10)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `coacher_infoview`
-- (See below for the actual view)
--
CREATE TABLE `coacher_infoview` (
`coacher_id` int(11)
,`last_name` varchar(20)
,`first_name` varchar(40)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_view`
-- (See below for the actual view)
--
CREATE TABLE `delete_view` (
`bank_id` int(11)
,`bank_name` varchar(30)
,`location` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `fun_club`
--

CREATE TABLE `fun_club` (
  `funclub_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `website` varchar(50) NOT NULL,
  `club_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fun_club`
--

INSERT INTO `fun_club` (`funclub_id`, `name`, `description`, `contact`, `website`, `club_id`) VALUES
(6, 'URUBABYINGWE FUN', 'A club for passionate football fans in Gasogi FC', '+250123456', 'www.gasogifunclub.com', 36),
(7, 'GITINYIRO FUN', 'Supporting local and national football teams in APR FC', '+250234567', 'www.kigalisupporters.com', 28),
(8, 'Rubavu Football Lovers', 'Bringing football fans together in Marine FC', '+250345678', 'www.rubavulovers.com', 38),
(9, 'Nyagatare Soccer Fans', 'Uniting soccer enthusiasts in Sunrise FC', '+250456789', 'www.nyagatarefans.com', 35),
(10, 'Huye Football Enclave', 'A community of football lovers in Mukura FC', '+250567890', 'www.huyeenclave.com', 37);

-- --------------------------------------------------------

--
-- Stand-in structure for view `fun_club_info`
-- (See below for the actual view)
--
CREATE TABLE `fun_club_info` (
`funclub_id` int(11)
,`name` varchar(50)
,`description` varchar(100)
,`contact` varchar(10)
,`website` varchar(50)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `fun_club_infoview`
-- (See below for the actual view)
--
CREATE TABLE `fun_club_infoview` (
`funclub_id` int(11)
,`name` varchar(50)
,`contact` varchar(10)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_coacherview`
-- (See below for the actual view)
--
CREATE TABLE `insert_coacherview` (
`coacher_id` int(11)
,`last_name` varchar(20)
,`first_name` varchar(40)
,`nationality` varchar(20)
,`email` varchar(100)
,`contact` varchar(10)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_funclubview`
-- (See below for the actual view)
--
CREATE TABLE `insert_funclubview` (
`funclub_id` int(11)
,`name` varchar(50)
,`description` varchar(100)
,`contact` varchar(10)
,`website` varchar(50)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_managerview`
-- (See below for the actual view)
--
CREATE TABLE `insert_managerview` (
`manager_id` int(11)
,`last_name` varchar(20)
,`first_name` varchar(20)
,`email` varchar(50)
,`contact` varchar(10)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_matchsview`
-- (See below for the actual view)
--
CREATE TABLE `insert_matchsview` (
`match_id` int(11)
,`match_date` date
,`home_club` varchar(10)
,`away_club` varchar(10)
,`referee_names` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_playerview`
-- (See below for the actual view)
--
CREATE TABLE `insert_playerview` (
`playeer_id` int(11)
,`last_name` varchar(50)
,`first_name` varchar(50)
,`email` varchar(100)
,`contact` varchar(10)
,`position` varchar(15)
,`club_id` int(11)
,`country` varchar(40)
,`date_of_birth` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_user_adminview`
-- (See below for the actual view)
--
CREATE TABLE `insert_user_adminview` (
`last_name` varchar(30)
,`first_name` varchar(30)
,`email` varchar(50)
,`password` varchar(10)
,`contact` varchar(10)
,`user_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_view` (
`club_id` int(11)
,`name` varchar(15)
,`city` varchar(20)
,`league` varchar(15)
,`stadium_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `league`
--

CREATE TABLE `league` (
  `league_id` int(11) NOT NULL,
  `league_name` varchar(200) NOT NULL,
  `country` varchar(20) NOT NULL,
  `season` varchar(150) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `number_club` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `league`
--

INSERT INTO `league` (`league_id`, `league_name`, `country`, `season`, `start_date`, `end_date`, `number_club`) VALUES
(1, 'Rwanda Premier League', 'Rwanda', '2023-2024', '2023-08-01', '2024-05-31', 16),
(2, 'Amahoro cup', 'Rwanda', '2023-2024', '2023-08-01', '2024-05-31', 32);

-- --------------------------------------------------------

--
-- Stand-in structure for view `league_info`
-- (See below for the actual view)
--
CREATE TABLE `league_info` (
`league_id` int(11)
,`league_name` varchar(200)
,`country` varchar(20)
,`season` varchar(150)
,`start_date` date
,`end_date` date
,`number_club` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `league_infoview`
-- (See below for the actual view)
--
CREATE TABLE `league_infoview` (
`league_id` int(11)
,`league_name` varchar(200)
,`start_date` date
,`end_date` date
);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `manager_id` int(11) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `club_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`manager_id`, `last_name`, `first_name`, `email`, `contact`, `club_id`, `user_id`) VALUES
(1, 'Smith', 'John', 'john.smith@example.com', '+250123456', 28, 1),
(2, 'Johnson', 'Alice', 'alice.johnson@example.com', '+250234567', 29, 2),
(3, 'Williams', 'Robert', 'mugeni@gmail.com', '+250345678', 30, 3),
(4, 'Jones', 'Emily', 'emily.jones@example.com', '+250456789', 35, 4),
(5, 'Brown', 'Michael', 'michael.brown@example.com', '+250567890', 32, 5);

-- --------------------------------------------------------

--
-- Stand-in structure for view `manager_info`
-- (See below for the actual view)
--
CREATE TABLE `manager_info` (
`manager_id` int(11)
,`last_name` varchar(20)
,`first_name` varchar(20)
,`email` varchar(50)
,`contact` varchar(10)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `manager_infoview`
-- (See below for the actual view)
--
CREATE TABLE `manager_infoview` (
`manager_id` int(11)
,`last_name` varchar(20)
,`first_name` varchar(20)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `matchs`
--

CREATE TABLE `matchs` (
  `match_id` int(11) NOT NULL,
  `match_date` date NOT NULL,
  `home_club` varchar(10) NOT NULL,
  `away_club` varchar(10) NOT NULL,
  `referee_names` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `matchs`
--

INSERT INTO `matchs` (`match_id`, `match_date`, `home_club`, `away_club`, `referee_names`) VALUES
(1, '2023-08-10', 'APR FC', 'Rayon Spor', 'MUKANSANGA'),
(2, '2023-08-11', 'AS Kigali ', 'Police FC', 'Alice Johnson'),
(3, '2023-08-12', 'Mukura FC', 'Gasogi FC', 'Robert Williams'),
(4, '2023-08-13', 'Marine FC', 'Sunrise FC', 'Emily Jones'),
(5, '2023-08-14', 'Bugesera F', 'Kiyovu FC', 'Michael Brown');

-- --------------------------------------------------------

--
-- Stand-in structure for view `matchs_info`
-- (See below for the actual view)
--
CREATE TABLE `matchs_info` (
`match_id` int(11)
,`match_date` date
,`home_club` varchar(10)
,`away_club` varchar(10)
,`referee_names` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `matchs_infoview`
-- (See below for the actual view)
--
CREATE TABLE `matchs_infoview` (
`match_id` int(11)
,`match_date` date
,`home_club` varchar(10)
,`away_club` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

CREATE TABLE `player` (
  `playeer_id` int(11) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `position` varchar(15) NOT NULL,
  `club_id` int(11) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `match_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `player`
--

INSERT INTO `player` (`playeer_id`, `last_name`, `first_name`, `email`, `contact`, `position`, `club_id`, `country`, `date_of_birth`, `match_id`) VALUES
(1, 'Mbaoma', 'Victor', 'mbaoma@gmail.com', '+245785643', 'Forward', 28, 'Rwanda', '1996-10-20', NULL),
(2, 'Sekamana', 'Maxime', 'sekamana@gmail.com', '+250785766', 'Forward', 28, 'Rwanda', '1996-01-01', NULL),
(3, 'Mugunga', 'Yves', 'mugunga@gmail.com', '+250788056', 'Forward', 28, 'Rwanda', '1997-01-01', NULL),
(4, 'Bizimana', 'Yannick', 'bizimana@gmail.com', '+250785566', 'Forward', 28, 'Rwanda', '2001-01-01', NULL),
(5, 'Mugisha', 'Gilbert', 'mugisha@gmail.com', '+250785643', 'Forward', 28, 'Rwanda', '2000-01-01', NULL);

--
-- Triggers `player`
--
DELIMITER $$
CREATE TRIGGER `AfterDeletePlayer` AFTER DELETE ON `player` FOR EACH ROW BEGIN
    
    UPDATE club SET total_players = total_players - 1 WHERE club_id = OLD.club_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertPlayer` AFTER INSERT ON `player` FOR EACH ROW BEGIN
    
    INSERT INTO player_audit (playeer_id, action, action_date)
    VALUES (NEW.playeer_id, 'INSERT', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdatePlayer` AFTER UPDATE ON `player` FOR EACH ROW BEGIN
    
    INSERT INTO player_audit (playeer_id, action, action_date)
    VALUES (NEW.playeer_id, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `player_infoview`
-- (See below for the actual view)
--
CREATE TABLE `player_infoview` (
`playeer_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`email` varchar(100)
,`contact` varchar(10)
,`position` varchar(15)
,`club_id` int(11)
,`country` varchar(40)
,`date_of_birth` date
);

-- --------------------------------------------------------

--
-- Table structure for table `stadium`
--

CREATE TABLE `stadium` (
  `studium_id` int(11) NOT NULL,
  `studium_name` varchar(30) NOT NULL,
  `capacity` int(11) NOT NULL,
  `club_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stadium`
--

INSERT INTO `stadium` (`studium_id`, `studium_name`, `capacity`, `club_id`) VALUES
(1, 'Kigali Pele Stadium', 15000, 28),
(2, 'Umuganda Stadium', 12000, 43),
(3, 'Huye Stadium', 7500, 37),
(4, 'UBWOROHERANE stadium Stadium', 9000, 33),
(5, 'Nyagatare Stadium', 8000, 35),
(6, 'Ngoma Stadium', 8000, 41),
(7, 'Bugesera Stadium', 8000, 39);

-- --------------------------------------------------------

--
-- Stand-in structure for view `stadium_info`
-- (See below for the actual view)
--
CREATE TABLE `stadium_info` (
`studium_id` int(11)
,`studium_name` varchar(30)
,`capacity` int(11)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `stadium_infoview`
-- (See below for the actual view)
--
CREATE TABLE `stadium_infoview` (
`studium_id` int(11)
,`studium_name` varchar(30)
,`capacity` int(11)
,`club_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `subquery_view`
-- (See below for the actual view)
--
CREATE TABLE `subquery_view` (
`name` varchar(15)
,`num_players` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_view`
-- (See below for the actual view)
--
CREATE TABLE `update_view` (
`club_id` int(11)
,`name` varchar(15)
,`city` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `user_admin`
--

CREATE TABLE `user_admin` (
  `last_name` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_admin`
--

INSERT INTO `user_admin` (`last_name`, `first_name`, `email`, `password`, `contact`, `user_id`) VALUES
('jean', 'NSHUTI', 'john.smith@example.com', 'password12', '+250123432', 1),
('Johnson', 'KABERA', 'alice.johnson@example.com', 'securepass', '+250234437', 2),
('Williams', 'RUSANGANWA', 'robert.williams@example.com', 'secret123!', '+250346578', 3),
('Jones', 'RUBAYITA', 'emily.jones@example.com', 'mypassword', '+250456789', 4),
('Brown', 'MUREKATETE', 'michael.brown@example.com', 'adminpass@', '+250567896', 5);

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_admin_info`
-- (See below for the actual view)
--
CREATE TABLE `user_admin_info` (
`last_name` int(11)
,`first_name` varchar(30)
,`email` varchar(50)
,`password` varchar(10)
,`contact` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_admin_infoview`
-- (See below for the actual view)
--
CREATE TABLE `user_admin_infoview` (
`last_name` int(11)
,`first_name` varchar(30)
,`email` varchar(50)
);

-- --------------------------------------------------------

--
-- Structure for view `all_info`
--
DROP TABLE IF EXISTS `all_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_info`  AS SELECT `p`.`playeer_id` AS `playeer_id`, `p`.`first_name` AS `player_first_name`, `p`.`last_name` AS `player_last_name`, `p`.`position` AS `player_position`, `p`.`date_of_birth` AS `player_date_of_birth`, `c`.`coacher_id` AS `coacher_id`, `c`.`first_name` AS `coach_first_name`, `c`.`last_name` AS `coach_last_name`, `cl`.`club_id` AS `club_id`, `cl`.`name` AS `name`, `cl`.`stadium_name` AS `club_stadium_name` FROM ((`player` `p` left join `coacher` `c` on(`p`.`club_id` = `c`.`club_id`)) left join `club` `cl` on(`p`.`club_id` = `cl`.`club_id`))  ;

-- --------------------------------------------------------

--
-- Structure for view `bank_info`
--
DROP TABLE IF EXISTS `bank_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bank_info`  AS SELECT `bank`.`bank_id` AS `bank_id`, `bank`.`bank_name` AS `bank_name`, `bank`.`location` AS `location`, `bank`.`website` AS `website`, `bank`.`contact` AS `contact`, `bank`.`bank_account` AS `bank_account` FROM `bank``bank`  ;

-- --------------------------------------------------------

--
-- Structure for view `bank_informationview`
--
DROP TABLE IF EXISTS `bank_informationview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bank_informationview`  AS SELECT `bank`.`bank_id` AS `bank_id`, `bank`.`bank_name` AS `bank_name`, `bank`.`location` AS `location`, `bank`.`bank_account` AS `bank_account` FROM `bank``bank`  ;

-- --------------------------------------------------------

--
-- Structure for view `club_infoview`
--
DROP TABLE IF EXISTS `club_infoview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `club_infoview`  AS SELECT `club`.`club_id` AS `club_id`, `club`.`name` AS `name`, `club`.`city` AS `city`, `club`.`league` AS `league`, `club`.`stadium_name` AS `stadium_name` FROM `club``club`  ;

-- --------------------------------------------------------

--
-- Structure for view `coacher_info`
--
DROP TABLE IF EXISTS `coacher_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `coacher_info`  AS SELECT `coacher`.`coacher_id` AS `coacher_id`, `coacher`.`last_name` AS `last_name`, `coacher`.`first_name` AS `first_name`, `coacher`.`nationality` AS `nationality`, `coacher`.`email` AS `email`, `coacher`.`contact` AS `contact`, `coacher`.`club_id` AS `club_id` FROM `coacher``coacher`  ;

-- --------------------------------------------------------

--
-- Structure for view `coacher_infoview`
--
DROP TABLE IF EXISTS `coacher_infoview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `coacher_infoview`  AS SELECT `coacher`.`coacher_id` AS `coacher_id`, `coacher`.`last_name` AS `last_name`, `coacher`.`first_name` AS `first_name`, `coacher`.`club_id` AS `club_id` FROM `coacher``coacher`  ;

-- --------------------------------------------------------

--
-- Structure for view `delete_view`
--
DROP TABLE IF EXISTS `delete_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `delete_view`  AS SELECT `bank`.`bank_id` AS `bank_id`, `bank`.`bank_name` AS `bank_name`, `bank`.`location` AS `location` FROM `bank` WHERE `bank`.`location` = 'Rubavu' union all select `stadium`.`studium_id` AS `studium_id`,`stadium`.`studium_name` AS `studium_name`,`stadium`.`capacity` AS `capacity` from `stadium` where `stadium`.`capacity` < 10000  ;

-- --------------------------------------------------------

--
-- Structure for view `fun_club_info`
--
DROP TABLE IF EXISTS `fun_club_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fun_club_info`  AS SELECT `fun_club`.`funclub_id` AS `funclub_id`, `fun_club`.`name` AS `name`, `fun_club`.`description` AS `description`, `fun_club`.`contact` AS `contact`, `fun_club`.`website` AS `website`, `fun_club`.`club_id` AS `club_id` FROM `fun_club``fun_club`  ;

-- --------------------------------------------------------

--
-- Structure for view `fun_club_infoview`
--
DROP TABLE IF EXISTS `fun_club_infoview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fun_club_infoview`  AS SELECT `fun_club`.`funclub_id` AS `funclub_id`, `fun_club`.`name` AS `name`, `fun_club`.`contact` AS `contact`, `fun_club`.`club_id` AS `club_id` FROM `fun_club``fun_club`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_coacherview`
--
DROP TABLE IF EXISTS `insert_coacherview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_coacherview`  AS SELECT `coacher`.`coacher_id` AS `coacher_id`, `coacher`.`last_name` AS `last_name`, `coacher`.`first_name` AS `first_name`, `coacher`.`nationality` AS `nationality`, `coacher`.`email` AS `email`, `coacher`.`contact` AS `contact`, `coacher`.`club_id` AS `club_id` FROM `coacher` WHERE `coacher`.`coacher_id` = 33  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_funclubview`
--
DROP TABLE IF EXISTS `insert_funclubview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_funclubview`  AS SELECT `fun_club`.`funclub_id` AS `funclub_id`, `fun_club`.`name` AS `name`, `fun_club`.`description` AS `description`, `fun_club`.`contact` AS `contact`, `fun_club`.`website` AS `website`, `fun_club`.`club_id` AS `club_id` FROM `fun_club` WHERE `fun_club`.`funclub_id` = 22  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_managerview`
--
DROP TABLE IF EXISTS `insert_managerview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_managerview`  AS SELECT `manager`.`manager_id` AS `manager_id`, `manager`.`last_name` AS `last_name`, `manager`.`first_name` AS `first_name`, `manager`.`email` AS `email`, `manager`.`contact` AS `contact`, `manager`.`club_id` AS `club_id` FROM `manager` WHERE 1 = 55  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_matchsview`
--
DROP TABLE IF EXISTS `insert_matchsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_matchsview`  AS SELECT `matchs`.`match_id` AS `match_id`, `matchs`.`match_date` AS `match_date`, `matchs`.`home_club` AS `home_club`, `matchs`.`away_club` AS `away_club`, `matchs`.`referee_names` AS `referee_names` FROM `matchs` WHERE `matchs`.`match_id` = 77  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_playerview`
--
DROP TABLE IF EXISTS `insert_playerview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_playerview`  AS SELECT `player`.`playeer_id` AS `playeer_id`, `player`.`last_name` AS `last_name`, `player`.`first_name` AS `first_name`, `player`.`email` AS `email`, `player`.`contact` AS `contact`, `player`.`position` AS `position`, `player`.`club_id` AS `club_id`, `player`.`country` AS `country`, `player`.`date_of_birth` AS `date_of_birth` FROM `player` WHERE 1 = 00  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_user_adminview`
--
DROP TABLE IF EXISTS `insert_user_adminview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_user_adminview`  AS SELECT `user_admin`.`last_name` AS `last_name`, `user_admin`.`first_name` AS `first_name`, `user_admin`.`email` AS `email`, `user_admin`.`password` AS `password`, `user_admin`.`contact` AS `contact`, `user_admin`.`user_id` AS `user_id` FROM `user_admin` WHERE `user_admin`.`user_id` = 55  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_view`
--
DROP TABLE IF EXISTS `insert_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_view`  AS SELECT `club`.`club_id` AS `club_id`, `club`.`name` AS `name`, `club`.`city` AS `city`, `club`.`league` AS `league`, `club`.`stadium_name` AS `stadium_name` FROM `club` WHERE 1 = 00  ;

-- --------------------------------------------------------

--
-- Structure for view `league_info`
--
DROP TABLE IF EXISTS `league_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `league_info`  AS SELECT `league`.`league_id` AS `league_id`, `league`.`league_name` AS `league_name`, `league`.`country` AS `country`, `league`.`season` AS `season`, `league`.`start_date` AS `start_date`, `league`.`end_date` AS `end_date`, `league`.`number_club` AS `number_club` FROM `league``league`  ;

-- --------------------------------------------------------

--
-- Structure for view `league_infoview`
--
DROP TABLE IF EXISTS `league_infoview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `league_infoview`  AS SELECT `league`.`league_id` AS `league_id`, `league`.`league_name` AS `league_name`, `league`.`start_date` AS `start_date`, `league`.`end_date` AS `end_date` FROM `league``league`  ;

-- --------------------------------------------------------

--
-- Structure for view `manager_info`
--
DROP TABLE IF EXISTS `manager_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `manager_info`  AS SELECT `manager`.`manager_id` AS `manager_id`, `manager`.`last_name` AS `last_name`, `manager`.`first_name` AS `first_name`, `manager`.`email` AS `email`, `manager`.`contact` AS `contact`, `manager`.`club_id` AS `club_id` FROM `manager``manager`  ;

-- --------------------------------------------------------

--
-- Structure for view `manager_infoview`
--
DROP TABLE IF EXISTS `manager_infoview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `manager_infoview`  AS SELECT `manager`.`manager_id` AS `manager_id`, `manager`.`last_name` AS `last_name`, `manager`.`first_name` AS `first_name`, `manager`.`club_id` AS `club_id` FROM `manager``manager`  ;

-- --------------------------------------------------------

--
-- Structure for view `matchs_info`
--
DROP TABLE IF EXISTS `matchs_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `matchs_info`  AS SELECT `matchs`.`match_id` AS `match_id`, `matchs`.`match_date` AS `match_date`, `matchs`.`home_club` AS `home_club`, `matchs`.`away_club` AS `away_club`, `matchs`.`referee_names` AS `referee_names` FROM `matchs``matchs`  ;

-- --------------------------------------------------------

--
-- Structure for view `matchs_infoview`
--
DROP TABLE IF EXISTS `matchs_infoview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `matchs_infoview`  AS SELECT `matchs`.`match_id` AS `match_id`, `matchs`.`match_date` AS `match_date`, `matchs`.`home_club` AS `home_club`, `matchs`.`away_club` AS `away_club` FROM `matchs``matchs`  ;

-- --------------------------------------------------------

--
-- Structure for view `player_infoview`
--
DROP TABLE IF EXISTS `player_infoview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `player_infoview`  AS SELECT `player`.`playeer_id` AS `playeer_id`, `player`.`first_name` AS `first_name`, `player`.`last_name` AS `last_name`, `player`.`email` AS `email`, `player`.`contact` AS `contact`, `player`.`position` AS `position`, `player`.`club_id` AS `club_id`, `player`.`country` AS `country`, `player`.`date_of_birth` AS `date_of_birth` FROM `player``player`  ;

-- --------------------------------------------------------

--
-- Structure for view `stadium_info`
--
DROP TABLE IF EXISTS `stadium_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `stadium_info`  AS SELECT `stadium`.`studium_id` AS `studium_id`, `stadium`.`studium_name` AS `studium_name`, `stadium`.`capacity` AS `capacity`, `stadium`.`club_id` AS `club_id` FROM `stadium``stadium`  ;

-- --------------------------------------------------------

--
-- Structure for view `stadium_infoview`
--
DROP TABLE IF EXISTS `stadium_infoview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `stadium_infoview`  AS SELECT `stadium`.`studium_id` AS `studium_id`, `stadium`.`studium_name` AS `studium_name`, `stadium`.`capacity` AS `capacity`, `stadium`.`club_id` AS `club_id` FROM `stadium``stadium`  ;

-- --------------------------------------------------------

--
-- Structure for view `subquery_view`
--
DROP TABLE IF EXISTS `subquery_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subquery_view`  AS SELECT `club`.`name` AS `name`, (select count(0) from `player` where `player`.`club_id` = `club`.`club_id`) AS `num_players` FROM `club``club`  ;

-- --------------------------------------------------------

--
-- Structure for view `update_view`
--
DROP TABLE IF EXISTS `update_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_view`  AS SELECT `club`.`club_id` AS `club_id`, `club`.`name` AS `name`, `club`.`city` AS `city` FROM `club` WHERE `club`.`city` = 'Kigali''Kigali'  ;

-- --------------------------------------------------------

--
-- Structure for view `user_admin_info`
--
DROP TABLE IF EXISTS `user_admin_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `user_admin_info`  AS SELECT `user_admin`.`user_id` AS `last_name`, `user_admin`.`first_name` AS `first_name`, `user_admin`.`email` AS `email`, `user_admin`.`password` AS `password`, `user_admin`.`contact` AS `contact` FROM `user_admin``user_admin`  ;

-- --------------------------------------------------------

--
-- Structure for view `user_admin_infoview`
--
DROP TABLE IF EXISTS `user_admin_infoview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `user_admin_infoview`  AS SELECT `user_admin`.`user_id` AS `last_name`, `user_admin`.`first_name` AS `first_name`, `user_admin`.`email` AS `email` FROM `user_admin``user_admin`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`bank_id`),
  ADD KEY `club_bank` (`club_id`);

--
-- Indexes for table `club`
--
ALTER TABLE `club`
  ADD PRIMARY KEY (`club_id`),
  ADD KEY `league_club` (`league_id`);

--
-- Indexes for table `coacher`
--
ALTER TABLE `coacher`
  ADD PRIMARY KEY (`coacher_id`),
  ADD KEY `club_id` (`club_id`);

--
-- Indexes for table `fun_club`
--
ALTER TABLE `fun_club`
  ADD PRIMARY KEY (`funclub_id`),
  ADD KEY `club_id` (`club_id`);

--
-- Indexes for table `league`
--
ALTER TABLE `league`
  ADD PRIMARY KEY (`league_id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`manager_id`),
  ADD KEY `club_id` (`club_id`),
  ADD KEY `user_admin_manager` (`user_id`);

--
-- Indexes for table `matchs`
--
ALTER TABLE `matchs`
  ADD PRIMARY KEY (`match_id`);

--
-- Indexes for table `player`
--
ALTER TABLE `player`
  ADD PRIMARY KEY (`playeer_id`),
  ADD KEY `club_player` (`club_id`);

--
-- Indexes for table `stadium`
--
ALTER TABLE `stadium`
  ADD PRIMARY KEY (`studium_id`),
  ADD KEY `club_id` (`club_id`);

--
-- Indexes for table `user_admin`
--
ALTER TABLE `user_admin`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `club`
--
ALTER TABLE `club`
  MODIFY `club_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `coacher`
--
ALTER TABLE `coacher`
  MODIFY `coacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fun_club`
--
ALTER TABLE `fun_club`
  MODIFY `funclub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `league`
--
ALTER TABLE `league`
  MODIFY `league_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `manager_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `matchs`
--
ALTER TABLE `matchs`
  MODIFY `match_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `player`
--
ALTER TABLE `player`
  MODIFY `playeer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `stadium`
--
ALTER TABLE `stadium`
  MODIFY `studium_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_admin`
--
ALTER TABLE `user_admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bank`
--
ALTER TABLE `bank`
  ADD CONSTRAINT `club_bank` FOREIGN KEY (`club_id`) REFERENCES `club` (`club_id`);

--
-- Constraints for table `club`
--
ALTER TABLE `club`
  ADD CONSTRAINT `league_club` FOREIGN KEY (`league_id`) REFERENCES `league` (`league_id`);

--
-- Constraints for table `coacher`
--
ALTER TABLE `coacher`
  ADD CONSTRAINT `coacher_ibfk_1` FOREIGN KEY (`club_id`) REFERENCES `club` (`club_id`);

--
-- Constraints for table `fun_club`
--
ALTER TABLE `fun_club`
  ADD CONSTRAINT `fun_club_ibfk_1` FOREIGN KEY (`club_id`) REFERENCES `club` (`club_id`);

--
-- Constraints for table `manager`
--
ALTER TABLE `manager`
  ADD CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`club_id`) REFERENCES `club` (`club_id`),
  ADD CONSTRAINT `user_admin_manager` FOREIGN KEY (`user_id`) REFERENCES `user_admin` (`user_id`);

--
-- Constraints for table `player`
--
ALTER TABLE `player`
  ADD CONSTRAINT `club_player` FOREIGN KEY (`club_id`) REFERENCES `club` (`club_id`);

--
-- Constraints for table `stadium`
--
ALTER TABLE `stadium`
  ADD CONSTRAINT `stadium_ibfk_1` FOREIGN KEY (`club_id`) REFERENCES `club` (`club_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
