-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 01:54 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ingabire_pascaline_222006249`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Deletecars` (IN `p_car_id` INT(11), IN `p_make` VARCHAR(50), IN `p_model` VARCHAR(50), IN `p_year` DATE, IN `p_licence_plate_number` VARCHAR(50))   BEGIN
    DELETE FROM cars
    WHERE car_id = p_car_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deleteinsurance` (IN `p_insurance_id` INT(11), IN `p_type` VARCHAR(50), IN `p_coverage_limit` VARCHAR(50), IN `p_year` DATE, IN `p_price` INT(34))   BEGIN
    DELETE FROM insurance
    WHERE insurance_id = p_insurance_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displaycars` ()   BEGIN
    SELECT * FROM cars;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displaycustomers` ()   BEGIN
    SELECT * FROM customers;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayinsurance` ()   BEGIN
    SELECT * FROM insurance;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displaypayment` ()   BEGIN
    SELECT * FROM payment;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayrentals` ()   BEGIN
    SELECT * FROM rentals;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayreservation` ()   BEGIN
    SELECT * FROM reservations;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Getcar` (IN `p_make` VARCHAR(255))   BEGIN
    SELECT make
    FROM cars
    WHERE car_id = (
        SELECT car_id
        FROM cars
        WHERE make = p_make
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertAttendanceReport` (IN `p_reportID` INT(11), IN `p_ReportType` VARCHAR(50), IN `p_GenerationDateTime` DATETIME, IN `p_Parameters` TEXT, IN `p_ReportFormat` VARCHAR(20))   BEGIN
    INSERT INTO Report (reportID,
                        ReportType, 
                        GenerationDateTime, 
                        Parameters, 
                        ReportFormat)
    VALUES (p_report,
            p_ReportType, 
            p_GenerationDateTime, 
            p_Parameters, 
            p_ReportFormat);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertLeave_information` (IN `p_leaveID` INT(11), IN `p_EmployeeID` INT, IN `p_LeaveType` VARCHAR(50), IN `p_StartDate` DATE, IN `p_EndDate` DATE, IN `p_TotalLeaveDays` DECIMAL(5,2), IN `p_ApprovalStatus` VARCHAR(20), IN `p_Reason` TEXT, IN `p_SupportingDocuments` BLOB)   BEGIN
    INSERT INTO employee_Leave (leaveID,
                                EmployeeID, 
                                LeaveType, 
                                StartDate, 
                                EndDate, 
                                TotalLeaveDays,
                                ApprovalStatus, 
                                Reason, 
                                SupportingDocuments)
    VALUES (p_leaveID,
            p_EmployeeID, 
            p_LeaveType,
            p_StartDate,
            p_EndDate, 
            p_TotalLeaveDays, 
            p_ApprovalStatus, 
            p_Reason, 
            p_SupportingDocuments);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertNotification` (IN `p_notificationID` INT(30), IN `p_EmployeeID` INT, IN `p_NotificationType` VARCHAR(50), IN `p_Content` TEXT, IN `p_Timestamp` DATETIME, IN `p_Status` VARCHAR(20))   BEGIN
    INSERT INTO Notification (notificationID,
                              EmployeeID, 
                              NotificationType, 
                              Content, 
                              Timestamp, Status)
    VALUES (P_notificationID,
            p_EmployeeID, 
            p_NotificationType, 
            p_Content, 
            p_Timestamp, 
            p_Status);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertSettings` (IN `p_settingID` INT(60), IN `p_SystemSettings` TEXT, IN `p_EmailSMSConfiguration` TEXT, IN `p_NotificationsConfiguration` TEXT, IN `p_UserRolesPermissions` TEXT)   BEGIN
    INSERT INTO Settings (settingID,SystemSettings, EmailSMSConfiguration, NotificationsConfiguration, UserRolesPermissions)
    VALUES (p_settingID,p_SystemSettings, p_EmailSMSConfiguration, p_NotificationsConfiguration, p_UserRolesPermissions);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_cars` (IN `p_car_id` INT(11), IN `p_make` VARCHAR(225), IN `p_model` VARCHAR(225), IN `p_year` INT(25), IN `p_license_plate_number` VARCHAR(225))   BEGIN
    INSERT INTO customers(car_id ,make,model,year,license_plate_number)
VALUES (
p_car_id,           
p_make,                
p_model ,            
p_year,         
p_licence_plate_number);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_customers` (IN `p_customer_id` INT(11), IN `p_name` VARCHAR(225), IN `p_address` VARCHAR(225), IN `p_phone_number` VARCHAR(25), IN `p_email` VARCHAR(225), IN `p_driver_license_number` VARCHAR(225))   BEGIN
    INSERT INTO customers(customer_id,name,address,phone_number,email,driver_license_number  
  
)
VALUES (
p_customer_id,           
p_name,                
p_address ,            
p_phone_number,         
p_email ,               
p_driver_license_number );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_insurance` (IN `p_insurance_id` INT(11), IN `p_type` VARCHAR(100), IN `p_coverage_limit` VARCHAR(70), IN `p_price` DECIMAL(10.2))   BEGIN
INSERT INTO insurance(insurance_id,type,coverage_limit,price)
VALUES (
p_insurance_id, 
p_type,      
p_coverage_limit,      
p_price);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_payments` (IN `p_payment_id` INT(11), IN `p_rental_id` INT(11), IN `p_date` DATETIME, IN `p_amount` INT(30), IN `P_payment_method` VARCHAR(50))   BEGIN
    INSERT INTO customers(payment_id,rental_id,date,amount,payment_method)
VALUES (
p_payment_id, 
p_rental_id,      
p_date,      
p_amount,     
P_payment_method );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_rental` (IN `p_rental_id` INT(11), IN `p_customer_id` INT(11), IN `p_car_id` INT(11), IN `p_start_date` DATETIME, IN `p_end_date` DATETIME, IN `p_total_price` DECIMAL(10,2))   BEGIN
    INSERT INTO customers(rental_id,customer_id ,car_id ,start_date,end_date,total_price)
VALUES (
p_rental_id, 
p_customer_id,      
p_car_id,         
p_start_date,       
p_end_date,         
p_total_price);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_reservation` (IN `p_reservation_id` INT(11), IN `p_car_id` VARCHAR(100), IN `p_customer_id` VARCHAR(70), IN `p_reservationdate` DATE)   BEGIN
INSERT INTO reservations(reservation_id,car_id,customer_id,reservation_date)
VALUES (
 p_reservation_id, 
p_car_id,      
p_customer_id,      
p_reservationdate
);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Updatecars` (IN `p_car_id` INT(11), IN `p_make` VARCHAR(50), IN `p_model` VARCHAR(50), IN `p_year` INT(50), IN `p_licence_plate_number` VARCHAR(50))   BEGIN
    UPDATE cars
    SET
        make= p_new_make,
        model = p_new_model, 
         year= p_new_year,
        licence_plate_number= p_new_licence_plate_number 
        
    WHERE
        car_id = p_car_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Updateinsurance` (IN `p_insurance_id` INT(11), IN `p_type` VARCHAR(50), IN `p_coverage_limit` VARCHAR(50), IN `p_price` DECIMAL(50))   BEGIN
    UPDATE insurance
    SET
        type= p_type,
        coverage_limit= p_coverage_limit, 
         price= p_price
        
    WHERE
        insurance_id = p_insurance_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_aline`
-- (See below for the actual view)
--
CREATE TABLE `all_aline` (
`payment_id` int(11)
,`rental_id` int(11)
,`date` datetime
,`amount` decimal(10,2)
,`payment_method` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_anita`
-- (See below for the actual view)
--
CREATE TABLE `all_anita` (
`car_id` int(11)
,`make` varchar(255)
,`model` varchar(255)
,`year` int(11)
,`license_plate_number` varchar(255)
,`current_location` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_cyntia`
-- (See below for the actual view)
--
CREATE TABLE `all_cyntia` (
`reservation_id` int(11)
,`car_id` int(11)
,`customer_id` int(11)
,`reservation_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_diane`
-- (See below for the actual view)
--
CREATE TABLE `all_diane` (
`insurance_id` int(11)
,`type` varchar(255)
,`coverage_limits` varchar(255)
,`price` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_gwiza`
-- (See below for the actual view)
--
CREATE TABLE `all_gwiza` (
`rental_id` int(11)
,`customer_id` int(11)
,`car_id` int(11)
,`start_date` datetime
,`end_date` datetime
,`total_price` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_pacc`
-- (See below for the actual view)
--
CREATE TABLE `all_pacc` (
`customer_id` int(11)
,`name` varchar(255)
,`address` varchar(255)
,`phone_number` varchar(255)
,`email` varchar(255)
,`driver_license_number` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `car_id` int(11) NOT NULL,
  `make` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `year` int(11) NOT NULL,
  `license_plate_number` varchar(255) NOT NULL,
  `current_location` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`car_id`, `make`, `model`, `year`, `license_plate_number`, `current_location`) VALUES
(1, 'Honda', 'Corolla', 2023, 'ABC123', 'Los Angeles'),
(2, 'Honda', 'Civic', 2022, 'DEF456', 'New York'),
(3, 'RANGOVER', 'APPLE', 2020, 'AED23001E', 'PARIS'),
(4, 'Toyota', 'Corolla', 2023, 'ABC123', 'Los Angeles'),
(5, 'Honda', 'Civic', 2022, 'ABC123', 'New York'),
(6, 'RANGOVER', 'APPLE', 2020, 'AED23001E', 'PARIS');

--
-- Triggers `cars`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertCAR` AFTER INSERT ON `cars` FOR EACH ROW BEGIN

END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertcars` AFTER INSERT ON `cars` FOR EACH ROW BEGIN
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdatecars` AFTER UPDATE ON `cars` FOR EACH ROW BEGIN

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `driver_license_number` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `name`, `address`, `phone_number`, `email`, `driver_license_number`) VALUES
(1, 'John Doe', '123 Main Street', '123-456-7890', 'new_email@email.com', '123456789'),
(2, 'Jane Doe', '456 Elm Street', '987-654-3210', 'jane.doe@email.com', '987654321'),
(3, 'kingjames', 'kigali', '+250783456348', 'kingjames12@gmail.com', '122334576'),
(4, 'John Doe', '123 Main Street', '123-456-7890', 'john.doe@email.com', '123456789'),
(5, 'Jane Doe', '456 Elm Street', '987-654-3210', 'jane.doe@email.com', '987654321'),
(6, 'kingjames', 'kigali', '+250783456348', 'kingjames12@gmail.com', '122334576'),
(7, 'John Doe', '123 Main Street', '123-456-7890', 'john.doe@email.com', '123456789'),
(8, 'Jane Doe', '456 Elm Street', '987-654-3210', 'jane.doe@email.com', '987654321'),
(9, 'kingjames', 'kigali', '+250783456348', 'kingjames12@gmail.com', '122334576');

--
-- Triggers `customers`
--
DELIMITER $$
CREATE TRIGGER `AfterDeletecustomers` AFTER DELETE ON `customers` FOR EACH ROW BEGIN
    -- Insert code for your desired actions here
    -- For example, you might want to log the deletion, update book availability, or send notifications
    -- You can reference OLD.column_name to access the data of the deleted borrowing record
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertcustomer` AFTER INSERT ON `customers` FOR EACH ROW BEGIN

END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdatecustomer_information` AFTER UPDATE ON `customers` FOR EACH ROW BEGIN
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `deleteinsurance_information`
-- (See below for the actual view)
--
CREATE TABLE `deleteinsurance_information` (
`insurance_id` int(11)
,`type` varchar(255)
,`coverage_limits` varchar(255)
,`price` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `deletepayments_information`
-- (See below for the actual view)
--
CREATE TABLE `deletepayments_information` (
`payment_id` int(11)
,`rental_id` int(11)
,`date` datetime
,`amount` decimal(10,2)
,`payment_method` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `insurance`
--

CREATE TABLE `insurance` (
  `insurance_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `coverage_limits` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `insurance`
--

INSERT INTO `insurance` (`insurance_id`, `type`, `coverage_limits`, `price`) VALUES
(1, 'Collision', '100,000', '100.00'),
(3, 'fire', '50000', '1000.00');

--
-- Triggers `insurance`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteinsurance` AFTER DELETE ON `insurance` FOR EACH ROW BEGIN
    -- Insert code for your desired actions here
    -- For example, you might want to log the deletion, update book availability, or send notifications
    -- You can reference OLD.column_name to access the data of the deleted borrowing record
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `rental_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `rental_id`, `date`, `amount`, `payment_method`) VALUES
(2, 2, '2023-08-21 00:00:00', '150.00', 'Cash'),
(3, 1, '2023-08-31 19:00:32', '120000.00', 'credit card');

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

CREATE TABLE `rentals` (
  `rental_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `car_id` int(11) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`rental_id`, `customer_id`, `car_id`, `start_date`, `end_date`, `total_price`) VALUES
(1, 1, 1, '2023-08-18 00:00:00', '2023-08-20 00:00:00', '100.00'),
(2, 2, 2, '2023-08-21 00:00:00', '2023-08-23 00:00:00', '150.00');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `reservation_id` int(11) NOT NULL,
  `car_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `reservation_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`reservation_id`, `car_id`, `customer_id`, `reservation_date`) VALUES
(1, 1, 1, '2023-09-10'),
(2, 2, 2, '2023-09-15'),
(3, 3, 1, '2023-09-20');

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_insurance_information`
-- (See below for the actual view)
--
CREATE TABLE `update_insurance_information` (
`insurance_id` int(11)
,`type` varchar(255)
,`coverage_limits` varchar(255)
,`price` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Structure for view `all_aline`
--
DROP TABLE IF EXISTS `all_aline`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_aline`  AS SELECT `payments`.`payment_id` AS `payment_id`, `payments`.`rental_id` AS `rental_id`, `payments`.`date` AS `date`, `payments`.`amount` AS `amount`, `payments`.`payment_method` AS `payment_method` FROM `payments``payments`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_anita`
--
DROP TABLE IF EXISTS `all_anita`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_anita`  AS SELECT `cars`.`car_id` AS `car_id`, `cars`.`make` AS `make`, `cars`.`model` AS `model`, `cars`.`year` AS `year`, `cars`.`license_plate_number` AS `license_plate_number`, `cars`.`current_location` AS `current_location` FROM `cars``cars`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_cyntia`
--
DROP TABLE IF EXISTS `all_cyntia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_cyntia`  AS SELECT `reservations`.`reservation_id` AS `reservation_id`, `reservations`.`car_id` AS `car_id`, `reservations`.`customer_id` AS `customer_id`, `reservations`.`reservation_date` AS `reservation_date` FROM `reservations``reservations`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_diane`
--
DROP TABLE IF EXISTS `all_diane`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_diane`  AS SELECT `insurance`.`insurance_id` AS `insurance_id`, `insurance`.`type` AS `type`, `insurance`.`coverage_limits` AS `coverage_limits`, `insurance`.`price` AS `price` FROM `insurance``insurance`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_gwiza`
--
DROP TABLE IF EXISTS `all_gwiza`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_gwiza`  AS SELECT `rentals`.`rental_id` AS `rental_id`, `rentals`.`customer_id` AS `customer_id`, `rentals`.`car_id` AS `car_id`, `rentals`.`start_date` AS `start_date`, `rentals`.`end_date` AS `end_date`, `rentals`.`total_price` AS `total_price` FROM `rentals``rentals`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_pacc`
--
DROP TABLE IF EXISTS `all_pacc`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_pacc`  AS SELECT `customers`.`customer_id` AS `customer_id`, `customers`.`name` AS `name`, `customers`.`address` AS `address`, `customers`.`phone_number` AS `phone_number`, `customers`.`email` AS `email`, `customers`.`driver_license_number` AS `driver_license_number` FROM `customers``customers`  ;

-- --------------------------------------------------------

--
-- Structure for view `deleteinsurance_information`
--
DROP TABLE IF EXISTS `deleteinsurance_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deleteinsurance_information`  AS SELECT `insurance`.`insurance_id` AS `insurance_id`, `insurance`.`type` AS `type`, `insurance`.`coverage_limits` AS `coverage_limits`, `insurance`.`price` AS `price` FROM `insurance` WHERE `insurance`.`insurance_id` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `deletepayments_information`
--
DROP TABLE IF EXISTS `deletepayments_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deletepayments_information`  AS SELECT `payments`.`payment_id` AS `payment_id`, `payments`.`rental_id` AS `rental_id`, `payments`.`date` AS `date`, `payments`.`amount` AS `amount`, `payments`.`payment_method` AS `payment_method` FROM `payments` WHERE `payments`.`payment_id` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `update_insurance_information`
--
DROP TABLE IF EXISTS `update_insurance_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_insurance_information`  AS SELECT `insurance`.`insurance_id` AS `insurance_id`, `insurance`.`type` AS `type`, `insurance`.`coverage_limits` AS `coverage_limits`, `insurance`.`price` AS `price` FROM `insurance` WHERE `insurance`.`insurance_id` = 33  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `insurance`
--
ALTER TABLE `insurance`
  ADD PRIMARY KEY (`insurance_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `rental_id` (`rental_id`);

--
-- Indexes for table `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`rental_id`),
  ADD KEY `car_id` (`car_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`reservation_id`),
  ADD KEY `car_id` (`car_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `insurance`
--
ALTER TABLE `insurance`
  MODIFY `insurance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `rentals`
--
ALTER TABLE `rentals`
  MODIFY `rental_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`rental_id`) REFERENCES `rentals` (`rental_id`);

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `rentals_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`),
  ADD CONSTRAINT `rentals_ibfk_2` FOREIGN KEY (`car_id`) REFERENCES `cars` (`car_id`),
  ADD CONSTRAINT `rentals_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`),
  ADD CONSTRAINT `rentals_ibfk_4` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `cars` (`car_id`),
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
