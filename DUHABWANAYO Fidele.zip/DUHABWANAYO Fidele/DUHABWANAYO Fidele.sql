-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2023 at 03:04 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `automated_students_attendance_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(20) NOT NULL,
  `student_id` int(20) NOT NULL,
  `course_id` int(20) NOT NULL,
  `attendance_date` date NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendance_id`, `student_id`, `course_id`, `attendance_date`, `status`) VALUES
(1, 222004920, 10, '2023-09-01', 'attend'),
(1, 222004920, 10, '2023-09-01', 'attend'),
(1, 222004920, 10, '2023-09-01', 'attend');

--
-- Triggers `attendance`
--
DELIMITER $$
CREATE TRIGGER `After deleting Trigger 2` AFTER DELETE ON `attendance` FOR EACH ROW DELETE FROM attendance WHERE attendance_id=10
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `After inserting Trigger` AFTER INSERT ON `attendance` FOR EACH ROW INSERT INTO `attendance` (`attendance_id`, `student_id`, `course_id`, `attendance_date`, `status`) VALUES ('1', '222004920', '10', '2023-09-01', 'attend')
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `After updating Trigger` AFTER UPDATE ON `attendance` FOR EACH ROW update attendance set status='clear' where attendance_id=1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `attendance_view`
-- (See below for the actual view)
--
CREATE TABLE `attendance_view` (
`attendance_id` int(20)
,`student_id` int(20)
,`course_id` int(20)
,`attendance_date` date
,`status` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(20) NOT NULL,
  `course_name` varchar(20) NOT NULL,
  `course_code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `course_code`) VALUES
(10, '12', 'BIT20'),
(10, '12', 'BIT20'),
(10, '12', 'BIT20');

--
-- Triggers `courses`
--
DELIMITER $$
CREATE TRIGGER `After deleting Trigger` AFTER DELETE ON `courses` FOR EACH ROW DELETE FROM courses WHERE course_id=10
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `After inserting Trigger 2` AFTER INSERT ON `courses` FOR EACH ROW INSERT INTO `courses` (`course_id`, `course_name`, `course_code`) VALUES ('10', '12', 'BIT20')
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `After updating Trigger 2` AFTER UPDATE ON `courses` FOR EACH ROW update courses set course_name='20' where course_id=10
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `courses_view`
-- (See below for the actual view)
--
CREATE TABLE `courses_view` (
`course_id` int(20)
,`course_name` varchar(20)
,`course_code` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `enrollment_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`enrollment_id`, `student_id`, `course_id`) VALUES
(1, 222004920, 10),
(2, 222004920, 10);

-- --------------------------------------------------------

--
-- Stand-in structure for view `enrollments_view`
-- (See below for the actual view)
--
CREATE TABLE `enrollments_view` (
`enrollment_id` int(11)
,`student_id` int(11)
,`course_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `Faculty_ID` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Contact_Information` varchar(20) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `Lecturer_names` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`Faculty_ID`, `Name`, `Contact_Information`, `course_id`, `Lecturer_names`) VALUES
(10, 'financial', '0780609487', 10, 'Dr Fidele'),
(11, 'financial', '0780609487', 10, 'Dr Fidele');

-- --------------------------------------------------------

--
-- Stand-in structure for view `faculty_view`
-- (See below for the actual view)
--
CREATE TABLE `faculty_view` (
`Faculty_ID` int(11)
,`Name` varchar(50)
,`Contact_Information` varchar(20)
,`course_id` int(11)
,`Lecturer_names` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `Student_ID` int(11) NOT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) DEFAULT NULL,
  `Date_Of_Birth` date DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`Student_ID`, `First_Name`, `Last_Name`, `Date_Of_Birth`, `Email`) VALUES
(1, 'DUHABWANAYO', 'Fidele', '2023-09-01', 'duhabwanayofidele@gmail.com'),
(2, 'DUHABWANAYO', 'Fidele', '2023-09-01', 'duhabwanayofidele@gmail.com');

-- --------------------------------------------------------

--
-- Stand-in structure for view `students_view`
-- (See below for the actual view)
--
CREATE TABLE `students_view` (
`Student_ID` int(11)
,`First_Name` varchar(50)
,`Last_Name` varchar(50)
,`Date_Of_Birth` date
,`Email` varchar(100)
);

-- --------------------------------------------------------

--
-- Structure for view `attendance_view`
--
DROP TABLE IF EXISTS `attendance_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `attendance_view`  AS  select `attendance`.`attendance_id` AS `attendance_id`,`attendance`.`student_id` AS `student_id`,`attendance`.`course_id` AS `course_id`,`attendance`.`attendance_date` AS `attendance_date`,`attendance`.`status` AS `status` from `attendance` ;

-- --------------------------------------------------------

--
-- Structure for view `courses_view`
--
DROP TABLE IF EXISTS `courses_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `courses_view`  AS  select `courses`.`course_id` AS `course_id`,`courses`.`course_name` AS `course_name`,`courses`.`course_code` AS `course_code` from `courses` ;

-- --------------------------------------------------------

--
-- Structure for view `enrollments_view`
--
DROP TABLE IF EXISTS `enrollments_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `enrollments_view`  AS  select `enrollments`.`enrollment_id` AS `enrollment_id`,`enrollments`.`student_id` AS `student_id`,`enrollments`.`course_id` AS `course_id` from `enrollments` ;

-- --------------------------------------------------------

--
-- Structure for view `faculty_view`
--
DROP TABLE IF EXISTS `faculty_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `faculty_view`  AS  select `faculty`.`Faculty_ID` AS `Faculty_ID`,`faculty`.`Name` AS `Name`,`faculty`.`Contact_Information` AS `Contact_Information`,`faculty`.`course_id` AS `course_id`,`faculty`.`Lecturer_names` AS `Lecturer_names` from `faculty` ;

-- --------------------------------------------------------

--
-- Structure for view `students_view`
--
DROP TABLE IF EXISTS `students_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `students_view`  AS  select `students`.`Student_ID` AS `Student_ID`,`students`.`First_Name` AS `First_Name`,`students`.`Last_Name` AS `Last_Name`,`students`.`Date_Of_Birth` AS `Date_Of_Birth`,`students`.`Email` AS `Email` from `students` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`enrollment_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`Faculty_ID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`Student_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `enrollment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
