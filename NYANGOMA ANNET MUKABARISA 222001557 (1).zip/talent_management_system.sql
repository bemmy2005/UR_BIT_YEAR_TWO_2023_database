-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2023 at 10:46 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `talent_management_system`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_employees`
-- (See below for the actual view)
--
CREATE TABLE `all_employees` (
`employee_id` int(11)
,`name` varchar(255)
,`contact_information` varchar(255)
,`job_title` varchar(255)
,`department` varchar(255)
,`date_of_hire` date
,`education` varchar(255)
,`skills` varchar(255)
,`experience` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `applicant_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_information` varchar(255) NOT NULL,
  `resume` varchar(255) NOT NULL,
  `cover_letter` varchar(255) NOT NULL,
  `application_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`applicant_id`, `name`, `contact_information`, `resume`, `cover_letter`, `application_status`) VALUES
(1, 'Jane Doe', 'jane.doe@email.com', 'resume.pdf', 'cover_letter.pdf', 'Pending');

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_applicant_view`
-- (See below for the actual view)
--
CREATE TABLE `delete_applicant_view` (
`applicant_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_data_view`
-- (See below for the actual view)
--
CREATE TABLE `delete_data_view` (
`employee_id` int(11)
,`name` varchar(255)
,`contact_information` varchar(255)
,`job_title` varchar(255)
,`department` varchar(255)
,`date_of_hire` date
,`education` varchar(255)
,`skills` varchar(255)
,`experience` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_information` varchar(255) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `date_of_hire` date NOT NULL,
  `education` varchar(255) NOT NULL,
  `skills` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employee_id`, `name`, `contact_information`, `job_title`, `department`, `date_of_hire`, `education`, `skills`, `experience`) VALUES
(1, 'John Doe', 'john.doe@email.com', 'Senior Software Engineer', 'Engineering', '2023-03-08', 'BS in Computer Science', 'Java, Python, SQL', '3 years'),
(2, 'Jane Doe', '', 'Software Engineer', 'Engineering', '0000-00-00', '', '', '');

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_job`
-- (See below for the actual view)
--
CREATE TABLE `insert_job` (
`job_title` varchar(255)
,`department` varchar(255)
,`location` varchar(255)
,`responsibilities` varchar(255)
,`qualifications` varchar(255)
,`salary_range` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `job_title` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `responsibilities` varchar(255) NOT NULL,
  `qualifications` varchar(255) NOT NULL,
  `salary_range` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`job_title`, `department`, `location`, `responsibilities`, `qualifications`, `salary_range`) VALUES
('Senior Software Engineer', 'Engineering', 'Kigali, Rwanda', 'Design, develop, and test software applications', 'BS in Computer Science', 0),
('Software Engineer', 'Engineering', 'Kigali, Rwanda', 'Design, develop, and test software applications', 'BS in Computer Science', 0);

-- --------------------------------------------------------

--
-- Table structure for table `performance_reviews`
--

CREATE TABLE `performance_reviews` (
  `performance_review_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `performance_goals` varchar(255) NOT NULL,
  `ratings` varchar(255) NOT NULL,
  `feedback` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recruitments`
--

CREATE TABLE `recruitments` (
  `job_requisition_number` int(11) NOT NULL,
  `recruiting_source` varchar(255) NOT NULL,
  `interview_notes` varchar(255) NOT NULL,
  `offer_letter` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure for view `all_employees`
--
DROP TABLE IF EXISTS `all_employees`;

CREATE ALGORITHM=UNDEFINED DEFINER=`nyangomannet`@`localhost` SQL SECURITY DEFINER VIEW `all_employees`  AS SELECT `employees`.`employee_id` AS `employee_id`, `employees`.`name` AS `name`, `employees`.`contact_information` AS `contact_information`, `employees`.`job_title` AS `job_title`, `employees`.`department` AS `department`, `employees`.`date_of_hire` AS `date_of_hire`, `employees`.`education` AS `education`, `employees`.`skills` AS `skills`, `employees`.`experience` AS `experience` FROM `employees` ;

-- --------------------------------------------------------

--
-- Structure for view `delete_applicant_view`
--
DROP TABLE IF EXISTS `delete_applicant_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`nyangomannet`@`localhost` SQL SECURITY DEFINER VIEW `delete_applicant_view`  AS SELECT `applicants`.`applicant_id` AS `applicant_id` FROM `applicants` WHERE `applicants`.`application_status` = 'Rejected' ;

-- --------------------------------------------------------

--
-- Structure for view `delete_data_view`
--
DROP TABLE IF EXISTS `delete_data_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`nyangomannet`@`localhost` SQL SECURITY DEFINER VIEW `delete_data_view`  AS SELECT `employees`.`employee_id` AS `employee_id`, `employees`.`name` AS `name`, `employees`.`contact_information` AS `contact_information`, `employees`.`job_title` AS `job_title`, `employees`.`department` AS `department`, `employees`.`date_of_hire` AS `date_of_hire`, `employees`.`education` AS `education`, `employees`.`skills` AS `skills`, `employees`.`experience` AS `experience` FROM `employees` WHERE `employees`.`department` = 'Engineering' ;

-- --------------------------------------------------------

--
-- Structure for view `insert_job`
--
DROP TABLE IF EXISTS `insert_job`;

CREATE ALGORITHM=UNDEFINED DEFINER=`nyangomannet`@`localhost` SQL SECURITY DEFINER VIEW `insert_job`  AS SELECT `jobs`.`job_title` AS `job_title`, `jobs`.`department` AS `department`, `jobs`.`location` AS `location`, `jobs`.`responsibilities` AS `responsibilities`, `jobs`.`qualifications` AS `qualifications`, `jobs`.`salary_range` AS `salary_range` FROM `jobs` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applicants`
--
ALTER TABLE `applicants`
  ADD PRIMARY KEY (`applicant_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`job_title`);

--
-- Indexes for table `performance_reviews`
--
ALTER TABLE `performance_reviews`
  ADD PRIMARY KEY (`performance_review_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `recruitments`
--
ALTER TABLE `recruitments`
  ADD PRIMARY KEY (`job_requisition_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applicants`
--
ALTER TABLE `applicants`
  MODIFY `applicant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `performance_reviews`
--
ALTER TABLE `performance_reviews`
  MODIFY `performance_review_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recruitments`
--
ALTER TABLE `recruitments`
  MODIFY `job_requisition_number` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `performance_reviews`
--
ALTER TABLE `performance_reviews`
  ADD CONSTRAINT `performance_reviews_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
