-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2023 at 11:04 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tourism_management_systems`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertintour`(
in p_tour_name varchar(20), 
in P_tour_duration time,
in p_tour_price int(20),
in p_tour_guide char(20))
insert into tour(tour_name,tour_duration,tour_price,tour_guide)
values(p_tour_name,P_tour_duration,p_tour_price,p_tour_guide)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attraction`
--

CREATE TABLE IF NOT EXISTS `attraction` (
  `attraction_id` int(30) DEFAULT NULL,
  `attraction_name` varchar(30) DEFAULT NULL,
  `attraction_adress` varchar(40) DEFAULT NULL,
  `attraction_city` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attraction`
--

INSERT INTO `attraction` (`attraction_id`, `attraction_name`, `attraction_adress`, `attraction_city`) VALUES
(2201, 'caves', 'kalimbi', 'musanze_city'),
(2202, 'gorrila', 'kinigi', 'musanze_city'),
(2203, 'elephant', 'kirehe', 'kirehe_city'),
(2204, 'leopard', 'nyamagabe', 'kitabi_city');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `customer_name` varchar(20) DEFAULT NULL,
  `customer_id` int(20) DEFAULT NULL,
  `customer_email` varchar(30) DEFAULT NULL,
  `customer_phone` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_name`, `customer_id`, `customer_email`, `customer_phone`) VALUES
('brain', 1001, 'braingmail', 2147483647),
('lorenzo', 1002, 'shemagmail', 2147483647),
('fils', 1003, 'filsgmail', 2147483647),
('loucias', 1004, 'fezagmail', 2147483647);

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer_view`
--
CREATE TABLE IF NOT EXISTS `customer_view` (
`customer_name` varchar(20)
,`customer_id` int(20)
,`customer_email` varchar(30)
,`customer_phone` int(20)
);
-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE IF NOT EXISTS `flight` (
  `airline` varchar(20) DEFAULT NULL,
  `flight_number` int(30) DEFAULT NULL,
  `arrival_time` int(30) DEFAULT NULL,
  `aircraft_type` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flight`
--

INSERT INTO `flight` (`airline`, `flight_number`, `arrival_time`, `aircraft_type`) VALUES
('qatar_airwys', 666, 3, 'busness_jet'),
('fly_emirates', 555, 4, 'helcopter'),
('rwandair', 333, 5, 'business_jet'),
('kenya_airways', 777, 6, 'public_jet');

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE IF NOT EXISTS `hotel` (
  `hotel_name` varchar(20) DEFAULT NULL,
  `hotel_room_booked` int(20) DEFAULT NULL,
  `hotel_place` varchar(20) DEFAULT NULL,
  `hotel_receptionist` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`hotel_name`, `hotel_room_booked`, `hotel_place`, `hotel_receptionist`) VALUES
('muhabura_hotel', 20, 'musanze', 'elonmask'),
('selena_hotel', 30, 'rubavu', 'mark'),
('singita_hotel', 15, 'kinigi', 'alex'),
('one_only_hotel', 30, 'kinigi', 'william');

-- --------------------------------------------------------

--
-- Table structure for table `tour`
--

CREATE TABLE IF NOT EXISTS `tour` (
  `tour_name` varchar(30) DEFAULT NULL,
  `tour_duration` time DEFAULT NULL,
  `tour_price` int(30) DEFAULT NULL,
  `tour_guide` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tour`
--

INSERT INTO `tour` (`tour_name`, `tour_duration`, `tour_price`, `tour_guide`) VALUES
('akagera_park', '04:00:00', 1000, 'adolphe'),
('birunga_gorrila', '03:00:00', 1000, 'sam'),
('musanze_caves', '12:00:00', 3000, 'prince'),
('nile_river', '13:00:00', 40000, 'bruce'),
('new tour_name', '00:00:05', 10000, 'kalisa'),
('new tour_name', '00:00:05', 10000, 'kalisa'),
('new tour_name', '00:00:04', 1000, 'malisa');

--
-- Triggers `tour`
--
DROP TRIGGER IF EXISTS `afterinserttour`;
DELIMITER //
CREATE TRIGGER `afterinserttour` AFTER INSERT ON `tour`
 FOR EACH ROW insert into tour(tour_name,tour_duration,tour_price,tour_guide)
select concat('new tour inserted:',new.tour_name,'',new.tour_guide)
//
DELIMITER ;
DROP TRIGGER IF EXISTS `set_tour_name`;
DELIMITER //
CREATE TRIGGER `set_tour_name` BEFORE INSERT ON `tour`
 FOR EACH ROW set new.tour_name='new tour_name'
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `tour_view`
--
CREATE TABLE IF NOT EXISTS `tour_view` (
`tour_name` varchar(30)
,`tour_guide` varchar(30)
);
-- --------------------------------------------------------

--
-- Structure for view `customer_view`
--
DROP TABLE IF EXISTS `customer_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_view` AS select `customer`.`customer_name` AS `customer_name`,`customer`.`customer_id` AS `customer_id`,`customer`.`customer_email` AS `customer_email`,`customer`.`customer_phone` AS `customer_phone` from `customer`;

-- --------------------------------------------------------

--
-- Structure for view `tour_view`
--
DROP TABLE IF EXISTS `tour_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tour_view` AS select `tour`.`tour_name` AS `tour_name`,`tour`.`tour_guide` AS `tour_guide` from `tour`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
