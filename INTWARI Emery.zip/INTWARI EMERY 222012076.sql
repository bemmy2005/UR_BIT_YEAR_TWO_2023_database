-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 09:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `intwari_emery_222012076`
--
CREATE DATABASE IF NOT EXISTS `intwari_emery_222012076` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `intwari_emery_222012076`;

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--
-- Creation: Aug 26, 2023 at 08:11 AM
--

DROP TABLE IF EXISTS `applicants`;
CREATE TABLE `applicants` (
  `APPLICANT_ID` varchar(255) NOT NULL,
  `USER_ID` varchar(255) NOT NULL,
  `FIRST_NAME` varchar(255) NOT NULL,
  `LAST_NAME` varchar(255) NOT NULL,
  `PHONE` int(255) NOT NULL,
  `RESUME` varchar(10000) NOT NULL,
  `SKILLS` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `applicants`:
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--
-- Creation: Aug 26, 2023 at 08:38 AM
--

DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications` (
  `APPLICATION_ID` varchar(255) NOT NULL,
  `APPLICANT_ID` varchar(255) NOT NULL,
  `JOB_ID` varchar(255) NOT NULL,
  `APPLICATION_DATE` date NOT NULL,
  `STATUS` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `applications`:
--

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--
-- Creation: Aug 26, 2023 at 08:31 AM
--

DROP TABLE IF EXISTS `employer`;
CREATE TABLE `employer` (
  `EMPLOYER_ID` varchar(255) NOT NULL,
  `USER_ID` varchar(255) NOT NULL,
  `COMPANY_NAME` varchar(255) NOT NULL,
  `COMPANY_DESCRIPTION` varchar(10000) NOT NULL,
  `INDUSTRY` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `CONTACT` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `employer`:
--

-- --------------------------------------------------------

--
-- Table structure for table `job`
--
-- Creation: Aug 26, 2023 at 08:35 AM
--

DROP TABLE IF EXISTS `job`;
CREATE TABLE `job` (
  `JOB_ID` varchar(255) NOT NULL,
  `EMPLOYER_ID` varchar(255) NOT NULL,
  `JOB_TITLE` varchar(255) NOT NULL,
  `JOB_DESCRIPTION` mediumtext NOT NULL,
  `REQUIREMENTS` mediumtext NOT NULL,
  `LOCATION` varchar(255) NOT NULL,
  `SALARY` varchar(50) NOT NULL,
  `DATE` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `job`:
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Aug 26, 2023 at 08:07 AM
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `USER_ID` varchar(255) NOT NULL,
  `USERNAME` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `USER_TYPE` varchar(255) NOT NULL,
  `REGISTRATION_DATE` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- RELATIONSHIPS FOR TABLE `users`:
--


--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata for table applicants
--

--
-- Metadata for table applications
--

--
-- Metadata for table employer
--

--
-- Metadata for table job
--

--
-- Metadata for table users
--

--
-- Metadata for database intwari_emery_222012076
--
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
