-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2023 at 02:28 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `igihozo_prince_222003087`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `Customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Gender` varchar(10) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` varchar(50) NOT NULL,
  `ZipCode` varchar(10) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Customer_id`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_id`, `FirstName`, `LastName`, `DateOfBirth`, `Gender`, `Address`, `City`, `State`, `ZipCode`, `Phone`, `Email`) VALUES
(1, 'Alice', 'Johnson', '1995-07-20', 'Female', '123 Oak Street', 'CityA', 'StateA', '12345', '555-123-4567', 'alice@email.com'),
(2, 'Bob', 'Smith', '1988-03-10', 'Male', '456 Pine Avenue', 'CityB', 'StateB', '67890', '555-987-6543', 'bob@email.com');

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer_view`
--
CREATE TABLE IF NOT EXISTS `customer_view` (
`Customer_id` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`DateOfBirth` date
,`Gender` varchar(10)
,`Address` varchar(255)
,`City` varchar(50)
,`State` varchar(50)
,`ZipCode` varchar(10)
,`Phone` varchar(15)
,`Email` varchar(100)
);
-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `Employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `Department` varchar(100) DEFAULT NULL,
  `HireDate` date DEFAULT NULL,
  `Salary` decimal(10,2) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Employee_id`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_id`, `FirstName`, `LastName`, `DateOfBirth`, `Gender`, `Department`, `HireDate`, `Salary`, `Email`) VALUES
(1, 'John', 'Doe', '1990-01-15', 'Male', 'Sales', '2021-03-15', 55000.00, 'johndoe@email.com'),
(2, 'Jane', 'Smith', '1985-05-20', 'Female', 'Operations', '2020-08-10', 60000.00, 'janesmith@email.com');

-- --------------------------------------------------------

--
-- Stand-in structure for view `employee_view`
--
CREATE TABLE IF NOT EXISTS `employee_view` (
`Customer_id` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`DateOfBirth` date
,`Gender` varchar(10)
,`Address` varchar(255)
,`City` varchar(50)
,`State` varchar(50)
,`ZipCode` varchar(10)
,`Phone` varchar(15)
,`Email` varchar(100)
);
-- --------------------------------------------------------

--
-- Table structure for table `fuel_stock`
--

CREATE TABLE IF NOT EXISTS `fuel_stock` (
  `Stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `Station_id` int(11) DEFAULT NULL,
  `Quantity` decimal(10,2) DEFAULT NULL,
  `PurchaseDate` date DEFAULT NULL,
  `ExpiryDate` date DEFAULT NULL,
  PRIMARY KEY (`Stock_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `fuel_stock`
--

INSERT INTO `fuel_stock` (`Stock_id`, `Station_id`, `Quantity`, `PurchaseDate`, `ExpiryDate`) VALUES
(1, 1, 1000.00, '2023-09-10', '2024-09-10'),
(2, 2, 800.50, '2023-09-10', '2024-09-10');

-- --------------------------------------------------------

--
-- Stand-in structure for view `fuel_stock_view`
--
CREATE TABLE IF NOT EXISTS `fuel_stock_view` (
`Stock_id` int(11)
,`Station_id` int(11)
,`Quantity` decimal(10,2)
,`PurchaseDate` date
,`ExpiryDate` date
);
-- --------------------------------------------------------

--
-- Table structure for table `fuel_type`
--

CREATE TABLE IF NOT EXISTS `fuel_type` (
  `Fuel_type_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Price_per_litres` int(11) DEFAULT NULL,
  PRIMARY KEY (`Fuel_type_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `fuel_type`
--

INSERT INTO `fuel_type` (`Fuel_type_ID`, `Name`, `Price_per_litres`) VALUES
(1, 'petrol', 1850);

-- --------------------------------------------------------

--
-- Stand-in structure for view `fuel_type_view`
--
CREATE TABLE IF NOT EXISTS `fuel_type_view` (
`Fuel_type_ID` int(11)
,`Name` varchar(50)
,`Price_per_litres` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_customerview`
--
CREATE TABLE IF NOT EXISTS `insert_customerview` (
`Customer_id` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`DateOfBirth` date
,`Gender` varchar(10)
,`Address` varchar(255)
,`City` varchar(50)
,`State` varchar(50)
,`ZipCode` varchar(10)
,`Phone` varchar(15)
,`Email` varchar(100)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_employeeview`
--
CREATE TABLE IF NOT EXISTS `insert_employeeview` (
`Employee_id` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`DateOfBirth` date
,`Gender` varchar(10)
,`Department` varchar(100)
,`HireDate` date
,`Salary` decimal(10,2)
,`Email` varchar(100)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_fuel_stockview`
--
CREATE TABLE IF NOT EXISTS `insert_fuel_stockview` (
`Stock_id` int(11)
,`Station_id` int(11)
,`Quantity` decimal(10,2)
,`PurchaseDate` date
,`ExpiryDate` date
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_fuel_typeview`
--
CREATE TABLE IF NOT EXISTS `insert_fuel_typeview` (
`Fuel_type_ID` int(11)
,`Name` varchar(50)
,`Price_per_litres` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_petrol_stationview`
--
CREATE TABLE IF NOT EXISTS `insert_petrol_stationview` (
`Station_ID` int(11)
,`Station_names` varchar(100)
,`Location` varchar(255)
,`Fuel_type` varchar(50)
,`Fuel_price` decimal(10,0)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_salesview`
--
CREATE TABLE IF NOT EXISTS `insert_salesview` (
`Sale_id` int(11)
,`Station_id` int(11)
,`Employee_id` int(11)
,`Customer_id` int(11)
,`SaleDate` datetime
,`Quantity` decimal(10,2)
,`TotalAmount` decimal(10,2)
);
-- --------------------------------------------------------

--
-- Table structure for table `petrol_station`
--

CREATE TABLE IF NOT EXISTS `petrol_station` (
  `Station_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Station_names` varchar(100) NOT NULL,
  `Location` varchar(255) NOT NULL,
  `Fuel_type` varchar(50) NOT NULL,
  `Fuel_price` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`Station_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `petrol_station`
--

INSERT INTO `petrol_station` (`Station_ID`, `Station_names`, `Location`, `Fuel_type`, `Fuel_price`) VALUES
(1, 'Station A', '123 Main Street', 'Regular Unleaded', 1850),
(2, 'Station B', '456 Elm Street', 'Diesel', 2009);

-- --------------------------------------------------------

--
-- Stand-in structure for view `petrol_station_view`
--
CREATE TABLE IF NOT EXISTS `petrol_station_view` (
`Station_ID` int(11)
,`Station_names` varchar(100)
,`Location` varchar(255)
,`Fuel_type` varchar(50)
,`Fuel_price` decimal(10,0)
);
-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `Sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `Station_id` int(11) DEFAULT NULL,
  `Employee_id` int(11) DEFAULT NULL,
  `Customer_id` int(11) DEFAULT NULL,
  `SaleDate` datetime DEFAULT NULL,
  `Quantity` decimal(10,2) DEFAULT NULL,
  `TotalAmount` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`Sale_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`Sale_id`, `Station_id`, `Employee_id`, `Customer_id`, `SaleDate`, `Quantity`, `TotalAmount`) VALUES
(1, 1, 1, 1, '0000-00-00 00:00:00', 350.90, 70.25),
(2, 2, 2, 2, '2023-09-20 00:00:00', 450.25, 90.50);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sales_view`
--
CREATE TABLE IF NOT EXISTS `sales_view` (
`Sale_id` int(11)
,`Station_id` int(11)
,`Employee_id` int(11)
,`Customer_id` int(11)
,`SaleDate` datetime
,`Quantity` decimal(10,2)
,`TotalAmount` decimal(10,2)
);
-- --------------------------------------------------------

--
-- Structure for view `customer_view`
--
DROP TABLE IF EXISTS `customer_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_view` AS select `customer`.`Customer_id` AS `Customer_id`,`customer`.`FirstName` AS `FirstName`,`customer`.`LastName` AS `LastName`,`customer`.`DateOfBirth` AS `DateOfBirth`,`customer`.`Gender` AS `Gender`,`customer`.`Address` AS `Address`,`customer`.`City` AS `City`,`customer`.`State` AS `State`,`customer`.`ZipCode` AS `ZipCode`,`customer`.`Phone` AS `Phone`,`customer`.`Email` AS `Email` from `customer`;

-- --------------------------------------------------------

--
-- Structure for view `employee_view`
--
DROP TABLE IF EXISTS `employee_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `employee_view` AS select `customer`.`Customer_id` AS `Customer_id`,`customer`.`FirstName` AS `FirstName`,`customer`.`LastName` AS `LastName`,`customer`.`DateOfBirth` AS `DateOfBirth`,`customer`.`Gender` AS `Gender`,`customer`.`Address` AS `Address`,`customer`.`City` AS `City`,`customer`.`State` AS `State`,`customer`.`ZipCode` AS `ZipCode`,`customer`.`Phone` AS `Phone`,`customer`.`Email` AS `Email` from `customer`;

-- --------------------------------------------------------

--
-- Structure for view `fuel_stock_view`
--
DROP TABLE IF EXISTS `fuel_stock_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fuel_stock_view` AS select `fuel_stock`.`Stock_id` AS `Stock_id`,`fuel_stock`.`Station_id` AS `Station_id`,`fuel_stock`.`Quantity` AS `Quantity`,`fuel_stock`.`PurchaseDate` AS `PurchaseDate`,`fuel_stock`.`ExpiryDate` AS `ExpiryDate` from `fuel_stock`;

-- --------------------------------------------------------

--
-- Structure for view `fuel_type_view`
--
DROP TABLE IF EXISTS `fuel_type_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fuel_type_view` AS select `fuel_type`.`Fuel_type_ID` AS `Fuel_type_ID`,`fuel_type`.`Name` AS `Name`,`fuel_type`.`Price_per_litres` AS `Price_per_litres` from `fuel_type`;

-- --------------------------------------------------------

--
-- Structure for view `insert_customerview`
--
DROP TABLE IF EXISTS `insert_customerview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_customerview` AS select `customer`.`Customer_id` AS `Customer_id`,`customer`.`FirstName` AS `FirstName`,`customer`.`LastName` AS `LastName`,`customer`.`DateOfBirth` AS `DateOfBirth`,`customer`.`Gender` AS `Gender`,`customer`.`Address` AS `Address`,`customer`.`City` AS `City`,`customer`.`State` AS `State`,`customer`.`ZipCode` AS `ZipCode`,`customer`.`Phone` AS `Phone`,`customer`.`Email` AS `Email` from `customer` where (`customer`.`Customer_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_employeeview`
--
DROP TABLE IF EXISTS `insert_employeeview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_employeeview` AS select `employee`.`Employee_id` AS `Employee_id`,`employee`.`FirstName` AS `FirstName`,`employee`.`LastName` AS `LastName`,`employee`.`DateOfBirth` AS `DateOfBirth`,`employee`.`Gender` AS `Gender`,`employee`.`Department` AS `Department`,`employee`.`HireDate` AS `HireDate`,`employee`.`Salary` AS `Salary`,`employee`.`Email` AS `Email` from `employee` where (`employee`.`Employee_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_fuel_stockview`
--
DROP TABLE IF EXISTS `insert_fuel_stockview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_fuel_stockview` AS select `fuel_stock`.`Stock_id` AS `Stock_id`,`fuel_stock`.`Station_id` AS `Station_id`,`fuel_stock`.`Quantity` AS `Quantity`,`fuel_stock`.`PurchaseDate` AS `PurchaseDate`,`fuel_stock`.`ExpiryDate` AS `ExpiryDate` from `fuel_stock` where (`fuel_stock`.`Stock_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_fuel_typeview`
--
DROP TABLE IF EXISTS `insert_fuel_typeview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_fuel_typeview` AS select `fuel_type`.`Fuel_type_ID` AS `Fuel_type_ID`,`fuel_type`.`Name` AS `Name`,`fuel_type`.`Price_per_litres` AS `Price_per_litres` from `fuel_type` where (`fuel_type`.`Fuel_type_ID` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_petrol_stationview`
--
DROP TABLE IF EXISTS `insert_petrol_stationview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_petrol_stationview` AS select `petrol_station`.`Station_ID` AS `Station_ID`,`petrol_station`.`Station_names` AS `Station_names`,`petrol_station`.`Location` AS `Location`,`petrol_station`.`Fuel_type` AS `Fuel_type`,`petrol_station`.`Fuel_price` AS `Fuel_price` from `petrol_station` where (`petrol_station`.`Station_ID` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_salesview`
--
DROP TABLE IF EXISTS `insert_salesview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_salesview` AS select `sales`.`Sale_id` AS `Sale_id`,`sales`.`Station_id` AS `Station_id`,`sales`.`Employee_id` AS `Employee_id`,`sales`.`Customer_id` AS `Customer_id`,`sales`.`SaleDate` AS `SaleDate`,`sales`.`Quantity` AS `Quantity`,`sales`.`TotalAmount` AS `TotalAmount` from `sales` where (`sales`.`Sale_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `petrol_station_view`
--
DROP TABLE IF EXISTS `petrol_station_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `petrol_station_view` AS select `petrol_station`.`Station_ID` AS `Station_ID`,`petrol_station`.`Station_names` AS `Station_names`,`petrol_station`.`Location` AS `Location`,`petrol_station`.`Fuel_type` AS `Fuel_type`,`petrol_station`.`Fuel_price` AS `Fuel_price` from `petrol_station`;

-- --------------------------------------------------------

--
-- Structure for view `sales_view`
--
DROP TABLE IF EXISTS `sales_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sales_view` AS select `sales`.`Sale_id` AS `Sale_id`,`sales`.`Station_id` AS `Station_id`,`sales`.`Employee_id` AS `Employee_id`,`sales`.`Customer_id` AS `Customer_id`,`sales`.`SaleDate` AS `SaleDate`,`sales`.`Quantity` AS `Quantity`,`sales`.`TotalAmount` AS `TotalAmount` from `sales`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
