-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 09:13 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emmanuel_ishimwe_222004496`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteCustomerByID` (IN `p_customer_id` INT)   BEGIN
    DELETE FROM customer WHERE id = p_customer_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteParkingLotByID` (IN `p_lot_id` INT)   BEGIN
    DELETE FROM parkinglot WHERE id = p_lot_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllParkingLots` ()   BEGIN
    SELECT * FROM parkinglot;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertCustomer` (IN `p_first_name` VARCHAR(255), IN `p_last_name` VARCHAR(255), IN `p_email` VARCHAR(255), IN `p_phone_number` VARCHAR(20))   BEGIN
    
    INSERT INTO customer (FirstName, LastName, Email, PhoneNumber)
    VALUES (p_first_name, p_last_name, p_email, p_phone_number);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertParkingLot` (IN `p_name` VARCHAR(255), IN `p_location` VARCHAR(255), IN `p_capacity` INT, IN `p_hourly_rate` DECIMAL(10,2), IN `p_daily_rate` DECIMAL(10,2))   BEGIN
    
    INSERT INTO parkinglot (Name, Location, Capacity, HourlyRate, DailyRate)
    VALUES (p_name, p_location, p_capacity, p_hourly_rate, p_daily_rate);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertParkingSlot` (IN `p_parking_lot_id` INT, IN `p_slot_number` INT, IN `p_slot_size` VARCHAR(255))   BEGIN
    
    INSERT INTO parkingslot (ParkingLotID, SlotNumber, SlotSize, IsAvailable, OccupancyStatus)
    VALUES (p_parking_lot_id, p_slot_number, p_slot_size, 1, 'Vacant');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertReservation` (IN `p_customer_id` INT, IN `p_parking_lot_id` INT, IN `p_parking_slot_id` INT, IN `p_start_time` DATETIME, IN `p_end_time` DATETIME, IN `p_total_cost` DECIMAL(10,2))   BEGIN
    
    INSERT INTO reservation (CustomerID, ParkingLotID, ParkingSlotID, StartTime, EndTime, TotalCost, PaymentStatus)
    VALUES (p_customer_id, p_parking_lot_id, p_parking_slot_id, p_start_time, p_end_time, p_total_cost, 'Pending');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateParkingLotAndSlot` (IN `p_lot_id` INT, IN `p_lot_name` VARCHAR(255), IN `p_location` VARCHAR(255), IN `p_capacity` INT, IN `p_hourly_rate` DECIMAL(10,2), IN `p_daily_rate` DECIMAL(10,2), IN `p_slot_id` INT, IN `p_slot_number` INT, IN `p_slot_size` VARCHAR(255))   BEGIN
    
    UPDATE parkinglot
    SET Name = p_lot_name, Location = p_location, Capacity = p_capacity, HourlyRate = p_hourly_rate, DailyRate = p_daily_rate
    WHERE id = p_lot_id;

    
    UPDATE parkingslot
    SET SlotNumber = p_slot_number, SlotSize = p_slot_size
    WHERE id = p_slot_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ViewCustomerReservations` (IN `p_customer_id` INT)   BEGIN
    
    SELECT
        r.ID AS ReservationID,
        pl.Name AS ParkingLotName,
        ps.SlotNumber AS SlotNumber,
        r.StartTime AS StartTime,
        r.EndTime AS EndTime,
        r.TotalCost AS TotalCost
    FROM
        reservation r
    INNER JOIN
        parkinglot pl ON r.ParkingLotID = pl.ID
    INNER JOIN
        parkingslot ps ON r.ParkingSlotID = ps.ID
    WHERE
        r.CustomerID = p_customer_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `available_parkingslots`
-- (See below for the actual view)
--
CREATE TABLE `available_parkingslots` (
`parkingslot_id` int(11)
,`slot_number` int(11)
,`size` varchar(20)
,`status` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `email`, `phone`) VALUES
(1, 'emmy', 'emmy@gmail.com', '0785237426'),
(2, 'dodos', 'dodos12@gmail.com', '0787934567'),
(3, 'simi', 'simi78@gmail.com', '0733114896'),
(4, 'remy', 'zone2346@gmail.com', '0728375847');

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer_info`
-- (See below for the actual view)
--
CREATE TABLE `customer_info` (
`customer_id` int(11)
,`customer_name` varchar(50)
,`email` varchar(80)
,`phone` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_info`
-- (See below for the actual view)
--
CREATE TABLE `delete_info` (
`parkinglot_id` int(11)
,`name` varchar(50)
,`address` varchar(80)
,`capacity` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_data` (
`parkinglot_id` int(1)
,`name` varchar(12)
,`address` varchar(15)
,`capacity` int(3)
);

-- --------------------------------------------------------

--
-- Table structure for table `parkinglot`
--

CREATE TABLE `parkinglot` (
  `parkinglot_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(80) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parkinglot`
--

INSERT INTO `parkinglot` (`parkinglot_id`, `name`, `address`, `capacity`) VALUES
(10, 'parkinglot1', '123mainstreet', 300),
(11, 'parkinglot2', '223mainstreet', 500),
(12, 'fatina sites', '130mainstreet', 400),
(14, 'parkinglot4', '143majorstreet', 250);

--
-- Triggers `parkinglot`
--
DELIMITER $$
CREATE TRIGGER `after_delete_parkinglot` AFTER DELETE ON `parkinglot` FOR EACH ROW BEGIN
    
    INSERT INTO ParkingLotAudit (ParkingLot_ID, Name, Address, Capacity, DeletedTimestamp)
    VALUES (OLD.ParkingLot_ID, OLD.Name, OLD.Address, OLD.Capacity, NOW());

    
    
    
    
    
    
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_parkinglot` AFTER INSERT ON `parkinglot` FOR EACH ROW BEGIN
    
    INSERT INTO ParkingLotAudit (ParkingLot_ID, Name, Address, Capacity, InsertedTimestamp)
    VALUES (NEW.ParkingLot_ID, NEW.Name, NEW.Address, NEW.Capacity, NOW());

    
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_update_parkinglot` AFTER UPDATE ON `parkinglot` FOR EACH ROW BEGIN
    
    INSERT INTO ParkingLotAudit (ParkingLot_ID, OldName, NewName, OldAddress, NewAddress, OldCapacity, NewCapacity, UpdateTimestamp)
    VALUES (OLD.ParkingLot_ID, OLD.Name, NEW.Name, OLD.Address, NEW.Address, OLD.Capacity, NEW.Capacity, NOW());

    
    
    
    
    
    
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `parkinglot_info`
-- (See below for the actual view)
--
CREATE TABLE `parkinglot_info` (
`parkinglot_id` int(11)
,`name` varchar(50)
,`address` varchar(80)
,`capacity` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `parkingslot`
--

CREATE TABLE `parkingslot` (
  `parkingslot_id` int(11) NOT NULL,
  `parkinglot_id` int(11) DEFAULT NULL,
  `slot_number` int(11) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parkingslot`
--

INSERT INTO `parkingslot` (`parkingslot_id`, `parkinglot_id`, `slot_number`, `size`, `status`) VALUES
(66, 14, 6, '200', 'available'),
(77, 12, 8, '400', 'available'),
(88, 11, 5, '300', 'occupied'),
(99, 10, 7, '230', 'available');

--
-- Triggers `parkingslot`
--
DELIMITER $$
CREATE TRIGGER `after_delete_parkingslot` AFTER DELETE ON `parkingslot` FOR EACH ROW BEGIN
    
    INSERT INTO ParkingSlotAudit (ParkingSlot_ID, Slot_Number, Size, Status, DeletedTimestamp)
    VALUES (OLD.ParkingSlot_ID, OLD.Slot_Number, OLD.Size, OLD.Status, NOW());

    
    
    
    
    
    
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_parkingslot` AFTER INSERT ON `parkingslot` FOR EACH ROW BEGIN
    
    INSERT INTO ParkingSlotAudit (ParkingSlot_ID, Slot_Number, Size, Status, InsertedTimestamp)
    VALUES (NEW.ParkingSlot_ID, NEW.Slot_Number, NEW.Size, NEW.Status, NOW());

    
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_update_parkingslot` AFTER UPDATE ON `parkingslot` FOR EACH ROW BEGIN
    
    INSERT INTO ParkingSlotAudit (ParkingSlot_ID, OldSlot_Number, NewSlot_Number, OldSize, NewSize, OldStatus, NewStatus, UpdateTimestamp)
    VALUES (OLD.ParkingSlot_ID, OLD.Slot_Number, NEW.Slot_Number, OLD.Size, NEW.Size, OLD.Status, NEW.Status, NOW());

    
    
    
    
    
    
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `parkingslot_info`
-- (See below for the actual view)
--
CREATE TABLE `parkingslot_info` (
`parkingslot_id` int(11)
,`slot_number` int(11)
,`size` varchar(20)
,`status` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `reservation_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `parkingslot_id` int(11) DEFAULT NULL,
  `start_time` int(11) DEFAULT NULL,
  `end_time` int(11) DEFAULT NULL,
  `cost` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reservation_id`, `customer_id`, `parkingslot_id`, `start_time`, `end_time`, `cost`) VALUES
(2000, 1, 99, 12, 13, 500),
(2001, 2, 88, 13, 14, 600),
(2002, 3, 77, 14, 15, 1000),
(2003, 4, 66, 15, 16, 700);

-- --------------------------------------------------------

--
-- Stand-in structure for view `reservation_info`
-- (See below for the actual view)
--
CREATE TABLE `reservation_info` (
`reservation_id` int(11)
,`customer_id` int(11)
,`parkingslot_id` int(11)
,`start_time` int(11)
,`end_time` int(11)
,`cost` float
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_info`
-- (See below for the actual view)
--
CREATE TABLE `update_info` (
`parkinglot_id` int(11)
,`name` varchar(50)
,`address` varchar(80)
,`capacity` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `available_parkingslots`
--
DROP TABLE IF EXISTS `available_parkingslots`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `available_parkingslots`  AS SELECT `parkingslot`.`parkingslot_id` AS `parkingslot_id`, `parkingslot`.`slot_number` AS `slot_number`, `parkingslot`.`size` AS `size`, `parkingslot`.`status` AS `status` FROM `parkingslot` WHERE `parkingslot`.`status` = 'Available''Available'  ;

-- --------------------------------------------------------

--
-- Structure for view `customer_info`
--
DROP TABLE IF EXISTS `customer_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_info`  AS SELECT `customer`.`customer_id` AS `customer_id`, `customer`.`customer_name` AS `customer_name`, `customer`.`email` AS `email`, `customer`.`phone` AS `phone` FROM `customer``customer`  ;

-- --------------------------------------------------------

--
-- Structure for view `delete_info`
--
DROP TABLE IF EXISTS `delete_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `delete_info`  AS SELECT `parkinglot`.`parkinglot_id` AS `parkinglot_id`, `parkinglot`.`name` AS `name`, `parkinglot`.`address` AS `address`, `parkinglot`.`capacity` AS `capacity` FROM `parkinglot` union all select `parkingslot`.`parkingslot_id` AS `parkingslot_id`,`parkingslot`.`slot_number` AS `slot_number`,`parkingslot`.`size` AS `size`,`parkingslot`.`status` AS `status` from `parkingslot`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_data`
--
DROP TABLE IF EXISTS `insert_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_data`  AS SELECT 1 AS `parkinglot_id`, 'Parkinglot 1' AS `name`, '123 Main Street' AS `address`, 100 AS `capacity``capacity`  ;

-- --------------------------------------------------------

--
-- Structure for view `parkinglot_info`
--
DROP TABLE IF EXISTS `parkinglot_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `parkinglot_info`  AS SELECT `parkinglot`.`parkinglot_id` AS `parkinglot_id`, `parkinglot`.`name` AS `name`, `parkinglot`.`address` AS `address`, `parkinglot`.`capacity` AS `capacity` FROM `parkinglot``parkinglot`  ;

-- --------------------------------------------------------

--
-- Structure for view `parkingslot_info`
--
DROP TABLE IF EXISTS `parkingslot_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `parkingslot_info`  AS SELECT `parkingslot`.`parkingslot_id` AS `parkingslot_id`, `parkingslot`.`slot_number` AS `slot_number`, `parkingslot`.`size` AS `size`, `parkingslot`.`status` AS `status` FROM `parkingslot``parkingslot`  ;

-- --------------------------------------------------------

--
-- Structure for view `reservation_info`
--
DROP TABLE IF EXISTS `reservation_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reservation_info`  AS SELECT `reservation`.`reservation_id` AS `reservation_id`, `reservation`.`customer_id` AS `customer_id`, `reservation`.`parkingslot_id` AS `parkingslot_id`, `reservation`.`start_time` AS `start_time`, `reservation`.`end_time` AS `end_time`, `reservation`.`cost` AS `cost` FROM `reservation``reservation`  ;

-- --------------------------------------------------------

--
-- Structure for view `update_info`
--
DROP TABLE IF EXISTS `update_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_info`  AS SELECT `parkinglot`.`parkinglot_id` AS `parkinglot_id`, `parkinglot`.`name` AS `name`, `parkinglot`.`address` AS `address`, `parkinglot`.`capacity` AS `capacity` FROM `parkinglot``parkinglot`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `parkinglot`
--
ALTER TABLE `parkinglot`
  ADD PRIMARY KEY (`parkinglot_id`);

--
-- Indexes for table `parkingslot`
--
ALTER TABLE `parkingslot`
  ADD PRIMARY KEY (`parkingslot_id`),
  ADD KEY `parkinglot_id` (`parkinglot_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`reservation_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `parkingslot_id` (`parkingslot_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `parkingslot`
--
ALTER TABLE `parkingslot`
  ADD CONSTRAINT `parkingslot_ibfk_1` FOREIGN KEY (`parkinglot_id`) REFERENCES `parkinglot` (`parkinglot_id`);

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`parkingslot_id`) REFERENCES `parkingslot` (`parkingslot_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
