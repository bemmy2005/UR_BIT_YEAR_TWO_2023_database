-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 04:59 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jail_management_system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CreatePrisonView` ()   BEGIN
    -- Check if the view already exists and drop it if it does
    IF EXISTS (SELECT table_name FROM information_schema.views WHERE table_name = 'prison_view') THEN
        DROP VIEW prison_view;
    END IF;

    -- Create the view using a subquery
    CREATE VIEW prison_view AS
    SELECT
        p.prison_id,
        p.prison_name,
        p.prison_district,
        p.prison_sector,
        pr.prisoner_id,
        pr.fname AS prisoner_fname,
        pr.lname AS prisoner_lname,
        pr.id_number AS prisoner_id_number,
        pr.gender AS prisoner_gender,
        pr.DoB AS prisoner_DoB,
        pr.martial_status AS prisoner_martial_status,
        pr.admission_date,
        pr.release_date
    FROM
        prisons p
    LEFT JOIN
        prisoners pr ON p.prison_id = pr.prison_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteDepartedEmployees` ()   BEGIN
    -- Delete employees who have left the company (status = 0)
    DELETE FROM employee
    WHERE employee_id = 2;

    -- Delete corresponding department records for departed employees
    DELETE FROM employee
    WHERE employee_id=2;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllAdmins` ()   BEGIN
    SELECT *
    FROM admin;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllDataFromTables` ()   BEGIN
    SELECT * FROM  admin;
    SELECT * FROM  employee;
    SELECT * FROM visitors;
    SELECT * FROM visit_date;
    SELECT * FROM prisons;
    SELECT * FROM prisoners;
SELECT * FROM visit_date;
SELECT * FROM visitors;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllEmployee` ()   BEGIN
    SELECT *
    FROM employee;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllPrisoners` ()   BEGIN
    SELECT *
    FROM prisoners;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllprisoner_relation` ()   BEGIN
    SELECT *
    FROM prisoner_relation;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllschedule_visit_date` ()   BEGIN
    SELECT *
    FROM schedule_visit_date;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllVisit` ()   BEGIN
    SELECT *
    FROM visit;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllvisitors` ()   BEGIN
    SELECT *
    FROM visitors;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetFilteredEmployeeDetails` (IN `filter_prison_id` INT, IN `filter_education_level` VARCHAR(255))   BEGIN
    SELECT
        employee_id,
        fname,
        lname,
        id_number,
        phone,
        gender,
        martial_status,
        education_level,
        DoB,
        email,
        password,
        prison_id
    FROM
        employees
    WHERE
        prison_id IN (
            SELECT prison_id FROM prisons WHERE prison_id = filter_prison_id
        )
        AND
        education_level IN (
            SELECT education_level FROM employees WHERE education_level = filter_education_level
        );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertDataIntoMultipleTables` (IN `admin_fname` VARCHAR(255), IN `admin_lname` VARCHAR(255), IN `admin_id_number` VARCHAR(255), IN `admin_phone` VARCHAR(15), IN `admin_gender` VARCHAR(10), IN `admin_martial_status` VARCHAR(20), IN `admin_DoB` DATE, IN `admin_email` VARCHAR(255), IN `admin_password` VARCHAR(255), IN `employee_id` INT, IN `employee_fname` VARCHAR(255), IN `employee_lname` VARCHAR(255), IN `employee_id_number` VARCHAR(255), IN `employee_phone` VARCHAR(15), IN `employee_gender` VARCHAR(10), IN `employee_martial_status` VARCHAR(20), IN `employee_education_level` VARCHAR(50), IN `employee_DoB` DATE, IN `employee_email` VARCHAR(255), IN `employee_password` VARCHAR(255), IN `employee_prison_id` INT, IN `prisoners_fname` VARCHAR(255), IN `prisoners_lname` VARCHAR(255), IN `prisoners_id_number` VARCHAR(255), IN `prisoners_gender` VARCHAR(10), IN `prisoners_DoB` DATE, IN `prisoners_martial_status` VARCHAR(20), IN `prisoners_admission_date` DATE, IN `prisoners_release_date` DATE, IN `prisoners_prison_id` INT, IN `prisoners_prisoner_relation` VARCHAR(255), IN `prison_id` INT, IN `prison_name` VARCHAR(255), IN `prison_district` VARCHAR(255), IN `prison_sector` VARCHAR(255))   BEGIN
    -- Insert data into admin table
    INSERT INTO admin (fname, lname, id_number, phone, gender, martial_status, DoB, email, password)
    VALUES (admin_fname, admin_lname, admin_id_number, admin_phone, admin_gender, admin_martial_status, admin_DoB, admin_email, admin_password);

    -- Insert data into employee table
    INSERT INTO employee (employee_id, fname, lname, id_number, phone, gender, martial_status, education_level, DoB, email, password, prison_id)
    VALUES (employee_id, employee_fname, employee_lname, employee_id_number, employee_phone, employee_gender, employee_martial_status, employee_education_level, employee_DoB, employee_email, employee_password, employee_prison_id);

    -- Insert data into prisoners table
    INSERT INTO prisoners (fname, lname, id_number, gender, DoB, martial_status, admission_date, release_date, prison_id, prisoner_relation)
    VALUES (prisoners_fname, prisoners_lname, prisoners_id_number, prisoners_gender, prisoners_DoB, prisoners_martial_status, prisoners_admission_date, prisoners_release_date, prisoners_prison_id, prisoners_prisoner_relation);

    -- Insert data into other tables as needed...

    COMMIT;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertEmployee` (IN `p_employee_id` INT, IN `p_fname` VARCHAR(50), IN `p_lname` VARCHAR(50), IN `p_id_number` VARCHAR(20), IN `p_phone` VARCHAR(15), IN `p_gender` VARCHAR(10), IN `p_marital_status` VARCHAR(20), IN `p_education_level` VARCHAR(50), IN `p_DoB` DATE, IN `p_email` VARCHAR(100), IN `p_password` VARCHAR(100), IN `p_prison_id` INT)   BEGIN
    INSERT INTO Employee (employee_id, fname, lname, id_number, phone, gender, martial_status, education_level, DoB, email, password, prison_id)
    VALUES (p_employee_id, p_fname, p_lname, p_id_number, p_phone, p_gender, p_marital_status, p_education_level, p_DoB, p_email, p_password, p_prison_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertPrisoner` (IN `prisoner_id` INT, IN `fname` VARCHAR(50), IN `lname` VARCHAR(50), IN `id_number` VARCHAR(20), IN `gender` VARCHAR(10), IN `DoB` DATE, IN `martial_status` VARCHAR(20), IN `admission_date` DATE, IN `release_date` DATE, IN `prison_id` INT)   BEGIN
    INSERT INTO Prisoners (prisoner_id, fname, lname, id_number, gender, DoB, martial_status, admission_date, release_date, prison_id)
    VALUES (prisoner_id, fname, lname, id_number, gender, DoB, martial_status, admission_date, release_date, prison_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertPrisonRelation` (IN `fname` VARCHAR(50), IN `lname` VARCHAR(50), IN `id_number` VARCHAR(20), IN `prisoner_id` INT, IN `gender` VARCHAR(10), IN `martial_status` VARCHAR(20), IN `email` VARCHAR(100), IN `district` VARCHAR(50), IN `sector` VARCHAR(50), IN `cell` VARCHAR(50), IN `prison_id` INT)   BEGIN
    INSERT INTO InsertPrison_relation (fname, lname, id_number, prisoner_id, gender, martial_status, email, district, sector, cell, prison_id)
    VALUES (fname, lname, id_number, prisoner_id, gender, martial_status, email, district, sector, cell, prison_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertVisitDate` (IN `visitor_id` INT, IN `prisoner_id` INT, IN `visit_id` INT, IN `reason` VARCHAR(255), IN `prison_id` INT)   BEGIN
    INSERT INTO schedule_visit_date (visitor_id, prisoner_id, visit_id, reason, prison_id)
    VALUES (visitor_id, prisoner_id, visit_id, reason, prison_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertVisitTime` (IN `visitor_id` INT, IN `prisoner_id` INT, IN `visit_id` INT, IN `reason` VARCHAR(255), IN `prison_id` INT)   BEGIN
    INSERT INTO schedule_visit_date (visitor_id, prisoner_id, visit_id, reason, prison_id)
    VALUES (visitor_id, prisoner_id, visit_id, reason, prison_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateEmployeePhoneNumber` (IN `p_employee_id` INT, IN `p_new_phone_number` VARCHAR(15))   BEGIN
    UPDATE Employee
    SET phone = p_new_phone_number
    WHERE employee_id = p_employee_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdatePrisonerMaritalStatus` (IN `p_prisoner_id` INT, IN `p_new_marital_status` VARCHAR(20))   BEGIN
    UPDATE Prisoners
    SET martial_status = p_new_marital_status
    WHERE prisoner_id = p_prisoner_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(10) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `id_number` varchar(16) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `gender` varchar(40) NOT NULL,
  `martial_status` varchar(50) NOT NULL,
  `DoB` date NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `fname`, `lname`, `id_number`, `phone`, `gender`, `martial_status`, `DoB`, `email`, `password`) VALUES
(1, 'RUGEMANA', 'Audilie', '1200256765392536', '+250781872915', 'male', 'single', '0192-09-05', 'rugemana@gmail.com', '1234567821');

-- --------------------------------------------------------

--
-- Stand-in structure for view `admin_view`
-- (See below for the actual view)
--
CREATE TABLE `admin_view` (
`admin_id` int(10)
,`fname` varchar(50)
,`lname` varchar(50)
,`id_number` varchar(16)
,`phone` varchar(13)
,`gender` varchar(40)
,`martial_status` varchar(50)
,`DoB` date
,`email` varchar(40)
,`password` varchar(40)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_information`
-- (See below for the actual view)
--
CREATE TABLE `all_information` (
`admin_id` int(10)
,`fname` varchar(50)
,`lname` varchar(50)
,`id_number` varchar(16)
,`phone` varchar(13)
,`gender` varchar(40)
,`martial_status` varchar(50)
,`DoB` date
,`email` varchar(40)
,`password` varchar(40)
,`employee_id` int(10)
,`employee_first_name` varchar(50)
,`employee_last_name` varchar(16)
,`employee_identity_card` varchar(16)
,`employee_telephone_number` varchar(13)
,`employee_gender` varchar(40)
,`employee_martial_status` varchar(50)
,`education_level` varchar(40)
,`employee_birthdate` date
,`employee_email` varchar(40)
,`employee_password` varchar(40)
,`prisoner_id` int(10)
,`prisoner_first_name` varchar(40)
,`prisoner_last_name` varchar(40)
,`prisoner_identity_card` varchar(16)
,`prisoner_gender` varchar(40)
,`prisoner_birthdate` date
,`prisoner_martial_status` varchar(40)
,`admission_date` date
,`release_date` date
,`relation_id` int(10)
,`relation_first_name` varchar(40)
,`relation_last_name` varchar(40)
,`relation_identity_card` varchar(16)
,`relation_gender` varchar(30)
,`relation_martial_status` varchar(30)
,`relation_email` varchar(40)
,`district` varchar(40)
,`sector` varchar(40)
,`cell` varchar(30)
,`prison_name` varchar(50)
,`prison_district` varchar(50)
,`prison_sector` varchar(50)
,`schedule_id` int(10)
,`visitor_id` int(10)
,`reason` varchar(100)
,`visitor_first_name` varchar(50)
,`visitor_last_name` varchar(50)
,`visitor_identity_card` varchar(16)
,`visitor_phone` varchar(13)
,`visitor_gender` varchar(30)
,`visitor_martial_status` varchar(50)
,`visitor_birthdate` date
,`visitor_email` varchar(40)
,`visitor_password` varchar(40)
,`visit_date` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `choosen_visitors`
-- (See below for the actual view)
--
CREATE TABLE `choosen_visitors` (
`prisoner_id` int(10)
,`fname` varchar(40)
,`lname` varchar(40)
,`id_number` varchar(16)
,`gender` varchar(40)
,`DoB` date
,`martial_status` varchar(40)
,`admission_date` date
,`release_date` date
,`prison_id` int(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `emoployee_view`
-- (See below for the actual view)
--
CREATE TABLE `emoployee_view` (
`employee_id` int(10)
,`fname` varchar(50)
,`lname` varchar(16)
,`id_number` varchar(16)
,`phone` varchar(13)
,`gender` varchar(40)
,`martial_status` varchar(50)
,`education_level` varchar(40)
,`DoB` date
,`email` varchar(40)
,`password` varchar(40)
);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(10) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(16) NOT NULL,
  `id_number` varchar(16) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `gender` varchar(40) NOT NULL,
  `martial_status` varchar(50) NOT NULL,
  `education_level` varchar(40) NOT NULL,
  `DoB` date NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `prison_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `fname`, `lname`, `id_number`, `phone`, `gender`, `martial_status`, `education_level`, `DoB`, `email`, `password`, `prison_id`) VALUES
(1, 'RUKUNDO', 'egide', '1200256765324536', '+250781452545', 'male', 'married', 'Banchelor', '2000-09-04', 'rukundo@gmaol.com', '12345678', 2),
(4, 'KANGABE', 'Ritha', '1200256765678617', '+250781423775', 'female', 'single', 'Banchelor', '2001-09-04', 'rukundo@gmaol.com', '12345678', 2);

--
-- Triggers `employee`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteEmployee` AFTER DELETE ON `employee` FOR EACH ROW BEGIN
    INSERT INTO employee_audit (employee_id, action, audit_timestamp)
    VALUES (employee_id, 'DELETE', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertEmployee` AFTER INSERT ON `employee` FOR EACH ROW BEGIN
    -- You can perform actions here after a new employee is inserted.
    -- For example, you might log the insertion or perform additional data operations.
    -- This is a placeholder for your custom logic.
    
    -- For demonstration purposes, we'll insert a record into an audit table.
    INSERT INTO employee_audit (employee_id, action, audit_timestamp)
    VALUES (NEW.employee_id, 'INSERT', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateEmployee` AFTER UPDATE ON `employee` FOR EACH ROW BEGIN
    INSERT INTO employee_audit (employee_id, action, audit_timestamp)
    VALUES (NEW.employee_id, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `employee_audit`
--

CREATE TABLE `employee_audit` (
  `employee_id` int(10) NOT NULL,
  `action` varchar(50) NOT NULL,
  `audit_timestamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_audit`
--

INSERT INTO `employee_audit` (`employee_id`, `action`, `audit_timestamp`) VALUES
(4, 'INSERT', '2023-09-12 21:17:42.000000');

-- --------------------------------------------------------

--
-- Table structure for table `prisoners`
--

CREATE TABLE `prisoners` (
  `prisoner_id` int(10) NOT NULL,
  `fname` varchar(40) NOT NULL,
  `lname` varchar(40) NOT NULL,
  `id_number` varchar(16) NOT NULL,
  `gender` varchar(40) NOT NULL,
  `DoB` date NOT NULL,
  `martial_status` varchar(40) NOT NULL,
  `admission_date` date NOT NULL,
  `release_date` date NOT NULL,
  `prison_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prisoners`
--

INSERT INTO `prisoners` (`prisoner_id`, `fname`, `lname`, `id_number`, `gender`, `DoB`, `martial_status`, `admission_date`, `release_date`, `prison_id`) VALUES
(2, 'RUGIMBANA', 'Christian', '1200256765324536', 'male', '2002-09-04', 'married', '2012-04-20', '2024-05-12', 1),
(3, 'RUGAJU', 'Albelt', '1200156583498765', 'male', '2001-09-15', 'single', '2023-09-06', '2023-09-03', 2),
(4, 'MUGABE', 'Ruth', '1200574567892309', 'female', '2002-09-02', 'devorse', '2014-09-16', '2022-09-20', 4),
(101, 'John', 'kwihangana', '123457654314273', 'Male', '1990-01-15', 'Married', '2023-09-01', '2024-09-01', 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `prisoners_view`
-- (See below for the actual view)
--
CREATE TABLE `prisoners_view` (
`prisoner_id` int(10)
,`fname` varchar(40)
,`lname` varchar(40)
,`id_number` varchar(16)
,`gender` varchar(40)
,`DoB` date
,`martial_status` varchar(40)
,`admission_date` date
,`release_date` date
,`prison_id` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `prisoner_relation`
--

CREATE TABLE `prisoner_relation` (
  `relation_id` int(10) NOT NULL,
  `fname` varchar(40) DEFAULT NULL,
  `lname` varchar(40) DEFAULT NULL,
  `id_number` varchar(16) DEFAULT NULL,
  `prisoner_id` int(10) DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `martial_status` varchar(30) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `district` varchar(40) DEFAULT NULL,
  `sector` varchar(40) DEFAULT NULL,
  `cell` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prisoner_relation`
--

INSERT INTO `prisoner_relation` (`relation_id`, `fname`, `lname`, `id_number`, `prisoner_id`, `gender`, `martial_status`, `email`, `district`, `sector`, `cell`) VALUES
(1, 'ISHIMWE', 'Kabebe', '1200232765324536', 3, 'male', 'single', 'kabe@gmail.com', 'RUTSIRO', 'GIHANGO', 'CONGO-NIL'),
(2, 'KABANO', 'Emmy', '1200156213493465', 4, 'female', 'married', 'emmy@gmail.com', 'Karongi', 'kibuyr', 'gisayo'),
(3, 'KANGABE', 'Ritha', '1200574985292309', 2, 'female', 'devorse', 'kagi@gmail.com', 'Huye', 'Ngoma', 'Ngoma');

-- --------------------------------------------------------

--
-- Stand-in structure for view `prisoner_relation_view`
-- (See below for the actual view)
--
CREATE TABLE `prisoner_relation_view` (
`relation_id` int(10)
,`fname` varchar(40)
,`lname` varchar(40)
,`id_number` varchar(16)
,`prisoner_id` int(10)
,`gender` varchar(30)
,`martial_status` varchar(30)
,`email` varchar(40)
,`district` varchar(40)
,`sector` varchar(40)
,`cell` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `prisons`
--

CREATE TABLE `prisons` (
  `prison_id` int(10) NOT NULL,
  `prison_name` varchar(50) NOT NULL,
  `prison_district` varchar(50) NOT NULL,
  `prison_sector` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prisons`
--

INSERT INTO `prisons` (`prison_id`, `prison_name`, `prison_district`, `prison_sector`) VALUES
(1, 'Huye prison', 'Huye', 'Ngoma'),
(2, 'Nyarugenge', 'Nyarugenge', 'Nyarugenge'),
(3, 'Muhanga', 'Muhanga', 'Muhanga'),
(4, 'Gisenyi', 'Rubavu', 'Rubavu'),
(5, 'Kigali', 'Nyanza', 'kigali'),
(6, 'Nyarugenge prison', 'Nyarugenge', 'Nyarugenge'),
(7, 'Kigali', 'Nyanza', 'kigali'),
(8, 'Kigali prison', 'Nyanza', 'kigali');

--
-- Triggers `prisons`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertPrison` AFTER INSERT ON `prisons` FOR EACH ROW BEGIN
    -- You can perform actions here after a new prison is inserted.
    -- For example, you might log the insertion or perform additional data operations.
    -- This is a placeholder for your custom logic.

    -- For demonstration purposes, we'll insert a record into an audit table.
    INSERT INTO prison_audit (prison_id, prison_name, prison_district, prison_sector, action, audit_timestamp)
    VALUES (NEW.prison_id, NEW.prison_name, NEW.prison_district, NEW.prison_sector, 'INSERT', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdatePrison` AFTER INSERT ON `prisons` FOR EACH ROW BEGIN
    INSERT INTO prison_audit (prison_id, prison_name, prison_district, prison_sector, action, audit_timestamp)
    VALUES (NEW.prison_id, NEW.prison_name, NEW.prison_district, NEW.prison_sector, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `prisons_view`
-- (See below for the actual view)
--
CREATE TABLE `prisons_view` (
`prison_id` int(10)
,`prison_name` varchar(50)
,`prison_district` varchar(50)
,`prison_sector` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `prison_audit`
--

CREATE TABLE `prison_audit` (
  `prison_id` int(10) NOT NULL,
  `prison_name` varchar(50) NOT NULL,
  `prison_district` varchar(50) NOT NULL,
  `prison_sector` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `audit_timestamp` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prison_audit`
--

INSERT INTO `prison_audit` (`prison_id`, `prison_name`, `prison_district`, `prison_sector`, `action`, `audit_timestamp`) VALUES
(7, 'Kigali', 'Nyanza', 'kigali', 'INSERT', '2023-09-12 22:09:14.000000'),
(7, 'Kigali', 'Nyanza', 'kigali', 'UPDATE', '2023-09-12 22:09:14.000000'),
(8, 'Kigali prison', 'Nyanza', 'kigali', 'INSERT', '2023-09-12 22:09:43.000000'),
(8, 'Kigali prison', 'Nyanza', 'kigali', 'UPDATE', '2023-09-12 22:09:43.000000');

-- --------------------------------------------------------

--
-- Stand-in structure for view `prison_view`
-- (See below for the actual view)
--
CREATE TABLE `prison_view` (
`prison_id` int(10)
,`prison_name` varchar(50)
,`prison_district` varchar(50)
,`prison_sector` varchar(50)
,`prisoner_id` int(10)
,`prisoner_fname` varchar(40)
,`prisoner_lname` varchar(40)
,`prisoner_id_number` varchar(16)
,`prisoner_gender` varchar(40)
,`prisoner_DoB` date
,`prisoner_martial_status` varchar(40)
,`admission_date` date
,`release_date` date
);

-- --------------------------------------------------------

--
-- Table structure for table `schedule_visit_date`
--

CREATE TABLE `schedule_visit_date` (
  `schedule_id` int(10) NOT NULL,
  `visitor_id` int(10) NOT NULL,
  `prisoner_id` int(10) NOT NULL,
  `visit_id` int(10) NOT NULL,
  `reason` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule_visit_date`
--

INSERT INTO `schedule_visit_date` (`schedule_id`, `visitor_id`, `prisoner_id`, `visit_id`, `reason`) VALUES
(1, 1, 3, 1, 'give him food'),
(2, 3, 2, 3, 'check the health'),
(3, 2, 2, 4, 'I miss him');

-- --------------------------------------------------------

--
-- Stand-in structure for view `schedule_visit_date_view`
-- (See below for the actual view)
--
CREATE TABLE `schedule_visit_date_view` (
`schedule_id` int(10)
,`visitor_id` int(10)
,`prisoner_id` int(10)
,`visit_id` int(10)
,`reason` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `visitor_id` int(10) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `id_number` varchar(16) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `martial_status` varchar(50) NOT NULL,
  `DoB` date NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`visitor_id`, `fname`, `lname`, `id_number`, `phone`, `gender`, `martial_status`, `DoB`, `email`, `password`) VALUES
(1, 'KWIZERA', 'Omah lay', '1200256765332536', '+250781454375', 'male', 'single', '2001-09-04', 'omah@gmail.com', '12345678'),
(2, 'RUKUNDO', 'Vivens', '1200156583432765', '+250781232215', 'male', 'single', '2001-09-04', 'vie@gmail.com', '12345vive'),
(3, 'ISHIME', 'Audile', '1200574987892309', '+250781322445', 'female', 'devorse', '2000-09-13', 'ishia@gmail.com', '123ogog');

-- --------------------------------------------------------

--
-- Stand-in structure for view `visitor_view`
-- (See below for the actual view)
--
CREATE TABLE `visitor_view` (
`visitor_id` int(10)
,`fname` varchar(50)
,`lname` varchar(50)
,`id_number` varchar(16)
,`phone` varchar(13)
,`gender` varchar(30)
,`martial_status` varchar(50)
,`DoB` date
,`email` varchar(40)
,`password` varchar(40)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `visit_data_view`
-- (See below for the actual view)
--
CREATE TABLE `visit_data_view` (
`visit_id` int(10)
,`visit_date` date
);

-- --------------------------------------------------------

--
-- Table structure for table `visit_date`
--

CREATE TABLE `visit_date` (
  `visit_id` int(10) NOT NULL,
  `visit_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `visit_date`
--

INSERT INTO `visit_date` (`visit_id`, `visit_date`) VALUES
(1, '2023-09-05'),
(2, '2023-09-14'),
(3, '2023-09-11'),
(4, '2023-09-16');

-- --------------------------------------------------------

--
-- Structure for view `admin_view`
--
DROP TABLE IF EXISTS `admin_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `admin_view`  AS SELECT `admin`.`admin_id` AS `admin_id`, `admin`.`fname` AS `fname`, `admin`.`lname` AS `lname`, `admin`.`id_number` AS `id_number`, `admin`.`phone` AS `phone`, `admin`.`gender` AS `gender`, `admin`.`martial_status` AS `martial_status`, `admin`.`DoB` AS `DoB`, `admin`.`email` AS `email`, `admin`.`password` AS `password` FROM `admin``admin`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_information`
--
DROP TABLE IF EXISTS `all_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_information`  AS SELECT `admin`.`admin_id` AS `admin_id`, `admin`.`fname` AS `fname`, `admin`.`lname` AS `lname`, `admin`.`id_number` AS `id_number`, `admin`.`phone` AS `phone`, `admin`.`gender` AS `gender`, `admin`.`martial_status` AS `martial_status`, `admin`.`DoB` AS `DoB`, `admin`.`email` AS `email`, `admin`.`password` AS `password`, `employee`.`employee_id` AS `employee_id`, `employee`.`fname` AS `employee_first_name`, `employee`.`lname` AS `employee_last_name`, `employee`.`id_number` AS `employee_identity_card`, `employee`.`phone` AS `employee_telephone_number`, `employee`.`gender` AS `employee_gender`, `employee`.`martial_status` AS `employee_martial_status`, `employee`.`education_level` AS `education_level`, `employee`.`DoB` AS `employee_birthdate`, `employee`.`email` AS `employee_email`, `employee`.`password` AS `employee_password`, `prisoners`.`prisoner_id` AS `prisoner_id`, `prisoners`.`fname` AS `prisoner_first_name`, `prisoners`.`lname` AS `prisoner_last_name`, `prisoners`.`id_number` AS `prisoner_identity_card`, `prisoners`.`gender` AS `prisoner_gender`, `prisoners`.`DoB` AS `prisoner_birthdate`, `prisoners`.`martial_status` AS `prisoner_martial_status`, `prisoners`.`admission_date` AS `admission_date`, `prisoners`.`release_date` AS `release_date`, `prisoner_relation`.`relation_id` AS `relation_id`, `prisoner_relation`.`fname` AS `relation_first_name`, `prisoner_relation`.`lname` AS `relation_last_name`, `prisoner_relation`.`id_number` AS `relation_identity_card`, `prisoner_relation`.`gender` AS `relation_gender`, `prisoner_relation`.`martial_status` AS `relation_martial_status`, `prisoner_relation`.`email` AS `relation_email`, `prisoner_relation`.`district` AS `district`, `prisoner_relation`.`sector` AS `sector`, `prisoner_relation`.`cell` AS `cell`, `prisons`.`prison_name` AS `prison_name`, `prisons`.`prison_district` AS `prison_district`, `prisons`.`prison_sector` AS `prison_sector`, `schedule_visit_date`.`schedule_id` AS `schedule_id`, `schedule_visit_date`.`visitor_id` AS `visitor_id`, `schedule_visit_date`.`reason` AS `reason`, `visitors`.`fname` AS `visitor_first_name`, `visitors`.`lname` AS `visitor_last_name`, `visitors`.`id_number` AS `visitor_identity_card`, `visitors`.`phone` AS `visitor_phone`, `visitors`.`gender` AS `visitor_gender`, `visitors`.`martial_status` AS `visitor_martial_status`, `visitors`.`DoB` AS `visitor_birthdate`, `visitors`.`email` AS `visitor_email`, `visitors`.`password` AS `visitor_password`, `visit_date`.`visit_date` AS `visit_date` FROM (((((((`admin` join `employee`) join `prisoners`) join `prisoner_relation` on(`prisoners`.`prisoner_id` = `prisoner_relation`.`prisoner_id`)) join `prisons` on(`prisoners`.`prison_id` = `prisons`.`prison_id`)) join `schedule_visit_date` on(`prisoners`.`prisoner_id` = `schedule_visit_date`.`prisoner_id`)) join `visit_date`) join `visitors` on(`schedule_visit_date`.`visitor_id` = `visitors`.`visitor_id`))  ;

-- --------------------------------------------------------

--
-- Structure for view `choosen_visitors`
--
DROP TABLE IF EXISTS `choosen_visitors`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `choosen_visitors`  AS SELECT `prisoners`.`prisoner_id` AS `prisoner_id`, `prisoners`.`fname` AS `fname`, `prisoners`.`lname` AS `lname`, `prisoners`.`id_number` AS `id_number`, `prisoners`.`gender` AS `gender`, `prisoners`.`DoB` AS `DoB`, `prisoners`.`martial_status` AS `martial_status`, `prisoners`.`admission_date` AS `admission_date`, `prisoners`.`release_date` AS `release_date`, `prisoners`.`prison_id` AS `prison_id` FROM `prisoners` WHERE `prisoners`.`prison_id` = (select `prisons`.`prison_id` from `prisons` where `prisons`.`prison_name` = 'Nyarugenge')  ;

-- --------------------------------------------------------

--
-- Structure for view `emoployee_view`
--
DROP TABLE IF EXISTS `emoployee_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `emoployee_view`  AS SELECT `employee`.`employee_id` AS `employee_id`, `employee`.`fname` AS `fname`, `employee`.`lname` AS `lname`, `employee`.`id_number` AS `id_number`, `employee`.`phone` AS `phone`, `employee`.`gender` AS `gender`, `employee`.`martial_status` AS `martial_status`, `employee`.`education_level` AS `education_level`, `employee`.`DoB` AS `DoB`, `employee`.`email` AS `email`, `employee`.`password` AS `password` FROM `employee``employee`  ;

-- --------------------------------------------------------

--
-- Structure for view `prisoners_view`
--
DROP TABLE IF EXISTS `prisoners_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `prisoners_view`  AS SELECT `prisoners`.`prisoner_id` AS `prisoner_id`, `prisoners`.`fname` AS `fname`, `prisoners`.`lname` AS `lname`, `prisoners`.`id_number` AS `id_number`, `prisoners`.`gender` AS `gender`, `prisoners`.`DoB` AS `DoB`, `prisoners`.`martial_status` AS `martial_status`, `prisoners`.`admission_date` AS `admission_date`, `prisoners`.`release_date` AS `release_date`, `prisoners`.`prison_id` AS `prison_id` FROM `prisoners``prisoners`  ;

-- --------------------------------------------------------

--
-- Structure for view `prisoner_relation_view`
--
DROP TABLE IF EXISTS `prisoner_relation_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `prisoner_relation_view`  AS SELECT `prisoner_relation`.`relation_id` AS `relation_id`, `prisoner_relation`.`fname` AS `fname`, `prisoner_relation`.`lname` AS `lname`, `prisoner_relation`.`id_number` AS `id_number`, `prisoner_relation`.`prisoner_id` AS `prisoner_id`, `prisoner_relation`.`gender` AS `gender`, `prisoner_relation`.`martial_status` AS `martial_status`, `prisoner_relation`.`email` AS `email`, `prisoner_relation`.`district` AS `district`, `prisoner_relation`.`sector` AS `sector`, `prisoner_relation`.`cell` AS `cell` FROM `prisoner_relation``prisoner_relation`  ;

-- --------------------------------------------------------

--
-- Structure for view `prisons_view`
--
DROP TABLE IF EXISTS `prisons_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `prisons_view`  AS SELECT `prisons`.`prison_id` AS `prison_id`, `prisons`.`prison_name` AS `prison_name`, `prisons`.`prison_district` AS `prison_district`, `prisons`.`prison_sector` AS `prison_sector` FROM `prisons``prisons`  ;

-- --------------------------------------------------------

--
-- Structure for view `prison_view`
--
DROP TABLE IF EXISTS `prison_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `prison_view`  AS SELECT `p`.`prison_id` AS `prison_id`, `p`.`prison_name` AS `prison_name`, `p`.`prison_district` AS `prison_district`, `p`.`prison_sector` AS `prison_sector`, `pr`.`prisoner_id` AS `prisoner_id`, `pr`.`fname` AS `prisoner_fname`, `pr`.`lname` AS `prisoner_lname`, `pr`.`id_number` AS `prisoner_id_number`, `pr`.`gender` AS `prisoner_gender`, `pr`.`DoB` AS `prisoner_DoB`, `pr`.`martial_status` AS `prisoner_martial_status`, `pr`.`admission_date` AS `admission_date`, `pr`.`release_date` AS `release_date` FROM (`prisons` `p` left join `prisoners` `pr` on(`p`.`prison_id` = `pr`.`prison_id`))  ;

-- --------------------------------------------------------

--
-- Structure for view `schedule_visit_date_view`
--
DROP TABLE IF EXISTS `schedule_visit_date_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `schedule_visit_date_view`  AS SELECT `schedule_visit_date`.`schedule_id` AS `schedule_id`, `schedule_visit_date`.`visitor_id` AS `visitor_id`, `schedule_visit_date`.`prisoner_id` AS `prisoner_id`, `schedule_visit_date`.`visit_id` AS `visit_id`, `schedule_visit_date`.`reason` AS `reason` FROM `schedule_visit_date``schedule_visit_date`  ;

-- --------------------------------------------------------

--
-- Structure for view `visitor_view`
--
DROP TABLE IF EXISTS `visitor_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `visitor_view`  AS SELECT `visitors`.`visitor_id` AS `visitor_id`, `visitors`.`fname` AS `fname`, `visitors`.`lname` AS `lname`, `visitors`.`id_number` AS `id_number`, `visitors`.`phone` AS `phone`, `visitors`.`gender` AS `gender`, `visitors`.`martial_status` AS `martial_status`, `visitors`.`DoB` AS `DoB`, `visitors`.`email` AS `email`, `visitors`.`password` AS `password` FROM `visitors``visitors`  ;

-- --------------------------------------------------------

--
-- Structure for view `visit_data_view`
--
DROP TABLE IF EXISTS `visit_data_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `visit_data_view`  AS SELECT `visit_date`.`visit_id` AS `visit_id`, `visit_date`.`visit_date` AS `visit_date` FROM `visit_date``visit_date`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `prisoners`
--
ALTER TABLE `prisoners`
  ADD PRIMARY KEY (`prisoner_id`),
  ADD KEY `prison_id` (`prison_id`);

--
-- Indexes for table `prisoner_relation`
--
ALTER TABLE `prisoner_relation`
  ADD PRIMARY KEY (`relation_id`),
  ADD KEY `prisoner_id` (`prisoner_id`);

--
-- Indexes for table `prisons`
--
ALTER TABLE `prisons`
  ADD PRIMARY KEY (`prison_id`);

--
-- Indexes for table `schedule_visit_date`
--
ALTER TABLE `schedule_visit_date`
  ADD PRIMARY KEY (`schedule_id`),
  ADD KEY `visitor_id` (`visitor_id`),
  ADD KEY `prisoner_id` (`prisoner_id`),
  ADD KEY `visit_id` (`visit_id`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`visitor_id`);

--
-- Indexes for table `visit_date`
--
ALTER TABLE `visit_date`
  ADD PRIMARY KEY (`visit_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `prisoners`
--
ALTER TABLE `prisoners`
  MODIFY `prisoner_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `prisoner_relation`
--
ALTER TABLE `prisoner_relation`
  MODIFY `relation_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `prisons`
--
ALTER TABLE `prisons`
  MODIFY `prison_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `schedule_visit_date`
--
ALTER TABLE `schedule_visit_date`
  MODIFY `schedule_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `visitor_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `visit_date`
--
ALTER TABLE `visit_date`
  MODIFY `visit_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `prisons` (`prison_id`);

--
-- Constraints for table `prisoners`
--
ALTER TABLE `prisoners`
  ADD CONSTRAINT `prisoners_ibfk_1` FOREIGN KEY (`prison_id`) REFERENCES `prisons` (`prison_id`);

--
-- Constraints for table `prisoner_relation`
--
ALTER TABLE `prisoner_relation`
  ADD CONSTRAINT `prisoner_relation_ibfk_1` FOREIGN KEY (`prisoner_id`) REFERENCES `prisoners` (`prisoner_id`);

--
-- Constraints for table `schedule_visit_date`
--
ALTER TABLE `schedule_visit_date`
  ADD CONSTRAINT `schedule_visit_date_ibfk_1` FOREIGN KEY (`visitor_id`) REFERENCES `visitors` (`visitor_id`),
  ADD CONSTRAINT `schedule_visit_date_ibfk_2` FOREIGN KEY (`prisoner_id`) REFERENCES `prisoners` (`prisoner_id`),
  ADD CONSTRAINT `schedule_visit_date_ibfk_3` FOREIGN KEY (`visit_id`) REFERENCES `visit_date` (`visit_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
