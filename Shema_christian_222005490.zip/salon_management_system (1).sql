-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 11:23 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salon_management_system`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `allcustomers`
-- (See below for the actual view)
--
CREATE TABLE `allcustomers` (
`CustID` int(11)
,`FirstName` varchar(30)
,`LastName` varchar(50)
,`PhoneNumber` varchar(10)
,`Address` varchar(100)
,`Email` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `allservice`
-- (See below for the actual view)
--
CREATE TABLE `allservice` (
`serviceID` int(11)
,`serviceName` varchar(100)
,`Description` text
,`Price` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `allstaff`
-- (See below for the actual view)
--
CREATE TABLE `allstaff` (
`staffID` int(11)
,`FirstName` varchar(30)
,`LastName` varchar(30)
,`Position` varchar(20)
,`PhoneNumber` varchar(10)
,`Address` varchar(50)
,`Email` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CustID` int(11) NOT NULL,
  `FirstName` varchar(30) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(10) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CustID`, `FirstName`, `LastName`, `PhoneNumber`, `Address`, `Email`) VALUES
(1, 'Urukundo', 'Adeline', '789', 'GISOZI', 'adelurukundo@email.com'),
(2, 'Mugisha', 'Amina', '78945', 'KIMIRONKO', 'amina@email.com');

-- --------------------------------------------------------

--
-- Table structure for table `emppayroll`
--

CREATE TABLE `emppayroll` (
  `PayID` int(11) NOT NULL,
  `FirstName` varchar(10) DEFAULT NULL,
  `LastName` varchar(10) DEFAULT NULL,
  `staffID` int(11) DEFAULT NULL,
  `Salary` varchar(60) DEFAULT NULL,
  `Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_customer_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_customer_data` (
`custID` varchar(1)
,`FirstName` varchar(7)
,`LastName` varchar(6)
,`Email` varchar(23)
,`Address` varchar(17)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_new_staff_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_new_staff_data` (
`staffID` varchar(1)
,`FirstName` varchar(8)
,`LastName` varchar(7)
,`Position` varchar(11)
,`PhoneNumber` varchar(6)
,`Address` varchar(7)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_service_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_service_data` (
`serviceID` varchar(1)
,`serviceName` varchar(7)
,`Description` varchar(16)
,`Price` varchar(3)
);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `InventoryID` int(11) NOT NULL,
  `ProductName` varchar(80) DEFAULT NULL,
  `ProductCategory` varchar(20) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `Quantity` varchar(30) DEFAULT NULL,
  `supplierID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `PaymentID` int(11) NOT NULL,
  `TransactionDate` date DEFAULT NULL,
  `AmountPaid` varchar(30) DEFAULT NULL,
  `PaymentMethod` varchar(40) DEFAULT NULL,
  `CustID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`PaymentID`, `TransactionDate`, `AmountPaid`, `PaymentMethod`, `CustID`) VALUES
(1, '2023-09-05', '5000', 'credit card', 1),
(2, '2023-09-05', '3400', 'credit card', 2);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `serviceID` int(11) NOT NULL,
  `serviceName` varchar(100) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`serviceID`, `serviceName`, `Description`, `Price`) VALUES
(1, 'Haircut', 'Include wash,cut,and styling', '3000.00'),
(2, 'Manicure', 'Nail shaping and polish', '1500.00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `show_stylist`
-- (See below for the actual view)
--
CREATE TABLE `show_stylist` (
`stylistID` int(11)
,`FirstName` varchar(20)
,`LastName` varchar(20)
,`Phone` varchar(10)
,`Email` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffID` int(11) NOT NULL,
  `FirstName` varchar(30) DEFAULT NULL,
  `LastName` varchar(30) DEFAULT NULL,
  `Position` varchar(20) DEFAULT NULL,
  `PhoneNumber` varchar(10) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `stylists`
--

CREATE TABLE `stylists` (
  `stylistID` int(11) NOT NULL,
  `FirstName` varchar(20) DEFAULT NULL,
  `LastName` varchar(20) DEFAULT NULL,
  `Phone` varchar(10) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stylists`
--

INSERT INTO `stylists` (`stylistID`, `FirstName`, `LastName`, `Phone`, `Email`) VALUES
(1, 'sarah', 'Mutuyesu', '670098', 'mutusarah@email.com'),
(2, 'Michel', 'Brown', '56765', 'brownmichel@email.com');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplierID` int(11) NOT NULL,
  `FirstName` varchar(30) DEFAULT NULL,
  `LastName` varchar(30) DEFAULT NULL,
  `Quantity` varchar(20) DEFAULT NULL,
  `PhoneNumber` varchar(10) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplierID`, `FirstName`, `LastName`, `Quantity`, `PhoneNumber`, `Email`) VALUES
(1, 'Shema', 'Chriss', '20', '34345', 'shemachriss@email.com'),
(2, 'Byiringiro', 'vivens', '70', '998', 'byiringiro@email.com');

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatecustomerinfo`
-- (See below for the actual view)
--
CREATE TABLE `updatecustomerinfo` (
`CustID` int(11)
,`FirstName` varchar(30)
,`LastName` varchar(50)
,`PhoneNumber` varchar(10)
,`Address` varchar(100)
,`Email` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatestylistinfo`
-- (See below for the actual view)
--
CREATE TABLE `updatestylistinfo` (
`stylistID` int(11)
,`FirstName` varchar(20)
,`LastName` varchar(20)
,`Phone` varchar(10)
,`Email` varchar(50)
);

-- --------------------------------------------------------

--
-- Structure for view `allcustomers`
--
DROP TABLE IF EXISTS `allcustomers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `allcustomers`  AS SELECT `customers`.`CustID` AS `CustID`, `customers`.`FirstName` AS `FirstName`, `customers`.`LastName` AS `LastName`, `customers`.`PhoneNumber` AS `PhoneNumber`, `customers`.`Address` AS `Address`, `customers`.`Email` AS `Email` FROM `customers``customers`  ;

-- --------------------------------------------------------

--
-- Structure for view `allservice`
--
DROP TABLE IF EXISTS `allservice`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `allservice`  AS SELECT `services`.`serviceID` AS `serviceID`, `services`.`serviceName` AS `serviceName`, `services`.`Description` AS `Description`, `services`.`Price` AS `Price` FROM `services``services`  ;

-- --------------------------------------------------------

--
-- Structure for view `allstaff`
--
DROP TABLE IF EXISTS `allstaff`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `allstaff`  AS SELECT `staff`.`staffID` AS `staffID`, `staff`.`FirstName` AS `FirstName`, `staff`.`LastName` AS `LastName`, `staff`.`Position` AS `Position`, `staff`.`PhoneNumber` AS `PhoneNumber`, `staff`.`Address` AS `Address`, `staff`.`Email` AS `Email` FROM `staff``staff`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_customer_data`
--
DROP TABLE IF EXISTS `insert_customer_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_customer_data`  AS SELECT '1' AS `custID`, 'Kwizera' AS `FirstName`, 'Arcade' AS `LastName`, 'kwizeraricade@email.com' AS `Email`, 'KIGALI_NYARUGENGE' AS `Address``Address`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_new_staff_data`
--
DROP TABLE IF EXISTS `insert_new_staff_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_new_staff_data`  AS SELECT '1' AS `staffID`, 'Hitimana' AS `FirstName`, 'Fabrice' AS `LastName`, 'DataManager' AS `Position`, '789000' AS `PhoneNumber`, 'GAHONDO' AS `Address``Address`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_service_data`
--
DROP TABLE IF EXISTS `insert_service_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_service_data`  AS SELECT '1' AS `serviceID`, 'Haircut' AS `serviceName`, 'Wash and styling' AS `Description`, '500' AS `Price``Price`  ;

-- --------------------------------------------------------

--
-- Structure for view `show_stylist`
--
DROP TABLE IF EXISTS `show_stylist`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `show_stylist`  AS SELECT `stylists`.`stylistID` AS `stylistID`, `stylists`.`FirstName` AS `FirstName`, `stylists`.`LastName` AS `LastName`, `stylists`.`Phone` AS `Phone`, `stylists`.`Email` AS `Email` FROM `stylists``stylists`  ;

-- --------------------------------------------------------

--
-- Structure for view `updatecustomerinfo`
--
DROP TABLE IF EXISTS `updatecustomerinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatecustomerinfo`  AS SELECT `customers`.`CustID` AS `CustID`, `customers`.`FirstName` AS `FirstName`, `customers`.`LastName` AS `LastName`, `customers`.`PhoneNumber` AS `PhoneNumber`, `customers`.`Address` AS `Address`, `customers`.`Email` AS `Email` FROM `customers``customers`  ;

-- --------------------------------------------------------

--
-- Structure for view `updatestylistinfo`
--
DROP TABLE IF EXISTS `updatestylistinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatestylistinfo`  AS SELECT `stylists`.`stylistID` AS `stylistID`, `stylists`.`FirstName` AS `FirstName`, `stylists`.`LastName` AS `LastName`, `stylists`.`Phone` AS `Phone`, `stylists`.`Email` AS `Email` FROM `stylists``stylists`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustID`);

--
-- Indexes for table `emppayroll`
--
ALTER TABLE `emppayroll`
  ADD PRIMARY KEY (`PayID`),
  ADD KEY `staffID` (`staffID`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`InventoryID`),
  ADD KEY `supplierID` (`supplierID`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `CustID` (`CustID`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`serviceID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffID`);

--
-- Indexes for table `stylists`
--
ALTER TABLE `stylists`
  ADD PRIMARY KEY (`stylistID`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplierID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `emppayroll`
--
ALTER TABLE `emppayroll`
  ADD CONSTRAINT `emppayroll_ibfk_1` FOREIGN KEY (`staffID`) REFERENCES `staff` (`staffID`);

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`supplierID`) REFERENCES `suppliers` (`supplierID`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`CustID`) REFERENCES `customers` (`CustID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
