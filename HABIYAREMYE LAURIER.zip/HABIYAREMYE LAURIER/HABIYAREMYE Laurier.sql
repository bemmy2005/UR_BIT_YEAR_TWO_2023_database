-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: Ambulance_booking_syst
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `AdminID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Role` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`AdminID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'Jean MURONGO','+250781111111','admin1@gmail.com','Administrator'),(2,'Alice MBONGO','+250722222222','alicembogo@dispatcher.abs.com','Dispatcher'),(3,'Laurier  Greens RUGWIZA','+250733333333','admin3@gmail.com','Coordinator');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `allinformationview`
--

DROP TABLE IF EXISTS `allinformationview`;
/*!50001 DROP VIEW IF EXISTS `allinformationview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `allinformationview` AS SELECT
 1 AS `UserID`,
  1 AS `UserName`,
  1 AS `PhoneNumber`,
  1 AS `Email`,
  1 AS `Address`,
  1 AS `DateOfBirth`,
  1 AS `Gender`,
  1 AS `MedicalHistory`,
  1 AS `InsuranceInfo`,
  1 AS `AmbulanceID`,
  1 AS `VehicleNumber`,
  1 AS `AmbulanceType`,
  1 AS `AmbulanceCapacity`,
  1 AS `AmbulanceEquipment`,
  1 AS `AmbulanceLatitude`,
  1 AS `AmbulanceLongitude`,
  1 AS `AmbulanceStatus`,
  1 AS `AmbulanceDriverName`,
  1 AS `AmbulanceDriverContact`,
  1 AS `AmbulanceDriverCertification`,
  1 AS `BookingID`,
  1 AS `PickupLatitude`,
  1 AS `PickupLongitude`,
  1 AS `DestinationLatitude`,
  1 AS `DestinationLongitude`,
  1 AS `DestinationHospitalName`,
  1 AS `BookingRequestedTime`,
  1 AS `BookingPriority`,
  1 AS `BookingStatus`,
  1 AS `BookingReason`,
  1 AS `BookingNotes`,
  1 AS `TripID`,
  1 AS `TripPickupTime`,
  1 AS `TripDropoffTime`,
  1 AS `TripDistanceTraveled`,
  1 AS `TripEstimatedArrivalTime`,
  1 AS `TripFare`,
  1 AS `TripPaymentStatus`,
  1 AS `PaymentID`,
  1 AS `PaymentMethod`,
  1 AS `PaymentAmount`,
  1 AS `PaymentDateTime`,
  1 AS `EmergencyContactID`,
  1 AS `EmergencyContactName`,
  1 AS `EmergencyContactRelationship`,
  1 AS `EmergencyContactPhoneNumber`,
  1 AS `FeedbackID`,
  1 AS `FeedbackRating`,
  1 AS `FeedbackComments`,
  1 AS `FeedbackDateTime`,
  1 AS `NotificationID`,
  1 AS `NotificationContent`,
  1 AS `NotificationTimestamp`,
  1 AS `NotificationStatus`,
  1 AS `ReportID`,
  1 AS `ReportType`,
  1 AS `ReportDateRange`,
  1 AS `ReportGeneratedBy`,
  1 AS `ReportContent` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `ambulance`
--

DROP TABLE IF EXISTS `ambulance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ambulance` (
  `AmbulanceID` int(11) NOT NULL AUTO_INCREMENT,
  `VehicleNumber` varchar(20) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Capacity` int(11) DEFAULT NULL,
  `Equipment` text DEFAULT NULL,
  `CurrentLatitude` decimal(9,6) DEFAULT NULL,
  `CurrentLongitude` decimal(9,6) DEFAULT NULL,
  `AvailabilityStatus` varchar(20) DEFAULT NULL,
  `DriverName` varchar(255) DEFAULT NULL,
  `DriverContact` varchar(20) DEFAULT NULL,
  `DriverCertification` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`AmbulanceID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ambulance`
--

LOCK TABLES `ambulance` WRITE;
/*!40000 ALTER TABLE `ambulance` DISABLE KEYS */;
INSERT INTO `ambulance` VALUES (1,'RAD-001C','Basic',2,'First Aid Kit, Oxygen',-1.949180,30.058360,'Available','Sean MUGABE','+250731234567','Certified EMT'),(2,'RAG-002D','Advanced',4,'Defibrillator, Ventilator',-1.949560,30.059740,'Available','Aline KEZA','+250789876543','Paramedic Certified');
/*!40000 ALTER TABLE `ambulance` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER AmbulanceAfterUpdate
AFTER UPDATE ON Ambulance
FOR EACH ROW
BEGIN
    IF NEW.AvailabilityStatus = 'Unavailable' THEN
        INSERT INTO Notification (UserID, Content, Timestamp, Status)
        VALUES (1, 'Ambulance is now unavailable: ' || NEW.VehicleNumber, NOW(), 'Ambulance Unavailable');
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `bookingrequest`
--

DROP TABLE IF EXISTS `bookingrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookingrequest` (
  `BookingID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `PickupLatitude` decimal(9,6) DEFAULT NULL,
  `PickupLongitude` decimal(9,6) DEFAULT NULL,
  `DestinationLatitude` decimal(9,6) DEFAULT NULL,
  `DestinationLongitude` decimal(9,6) DEFAULT NULL,
  `HospitalName` varchar(50) DEFAULT NULL,
  `RequestedTime` datetime DEFAULT NULL,
  `PriorityLevel` varchar(20) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `Reason` text DEFAULT NULL,
  `AdditionalNotes` text DEFAULT NULL,
  PRIMARY KEY (`BookingID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `bookingrequest_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookingrequest`
--

LOCK TABLES `bookingrequest` WRITE;
/*!40000 ALTER TABLE `bookingrequest` DISABLE KEYS */;
INSERT INTO `bookingrequest` VALUES (1,1,-1.949285,30.059917,-1.932574,30.061589,'CHUK','2023-09-12 08:00:00','High','Pending','Emergency','Patient is in critical condition'),(2,2,-1.942345,30.058123,-1.926789,30.055432,'Laurier Int Hospital','2023-09-12 10:30:00','Medium','Pending','Accident','Multiple injuries reported'),(3,3,-1.942345,30.058123,-1.926789,30.055432,'Laurier Int Hospital','2023-09-12 10:35:10','High','Pending','Accident','Patient had a panic');
/*!40000 ALTER TABLE `bookingrequest` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER BookingRequestAfterDelete
AFTER DELETE ON BookingRequest
FOR EACH ROW
BEGIN

    UPDATE Trip
    SET Status = 'Canceled'
    WHERE BookingID = OLD.BookingID;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `emergencycontacts`
--

DROP TABLE IF EXISTS `emergencycontacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emergencycontacts` (
  `ContactID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `ContactName` varchar(255) DEFAULT NULL,
  `Relationship` varchar(50) DEFAULT NULL,
  `ContactPhoneNumber` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ContactID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `emergencycontacts_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emergencycontacts`
--

LOCK TABLES `emergencycontacts` WRITE;
/*!40000 ALTER TABLE `emergencycontacts` DISABLE KEYS */;
INSERT INTO `emergencycontacts` VALUES (1,1,'Aline MUGISHA','Wife','+250732345678'),(2,2,'Joh KAREMERA','Sibling','+250784576456');
/*!40000 ALTER TABLE `emergencycontacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedbackandratings`
--

DROP TABLE IF EXISTS `feedbackandratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedbackandratings` (
  `FeedbackID` int(11) NOT NULL AUTO_INCREMENT,
  `TripID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Rating` int(11) DEFAULT NULL,
  `Comments` text DEFAULT NULL,
  `FeedbackDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`FeedbackID`),
  KEY `TripID` (`TripID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `feedbackandratings_ibfk_1` FOREIGN KEY (`TripID`) REFERENCES `trip` (`TripID`),
  CONSTRAINT `feedbackandratings_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedbackandratings`
--

LOCK TABLES `feedbackandratings` WRITE;
/*!40000 ALTER TABLE `feedbackandratings` DISABLE KEYS */;
INSERT INTO `feedbackandratings` VALUES (1,1,1,5,'Excellent service! Mukomereze aho.','2023-09-12 11:30:00'),(2,2,2,4,'Badutabaye mugihe cyihuse, murakoze.','2023-09-12 12:30:00');
/*!40000 ALTER TABLE `feedbackandratings` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER FeedbackAfterInsert
AFTER INSERT ON FeedbackAndRatings
FOR EACH ROW
BEGIN
    UPDATE Trip
    SET Rating = (SELECT AVG(Rating) FROM FeedbackAndRatings WHERE TripID = NEW.TripID)
    WHERE TripID = NEW.TripID;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `highprioritybookings`
--

DROP TABLE IF EXISTS `highprioritybookings`;
/*!50001 DROP VIEW IF EXISTS `highprioritybookings`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `highprioritybookings` AS SELECT
 1 AS `BookingID`,
  1 AS `UserID`,
  1 AS `PickupLatitude`,
  1 AS `PickupLongitude`,
  1 AS `DestinationLatitude`,
  1 AS `DestinationLongitude`,
  1 AS `HospitalName`,
  1 AS `RequestedTime`,
  1 AS `PriorityLevel`,
  1 AS `Status`,
  1 AS `Reason`,
  1 AS `AdditionalNotes` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `insert_adminrview`
--

DROP TABLE IF EXISTS `insert_adminrview`;
/*!50001 DROP VIEW IF EXISTS `insert_adminrview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `insert_adminrview` AS SELECT
 1 AS `AdminID`,
  1 AS `Name`,
  1 AS `PhoneNumber`,
  1 AS `Email`,
  1 AS `Role` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `insert_ambulanceview`
--

DROP TABLE IF EXISTS `insert_ambulanceview`;
/*!50001 DROP VIEW IF EXISTS `insert_ambulanceview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `insert_ambulanceview` AS SELECT
 1 AS `AmbulanceID`,
  1 AS `VehicleNumber`,
  1 AS `Type`,
  1 AS `Capacity`,
  1 AS `Equipment`,
  1 AS `CurrentLatitude`,
  1 AS `CurrentLongitude`,
  1 AS `AvailabilityStatus`,
  1 AS `DriverName`,
  1 AS `DriverContact`,
  1 AS `DriverCertification` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `insert_bookingrequestview`
--

DROP TABLE IF EXISTS `insert_bookingrequestview`;
/*!50001 DROP VIEW IF EXISTS `insert_bookingrequestview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `insert_bookingrequestview` AS SELECT
 1 AS `BookingID`,
  1 AS `UserID`,
  1 AS `PickupLatitude`,
  1 AS `PickupLongitude`,
  1 AS `DestinationLatitude`,
  1 AS `DestinationLongitude`,
  1 AS `HospitalName`,
  1 AS `RequestedTime`,
  1 AS `PriorityLevel`,
  1 AS `Status`,
  1 AS `Reason`,
  1 AS `AdditionalNotes` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `insert_emergencycontactsview`
--

DROP TABLE IF EXISTS `insert_emergencycontactsview`;
/*!50001 DROP VIEW IF EXISTS `insert_emergencycontactsview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `insert_emergencycontactsview` AS SELECT
 1 AS `ContactID`,
  1 AS `UserID`,
  1 AS `ContactName`,
  1 AS `Relationship`,
  1 AS `ContactPhoneNumber` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `insert_paymentview`
--

DROP TABLE IF EXISTS `insert_paymentview`;
/*!50001 DROP VIEW IF EXISTS `insert_paymentview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `insert_paymentview` AS SELECT
 1 AS `PaymentID`,
  1 AS `TripID`,
  1 AS `UserID`,
  1 AS `PaymentMethod`,
  1 AS `Amount`,
  1 AS `PaymentDateTime` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `insert_tripview`
--

DROP TABLE IF EXISTS `insert_tripview`;
/*!50001 DROP VIEW IF EXISTS `insert_tripview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `insert_tripview` AS SELECT
 1 AS `TripID`,
  1 AS `BookingID`,
  1 AS `AmbulanceID`,
  1 AS `PickupTime`,
  1 AS `DropoffTime`,
  1 AS `DistanceTraveled`,
  1 AS `EstimatedArrivalTime`,
  1 AS `Fare`,
  1 AS `PaymentStatus` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `insert_userview`
--

DROP TABLE IF EXISTS `insert_userview`;
/*!50001 DROP VIEW IF EXISTS `insert_userview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `insert_userview` AS SELECT
 1 AS `UserID`,
  1 AS `Name`,
  1 AS `PhoneNumber`,
  1 AS `Email`,
  1 AS `Address`,
  1 AS `DateOfBirth`,
  1 AS `Gender`,
  1 AS `MedicalHistory`,
  1 AS `InsuranceInfo` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `NotificationID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) DEFAULT NULL,
  `Content` text DEFAULT NULL,
  `Timestamp` datetime DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`NotificationID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (1,6,'A new user has been added.','2023-09-16 16:44:49','New User');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `PaymentID` int(11) NOT NULL AUTO_INCREMENT,
  `TripID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `PaymentMethod` varchar(20) DEFAULT NULL,
  `Amount` decimal(10,2) DEFAULT NULL,
  `PaymentDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`PaymentID`),
  KEY `TripID` (`TripID`),
  KEY `UserID` (`UserID`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`TripID`) REFERENCES `trip` (`TripID`),
  CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,1,1,'Credit Card',75.00,'2023-09-12 11:00:00'),(2,2,2,'Bitcoin',65.00,'2023-09-12 12:15:00'),(3,3,3,'Bitcoin',70.50,'2023-09-12 12:15:00');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reportsandanalytics`
--

DROP TABLE IF EXISTS `reportsandanalytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reportsandanalytics` (
  `ReportID` int(11) NOT NULL AUTO_INCREMENT,
  `ReportType` varchar(50) DEFAULT NULL,
  `DateRange` varchar(50) DEFAULT NULL,
  `GeneratedBy` int(11) DEFAULT NULL,
  `ReportContent` text DEFAULT NULL,
  PRIMARY KEY (`ReportID`),
  KEY `GeneratedBy` (`GeneratedBy`),
  CONSTRAINT `reportsandanalytics_ibfk_1` FOREIGN KEY (`GeneratedBy`) REFERENCES `admin` (`AdminID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reportsandanalytics`
--

LOCK TABLES `reportsandanalytics` WRITE;
/*!40000 ALTER TABLE `reportsandanalytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `reportsandanalytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trip`
--

DROP TABLE IF EXISTS `trip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trip` (
  `TripID` int(11) NOT NULL AUTO_INCREMENT,
  `BookingID` int(11) DEFAULT NULL,
  `AmbulanceID` int(11) DEFAULT NULL,
  `PickupTime` datetime DEFAULT NULL,
  `DropoffTime` datetime DEFAULT NULL,
  `DistanceTraveled` decimal(10,2) DEFAULT NULL,
  `EstimatedArrivalTime` datetime DEFAULT NULL,
  `Fare` decimal(10,2) DEFAULT NULL,
  `PaymentStatus` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`TripID`),
  KEY `BookingID` (`BookingID`),
  KEY `AmbulanceID` (`AmbulanceID`),
  CONSTRAINT `trip_ibfk_1` FOREIGN KEY (`BookingID`) REFERENCES `bookingrequest` (`BookingID`),
  CONSTRAINT `trip_ibfk_2` FOREIGN KEY (`AmbulanceID`) REFERENCES `ambulance` (`AmbulanceID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trip`
--

LOCK TABLES `trip` WRITE;
/*!40000 ALTER TABLE `trip` DISABLE KEYS */;
INSERT INTO `trip` VALUES (1,1,1,'2023-09-12 10:35:00','2023-09-12 10:55:00',5.30,'2023-09-12 10:55:00',75.00,'Paid'),(2,2,2,'2023-09-12 11:50:00','2023-09-12 12:10:00',4.80,'2023-09-12 12:10:00',65.00,'Pending'),(3,3,2,'2023-09-12 10:52:10','2023-09-12 11:37:19',5.80,'2023-09-12 12:10:00',70.50,'Paid');
/*!40000 ALTER TABLE `trip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `MedicalHistory` text DEFAULT NULL,
  `InsuranceInfo` text DEFAULT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'John MUGISHA','+250780116574','joh@gmail.com','Kigali, Rwanda','1990-01-15','Male','Diabetes','Greens Insurance'),(2,'Jane KEZA','+250787654321','jane@gmail.com','Kigali, Rwanda','1985-03-20','Female','Allergies','UAP Insurance'),(3,'Sam ISHIMWE','+250723456745','sam@gmail.com','Kigali, Rwanda','1990-01-15','Male','None','RSSB Insurance'),(5,'John RUREMA','+250732345678','john@gmail.com','Kigali, Rwanda','1990-01-15','Male','Heart Attack','Greens Insurance'),(6,'Alain MIKWEGE','+250723456700','alainmikwege@gmail.com','Kigali, Rwanda','1990-11-25','Male','Headache','Greens Insurance');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER UserAfterInsert
AFTER INSERT ON User
FOR EACH ROW
BEGIN
  INSERT INTO Notification (UserID, Content, Timestamp, Status)
   VALUES (NEW.UserID, 'A new user has been added.', NOW(), 'New User');
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER UserAfterUpdate
AFTER UPDATE ON User
FOR EACH ROW
BEGIN

    INSERT INTO Notification (UserID, Content, Timestamp, Status)
    VALUES (NEW.UserID, CONCAT('User information updated: ', NEW.Name), NOW(), 'User Updated');
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER UserAfterDelete
AFTER DELETE ON User
FOR EACH ROW
BEGIN
    INSERT INTO Notification (UserID, Content, Timestamp, Status)
    VALUES (OLD.UserID, CONCAT('User deleted: ', OLD.Name), NOW(), 'User Deleted');
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `userview`
--

DROP TABLE IF EXISTS `userview`;
/*!50001 DROP VIEW IF EXISTS `userview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `userview` AS SELECT
 1 AS `UserID`,
  1 AS `Name`,
  1 AS `PhoneNumber`,
  1 AS `Email`,
  1 AS `Address` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `allinformationview`
--

/*!50001 DROP VIEW IF EXISTS `allinformationview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `allinformationview` AS select `u`.`UserID` AS `UserID`,`u`.`Name` AS `UserName`,`u`.`PhoneNumber` AS `PhoneNumber`,`u`.`Email` AS `Email`,`u`.`Address` AS `Address`,`u`.`DateOfBirth` AS `DateOfBirth`,`u`.`Gender` AS `Gender`,`u`.`MedicalHistory` AS `MedicalHistory`,`u`.`InsuranceInfo` AS `InsuranceInfo`,`a`.`AmbulanceID` AS `AmbulanceID`,`a`.`VehicleNumber` AS `VehicleNumber`,`a`.`Type` AS `AmbulanceType`,`a`.`Capacity` AS `AmbulanceCapacity`,`a`.`Equipment` AS `AmbulanceEquipment`,`a`.`CurrentLatitude` AS `AmbulanceLatitude`,`a`.`CurrentLongitude` AS `AmbulanceLongitude`,`a`.`AvailabilityStatus` AS `AmbulanceStatus`,`a`.`DriverName` AS `AmbulanceDriverName`,`a`.`DriverContact` AS `AmbulanceDriverContact`,`a`.`DriverCertification` AS `AmbulanceDriverCertification`,`br`.`BookingID` AS `BookingID`,`br`.`PickupLatitude` AS `PickupLatitude`,`br`.`PickupLongitude` AS `PickupLongitude`,`br`.`DestinationLatitude` AS `DestinationLatitude`,`br`.`DestinationLongitude` AS `DestinationLongitude`,`br`.`HospitalName` AS `DestinationHospitalName`,`br`.`RequestedTime` AS `BookingRequestedTime`,`br`.`PriorityLevel` AS `BookingPriority`,`br`.`Status` AS `BookingStatus`,`br`.`Reason` AS `BookingReason`,`br`.`AdditionalNotes` AS `BookingNotes`,`t`.`TripID` AS `TripID`,`t`.`PickupTime` AS `TripPickupTime`,`t`.`DropoffTime` AS `TripDropoffTime`,`t`.`DistanceTraveled` AS `TripDistanceTraveled`,`t`.`EstimatedArrivalTime` AS `TripEstimatedArrivalTime`,`t`.`Fare` AS `TripFare`,`t`.`PaymentStatus` AS `TripPaymentStatus`,`p`.`PaymentID` AS `PaymentID`,`p`.`PaymentMethod` AS `PaymentMethod`,`p`.`Amount` AS `PaymentAmount`,`p`.`PaymentDateTime` AS `PaymentDateTime`,`ec`.`ContactID` AS `EmergencyContactID`,`ec`.`ContactName` AS `EmergencyContactName`,`ec`.`Relationship` AS `EmergencyContactRelationship`,`ec`.`ContactPhoneNumber` AS `EmergencyContactPhoneNumber`,`far`.`FeedbackID` AS `FeedbackID`,`far`.`Rating` AS `FeedbackRating`,`far`.`Comments` AS `FeedbackComments`,`far`.`FeedbackDateTime` AS `FeedbackDateTime`,`n`.`NotificationID` AS `NotificationID`,`n`.`Content` AS `NotificationContent`,`n`.`Timestamp` AS `NotificationTimestamp`,`n`.`Status` AS `NotificationStatus`,`rra`.`ReportID` AS `ReportID`,`rra`.`ReportType` AS `ReportType`,`rra`.`DateRange` AS `ReportDateRange`,`rra`.`GeneratedBy` AS `ReportGeneratedBy`,`rra`.`ReportContent` AS `ReportContent` from ((((((((`user` `u` left join `ambulance` `a` on(`u`.`UserID` = `a`.`AmbulanceID`)) left join `bookingrequest` `br` on(`u`.`UserID` = `br`.`UserID`)) left join `trip` `t` on(`br`.`BookingID` = `t`.`BookingID`)) left join `payment` `p` on(`t`.`TripID` = `p`.`TripID`)) left join `emergencycontacts` `ec` on(`u`.`UserID` = `ec`.`UserID`)) left join `feedbackandratings` `far` on(`t`.`TripID` = `far`.`TripID`)) left join `notification` `n` on(`u`.`UserID` = `n`.`UserID`)) left join `reportsandanalytics` `rra` on(`u`.`UserID` = `rra`.`GeneratedBy`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `highprioritybookings`
--

/*!50001 DROP VIEW IF EXISTS `highprioritybookings`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `highprioritybookings` AS select `bookingrequest`.`BookingID` AS `BookingID`,`bookingrequest`.`UserID` AS `UserID`,`bookingrequest`.`PickupLatitude` AS `PickupLatitude`,`bookingrequest`.`PickupLongitude` AS `PickupLongitude`,`bookingrequest`.`DestinationLatitude` AS `DestinationLatitude`,`bookingrequest`.`DestinationLongitude` AS `DestinationLongitude`,`bookingrequest`.`HospitalName` AS `HospitalName`,`bookingrequest`.`RequestedTime` AS `RequestedTime`,`bookingrequest`.`PriorityLevel` AS `PriorityLevel`,`bookingrequest`.`Status` AS `Status`,`bookingrequest`.`Reason` AS `Reason`,`bookingrequest`.`AdditionalNotes` AS `AdditionalNotes` from `bookingrequest` where `bookingrequest`.`PriorityLevel` = 'High' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `insert_adminrview`
--

/*!50001 DROP VIEW IF EXISTS `insert_adminrview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `insert_adminrview` AS select `admin`.`AdminID` AS `AdminID`,`admin`.`Name` AS `Name`,`admin`.`PhoneNumber` AS `PhoneNumber`,`admin`.`Email` AS `Email`,`admin`.`Role` AS `Role` from `admin` where `admin`.`AdminID` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `insert_ambulanceview`
--

/*!50001 DROP VIEW IF EXISTS `insert_ambulanceview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `insert_ambulanceview` AS select `ambulance`.`AmbulanceID` AS `AmbulanceID`,`ambulance`.`VehicleNumber` AS `VehicleNumber`,`ambulance`.`Type` AS `Type`,`ambulance`.`Capacity` AS `Capacity`,`ambulance`.`Equipment` AS `Equipment`,`ambulance`.`CurrentLatitude` AS `CurrentLatitude`,`ambulance`.`CurrentLongitude` AS `CurrentLongitude`,`ambulance`.`AvailabilityStatus` AS `AvailabilityStatus`,`ambulance`.`DriverName` AS `DriverName`,`ambulance`.`DriverContact` AS `DriverContact`,`ambulance`.`DriverCertification` AS `DriverCertification` from `ambulance` where `ambulance`.`AmbulanceID` = 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `insert_bookingrequestview`
--

/*!50001 DROP VIEW IF EXISTS `insert_bookingrequestview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `insert_bookingrequestview` AS select `bookingrequest`.`BookingID` AS `BookingID`,`bookingrequest`.`UserID` AS `UserID`,`bookingrequest`.`PickupLatitude` AS `PickupLatitude`,`bookingrequest`.`PickupLongitude` AS `PickupLongitude`,`bookingrequest`.`DestinationLatitude` AS `DestinationLatitude`,`bookingrequest`.`DestinationLongitude` AS `DestinationLongitude`,`bookingrequest`.`HospitalName` AS `HospitalName`,`bookingrequest`.`RequestedTime` AS `RequestedTime`,`bookingrequest`.`PriorityLevel` AS `PriorityLevel`,`bookingrequest`.`Status` AS `Status`,`bookingrequest`.`Reason` AS `Reason`,`bookingrequest`.`AdditionalNotes` AS `AdditionalNotes` from `bookingrequest` where `bookingrequest`.`BookingID` = 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `insert_emergencycontactsview`
--

/*!50001 DROP VIEW IF EXISTS `insert_emergencycontactsview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `insert_emergencycontactsview` AS select `emergencycontacts`.`ContactID` AS `ContactID`,`emergencycontacts`.`UserID` AS `UserID`,`emergencycontacts`.`ContactName` AS `ContactName`,`emergencycontacts`.`Relationship` AS `Relationship`,`emergencycontacts`.`ContactPhoneNumber` AS `ContactPhoneNumber` from `emergencycontacts` where `emergencycontacts`.`ContactID` = 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `insert_paymentview`
--

/*!50001 DROP VIEW IF EXISTS `insert_paymentview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `insert_paymentview` AS select `payment`.`PaymentID` AS `PaymentID`,`payment`.`TripID` AS `TripID`,`payment`.`UserID` AS `UserID`,`payment`.`PaymentMethod` AS `PaymentMethod`,`payment`.`Amount` AS `Amount`,`payment`.`PaymentDateTime` AS `PaymentDateTime` from `payment` where `payment`.`PaymentID` = 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `insert_tripview`
--

/*!50001 DROP VIEW IF EXISTS `insert_tripview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `insert_tripview` AS select `trip`.`TripID` AS `TripID`,`trip`.`BookingID` AS `BookingID`,`trip`.`AmbulanceID` AS `AmbulanceID`,`trip`.`PickupTime` AS `PickupTime`,`trip`.`DropoffTime` AS `DropoffTime`,`trip`.`DistanceTraveled` AS `DistanceTraveled`,`trip`.`EstimatedArrivalTime` AS `EstimatedArrivalTime`,`trip`.`Fare` AS `Fare`,`trip`.`PaymentStatus` AS `PaymentStatus` from `trip` where `trip`.`TripID` = 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `insert_userview`
--

/*!50001 DROP VIEW IF EXISTS `insert_userview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `insert_userview` AS select `user`.`UserID` AS `UserID`,`user`.`Name` AS `Name`,`user`.`PhoneNumber` AS `PhoneNumber`,`user`.`Email` AS `Email`,`user`.`Address` AS `Address`,`user`.`DateOfBirth` AS `DateOfBirth`,`user`.`Gender` AS `Gender`,`user`.`MedicalHistory` AS `MedicalHistory`,`user`.`InsuranceInfo` AS `InsuranceInfo` from `user` where `user`.`UserID` = 4 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `userview`
--

/*!50001 DROP VIEW IF EXISTS `userview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `userview` AS select `user`.`UserID` AS `UserID`,`user`.`Name` AS `Name`,`user`.`PhoneNumber` AS `PhoneNumber`,`user`.`Email` AS `Email`,`user`.`Address` AS `Address` from `user` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-16 18:08:58
