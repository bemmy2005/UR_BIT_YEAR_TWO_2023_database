-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 04:41 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cbe_management_system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Deleteevents` (IN `p_eventID` INT)   BEGIN
    DELETE FROM events
    WHERE eventID = p_eventID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deletestudent` (IN `p_studentID` INT)   BEGIN
    DELETE FROM students
    WHERE studentID = p_studentID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_courses_Information` ()   BEGIN
    SELECT * FROM courses;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_department_Information` ()   BEGIN
    SELECT * FROM department;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_enrollments_Information` ()   BEGIN
    SELECT * FROM enrollments;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_events_Information` ()   BEGIN
    SELECT * FROM events;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_students_Information` ()   BEGIN
    SELECT * FROM students;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertcourses` (IN `p_coursecode` INT(5), IN `p_CourseTitle` VARCHAR(50), IN `p_Description` VARCHAR(100), IN `p_credithours` VARCHAR(100), IN `p_Prerequisites` VARCHAR(40), IN `p_ScheduleInfo` VARCHAR(40), IN `p_Instructor` VARCHAR(40))   BEGIN
       INSERT INTO Courses (CourseCode, CourseTitle, Description,credithours, Prerequisites, ScheduleInfo, Instructor)
    VALUES (p_CourseCode, p_CourseTitle, p_Description, p_CreditHours, p_Prerequisites, p_ScheduleInfo, p_Instructor);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertevent` (IN `p_eventID` INT(5), IN `p_eventName` VARCHAR(50), IN `p_eventdate` DATE, IN `p_location` VARCHAR(100), IN `p_description` VARCHAR(40))   BEGIN
    INSERT INTO events (eventID ,eventName, eventdate,location, description)
    VALUES (p_eventID,p_eventName,p_eventdate, p_location, p_description);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertfacility` (IN `p_facilityID` INT(5), IN `p_facilityName` VARCHAR(50), IN `p_type` VARCHAR(100), IN `p_location` VARCHAR(100), IN `p_capacity` VARCHAR(40))   BEGIN
    INSERT INTO facilities (facilityID ,facilityName, type,location, capacity)
    VALUES (p_facilityID,p_facilitytName,p_type, p_location, p_capacity);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertfaculty` (IN `p_facultyID` INT(5), IN `p_Name` VARCHAR(50), IN `p_Department` VARCHAR(100), IN `p_Title` VARCHAR(100), IN `p_researchInterests` VARCHAR(40))   BEGIN
    INSERT INTO faculty (facultyID ,Name, Department, Title, ResearchInterests)
    VALUES (p_facultyID,p_Name,p_Department, p_Title, p_ResearchInterests);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertStudent` (IN `p_FirstName` VARCHAR(50), IN `p_LastName` VARCHAR(50), IN `p_DateOfBirth` DATE, IN `p_ContactEmail` VARCHAR(100), IN `p_EnrollmentStatus` VARCHAR(50), IN `p_Major` VARCHAR(100), IN `p_GraduationDate` DATE, IN `p_AcademicAdvisor` VARCHAR(100))   BEGIN
    INSERT INTO Students (FirstName, LastName, DateOfBirth, ContactEmail, EnrollmentStatus, Major, GraduationDate, AcademicAdvisor)
    VALUES (p_FirstName, p_LastName, p_DateOfBirth, p_ContactEmail, p_EnrollmentStatus, p_Major, p_GraduationDate, p_AcademicAdvisor);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_departmentdata` (IN `p_departmentID` INT(11), IN `p_departmentname` VARCHAR(50), IN `p_departmentchair` VARCHAR(50))   BEGIN
    UPDATE departments
    SET
       DepartmentName= p_new_departmentname,
      department= p_new_departmentchair
       
    WHERE
        DepartmentIDID= p_department;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_user_account` (IN `p_userID` INT(11), IN `p_username` VARCHAR(50), IN `p_passwordhash` VARCHAR(50), IN `p_role` VARCHAR(50))   BEGIN
    UPDATE users
    SET
        username = p_new_username,
       passwordhash = p_new_passwordhash,
       role=p_role
 WHERE
        userID=p_userID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ViewDepartmentWithEmployeeCount` ()   BEGIN
    SELECT
        D.Departmentcode,
        D.DepartmentName,
        D.departmentchair,
        (SELECT COUNT(*) FROM students E WHERE s.DepartmentID = D.DepartmentID) AS studentCount
    FROM Department D;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `CourseCode` varchar(20) NOT NULL,
  `CourseTitle` varchar(100) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `CreditHours` int(11) DEFAULT NULL,
  `Prerequisites` varchar(100) DEFAULT NULL,
  `ScheduleInfo` varchar(200) DEFAULT NULL,
  `Instructor` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`CourseCode`, `CourseTitle`, `Description`, `CreditHours`, `Prerequisites`, `ScheduleInfo`, `Instructor`) VALUES
('BA101', 'Introduction to Business', 'Overview of business concepts', 3, NULL, 'MWF 10:00 AM - 11:30 AM', 'Dr. NewInstructor'),
('FIN201', 'Financial Management', 'Managing corporate finances', 3, 'BA101', 'TTh 1:00 PM - 2:30 PM', 'Dr. Johnson'),
('MKT301', 'Marketing Strategy', 'Developing marketing strategies', 3, 'BA101', 'MWF 2:00 PM - 3:30 PM', 'Dr. Brown');

-- --------------------------------------------------------

--
-- Stand-in structure for view `deleteevent_information`
-- (See below for the actual view)
--
CREATE TABLE `deleteevent_information` (
`EventID` int(11)
,`EventName` varchar(100)
,`EventDate` date
,`Location` varchar(100)
,`Description` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `deletefaculty_information`
-- (See below for the actual view)
--
CREATE TABLE `deletefaculty_information` (
`FacultyID` int(11)
,`Name` varchar(50)
,`Department` varchar(100)
,`Title` varchar(100)
,`ResearchInterests` text
);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DepartmentCode` varchar(10) NOT NULL,
  `DepartmentName` varchar(100) DEFAULT NULL,
  `DepartmentChair` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DepartmentCode`, `DepartmentName`, `DepartmentChair`) VALUES
('BA', 'Business Administration', 'Dr. Smith'),
('FIN', 'Finance', 'Dr. Johnson'),
('MKT', 'Marketing', 'Dr. Brown');

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `EnrollmentID` int(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `CourseCode` varchar(20) DEFAULT NULL,
  `SemesterYear` varchar(20) DEFAULT NULL,
  `EnrollmentStatus` varchar(50) DEFAULT NULL,
  `Grade` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`EnrollmentID`, `StudentID`, `CourseCode`, `SemesterYear`, `EnrollmentStatus`, `Grade`) VALUES
(1, 1, 'BA101', '2023Fall', 'Registered', NULL),
(2, 1, 'FIN201', '2023Fall', 'Registered', NULL),
(3, 2, 'BA101', '2023Fall', 'Registered', NULL),
(4, 2, 'MKT301', '2023Fall', 'Registered', NULL),
(5, 3, 'BA101', '2023Fall', 'Registered', NULL),
(6, 3, 'FIN201', '2023Fall', 'Registered', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `EventID` int(11) NOT NULL,
  `EventName` varchar(100) DEFAULT NULL,
  `EventDate` date DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`EventID`, `EventName`, `EventDate`, `Location`, `Description`) VALUES
(2, 'trip for holidaay', '2023-12-02', 'south', 'business management');

--
-- Triggers `events`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteevents` AFTER DELETE ON `events` FOR EACH ROW BEGIN
    INSERT INTO events(eventID, Action, DateTime, IPAddress)
    VALUES (eventID, 'Employee Deleted', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE `facilities` (
  `FacilityID` int(11) NOT NULL,
  `FacilityName` varchar(100) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Capacity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`FacilityID`, `FacilityName`, `Type`, `Location`, `Capacity`) VALUES
(1, 'supervision', 'teaching', 'main auditoliaum', 1),
(2, 'training', 'contoling', 'main kall of koica', 2);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `FacultyID` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Department` varchar(100) DEFAULT NULL,
  `Title` varchar(100) DEFAULT NULL,
  `ResearchInterests` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`FacultyID`, `Name`, `Department`, `Title`, `ResearchInterests`) VALUES
(2, 'uwera', 'Finance', 'Associate Professor', 'Financial Markets'),
(3, 'Dr. Brown', 'Marketing', 'Professor', 'Consumer Behavior');

--
-- Triggers `faculty`
--
DELIMITER $$
CREATE TRIGGER `AfterUpdatefaculty` AFTER UPDATE ON `faculty` FOR EACH ROW BEGIN
    UPDATE faculty
    SET LastUpdated = NOW()
    WHERE facultyID = OLD.facultyID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `financialrecords`
--

CREATE TABLE `financialrecords` (
  `RecordID` int(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `TransactionDate` date DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `financialrecords`
--

INSERT INTO `financialrecords` (`RecordID`, `StudentID`, `TransactionDate`, `Description`, `Amount`) VALUES
(1, 1, '2023-02-12', 'application fees', '5000.00'),
(2, 2, '2021-12-04', 'registration', '60000.00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_courses`
-- (See below for the actual view)
--
CREATE TABLE `insert_courses` (
`CourseCode` varchar(20)
,`CourseTitle` varchar(100)
,`Description` text
,`CreditHours` int(11)
,`Prerequisites` varchar(100)
,`ScheduleInfo` varchar(200)
,`Instructor` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_department`
-- (See below for the actual view)
--
CREATE TABLE `insert_department` (
`DepartmentCode` varchar(10)
,`DepartmentName` varchar(100)
,`DepartmentChair` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_enrollments`
-- (See below for the actual view)
--
CREATE TABLE `insert_enrollments` (
`EnrollmentID` int(11)
,`StudentID` int(11)
,`CourseCode` varchar(20)
,`SemesterYear` varchar(20)
,`EnrollmentStatus` varchar(50)
,`Grade` varchar(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_students`
-- (See below for the actual view)
--
CREATE TABLE `insert_students` (
`StudentID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`DateOfBirth` date
,`ContactEmail` varchar(100)
,`EnrollmentStatus` varchar(50)
,`Major` varchar(100)
,`GraduationDate` date
,`AcademicAdvisor` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `libraryresources`
--

CREATE TABLE `libraryresources` (
  `ResourceID` int(11) NOT NULL,
  `ResourceType` varchar(50) DEFAULT NULL,
  `ResourceName` varchar(100) DEFAULT NULL,
  `AvailabilityStatus` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `libraryresources`
--

INSERT INTO `libraryresources` (`ResourceID`, `ResourceType`, `ResourceName`, `AvailabilityStatus`) VALUES
(1, 'teaching', 'project', 'visual digital'),
(2, 'keeping', 'boards', 'white board');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `StudentID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `ContactEmail` varchar(100) DEFAULT NULL,
  `EnrollmentStatus` varchar(50) DEFAULT NULL,
  `Major` varchar(100) DEFAULT NULL,
  `GraduationDate` date DEFAULT NULL,
  `AcademicAdvisor` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`StudentID`, `FirstName`, `LastName`, `DateOfBirth`, `ContactEmail`, `EnrollmentStatus`, `Major`, `GraduationDate`, `AcademicAdvisor`) VALUES
(1, 'nezerwa', 'ella', '1998-05-15', 'newemail@example.com', 'Enrolled', 'Business Administration', '2024-05-15', 'Dr. Smith'),
(2, 'Jane', 'berwa', '1999-03-20', 'jane.smith@gmail.com', 'Enrolled', 'Finance', '2024-05-15', 'Dr. Johnson'),
(3, 'Alice', 'keza', '1997-08-10', 'alice.johnson@gmail.com', 'Enrolled', 'Marketing', '2024-05-15', 'Dr. Brown');

--
-- Triggers `students`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteSTUDENTS` AFTER DELETE ON `students` FOR EACH ROW BEGIN
    INSERT INTO users(UserID, Action, DateTime, IPAddress)
    VALUES (userID, 'Employee Deleted', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertstudents` AFTER INSERT ON `students` FOR EACH ROW BEGIN
    INSERT INTO users (UserID, Action, DateTime, IPAddress)
    VALUES (NEW.studentID, 'New Employee Added', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_events_information`
-- (See below for the actual view)
--
CREATE TABLE `update_events_information` (
`EventID` int(11)
,`EventName` varchar(100)
,`EventDate` date
,`Location` varchar(100)
,`Description` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_faculty_information`
-- (See below for the actual view)
--
CREATE TABLE `update_faculty_information` (
`FacultyID` int(11)
,`Name` varchar(50)
,`Department` varchar(100)
,`Title` varchar(100)
,`ResearchInterests` text
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `PasswordHash` varchar(100) DEFAULT NULL,
  `Role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Username`, `PasswordHash`, `Role`) VALUES
(1, 'diane', '12a', 'all grants'),
(2, 'ella', '2222', 'generating reports');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `AfterUpdateuser` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
    INSERT INTO users (userID, Username,Passwordhash,role)
    VALUES (userID, username, NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_insert_events`
-- (See below for the actual view)
--
CREATE TABLE `view_insert_events` (
`EventID` int(11)
,`EventName` varchar(100)
,`EventDate` date
,`Location` varchar(100)
,`Description` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_insert_facilities`
-- (See below for the actual view)
--
CREATE TABLE `view_insert_facilities` (
`FacilityID` int(11)
,`FacilityName` varchar(100)
,`Type` varchar(50)
,`Location` varchar(100)
,`Capacity` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_insert_faculty`
-- (See below for the actual view)
--
CREATE TABLE `view_insert_faculty` (
`FacultyID` int(11)
,`Name` varchar(50)
,`Department` varchar(100)
,`Title` varchar(100)
,`ResearchInterests` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_insert_financialrecords`
-- (See below for the actual view)
--
CREATE TABLE `view_insert_financialrecords` (
`RecordID` int(11)
,`StudentID` int(11)
,`TransactionDate` date
,`Description` varchar(200)
,`Amount` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_insert_libraryresources`
-- (See below for the actual view)
--
CREATE TABLE `view_insert_libraryresources` (
`ResourceID` int(11)
,`ResourceType` varchar(50)
,`ResourceName` varchar(100)
,`AvailabilityStatus` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_insert_user`
-- (See below for the actual view)
--
CREATE TABLE `view_insert_user` (
`UserID` int(11)
,`Username` varchar(50)
,`PasswordHash` varchar(100)
,`Role` varchar(50)
);

-- --------------------------------------------------------

--
-- Structure for view `deleteevent_information`
--
DROP TABLE IF EXISTS `deleteevent_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deleteevent_information`  AS SELECT `events`.`EventID` AS `EventID`, `events`.`EventName` AS `EventName`, `events`.`EventDate` AS `EventDate`, `events`.`Location` AS `Location`, `events`.`Description` AS `Description` FROM `events` WHERE `events`.`EventID` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `deletefaculty_information`
--
DROP TABLE IF EXISTS `deletefaculty_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deletefaculty_information`  AS SELECT `faculty`.`FacultyID` AS `FacultyID`, `faculty`.`Name` AS `Name`, `faculty`.`Department` AS `Department`, `faculty`.`Title` AS `Title`, `faculty`.`ResearchInterests` AS `ResearchInterests` FROM `faculty` WHERE `faculty`.`FacultyID` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_courses`
--
DROP TABLE IF EXISTS `insert_courses`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_courses`  AS SELECT `courses`.`CourseCode` AS `CourseCode`, `courses`.`CourseTitle` AS `CourseTitle`, `courses`.`Description` AS `Description`, `courses`.`CreditHours` AS `CreditHours`, `courses`.`Prerequisites` AS `Prerequisites`, `courses`.`ScheduleInfo` AS `ScheduleInfo`, `courses`.`Instructor` AS `Instructor` FROM `courses``courses`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_department`
--
DROP TABLE IF EXISTS `insert_department`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_department`  AS SELECT `departments`.`DepartmentCode` AS `DepartmentCode`, `departments`.`DepartmentName` AS `DepartmentName`, `departments`.`DepartmentChair` AS `DepartmentChair` FROM `departments``departments`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_enrollments`
--
DROP TABLE IF EXISTS `insert_enrollments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_enrollments`  AS SELECT `enrollments`.`EnrollmentID` AS `EnrollmentID`, `enrollments`.`StudentID` AS `StudentID`, `enrollments`.`CourseCode` AS `CourseCode`, `enrollments`.`SemesterYear` AS `SemesterYear`, `enrollments`.`EnrollmentStatus` AS `EnrollmentStatus`, `enrollments`.`Grade` AS `Grade` FROM `enrollments``enrollments`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_students`
--
DROP TABLE IF EXISTS `insert_students`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_students`  AS SELECT `students`.`StudentID` AS `StudentID`, `students`.`FirstName` AS `FirstName`, `students`.`LastName` AS `LastName`, `students`.`DateOfBirth` AS `DateOfBirth`, `students`.`ContactEmail` AS `ContactEmail`, `students`.`EnrollmentStatus` AS `EnrollmentStatus`, `students`.`Major` AS `Major`, `students`.`GraduationDate` AS `GraduationDate`, `students`.`AcademicAdvisor` AS `AcademicAdvisor` FROM `students``students`  ;

-- --------------------------------------------------------

--
-- Structure for view `update_events_information`
--
DROP TABLE IF EXISTS `update_events_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_events_information`  AS SELECT `events`.`EventID` AS `EventID`, `events`.`EventName` AS `EventName`, `events`.`EventDate` AS `EventDate`, `events`.`Location` AS `Location`, `events`.`Description` AS `Description` FROM `events` WHERE `events`.`EventID` = 22  ;

-- --------------------------------------------------------

--
-- Structure for view `update_faculty_information`
--
DROP TABLE IF EXISTS `update_faculty_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_faculty_information`  AS SELECT `faculty`.`FacultyID` AS `FacultyID`, `faculty`.`Name` AS `Name`, `faculty`.`Department` AS `Department`, `faculty`.`Title` AS `Title`, `faculty`.`ResearchInterests` AS `ResearchInterests` FROM `faculty` WHERE `faculty`.`FacultyID` = 22  ;

-- --------------------------------------------------------

--
-- Structure for view `view_insert_events`
--
DROP TABLE IF EXISTS `view_insert_events`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_insert_events`  AS SELECT `events`.`EventID` AS `EventID`, `events`.`EventName` AS `EventName`, `events`.`EventDate` AS `EventDate`, `events`.`Location` AS `Location`, `events`.`Description` AS `Description` FROM `events``events`  ;

-- --------------------------------------------------------

--
-- Structure for view `view_insert_facilities`
--
DROP TABLE IF EXISTS `view_insert_facilities`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_insert_facilities`  AS SELECT `facilities`.`FacilityID` AS `FacilityID`, `facilities`.`FacilityName` AS `FacilityName`, `facilities`.`Type` AS `Type`, `facilities`.`Location` AS `Location`, `facilities`.`Capacity` AS `Capacity` FROM `facilities``facilities`  ;

-- --------------------------------------------------------

--
-- Structure for view `view_insert_faculty`
--
DROP TABLE IF EXISTS `view_insert_faculty`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_insert_faculty`  AS SELECT `faculty`.`FacultyID` AS `FacultyID`, `faculty`.`Name` AS `Name`, `faculty`.`Department` AS `Department`, `faculty`.`Title` AS `Title`, `faculty`.`ResearchInterests` AS `ResearchInterests` FROM `faculty``faculty`  ;

-- --------------------------------------------------------

--
-- Structure for view `view_insert_financialrecords`
--
DROP TABLE IF EXISTS `view_insert_financialrecords`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_insert_financialrecords`  AS SELECT `financialrecords`.`RecordID` AS `RecordID`, `financialrecords`.`StudentID` AS `StudentID`, `financialrecords`.`TransactionDate` AS `TransactionDate`, `financialrecords`.`Description` AS `Description`, `financialrecords`.`Amount` AS `Amount` FROM `financialrecords``financialrecords`  ;

-- --------------------------------------------------------

--
-- Structure for view `view_insert_libraryresources`
--
DROP TABLE IF EXISTS `view_insert_libraryresources`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_insert_libraryresources`  AS SELECT `libraryresources`.`ResourceID` AS `ResourceID`, `libraryresources`.`ResourceType` AS `ResourceType`, `libraryresources`.`ResourceName` AS `ResourceName`, `libraryresources`.`AvailabilityStatus` AS `AvailabilityStatus` FROM `libraryresources``libraryresources`  ;

-- --------------------------------------------------------

--
-- Structure for view `view_insert_user`
--
DROP TABLE IF EXISTS `view_insert_user`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_insert_user`  AS SELECT `users`.`UserID` AS `UserID`, `users`.`Username` AS `Username`, `users`.`PasswordHash` AS `PasswordHash`, `users`.`Role` AS `Role` FROM `users``users`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`CourseCode`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`DepartmentCode`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`EnrollmentID`),
  ADD KEY `StudentID` (`StudentID`),
  ADD KEY `CourseCode` (`CourseCode`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`EventID`);

--
-- Indexes for table `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`FacilityID`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`FacultyID`);

--
-- Indexes for table `financialrecords`
--
ALTER TABLE `financialrecords`
  ADD PRIMARY KEY (`RecordID`),
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `libraryresources`
--
ALTER TABLE `libraryresources`
  ADD PRIMARY KEY (`ResourceID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`StudentID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`),
  ADD CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`CourseCode`) REFERENCES `courses` (`CourseCode`);

--
-- Constraints for table `financialrecords`
--
ALTER TABLE `financialrecords`
  ADD CONSTRAINT `financialrecords_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
