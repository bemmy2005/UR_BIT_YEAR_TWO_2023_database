-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 09:12 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nzayisenga_222010587`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteJobseeker` (IN `p_jobseeker_id` INT)   BEGIN
    DELETE FROM jobseeker
    WHERE jobseeker_ID = p_jobseeker_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertInterview` (IN `p_interview_id` INT, IN `p_job_id` INT, IN `p_jobseeker_id` INT, IN `p_interviewer_id` INT, IN `p_date` DATE, IN `p_time` TIME, IN `p_location` VARCHAR(50), IN `p_interview_type` VARCHAR(50), IN `p_interviewer_name` VARCHAR(40), IN `p_interview_feedback` VARCHAR(40), IN `p_interview_status` VARCHAR(40))   BEGIN
    INSERT INTO interview (
        interview_id,
        job_id,
        jobseeker_id,
        interviewer_id,
        date,
        time,
        location,
        interview_type,
        interviewer_name,
        interview_feedback,
        interview_status
    ) VALUES (
        p_interview_id,
        p_job_id,
        p_jobseeker_id,
        p_interviewer_id,
        p_date,
        p_time,
        p_location,
        p_interview_type,
        p_interviewer_name,
        p_interview_feedback,
        p_interview_status
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertJob` (IN `p_job_id` INT, IN `p_recruiter_id` INT, IN `p_job_description` VARCHAR(50), IN `p_job_name` VARCHAR(40), IN `p_job_location` VARCHAR(40), IN `p_job_salary` VARCHAR(50), IN `p_posting_date` VARCHAR(40), IN `p_application_deadline` VARCHAR(40), IN `p_employment_type` VARCHAR(50), IN `p_job_requirements` VARCHAR(40), IN `p_department` VARCHAR(40), IN `p_status` VARCHAR(40))   BEGIN
    INSERT INTO job (
        job_id,
        recruiter_id,
        job_description,
        job_name,
        job_location,
        job_salary,
        posting_date,
        application_deadline,
        employment_type,
        job_requirements,
        department,
        status
    ) VALUES (
        p_job_id,
        p_recruiter_id,
        p_job_description,
        p_job_name,
        p_job_location,
        p_job_salary,
        p_posting_date,
        p_application_deadline,
        p_employment_type,
        p_job_requirements,
        p_department,
        p_status
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertJobseeker` (IN `p_jobseeker_ID` INT, IN `p_jobseeker_name` VARCHAR(30), IN `p_jobseeker_phone` VARCHAR(40), IN `p_jobseeker_email_address` VARCHAR(50), IN `p_jobseeker_username` VARCHAR(60), IN `p_jobseeker_password` VARCHAR(20), IN `p_jobseeker_address` VARCHAR(40), IN `p_jobseeker_resume` VARCHAR(40), IN `p_jobseeker_disability` VARCHAR(50), IN `p_jobseeker_reference` VARCHAR(40), IN `p_application_date` VARCHAR(50), IN `p_status` VARCHAR(50))   BEGIN
    INSERT INTO jobseeker (
        jobseeker_ID,
        jobseeker_name,
        jobseeker_phone,
        jobseeker_email_address,
        jobseeker_username,
        jobseeker_password,
        jobseeker_address,
        jobseeker_resume,
        jobseeker_disability,
        jobseeker_reference,
        application_date,
        status
    ) VALUES (
        p_jobseeker_ID,
        p_jobseeker_name,
        p_jobseeker_phone,
        p_jobseeker_email_address,
        p_jobseeker_username,
        p_jobseeker_password,
        p_jobseeker_address,
        p_jobseeker_resume,
        p_jobseeker_disability,
        p_jobseeker_reference,
        p_application_date,
        p_status
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertRecruiter` (IN `p_recruiter_id` INT, IN `p_recruiter_name` VARCHAR(50), IN `p_company_type` VARCHAR(100), IN `p_recruiter_address` VARCHAR(50), IN `p_recruiter_email` VARCHAR(50), IN `p_recruiter_description` VARCHAR(50), IN `p_recruiter_phone` VARCHAR(40), IN `p_industry` VARCHAR(50))   BEGIN
    INSERT INTO recruiter (
        recruiter_id,
        recruiter_name,
        company_type,
        recruiter_address,
        recruiter_email,
        recruiter_description,
        recruiter_phone,
        industry
    ) VALUES (
        p_recruiter_id,
        p_recruiter_name,
        p_company_type,
        p_recruiter_address,
        p_recruiter_email,
        p_recruiter_description,
        p_recruiter_phone,
        p_industry
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `JobseekerWithSubquery` ()   BEGIN
    SELECT j.*, r.recruiter_name
    FROM jobseeker j
    LEFT JOIN (
        SELECT jobseeker_id, MAX(application_date) AS latest_application_date
        FROM application
        GROUP BY jobseeker_id
    ) AS subq ON j.jobseeker_id = subq.jobseeker_id
    LEFT JOIN application a ON j.jobseeker_id = a.jobseeker_id AND subq.latest_application_date = a.application_date
    LEFT JOIN jobseeker_reference r ON j.jobseeker_reference = r.reference_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateJobseekerInformation` (IN `p_jobseeker_id` INT, IN `p_new_name` VARCHAR(30), IN `p_new_phone` VARCHAR(40), IN `p_new_email_address` VARCHAR(50), IN `p_new_username` VARCHAR(60), IN `p_new_password` VARCHAR(20), IN `p_new_address` VARCHAR(40), IN `p_new_resume` VARCHAR(40), IN `p_new_disability` VARCHAR(50), IN `p_new_reference` VARCHAR(40), IN `p_new_application_date` VARCHAR(50), IN `p_new_status` VARCHAR(50))   BEGIN
    UPDATE jobseeker
    SET
        jobseeker_name = p_new_name,
        jobseeker_phone = p_new_phone,
        jobseeker_email_address = p_new_email_address,
        jobseeker_username = p_new_username,
        jobseeker_password = p_new_password,
        jobseeker_address = p_new_address,
        jobseeker_resume = p_new_resume,
        jobseeker_disability = p_new_disability,
        jobseeker_reference = p_new_reference,
        application_date = p_new_application_date,
        status = p_new_status
    WHERE jobseeker_ID = p_jobseeker_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_application`
-- (See below for the actual view)
--
CREATE TABLE `all_application` (
`application_id` int(11)
,`jobseeker_id` int(11)
,`job_name` varchar(40)
,`application_date` date
,`status` varchar(40)
,`institution` varchar(40)
,`action` varchar(40)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_interview`
-- (See below for the actual view)
--
CREATE TABLE `all_interview` (
`interview_id` int(11)
,`job_id` int(11)
,`jobseeker_id` int(11)
,`interviewer_id` int(11)
,`date` date
,`time` int(11)
,`location` varchar(50)
,`interview_type` varchar(50)
,`interview_name` varchar(40)
,`interview_feedback` varchar(40)
,`interview_status` varchar(40)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_jobs`
-- (See below for the actual view)
--
CREATE TABLE `all_jobs` (
`job_id` int(11)
,`job_description` varchar(50)
,`job_name` varchar(40)
,`job_location` varchar(40)
,`job_salary` varchar(50)
,`posting_date` varchar(40)
,`application_deadline` varchar(40)
,`employment_type` varchar(50)
,`job_requirements` varchar(40)
,`department` varchar(40)
,`status` varchar(40)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_jobseekers`
-- (See below for the actual view)
--
CREATE TABLE `all_jobseekers` (
`jobseeker_id` int(11)
,`jobseeker_name` varchar(30)
,`jobseeker_phone` varchar(40)
,`jobseeker_email_address` varchar(50)
,`jobseeker_username` varchar(60)
,`jobseeker_password` varchar(20)
,`jobseeker_address` varchar(40)
,`jobseeker_resume` varchar(40)
,`jobseeker_disability` varchar(50)
,`jobseeker_reference` varchar(40)
,`application_date` varchar(50)
,`status` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_offer`
-- (See below for the actual view)
--
CREATE TABLE `all_offer` (
`offer_id` int(11)
,`job_id` int(11)
,`jobseeker_id` int(11)
,`salary` int(11)
,`benefit` varchar(50)
,`start_date` date
,`end_date` date
,`offer_status` varchar(50)
,`reason_for_status` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_placement`
-- (See below for the actual view)
--
CREATE TABLE `all_placement` (
`placement_id` int(11)
,`job_id` int(11)
,`jobseeker_id` int(11)
,`start_date` date
,`end_date` date
,`job_name` varchar(50)
,`company_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_recruiters`
-- (See below for the actual view)
--
CREATE TABLE `all_recruiters` (
`recruiter_id` int(11)
,`recruiter_name` varchar(50)
,`company_type` varchar(100)
,`recruiter_address` varchar(50)
,`recruiter_email` varchar(50)
,`recruiter_description` varchar(50)
,`recruiter_phone` varchar(40)
,`industry` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_resume`
-- (See below for the actual view)
--
CREATE TABLE `all_resume` (
`jobseeker_id` int(11)
,`education` varchar(40)
,`skills` varchar(40)
,`work_experiance` int(11)
,`languages` varchar(40)
,`jobseeker_address` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `application_id` int(11) NOT NULL,
  `jobseeker_id` int(11) DEFAULT NULL,
  `job_name` varchar(40) DEFAULT NULL,
  `application_date` date DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `institution` varchar(40) DEFAULT NULL,
  `action` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`application_id`, `jobseeker_id`, `job_name`, `application_date`, `status`, `institution`, `action`) VALUES
(1, 1, 'manager', '0000-00-00', 'application_received', 'gicumbi_district', 'hide');

--
-- Triggers `application`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteApplication` AFTER DELETE ON `application` FOR EACH ROW BEGIN    
    INSERT INTO application_delete_log (application_id, deletion_date)
    VALUES (OLD.application_id, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_info`
-- (See below for the actual view)
--
CREATE TABLE `delete_info` (
`placement_id` int(11)
,`job_id` int(11)
,`jobseeker_id` varchar(40)
,`start_date` varchar(40)
,`end_date` varchar(11)
,`job_name` varchar(50)
,`company_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_application_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_application_data` (
`application_id` varchar(1)
,`jobseeker_id` varchar(3)
,`job_name` varchar(10)
,`application_date` varchar(10)
,`status` varchar(20)
,`institution` varchar(9)
,`action` varchar(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_interview_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_interview_data` (
`interview_id` varchar(1)
,`job_id` varchar(1)
,`jobseeker_id` varchar(1)
,`interviewer_id` varchar(1)
,`date` varchar(10)
,`time` varchar(5)
,`location` varchar(13)
,`interview_type` varchar(5)
,`interviewer_name` varchar(9)
,`interview_feedback` varchar(4)
,`interview_status` varchar(9)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_jobseeker_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_jobseeker_data` (
`jobseeker_id` varchar(3)
,`jobseeker_name` varchar(10)
,`jobseeker_phone` varchar(10)
,`jobseeker_email_address` varchar(20)
,`jobseeker_username` varchar(20)
,`jobseeker_password` varchar(13)
,`jobseeker_address` varchar(7)
,`jobseeker_resume` varchar(2)
,`jobseeker_disability` varchar(4)
,`reference` varchar(18)
,`application_date` varchar(10)
,`status` varchar(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_job_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_job_data` (
`job_id` varchar(1)
,`recruiter_id` varchar(1)
,`job_name` varchar(17)
,`location` varchar(13)
,`job_salary` varchar(6)
,`posting_date` varchar(10)
,`application_deadline` varchar(10)
,`employment_type` varchar(9)
,`job_requirement` varchar(16)
,`department` varchar(22)
,`status` varchar(4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_offer_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_offer_data` (
`offer_id` varchar(3)
,`job_id` varchar(3)
,`jobseeker_id` varchar(3)
,`salary` varchar(6)
,`benefit` varchar(11)
,`start_date` varchar(10)
,`end_date` varchar(10)
,`offer_status` varchar(8)
,`reason_for_status` varchar(9)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_placement_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_placement_data` (
`placement_id` varchar(3)
,`job_id` varchar(2)
,`jobseeker_id` varchar(3)
,`start_date` varchar(10)
,`end_date` varchar(10)
,`job_name` varchar(4)
,`company_name` varchar(16)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_recruiter_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_recruiter_data` (
`RECRUITER_ID` varchar(2)
,`RECRUITER_NAME` varchar(7)
,`COMPANY_TYPE` varchar(7)
,`RECRUITER_ADDRESS` varchar(10)
,`RECRUITER_EMAIL` varchar(17)
,`RECRUITER_DESCRIPTION` varchar(55)
,`RECRUITER_PHONE` varchar(10)
,`INDUSTRY` varchar(8)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_resume_data`
-- (See below for the actual view)
--
CREATE TABLE `insert_resume_data` (
`Resume_id` varchar(3)
,`jobseeker_id` varchar(3)
,`education` varchar(15)
,`skills` varchar(43)
,`work_experiance` varchar(19)
,`languages` varchar(37)
,`jobseeker_address` varchar(13)
);

-- --------------------------------------------------------

--
-- Table structure for table `interview`
--

CREATE TABLE `interview` (
  `interview_id` int(11) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `jobseeker_id` int(11) DEFAULT NULL,
  `interviewer_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `interview_type` varchar(50) DEFAULT NULL,
  `interview_name` varchar(40) DEFAULT NULL,
  `interview_feedback` varchar(40) DEFAULT NULL,
  `interview_status` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `interview`
--

INSERT INTO `interview` (`interview_id`, `job_id`, `jobseeker_id`, `interviewer_id`, `date`, `time`, `location`, `interview_type`, `interview_name`, `interview_feedback`, `interview_status`) VALUES
(1, 1, 1, 1, '0000-00-00', 4, 'huye_ngoma', 'phone', 'simon', 'pass', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `job_id` int(11) NOT NULL,
  `recruiter_id` int(11) DEFAULT NULL,
  `job_description` varchar(50) DEFAULT NULL,
  `job_name` varchar(40) DEFAULT NULL,
  `job_location` varchar(40) DEFAULT NULL,
  `job_salary` varchar(50) DEFAULT NULL,
  `posting_date` varchar(40) DEFAULT NULL,
  `application_deadline` varchar(40) DEFAULT NULL,
  `employment_type` varchar(50) DEFAULT NULL,
  `job_requirements` varchar(40) DEFAULT NULL,
  `department` varchar(40) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`job_id`, `recruiter_id`, `job_description`, `job_name`, `job_location`, `job_salary`, `posting_date`, `application_deadline`, `employment_type`, `job_requirements`, `department`, `status`) VALUES
(1, 1, 'prepare of salary of workers', 'financial manager', 'kigali_gasabo', '300000', '20_09_2023', '29_09_2023', 'full_time', 'bachlors in financial accounting', 'management', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `jobseeker`
--

CREATE TABLE `jobseeker` (
  `jobseeker_name` varchar(30) DEFAULT NULL,
  `jobseeker_phone` varchar(40) DEFAULT NULL,
  `jobseeker_email_address` varchar(50) DEFAULT NULL,
  `jobseeker_ID` int(11) NOT NULL,
  `jobseeker_username` varchar(60) DEFAULT NULL,
  `jobseeker_password` varchar(20) DEFAULT NULL,
  `jobseeker_address` varchar(40) DEFAULT NULL,
  `jobseeker_resume` varchar(40) DEFAULT NULL,
  `jobseeker_disability` varchar(50) DEFAULT NULL,
  `jobseeker_reference` varchar(40) DEFAULT NULL,
  `application_date` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobseeker`
--

INSERT INTO `jobseeker` (`jobseeker_name`, `jobseeker_phone`, `jobseeker_email_address`, `jobseeker_ID`, `jobseeker_username`, `jobseeker_password`, `jobseeker_address`, `jobseeker_resume`, `jobseeker_disability`, `jobseeker_reference`, `application_date`, `status`) VALUES
('muvunyi', '0737352709', 'muvunyi@gmail.com', 1, 'muvunyi', 'muvunyi12@', 'kigali_gasabo', 'CV', 'none', 'ishimwe_0787878932', '20_09_2023', 'shortlisted');

--
-- Triggers `jobseeker`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteJobseeker` AFTER DELETE ON `jobseeker` FOR EACH ROW BEGIN    
    INSERT INTO jobseeker_delete_log (jobseeker_id, deletion_date)
    VALUES (OLD.jobseeker_id, NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertJobseeker` AFTER INSERT ON `jobseeker` FOR EACH ROW BEGIN    
    INSERT INTO jobseeker_insert_log (jobseeker_id, insertion_date)
    VALUES (NEW.jobseeker_id, NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateJobseeker` AFTER UPDATE ON `jobseeker` FOR EACH ROW BEGIN    
    INSERT INTO jobseeker_update_log (jobseeker_id, update_date)
    VALUES (NEW.jobseeker_id, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `jobseeker_with_max_offer`
-- (See below for the actual view)
--
CREATE TABLE `jobseeker_with_max_offer` (
`jobseeker_id` int(11)
,`jobseeker_name` varchar(30)
,`jobseeker_email_address` varchar(50)
,`jobseeker_phone` varchar(40)
,`max_offer_salary` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `offer`
--

CREATE TABLE `offer` (
  `offer_id` int(11) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `jobseeker_id` int(11) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  `benefit` varchar(50) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `Offer_Status` varchar(50) DEFAULT NULL,
  `reason_for_status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `offer`
--

INSERT INTO `offer` (`offer_id`, `job_id`, `jobseeker_id`, `salary`, `benefit`, `start_date`, `end_date`, `Offer_Status`, `reason_for_status`) VALUES
(1, 1, 1, 300000, 'get experience', '0000-00-00', '0000-00-00', 'accepted', 'do not delay');

-- --------------------------------------------------------

--
-- Table structure for table `placement`
--

CREATE TABLE `placement` (
  `placement_id` int(11) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `jobseeker_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `job_name` varchar(50) DEFAULT NULL,
  `company_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `placement`
--

INSERT INTO `placement` (`placement_id`, `job_id`, `jobseeker_id`, `start_date`, `end_date`, `job_name`, `company_name`) VALUES
(1, 1, 1, '0000-00-00', '0000-00-00', 'data manager', 'REG');

-- --------------------------------------------------------

--
-- Table structure for table `recruiter`
--

CREATE TABLE `recruiter` (
  `recruiter_id` int(11) NOT NULL,
  `recruiter_name` varchar(50) DEFAULT NULL,
  `company_type` varchar(100) DEFAULT NULL,
  `recruiter_address` varchar(50) DEFAULT NULL,
  `recruiter_email` varchar(50) DEFAULT NULL,
  `recruiter_description` varchar(50) DEFAULT NULL,
  `recruiter_phone` varchar(40) DEFAULT NULL,
  `industry` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recruiter`
--

INSERT INTO `recruiter` (`recruiter_id`, `recruiter_name`, `company_type`, `recruiter_address`, `recruiter_email`, `recruiter_description`, `recruiter_phone`, `industry`) VALUES
(1, 'ishimwe emmanuel', 'private', 'Byumba_Gicumbi', 'gicumbi@gmail.com', 'prepare salary of workers', '0737352709', 'gicumbi');

--
-- Triggers `recruiter`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertRecruiter` AFTER INSERT ON `recruiter` FOR EACH ROW BEGIN
    
    INSERT INTO recruiter_insert_log (recruiter_id, insertion_date)
    VALUES (NEW.recruiter_id, NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateRecruiter` AFTER UPDATE ON `recruiter` FOR EACH ROW BEGIN    
    INSERT INTO recruiter_update_log (recruiter_id, update_date)
    VALUES (NEW.recruiter_id, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `resume`
--

CREATE TABLE `resume` (
  `Resume_id` int(11) NOT NULL,
  `jobseeker_id` int(11) DEFAULT NULL,
  `education` varchar(40) DEFAULT NULL,
  `skills` varchar(40) DEFAULT NULL,
  `work_experiance` int(11) DEFAULT NULL,
  `languages` varchar(40) DEFAULT NULL,
  `jobseeker_address` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `resume`
--

INSERT INTO `resume` (`Resume_id`, `jobseeker_id`, `education`, `skills`, `work_experiance`, `languages`, `jobseeker_address`) VALUES
(1, 1, 'bachlors degree', 'I am experienced to information  technol', 5, 'kinyarwanda_english_french', 'kigali_gasabo');

-- --------------------------------------------------------

--
-- Stand-in structure for view `updateapplication`
-- (See below for the actual view)
--
CREATE TABLE `updateapplication` (
`Application_id` int(11)
,`jobseeker_id` int(11)
,`job_name` varchar(40)
,`application_date` date
,`status` varchar(40)
,`institution` varchar(40)
,`action` varchar(40)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_info`
-- (See below for the actual view)
--
CREATE TABLE `update_info` (
`recruiter_id` int(11)
,`recruiter_name` varchar(50)
,`company_type` varchar(100)
,`recruiter_address` varchar(50)
,`recruiter_email` varchar(50)
,`recruiter_description` varchar(50)
,`recruiter_phone` varchar(40)
,`industry` varchar(50)
);

-- --------------------------------------------------------

--
-- Structure for view `all_application`
--
DROP TABLE IF EXISTS `all_application`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_application`  AS SELECT `application`.`application_id` AS `application_id`, `application`.`jobseeker_id` AS `jobseeker_id`, `application`.`job_name` AS `job_name`, `application`.`application_date` AS `application_date`, `application`.`status` AS `status`, `application`.`institution` AS `institution`, `application`.`action` AS `action` FROM `application``application`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_interview`
--
DROP TABLE IF EXISTS `all_interview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_interview`  AS SELECT `interview`.`interview_id` AS `interview_id`, `interview`.`job_id` AS `job_id`, `interview`.`jobseeker_id` AS `jobseeker_id`, `interview`.`interviewer_id` AS `interviewer_id`, `interview`.`date` AS `date`, `interview`.`time` AS `time`, `interview`.`location` AS `location`, `interview`.`interview_type` AS `interview_type`, `interview`.`interview_name` AS `interview_name`, `interview`.`interview_feedback` AS `interview_feedback`, `interview`.`interview_status` AS `interview_status` FROM `interview``interview`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_jobs`
--
DROP TABLE IF EXISTS `all_jobs`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_jobs`  AS SELECT `job`.`job_id` AS `job_id`, `job`.`job_description` AS `job_description`, `job`.`job_name` AS `job_name`, `job`.`job_location` AS `job_location`, `job`.`job_salary` AS `job_salary`, `job`.`posting_date` AS `posting_date`, `job`.`application_deadline` AS `application_deadline`, `job`.`employment_type` AS `employment_type`, `job`.`job_requirements` AS `job_requirements`, `job`.`department` AS `department`, `job`.`status` AS `status` FROM `job``job`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_jobseekers`
--
DROP TABLE IF EXISTS `all_jobseekers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_jobseekers`  AS SELECT `jobseeker`.`jobseeker_ID` AS `jobseeker_id`, `jobseeker`.`jobseeker_name` AS `jobseeker_name`, `jobseeker`.`jobseeker_phone` AS `jobseeker_phone`, `jobseeker`.`jobseeker_email_address` AS `jobseeker_email_address`, `jobseeker`.`jobseeker_username` AS `jobseeker_username`, `jobseeker`.`jobseeker_password` AS `jobseeker_password`, `jobseeker`.`jobseeker_address` AS `jobseeker_address`, `jobseeker`.`jobseeker_resume` AS `jobseeker_resume`, `jobseeker`.`jobseeker_disability` AS `jobseeker_disability`, `jobseeker`.`jobseeker_reference` AS `jobseeker_reference`, `jobseeker`.`application_date` AS `application_date`, `jobseeker`.`status` AS `status` FROM `jobseeker``jobseeker`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_offer`
--
DROP TABLE IF EXISTS `all_offer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_offer`  AS SELECT `offer`.`offer_id` AS `offer_id`, `offer`.`job_id` AS `job_id`, `offer`.`jobseeker_id` AS `jobseeker_id`, `offer`.`salary` AS `salary`, `offer`.`benefit` AS `benefit`, `offer`.`start_date` AS `start_date`, `offer`.`end_date` AS `end_date`, `offer`.`Offer_Status` AS `offer_status`, `offer`.`reason_for_status` AS `reason_for_status` FROM `offer``offer`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_placement`
--
DROP TABLE IF EXISTS `all_placement`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_placement`  AS SELECT `placement`.`placement_id` AS `placement_id`, `placement`.`job_id` AS `job_id`, `placement`.`jobseeker_id` AS `jobseeker_id`, `placement`.`start_date` AS `start_date`, `placement`.`end_date` AS `end_date`, `placement`.`job_name` AS `job_name`, `placement`.`company_name` AS `company_name` FROM `placement``placement`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_recruiters`
--
DROP TABLE IF EXISTS `all_recruiters`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_recruiters`  AS SELECT `recruiter`.`recruiter_id` AS `recruiter_id`, `recruiter`.`recruiter_name` AS `recruiter_name`, `recruiter`.`company_type` AS `company_type`, `recruiter`.`recruiter_address` AS `recruiter_address`, `recruiter`.`recruiter_email` AS `recruiter_email`, `recruiter`.`recruiter_description` AS `recruiter_description`, `recruiter`.`recruiter_phone` AS `recruiter_phone`, `recruiter`.`industry` AS `industry` FROM `recruiter``recruiter`  ;

-- --------------------------------------------------------

--
-- Structure for view `all_resume`
--
DROP TABLE IF EXISTS `all_resume`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_resume`  AS SELECT `resume`.`jobseeker_id` AS `jobseeker_id`, `resume`.`education` AS `education`, `resume`.`skills` AS `skills`, `resume`.`work_experiance` AS `work_experiance`, `resume`.`languages` AS `languages`, `resume`.`jobseeker_address` AS `jobseeker_address` FROM `resume``resume`  ;

-- --------------------------------------------------------

--
-- Structure for view `delete_info`
--
DROP TABLE IF EXISTS `delete_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `delete_info`  AS SELECT `placement`.`placement_id` AS `placement_id`, `placement`.`job_id` AS `job_id`, `placement`.`jobseeker_id` AS `jobseeker_id`, `placement`.`start_date` AS `start_date`, `placement`.`end_date` AS `end_date`, `placement`.`job_name` AS `job_name`, `placement`.`company_name` AS `company_name` FROM `placement` union all select `resume`.`Resume_id` AS `Resume_id`,`resume`.`jobseeker_id` AS `jobseeker_id`,`resume`.`education` AS `education`,`resume`.`skills` AS `skills`,`resume`.`work_experiance` AS `work_experiance`,`resume`.`languages` AS `languages`,`resume`.`jobseeker_address` AS `jobseeker_address` from `resume`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_application_data`
--
DROP TABLE IF EXISTS `insert_application_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_application_data`  AS SELECT '1' AS `application_id`, '001' AS `jobseeker_id`, 'nzayisenga' AS `job_name`, '11_09_2023' AS `application_date`, 'application received' AS `status`, 'Bscholars' AS `institution`, 'hide' AS `action``action`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_interview_data`
--
DROP TABLE IF EXISTS `insert_interview_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_interview_data`  AS SELECT '1' AS `interview_id`, '2' AS `job_id`, '3' AS `jobseeker_id`, '4' AS `interviewer_id`, '11_09_2022' AS `date`, '10:20' AS `time`, 'kigali_gasabo' AS `location`, 'phone' AS `interview_type`, 'sekaganda' AS `interviewer_name`, 'pass' AS `interview_feedback`, 'completed' AS `interview_status``interview_status`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_jobseeker_data`
--
DROP TABLE IF EXISTS `insert_jobseeker_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_jobseeker_data`  AS SELECT '001' AS `jobseeker_id`, 'nzayisenga' AS `jobseeker_name`, '0737352709' AS `jobseeker_phone`, 'nzayisenga@gmail.com' AS `jobseeker_email_address`, 'nzayisenga@gmail.com' AS `jobseeker_username`, 'Nzayisenga12@' AS `jobseeker_password`, 'gicumbi' AS `jobseeker_address`, 'cv' AS `jobseeker_resume`, 'none' AS `jobseeker_disability`, 'viateur_0787878953' AS `reference`, '20_04_2023' AS `application_date`, 'shortlisted' AS `status``status`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_job_data`
--
DROP TABLE IF EXISTS `insert_job_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_job_data`  AS SELECT '1' AS `job_id`, '2' AS `recruiter_id`, 'software engineer' AS `job_name`, 'kigali_gasabo' AS `location`, '100000' AS `job_salary`, '11_09_2023' AS `posting_date`, '20_10_2023' AS `application_deadline`, 'full_time' AS `employment_type`, 'advanced diploma' AS `job_requirement`, 'information technology' AS `department`, 'open' AS `status``status`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_offer_data`
--
DROP TABLE IF EXISTS `insert_offer_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_offer_data`  AS SELECT '001' AS `offer_id`, '002' AS `job_id`, '003' AS `jobseeker_id`, '300000' AS `salary`, 'better life' AS `benefit`, '20_08_2023' AS `start_date`, '29_09_2023' AS `end_date`, 'accepted' AS `offer_status`, 'pass exam' AS `reason_for_status``reason_for_status`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_placement_data`
--
DROP TABLE IF EXISTS `insert_placement_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_placement_data`  AS SELECT '001' AS `placement_id`, '01' AS `job_id`, '003' AS `jobseeker_id`, '11_09_2023' AS `start_date`, '20_11_2023' AS `end_date`, 'SEDO' AS `job_name`, 'muhanga_district' AS `company_name``company_name`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_recruiter_data`
--
DROP TABLE IF EXISTS `insert_recruiter_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_recruiter_data`  AS SELECT '01' AS `RECRUITER_ID`, 'JOHNSON' AS `RECRUITER_NAME`, 'PRIVATE' AS `COMPANY_TYPE`, 'HUYE_TUMBA' AS `RECRUITER_ADDRESS`, 'johnson@gmail.com' AS `RECRUITER_EMAIL`, 'We are looking for a Software Engineer to join our team' AS `RECRUITER_DESCRIPTION`, '0784481596' AS `RECRUITER_PHONE`, 'CIMWERWA' AS `INDUSTRY``INDUSTRY`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_resume_data`
--
DROP TABLE IF EXISTS `insert_resume_data`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_resume_data`  AS SELECT '003' AS `Resume_id`, '002' AS `jobseeker_id`, 'bachlors degree' AS `education`, 'iI am experienced about application process' AS `skills`, '+5 years experiance' AS `work_experiance`, 'kinyarwanda_english_french_protuguese' AS `languages`, 'kigali_gasabo' AS `jobseeker_address``jobseeker_address`  ;

-- --------------------------------------------------------

--
-- Structure for view `jobseeker_with_max_offer`
--
DROP TABLE IF EXISTS `jobseeker_with_max_offer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `jobseeker_with_max_offer`  AS SELECT `j`.`jobseeker_ID` AS `jobseeker_id`, `j`.`jobseeker_name` AS `jobseeker_name`, `j`.`jobseeker_email_address` AS `jobseeker_email_address`, `j`.`jobseeker_phone` AS `jobseeker_phone`, `o`.`salary` AS `max_offer_salary` FROM (`jobseeker` `j` left join (select `offer`.`jobseeker_id` AS `jobseeker_id`,max(`offer`.`salary`) AS `salary` from `offer` group by `offer`.`jobseeker_id`) `o` on(`j`.`jobseeker_ID` = `o`.`jobseeker_id`))  ;

-- --------------------------------------------------------

--
-- Structure for view `updateapplication`
--
DROP TABLE IF EXISTS `updateapplication`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updateapplication`  AS SELECT `application`.`application_id` AS `Application_id`, `application`.`jobseeker_id` AS `jobseeker_id`, `application`.`job_name` AS `job_name`, `application`.`application_date` AS `application_date`, `application`.`status` AS `status`, `application`.`institution` AS `institution`, `application`.`action` AS `action` FROM `application``application`  ;

-- --------------------------------------------------------

--
-- Structure for view `update_info`
--
DROP TABLE IF EXISTS `update_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_info`  AS SELECT `recruiter`.`recruiter_id` AS `recruiter_id`, `recruiter`.`recruiter_name` AS `recruiter_name`, `recruiter`.`company_type` AS `company_type`, `recruiter`.`recruiter_address` AS `recruiter_address`, `recruiter`.`recruiter_email` AS `recruiter_email`, `recruiter`.`recruiter_description` AS `recruiter_description`, `recruiter`.`recruiter_phone` AS `recruiter_phone`, `recruiter`.`industry` AS `industry` FROM `recruiter``recruiter`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`application_id`),
  ADD KEY `jobseeker_id` (`jobseeker_id`);

--
-- Indexes for table `interview`
--
ALTER TABLE `interview`
  ADD PRIMARY KEY (`interview_id`),
  ADD KEY `job_id` (`job_id`),
  ADD KEY `jobseeker_id` (`jobseeker_id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`job_id`),
  ADD KEY `recruiter_id` (`recruiter_id`);

--
-- Indexes for table `jobseeker`
--
ALTER TABLE `jobseeker`
  ADD PRIMARY KEY (`jobseeker_ID`);

--
-- Indexes for table `offer`
--
ALTER TABLE `offer`
  ADD PRIMARY KEY (`offer_id`),
  ADD KEY `job_id` (`job_id`),
  ADD KEY `jobseeker_id` (`jobseeker_id`);

--
-- Indexes for table `placement`
--
ALTER TABLE `placement`
  ADD PRIMARY KEY (`placement_id`),
  ADD KEY `job_id` (`job_id`),
  ADD KEY `jobseeker_id` (`jobseeker_id`);

--
-- Indexes for table `recruiter`
--
ALTER TABLE `recruiter`
  ADD PRIMARY KEY (`recruiter_id`);

--
-- Indexes for table `resume`
--
ALTER TABLE `resume`
  ADD PRIMARY KEY (`Resume_id`),
  ADD KEY `jobseeker_id` (`jobseeker_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `application`
--
ALTER TABLE `application`
  ADD CONSTRAINT `application_ibfk_1` FOREIGN KEY (`jobseeker_id`) REFERENCES `jobseeker` (`jobseeker_ID`);

--
-- Constraints for table `interview`
--
ALTER TABLE `interview`
  ADD CONSTRAINT `interview_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`),
  ADD CONSTRAINT `interview_ibfk_2` FOREIGN KEY (`jobseeker_id`) REFERENCES `jobseeker` (`jobseeker_ID`);

--
-- Constraints for table `job`
--
ALTER TABLE `job`
  ADD CONSTRAINT `job_ibfk_1` FOREIGN KEY (`recruiter_id`) REFERENCES `recruiter` (`recruiter_id`);

--
-- Constraints for table `offer`
--
ALTER TABLE `offer`
  ADD CONSTRAINT `offer_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`),
  ADD CONSTRAINT `offer_ibfk_2` FOREIGN KEY (`jobseeker_id`) REFERENCES `jobseeker` (`jobseeker_ID`);

--
-- Constraints for table `placement`
--
ALTER TABLE `placement`
  ADD CONSTRAINT `placement_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`),
  ADD CONSTRAINT `placement_ibfk_2` FOREIGN KEY (`jobseeker_id`) REFERENCES `jobseeker` (`jobseeker_ID`);

--
-- Constraints for table `resume`
--
ALTER TABLE `resume`
  ADD CONSTRAINT `resume_ibfk_1` FOREIGN KEY (`jobseeker_id`) REFERENCES `jobseeker` (`jobseeker_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
