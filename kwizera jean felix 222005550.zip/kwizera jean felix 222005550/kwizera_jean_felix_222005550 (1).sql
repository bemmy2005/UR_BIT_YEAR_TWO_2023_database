-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2023 at 08:22 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kwizera_jean_felix_222005550`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculateAverageFuelQuantity` (IN `p_fuel_type` VARCHAR(50), OUT `p_average_quantity` DECIMAL(10,2))   BEGIN
    SELECT AVG(subquery.quantity) INTO p_average_quantity
    FROM (
        SELECT t.quantity
        FROM ORDERS o
        JOIN transaction t ON o.order_id = t.order_id
        WHERE o.fuel_type = p_fuel_type
    ) AS subquery;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteInactiveCustomerAndORDERS` ()   BEGIN
    DELETE FROM customer
    WHERE DATEDIFF(NOW(),quentity) > 30000;
     DELETE FROM orders
    WHERE customer_id NOT IN (SELECT customer_id FROM ORDERS WHERE DATEDIFF(NOW(), order_quentity) <= 30000);
    
    SELECT 'Inactive users and customers deleted successfully.' AS message;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteInactiveUsersAndCustomers` ()   BEGIN
    DELETE FROM user
    WHERE DATEDIFF(NOW(), last_login_date) > 365;
     DELETE FROM customer
    WHERE customer_id NOT IN (SELECT customer_id FROM ORDERS WHERE DATEDIFF(NOW(), order_date) <= 365);
    
    SELECT 'Inactive users and customers deleted successfully.' AS message;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllData` ()   BEGIN
    SELECT * FROM user;
SELECT * FROM bank;
    SELECT * FROM customer;
    SELECT * FROM driver;
    SELECT * FROM fuel_admin;
    SELECT * FROM fuel_deliveryorders;
    SELECT * FROM fuel_deliveryrecord;
    SELECT * FROM fuel_station;
   SELECT * FROM fuel_suppler;
    SELECT * FROM fuel_type;
   SELECT * FROM order_assignment;
    SELECT * FROM order_history;
   SELECT * FROM ORDERS;
   SELECT * FROM transaction;
   SELECT * FROM vehicle;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertBank` (IN `p_name` VARCHAR(10), IN `p_address` VARCHAR(40), IN `p_account_number` INT, IN `p_phone_number` VARCHAR(10), IN `p_routing_number` INT)   BEGIN
    INSERT INTO bank (name, address, account_number, phone_number, routing_number)
    VALUES (p_name, p_address, p_account_number, p_phone_number, p_routing_number);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertCustomer` (IN `p_first_name` VARCHAR(25), IN `p_last_name` VARCHAR(50), IN `p_email` VARCHAR(100), IN `p_phone` VARCHAR(10), IN `p_address` VARCHAR(50), IN `p_payment_method` VARCHAR(10))   BEGIN
    INSERT INTO customer (first_name, last_name, emai, phone, address, payment_method)
    VALUES (p_first_name, p_last_name, p_email, p_phone, p_address, p_payment_method);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertDriver` (IN `p_first_name` VARCHAR(50), IN `p_last_name` VARCHAR(40), IN `p_phone` VARCHAR(10), IN `p_licence_number` VARCHAR(20), IN `p_vehicle_id` INT)   BEGIN
    INSERT INTO driver (first_name, last_name, phone, licence_number, vehicle_id)
    VALUES (p_first_name, p_last_name, p_phone, p_licence_number, p_vehicle_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertFuelAdmin` (IN `p_email` VARCHAR(50), IN `p_password` VARCHAR(50), IN `p_first_name` VARCHAR(50), IN `p_last_name` VARCHAR(50), IN `p_phone_number` VARCHAR(100), IN `p_permissions` VARCHAR(8))   BEGIN
    INSERT INTO fuel_admin (Email, Password, first_name, last_name, phone_number, permissions)
    VALUES (p_email, p_password, p_first_name, p_last_name, p_phone_number, p_permissions);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertFuelDeliveryOrder` (IN `p_fuelsup_id` INT, IN `p_order_id` INT, IN `p_date_delivered` DATE)   BEGIN
    INSERT INTO fuel_deliveryorders (fuelsup_id, order_id, date_delivered)
    VALUES (p_fuelsup_id, p_order_id, p_date_delivered);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertFuelDeliveryRecord` (IN `p_order_id` INT, IN `p_driver_id` INT, IN `p_fuelsta_id` INT, IN `p_quantity` INT, IN `p_date_delivered` DATE)   BEGIN
    INSERT INTO fuel_deliveryrecord (order_id, driver, fuelsta_id, quantity, date_delivered)
    VALUES (p_order_id, p_driver_id, p_fuelsta_id, p_quantity, p_date_delivered);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertFuelStation` (IN `p_name` VARCHAR(50), IN `p_address` VARCHAR(30), IN `p_phone` VARCHAR(10), IN `p_fuel_type` VARCHAR(20))   BEGIN
    INSERT INTO fuel_station (name, address, phone, fuel_type)
    VALUES (p_name, p_address, p_phone, p_fuel_type);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertFuelSuppler` (IN `p_first_name` VARCHAR(50), IN `p_last_name` VARCHAR(50), IN `p_email` VARCHAR(40), IN `p_address` VARCHAR(40), IN `p_phone_number` VARCHAR(10))   BEGIN
    INSERT INTO fuel_suppler (first_name, last_name, email, address, phone_number)
    VALUES (p_first_name, p_last_name, p_email, p_address, p_phone_number);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertFuelType` (IN `p_name` VARCHAR(30), IN `p_price` INT)   BEGIN
    INSERT INTO fuel_type (name, price)
    VALUES (p_name, p_price);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertOrder` (IN `p_customer_id` INT, IN `p_driver_id` INT, IN `p_fuelsta_id` INT, IN `p_fuel_type` VARCHAR(50), IN `p_quentity` INT, IN `p_total_price` INT)   BEGIN
    INSERT INTO ORDERS (customer_id, driver_id, fuelsta_id, fuel_type, quentity, total_price)
    VALUES (p_customer_id, p_driver_id, p_fuelsta_id, p_fuel_type, p_quantity, p_total_price);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertOrderAssignment` (IN `p_order_id` INT, IN `p_driver_id` INT)   BEGIN
    INSERT INTO order_assignment (order_id, driver_id)
    VALUES (p_order_id, p_driver_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertOrderHistory` (IN `p_customer_id` INT, IN `p_order_id` INT)   BEGIN
    INSERT INTO order_history (customer_id, order_id)
    VALUES (p_customer_id, p_order_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertUser` (IN `p_first_name` VARCHAR(25), IN `p_last_name` VARCHAR(20), IN `p_phone_number` INT, IN `p_email` VARCHAR(67), IN `p_role` VARCHAR(80))   BEGIN
    INSERT INTO user (first_name, last_name, phone_number, email, role)
    VALUES (p_first_name, p_last_name, p_phone_number, p_email, p_role);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertVehicle` (IN `p_vehicle_name` VARCHAR(20), IN `p_prake_name` VARCHAR(15))   BEGIN
    INSERT INTO vehicle (vehicle_name, prake_name)
    VALUES (p_vehicle_name, p_prake_name);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateCustomerInfo` (IN `p_customer_id` INT, IN `p_new_first_name` VARCHAR(25), IN `p_new_last_name` VARCHAR(50), IN `p_new_email` VARCHAR(100), IN `p_new_phone` VARCHAR(10), IN `p_new_address` VARCHAR(50), IN `p_new_payment_method` VARCHAR(10))   BEGIN
     IF (SELECT COUNT(*) FROM customer WHERE customer_id = p_customer_id) > 0 THEN
        UPDATE customer
        SET
            first_name = p_new_first_name,
            last_name = p_new_last_name,
            emai = p_new_email,
            phone = p_new_phone,
            address = p_new_address,
            payment_method = p_new_payment_method
        WHERE customer_id = p_customer_id;
        
        SELECT 'Customer information updated successfully.' AS message;
    ELSE
        SELECT 'Customer not found. No updates performed.' AS message;
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateUserInfo` (IN `p_user_id` INT, IN `p_new_first_name` VARCHAR(25), IN `p_new_last_name` VARCHAR(20), IN `p_new_phone_number` INT, IN `p_new_email` VARCHAR(67), IN `p_new_role` VARCHAR(80))   BEGIN
    IF (SELECT COUNT(*) FROM user WHERE user_id = p_user_id) > 0 THEN
        
        UPDATE user
        SET
            first_name = p_new_first_name,
            last_name = p_new_last_name,
            phone_number = p_new_phone_number,
            email = p_new_email,
            role = p_new_role
        WHERE user_id = p_user_id;
        
        SELECT 'User information updated successfully.' AS message;
    ELSE
        SELECT 'User not found. No updates performed.' AS message;
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_data_view`
-- (See below for the actual view)
--
CREATE TABLE `all_data_view` (
`source_table` varchar(19)
,`user_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`phone_number` varchar(100)
,`email` varchar(100)
,`role` varchar(80)
,`NULL` varchar(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `bank_id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `address` varchar(40) NOT NULL,
  `account_number` int(11) NOT NULL,
  `phone_number` varchar(10) DEFAULT NULL,
  `routing_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `name`, `address`, `account_number`, `phone_number`, `routing_number`) VALUES
(1, 'zigama ban', '250KGL', 2147483647, '8765432109', 987654),
(2, 'Bank of ki', '250KGL', 2147483647, '0785432109', 407654),
(3, 'equity ban', '250KGL', 1334567890, '0725432109', 907654);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `emai` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `payment_method` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `last_name`, `first_name`, `emai`, `phone`, `address`, `payment_method`) VALUES
(1, 'eto', 'Jane', 'jane.eto@gmail.com', '0786543210', '123 Main St', 'Credit Car'),
(2, 'Smith', 'Jane', 'jane.smith@gmail.com', '0786543210', '123 Main St', 'momo pay'),
(3, 'Niyonshuti', 'Jean Pierre', 'jeanpierreniyonshuti71@gmail.com', '0786543210', '250 R/KGL', 'mobile mon');

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `AfterCustomerDelete` AFTER DELETE ON `customer` FOR EACH ROW BEGIN
    INSERT INTO customer_log (customer_id, action, timestamp)
    VALUES (OLD.customer_id, 'DELETE', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterCustomerInsert` AFTER INSERT ON `customer` FOR EACH ROW BEGIN
    INSERT INTO customer_log (customer_id, action, timestamp)
    VALUES (NEW.customer_id, 'INSERT', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterCustomerUpdate` AFTER UPDATE ON `customer` FOR EACH ROW BEGIN
    INSERT INTO customer_log (customer_id, action, timestamp)
    VALUES (NEW.customer_id, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer_to_delete`
-- (See below for the actual view)
--
CREATE TABLE `customer_to_delete` (
`customer_id` int(11)
,`last_name` varchar(50)
,`first_name` varchar(25)
,`emai` varchar(100)
,`Address` varchar(50)
,`Phone` varchar(10)
,`payment_method` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer_to_deletes`
-- (See below for the actual view)
--
CREATE TABLE `customer_to_deletes` (
`customer_id` int(11)
,`last_name` varchar(50)
,`first_name` varchar(25)
,`emai` varchar(100)
,`Address` varchar(50)
,`Phone` varchar(10)
,`payment_method` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `driver_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `licence_number` varchar(20) NOT NULL,
  `vehicle_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`driver_id`, `first_name`, `last_name`, `phone`, `licence_number`, `vehicle_id`) VALUES
(1, 'alice', 'tumukunde', '0785432199', 'DL123456', 1),
(2, 'Michael', 'IRAKOZE', '0795432109', 'DL199456', 2),
(3, 'Pierre', 'RUKARA', '0735432109', 'DL188456', 3);

--
-- Triggers `driver`
--
DELIMITER $$
CREATE TRIGGER `AfterDriverUpdate` AFTER UPDATE ON `driver` FOR EACH ROW BEGIN
    INSERT INTO driver_log (driver_id, action, timestamp)
    VALUES (NEW.driver_id, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `fuel_admin`
--

CREATE TABLE `fuel_admin` (
  `adm_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `phon_number` varchar(10) NOT NULL,
  `permissions` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fuel_admin`
--

INSERT INTO `fuel_admin` (`adm_id`, `email`, `Password`, `first_name`, `last_name`, `phon_number`, `permissions`) VALUES
(1, 'felix@gmail.com', '222005550', 'felix', 'kwizera', '0786543210', 'ALL'),
(2, 'luka@gmail.com', '222000745', 'kiza', 'alex', '0726543210', 'ALL'),
(3, 'admin@gmail.com', '33333000', 'odeta', 'akaliza', '0796543210', 'ALL');

-- --------------------------------------------------------

--
-- Table structure for table `fuel_deliveryorders`
--

CREATE TABLE `fuel_deliveryorders` (
  `fueldelorder_id` int(11) NOT NULL,
  `fuelsup_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `date_delivered` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fuel_deliveryorders`
--

INSERT INTO `fuel_deliveryorders` (`fueldelorder_id`, `fuelsup_id`, `order_id`, `date_delivered`) VALUES
(1, 1, 1, '2023-04-15'),
(2, 2, 3, '2023-08-31'),
(3, 3, 3, '2023-09-30');

-- --------------------------------------------------------

--
-- Table structure for table `fuel_deliveryrecord`
--

CREATE TABLE `fuel_deliveryrecord` (
  `fueldelrecord_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `fuelsta_id` int(11) DEFAULT NULL,
  `quentity` int(11) DEFAULT NULL,
  `date_delivered` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fuel_deliveryrecord`
--

INSERT INTO `fuel_deliveryrecord` (`fueldelrecord_id`, `order_id`, `driver_id`, `fuelsta_id`, `quentity`, `date_delivered`) VALUES
(1, 1, 1, 1, 50, '2023-08-31'),
(2, 2, 3, 1, 150, '2023-08-11'),
(3, 3, 1, 2, 250, '2023-08-22');

-- --------------------------------------------------------

--
-- Table structure for table `fuel_station`
--

CREATE TABLE `fuel_station` (
  `fuelsta_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(30) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `fuel_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fuel_station`
--

INSERT INTO `fuel_station` (`fuelsta_id`, `name`, `address`, `phone`, `fuel_type`) VALUES
(1, 'Fuel Station HUYE', '250 huye', '0783210987', 'gaz'),
(2, 'Fuel Station kigali', '250KGL', '0793210980', 'Gasoline'),
(3, 'Fuel Station RUBAVU', '250 RUB', '0723210987', 'OIL');

-- --------------------------------------------------------

--
-- Table structure for table `fuel_suppler`
--

CREATE TABLE `fuel_suppler` (
  `fuelsup_id` int(11) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `address` varchar(40) NOT NULL,
  `phone_number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fuel_suppler`
--

INSERT INTO `fuel_suppler` (`fuelsup_id`, `last_name`, `first_name`, `email`, `address`, `phone_number`) VALUES
(1, 'Williams', 'David', 'david@gmail.com', '250 Rd', '0724321098'),
(2, 'Williams', 'RITA', 'williams@gmail.com', '250 RD', '0794321098'),
(3, 'BRYAN', 'RUKUNDO', 'niyotwambaza@gmail.com', '250 RD', '0780321098');

-- --------------------------------------------------------

--
-- Table structure for table `fuel_type`
--

CREATE TABLE `fuel_type` (
  `fuel_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fuel_type`
--

INSERT INTO `fuel_type` (`fuel_id`, `name`, `price`) VALUES
(1, 'GENERAL Gasoline', 5000),
(2, 'Regular Gasoline', 3000),
(3, 'MEDIAN Gasoline', 2000);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_bankview`
-- (See below for the actual view)
--
CREATE TABLE `insert_bankview` (
`bank_id` int(11)
,`name` varchar(10)
,`address` varchar(40)
,`account_number` int(11)
,`phone_number` varchar(10)
,`routing_number` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_customerview`
-- (See below for the actual view)
--
CREATE TABLE `insert_customerview` (
`customer_id` int(11)
,`last_name` varchar(50)
,`first_name` varchar(25)
,`emai` varchar(100)
,`phone` varchar(10)
,`address` varchar(50)
,`payment_method` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_driverview`
-- (See below for the actual view)
--
CREATE TABLE `insert_driverview` (
`driver_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(40)
,`phone` varchar(10)
,`licence_number` varchar(20)
,`vehicle_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_fuel_adminview`
-- (See below for the actual view)
--
CREATE TABLE `insert_fuel_adminview` (
`adm_id` int(11)
,`email` varchar(50)
,`Password` varchar(50)
,`first_name` varchar(100)
,`last_name` varchar(100)
,`phon_number` varchar(10)
,`permissions` varchar(8)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_fuel_deliveryordersview`
-- (See below for the actual view)
--
CREATE TABLE `insert_fuel_deliveryordersview` (
`fueldelorder_id` int(11)
,`fuelsup_id` int(11)
,`order_id` int(11)
,`date_delivered` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_fuel_deliveryrecordview`
-- (See below for the actual view)
--
CREATE TABLE `insert_fuel_deliveryrecordview` (
`fueldelrecord_id` int(11)
,`order_id` int(11)
,`driver_id` int(11)
,`fuelsta_id` int(11)
,`quentity` int(11)
,`date_delivered` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_fuel_stationview`
-- (See below for the actual view)
--
CREATE TABLE `insert_fuel_stationview` (
`fuelsta_id` int(11)
,`name` varchar(50)
,`address` varchar(30)
,`phone` varchar(10)
,`fuel_type` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_fuel_supplerview`
-- (See below for the actual view)
--
CREATE TABLE `insert_fuel_supplerview` (
`fuelsup_id` int(11)
,`last_name` varchar(50)
,`first_name` varchar(50)
,`email` varchar(40)
,`address` varchar(40)
,`phone_number` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_fuel_typeview`
-- (See below for the actual view)
--
CREATE TABLE `insert_fuel_typeview` (
`fuel_id` int(11)
,`name` varchar(30)
,`price` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_ordersview`
-- (See below for the actual view)
--
CREATE TABLE `insert_ordersview` (
`order_id` int(11)
,`customer_id` int(11)
,`driver_id` int(11)
,`fuelsta_id` int(11)
,`fuel_type` varchar(50)
,`quentity` int(11)
,`total_price` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_order_assignmentview`
-- (See below for the actual view)
--
CREATE TABLE `insert_order_assignmentview` (
`orderass_id` int(11)
,`order_id` int(11)
,`driver_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_order_historyview`
-- (See below for the actual view)
--
CREATE TABLE `insert_order_historyview` (
`orderhis_id` int(11)
,`customer_id` int(11)
,`order_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_transactionview`
-- (See below for the actual view)
--
CREATE TABLE `insert_transactionview` (
`trans_id` int(11)
,`order_id` int(11)
,`driver_id` int(11)
,`fuelsta_id` int(11)
,`quentity` int(11)
,`date_delivered` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_userview`
-- (See below for the actual view)
--
CREATE TABLE `insert_userview` (
`user_id` int(11)
,`first_name` varchar(25)
,`last_name` varchar(20)
,`phone_number` int(10)
,`email` varchar(67)
,`role` varchar(80)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_vehicleview`
-- (See below for the actual view)
--
CREATE TABLE `insert_vehicleview` (
`vehicle_id` int(11)
,`vehicle_name` varchar(20)
,`prake_name` varchar(15)
);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `fuelsta_id` int(11) DEFAULT NULL,
  `fuel_type` varchar(50) NOT NULL,
  `quentity` int(11) NOT NULL,
  `total_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `driver_id`, `fuelsta_id`, `fuel_type`, `quentity`, `total_price`) VALUES
(1, 1, 1, 1, 'GENERAL  Gasoline', 10, 500000),
(2, 2, 2, 2, 'Regular Gasoline', 50, 150000),
(3, 3, 3, 3, 'MEDIAN Gasoline', 50, 100000);

--
-- Triggers `orders`
--
DELIMITER $$
CREATE TRIGGER `AfterOrderDelete` AFTER DELETE ON `orders` FOR EACH ROW BEGIN
    UPDATE customer
    SET total_orders = total_orders - 1
    WHERE customer_id = OLD.customer_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterOrderInsert` AFTER INSERT ON `orders` FOR EACH ROW BEGIN
    UPDATE customer
    SET total_orders = total_orders + 1
    WHERE customer_id = NEW.customer_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterOrderUpdate` AFTER UPDATE ON `orders` FOR EACH ROW BEGIN
    UPDATE ORDERS
    SET modified_date = NOW()
    WHERE order_id = NEW.order_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `order_assignment`
--

CREATE TABLE `order_assignment` (
  `orderass_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_assignment`
--

INSERT INTO `order_assignment` (`orderass_id`, `order_id`, `driver_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 1),
(4, 3, 3),
(5, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `order_history`
--

CREATE TABLE `order_history` (
  `orderhis_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_history`
--

INSERT INTO `order_history` (`orderhis_id`, `customer_id`, `order_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 1),
(4, 3, 3),
(5, 3, 2);

-- --------------------------------------------------------

--
-- Stand-in structure for view `recent_customer_orders`
-- (See below for the actual view)
--
CREATE TABLE `recent_customer_orders` (
`customer_id` int(11)
,`first_name` varchar(25)
,`last_name` varchar(50)
,`order_id` int(11)
,`total_price` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `trans_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `fuelsta_id` int(11) DEFAULT NULL,
  `quentity` int(11) NOT NULL,
  `date_delivered` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`trans_id`, `order_id`, `driver_id`, `fuelsta_id`, `quentity`, `date_delivered`) VALUES
(1, 1, 1, 2, 50, '2023-08-31'),
(2, 1, 2, 1, 150, '2023-12-31'),
(3, 2, 2, 1, 250, '2023-10-31'),
(4, 1, 3, 2, 350, '2023-07-31'),
(5, 2, 1, 3, 450, '0000-00-00');

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatable_customer`
-- (See below for the actual view)
--
CREATE TABLE `updatable_customer` (
`customer_id` int(11)
,`last_name` varchar(50)
,`first_name` varchar(25)
,`emai` varchar(100)
,`Address` varchar(50)
,`Phone` varchar(10)
,`payment_method` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatable_fuel_suppler_info`
-- (See below for the actual view)
--
CREATE TABLE `updatable_fuel_suppler_info` (
`fuelsup_id` int(11)
,`First_name` varchar(50)
,`Last_name` varchar(50)
,`Email` varchar(40)
,`Address` varchar(40)
,`Phone_number` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `phone_number` int(10) DEFAULT NULL,
  `email` varchar(67) DEFAULT NULL,
  `role` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `phone_number`, `email`, `role`) VALUES
(1, 'David', 'Kwizera', 785707681, 'davidkwizera@gmail.com', 'Admin'),
(2, 'uwera', 'ruth', 785707681, 'ruth@gmail.com', 'Administrator'),
(3, 'John', 'pazzo', 725050334, 'john@gmail.com', 'Administrator');

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `AfterUserDelete` AFTER DELETE ON `user` FOR EACH ROW BEGIN
    INSERT INTO user_log (user_id, action, timestamp)
    VALUES (OLD.user_id, 'DELETE', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUserInsert` AFTER INSERT ON `user` FOR EACH ROW BEGIN
    INSERT INTO user_log (user_id, action, timestamp)
    VALUES (NEW.user_id, 'INSERT', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_to_deletes`
-- (See below for the actual view)
--
CREATE TABLE `user_to_deletes` (
`user_id` int(11)
,`last_name` varchar(20)
,`first_name` varchar(25)
,`phone_number` int(10)
,`email` varchar(67)
,`role` varchar(80)
);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `vehicle_id` int(11) NOT NULL,
  `vehicle_name` varchar(20) NOT NULL,
  `prake_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`vehicle_id`, `vehicle_name`, `prake_name`) VALUES
(1, 'Toyota Camry', '234RF'),
(2, 'rava4 ', 'RAB 223 C'),
(3, 'fuso', 'RAC 323 D');

-- --------------------------------------------------------

--
-- Structure for view `all_data_view`
--
DROP TABLE IF EXISTS `all_data_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_data_view`  AS SELECT 'user' AS `source_table`, `user`.`user_id` AS `user_id`, `user`.`first_name` AS `first_name`, `user`.`last_name` AS `last_name`, `user`.`phone_number` AS `phone_number`, `user`.`email` AS `email`, `user`.`role` AS `role`, NULL AS `NULL` FROM `user`union all select 'bank' AS `source_table`,`bank`.`bank_id` AS `bank_id`,`bank`.`name` AS `name`,`bank`.`address` AS `address`,`bank`.`account_number` AS `account_number`,`bank`.`phone_number` AS `phone_number`,`bank`.`routing_number` AS `routing_number`,NULL AS `NULL` from `bank` union all select 'customer' AS `source_table`,`customer`.`customer_id` AS `customer_id`,`customer`.`first_name` AS `first_name`,`customer`.`last_name` AS `last_name`,`customer`.`emai` AS `emai`,`customer`.`phone` AS `phone`,`customer`.`address` AS `address`,`customer`.`payment_method` AS `payment_method` from `customer` union all select 'driver' AS `source_table`,`driver`.`driver_id` AS `driver_id`,`driver`.`first_name` AS `first_name`,`driver`.`last_name` AS `last_name`,`driver`.`phone` AS `phone`,`driver`.`licence_number` AS `licence_number`,`driver`.`vehicle_id` AS `vehicle_id`,NULL AS `NULL` from `driver` union all select 'fuel_admin' AS `source_table`,`fuel_admin`.`adm_id` AS `Adm_id`,`fuel_admin`.`email` AS `Email`,`fuel_admin`.`Password` AS `Password`,`fuel_admin`.`first_name` AS `first_name`,`fuel_admin`.`last_name` AS `last_name`,`fuel_admin`.`phon_number` AS `phon_number`,`fuel_admin`.`permissions` AS `permissions` from `fuel_admin` union all select 'fuel_deliveryorders' AS `source_table`,`fuel_deliveryorders`.`fueldelorder_id` AS `Fueldelorder_id`,`fuel_deliveryorders`.`fuelsup_id` AS `fuelsup_id`,`fuel_deliveryorders`.`order_id` AS `order_id`,`fuel_deliveryorders`.`date_delivered` AS `date_delivered`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL` from `fuel_deliveryorders` union all select 'fuel_deliveryrecord' AS `source_table`,`fuel_deliveryrecord`.`fueldelrecord_id` AS `fueldelrecord_id`,`fuel_deliveryrecord`.`order_id` AS `order_id`,`fuel_deliveryrecord`.`driver_id` AS `driver_id`,`fuel_deliveryrecord`.`fuelsta_id` AS `fuelsta_id`,`fuel_deliveryrecord`.`quentity` AS `quentity`,`fuel_deliveryrecord`.`date_delivered` AS `date_delivered`,NULL AS `NULL` from `fuel_deliveryrecord` union all select 'fuel_station' AS `source_table`,`fuel_station`.`fuelsta_id` AS `fuelsta_id`,`fuel_station`.`name` AS `name`,`fuel_station`.`address` AS `address`,`fuel_station`.`phone` AS `phone`,`fuel_station`.`fuel_type` AS `fuel_type`,NULL AS `NULL`,NULL AS `NULL` from `fuel_station` union all select 'fuel_suppler' AS `source_table`,`fuel_suppler`.`fuelsup_id` AS `fuelsup_id`,`fuel_suppler`.`last_name` AS `last_name`,`fuel_suppler`.`first_name` AS `first_name`,`fuel_suppler`.`email` AS `email`,`fuel_suppler`.`address` AS `address`,`fuel_suppler`.`phone_number` AS `phone_number`,NULL AS `NULL` from `fuel_suppler` union all select 'fuel_type' AS `source_table`,`fuel_type`.`fuel_id` AS `fuel_id`,`fuel_type`.`name` AS `name`,`fuel_type`.`price` AS `price`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL` from `fuel_type` union all select 'order_assignment' AS `source_table`,`order_assignment`.`orderass_id` AS `orderass_id`,`order_assignment`.`order_id` AS `order_id`,`order_assignment`.`driver_id` AS `driver_id`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL` from `order_assignment` union all select 'order_history' AS `source_table`,`order_history`.`orderhis_id` AS `orderhis_id`,`order_history`.`customer_id` AS `customer_id`,`order_history`.`order_id` AS `order_id`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL` from `order_history` union all select 'ORDERS' AS `source_table`,`orders`.`order_id` AS `order_id`,`orders`.`customer_id` AS `customer_id`,`orders`.`driver_id` AS `driver_id`,`orders`.`fuelsta_id` AS `fuelsta_id`,`orders`.`fuel_type` AS `fuel_type`,`orders`.`quentity` AS `quentity`,`orders`.`total_price` AS `total_price` from `orders` union all select 'transaction' AS `source_table`,`transaction`.`trans_id` AS `trans_id`,`transaction`.`quentity` AS `quentity`,`transaction`.`date_delivered` AS `date_delivered`,`transaction`.`driver_id` AS `driver_id`,`transaction`.`fuelsta_id` AS `fuelsta_id`,`transaction`.`order_id` AS `order_id`,NULL AS `NULL` from `transaction` union all select 'vehicle' AS `source_table`,`vehicle`.`vehicle_id` AS `vehicle_id`,`vehicle`.`vehicle_name` AS `vehicle_name`,`vehicle`.`prake_name` AS `prake_name`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL`,NULL AS `NULL` from `vehicle`  ;

-- --------------------------------------------------------

--
-- Structure for view `customer_to_delete`
--
DROP TABLE IF EXISTS `customer_to_delete`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_to_delete`  AS SELECT `customer`.`customer_id` AS `customer_id`, `customer`.`last_name` AS `last_name`, `customer`.`first_name` AS `first_name`, `customer`.`emai` AS `emai`, `customer`.`address` AS `Address`, `customer`.`phone` AS `Phone`, `customer`.`payment_method` AS `payment_method` FROM `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `customer_to_deletes`
--
DROP TABLE IF EXISTS `customer_to_deletes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_to_deletes`  AS SELECT `customer`.`customer_id` AS `customer_id`, `customer`.`last_name` AS `last_name`, `customer`.`first_name` AS `first_name`, `customer`.`emai` AS `emai`, `customer`.`address` AS `Address`, `customer`.`phone` AS `Phone`, `customer`.`payment_method` AS `payment_method` FROM `customer` WHERE `customer`.`customer_id` = 1 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_bankview`
--
DROP TABLE IF EXISTS `insert_bankview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_bankview`  AS SELECT `bank`.`bank_id` AS `bank_id`, `bank`.`name` AS `name`, `bank`.`address` AS `address`, `bank`.`account_number` AS `account_number`, `bank`.`phone_number` AS `phone_number`, `bank`.`routing_number` AS `routing_number` FROM `bank` WHERE `bank`.`bank_id` = 10 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_customerview`
--
DROP TABLE IF EXISTS `insert_customerview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_customerview`  AS SELECT `customer`.`customer_id` AS `customer_id`, `customer`.`last_name` AS `last_name`, `customer`.`first_name` AS `first_name`, `customer`.`emai` AS `emai`, `customer`.`phone` AS `phone`, `customer`.`address` AS `address`, `customer`.`payment_method` AS `payment_method` FROM `customer` WHERE `customer`.`customer_id` = 2 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_driverview`
--
DROP TABLE IF EXISTS `insert_driverview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_driverview`  AS SELECT `driver`.`driver_id` AS `driver_id`, `driver`.`first_name` AS `first_name`, `driver`.`last_name` AS `last_name`, `driver`.`phone` AS `phone`, `driver`.`licence_number` AS `licence_number`, `driver`.`vehicle_id` AS `vehicle_id` FROM `driver` WHERE `driver`.`driver_id` = 11 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_fuel_adminview`
--
DROP TABLE IF EXISTS `insert_fuel_adminview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_fuel_adminview`  AS SELECT `fuel_admin`.`adm_id` AS `adm_id`, `fuel_admin`.`email` AS `email`, `fuel_admin`.`Password` AS `Password`, `fuel_admin`.`first_name` AS `first_name`, `fuel_admin`.`last_name` AS `last_name`, `fuel_admin`.`phon_number` AS `phon_number`, `fuel_admin`.`permissions` AS `permissions` FROM `fuel_admin` WHERE `fuel_admin`.`adm_id` = 15 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_fuel_deliveryordersview`
--
DROP TABLE IF EXISTS `insert_fuel_deliveryordersview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_fuel_deliveryordersview`  AS SELECT `fuel_deliveryorders`.`fueldelorder_id` AS `fueldelorder_id`, `fuel_deliveryorders`.`fuelsup_id` AS `fuelsup_id`, `fuel_deliveryorders`.`order_id` AS `order_id`, `fuel_deliveryorders`.`date_delivered` AS `date_delivered` FROM `fuel_deliveryorders` WHERE `fuel_deliveryorders`.`fueldelorder_id` = 2 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_fuel_deliveryrecordview`
--
DROP TABLE IF EXISTS `insert_fuel_deliveryrecordview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_fuel_deliveryrecordview`  AS SELECT `fuel_deliveryrecord`.`fueldelrecord_id` AS `fueldelrecord_id`, `fuel_deliveryrecord`.`order_id` AS `order_id`, `fuel_deliveryrecord`.`driver_id` AS `driver_id`, `fuel_deliveryrecord`.`fuelsta_id` AS `fuelsta_id`, `fuel_deliveryrecord`.`quentity` AS `quentity`, `fuel_deliveryrecord`.`date_delivered` AS `date_delivered` FROM `fuel_deliveryrecord` WHERE `fuel_deliveryrecord`.`fueldelrecord_id` = 6 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_fuel_stationview`
--
DROP TABLE IF EXISTS `insert_fuel_stationview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_fuel_stationview`  AS SELECT `fuel_station`.`fuelsta_id` AS `fuelsta_id`, `fuel_station`.`name` AS `name`, `fuel_station`.`address` AS `address`, `fuel_station`.`phone` AS `phone`, `fuel_station`.`fuel_type` AS `fuel_type` FROM `fuel_station` WHERE `fuel_station`.`fuelsta_id` = 6 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_fuel_supplerview`
--
DROP TABLE IF EXISTS `insert_fuel_supplerview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_fuel_supplerview`  AS SELECT `fuel_suppler`.`fuelsup_id` AS `fuelsup_id`, `fuel_suppler`.`last_name` AS `last_name`, `fuel_suppler`.`first_name` AS `first_name`, `fuel_suppler`.`email` AS `email`, `fuel_suppler`.`address` AS `address`, `fuel_suppler`.`phone_number` AS `phone_number` FROM `fuel_suppler` WHERE `fuel_suppler`.`fuelsup_id` = 17 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_fuel_typeview`
--
DROP TABLE IF EXISTS `insert_fuel_typeview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_fuel_typeview`  AS SELECT `fuel_type`.`fuel_id` AS `fuel_id`, `fuel_type`.`name` AS `name`, `fuel_type`.`price` AS `price` FROM `fuel_type` WHERE `fuel_type`.`fuel_id` = 17 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_ordersview`
--
DROP TABLE IF EXISTS `insert_ordersview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_ordersview`  AS SELECT `orders`.`order_id` AS `order_id`, `orders`.`customer_id` AS `customer_id`, `orders`.`driver_id` AS `driver_id`, `orders`.`fuelsta_id` AS `fuelsta_id`, `orders`.`fuel_type` AS `fuel_type`, `orders`.`quentity` AS `quentity`, `orders`.`total_price` AS `total_price` FROM `orders` WHERE `orders`.`order_id` = 8 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_order_assignmentview`
--
DROP TABLE IF EXISTS `insert_order_assignmentview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_order_assignmentview`  AS SELECT `order_assignment`.`orderass_id` AS `orderass_id`, `order_assignment`.`order_id` AS `order_id`, `order_assignment`.`driver_id` AS `driver_id` FROM `order_assignment` WHERE `order_assignment`.`orderass_id` = 3 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_order_historyview`
--
DROP TABLE IF EXISTS `insert_order_historyview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_order_historyview`  AS SELECT `order_history`.`orderhis_id` AS `orderhis_id`, `order_history`.`customer_id` AS `customer_id`, `order_history`.`order_id` AS `order_id` FROM `order_history` WHERE `order_history`.`orderhis_id` = 16 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_transactionview`
--
DROP TABLE IF EXISTS `insert_transactionview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_transactionview`  AS SELECT `transaction`.`trans_id` AS `trans_id`, `transaction`.`order_id` AS `order_id`, `transaction`.`driver_id` AS `driver_id`, `transaction`.`fuelsta_id` AS `fuelsta_id`, `transaction`.`quentity` AS `quentity`, `transaction`.`date_delivered` AS `date_delivered` FROM `transaction` WHERE `transaction`.`trans_id` = 35 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_userview`
--
DROP TABLE IF EXISTS `insert_userview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_userview`  AS SELECT `user`.`user_id` AS `user_id`, `user`.`first_name` AS `first_name`, `user`.`last_name` AS `last_name`, `user`.`phone_number` AS `phone_number`, `user`.`email` AS `email`, `user`.`role` AS `role` FROM `user` WHERE `user`.`user_id` = 7 ;

-- --------------------------------------------------------

--
-- Structure for view `insert_vehicleview`
--
DROP TABLE IF EXISTS `insert_vehicleview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_vehicleview`  AS SELECT `vehicle`.`vehicle_id` AS `vehicle_id`, `vehicle`.`vehicle_name` AS `vehicle_name`, `vehicle`.`prake_name` AS `prake_name` FROM `vehicle` WHERE `vehicle`.`vehicle_id` = 13 ;

-- --------------------------------------------------------

--
-- Structure for view `recent_customer_orders`
--
DROP TABLE IF EXISTS `recent_customer_orders`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `recent_customer_orders`  AS SELECT `c`.`customer_id` AS `customer_id`, `c`.`first_name` AS `first_name`, `c`.`last_name` AS `last_name`, `o`.`order_id` AS `order_id`, `o`.`total_price` AS `total_price` FROM ((`customer` `c` join (select `orders`.`customer_id` AS `customer_id`,avg(`orders`.`total_price`) AS `recent_order_total_price` from `orders` group by `orders`.`customer_id`) `subquery` on(`c`.`customer_id` = `subquery`.`customer_id`)) join `orders` `o` on(`c`.`customer_id` = `o`.`customer_id` and `subquery`.`recent_order_total_price` = `o`.`total_price`)) ;

-- --------------------------------------------------------

--
-- Structure for view `updatable_customer`
--
DROP TABLE IF EXISTS `updatable_customer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatable_customer`  AS SELECT `customer`.`customer_id` AS `customer_id`, `customer`.`last_name` AS `last_name`, `customer`.`first_name` AS `first_name`, `customer`.`emai` AS `emai`, `customer`.`address` AS `Address`, `customer`.`phone` AS `Phone`, `customer`.`payment_method` AS `payment_method` FROM `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `updatable_fuel_suppler_info`
--
DROP TABLE IF EXISTS `updatable_fuel_suppler_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatable_fuel_suppler_info`  AS SELECT `fuel_suppler`.`fuelsup_id` AS `fuelsup_id`, `fuel_suppler`.`first_name` AS `First_name`, `fuel_suppler`.`last_name` AS `Last_name`, `fuel_suppler`.`email` AS `Email`, `fuel_suppler`.`address` AS `Address`, `fuel_suppler`.`phone_number` AS `Phone_number` FROM `fuel_suppler` ;

-- --------------------------------------------------------

--
-- Structure for view `user_to_deletes`
--
DROP TABLE IF EXISTS `user_to_deletes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `user_to_deletes`  AS SELECT `user`.`user_id` AS `user_id`, `user`.`last_name` AS `last_name`, `user`.`first_name` AS `first_name`, `user`.`phone_number` AS `phone_number`, `user`.`email` AS `email`, `user`.`role` AS `role` FROM `user` WHERE `user`.`user_id` = 1 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`bank_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`driver_id`),
  ADD KEY `vehicle_id` (`vehicle_id`);

--
-- Indexes for table `fuel_admin`
--
ALTER TABLE `fuel_admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `fuel_deliveryorders`
--
ALTER TABLE `fuel_deliveryorders`
  ADD PRIMARY KEY (`fueldelorder_id`),
  ADD KEY `fuelsup_id` (`fuelsup_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `fuel_deliveryrecord`
--
ALTER TABLE `fuel_deliveryrecord`
  ADD PRIMARY KEY (`fueldelrecord_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `driver_id` (`driver_id`),
  ADD KEY `fuelsta_id` (`fuelsta_id`);

--
-- Indexes for table `fuel_station`
--
ALTER TABLE `fuel_station`
  ADD PRIMARY KEY (`fuelsta_id`);

--
-- Indexes for table `fuel_suppler`
--
ALTER TABLE `fuel_suppler`
  ADD PRIMARY KEY (`fuelsup_id`);

--
-- Indexes for table `fuel_type`
--
ALTER TABLE `fuel_type`
  ADD PRIMARY KEY (`fuel_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `driver_id` (`driver_id`),
  ADD KEY `fuelsta_id` (`fuelsta_id`);

--
-- Indexes for table `order_assignment`
--
ALTER TABLE `order_assignment`
  ADD PRIMARY KEY (`orderass_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `driver_id` (`driver_id`);

--
-- Indexes for table `order_history`
--
ALTER TABLE `order_history`
  ADD PRIMARY KEY (`orderhis_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`trans_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `driver_id` (`driver_id`),
  ADD KEY `fuelsta_id` (`fuelsta_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`vehicle_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `driver`
--
ALTER TABLE `driver`
  MODIFY `driver_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fuel_admin`
--
ALTER TABLE `fuel_admin`
  MODIFY `adm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fuel_deliveryorders`
--
ALTER TABLE `fuel_deliveryorders`
  MODIFY `fueldelorder_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fuel_deliveryrecord`
--
ALTER TABLE `fuel_deliveryrecord`
  MODIFY `fueldelrecord_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fuel_station`
--
ALTER TABLE `fuel_station`
  MODIFY `fuelsta_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fuel_suppler`
--
ALTER TABLE `fuel_suppler`
  MODIFY `fuelsup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fuel_type`
--
ALTER TABLE `fuel_type`
  MODIFY `fuel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_assignment`
--
ALTER TABLE `order_assignment`
  MODIFY `orderass_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_history`
--
ALTER TABLE `order_history`
  MODIFY `orderhis_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `vehicle_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `driver`
--
ALTER TABLE `driver`
  ADD CONSTRAINT `driver_ibfk_1` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`vehicle_id`);

--
-- Constraints for table `fuel_deliveryorders`
--
ALTER TABLE `fuel_deliveryorders`
  ADD CONSTRAINT `fuel_deliveryorders_ibfk_1` FOREIGN KEY (`fuelsup_id`) REFERENCES `fuel_suppler` (`fuelsup_id`),
  ADD CONSTRAINT `fuel_deliveryorders_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);

--
-- Constraints for table `fuel_deliveryrecord`
--
ALTER TABLE `fuel_deliveryrecord`
  ADD CONSTRAINT `fuel_deliveryrecord_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `fuel_deliveryrecord_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`),
  ADD CONSTRAINT `fuel_deliveryrecord_ibfk_3` FOREIGN KEY (`fuelsta_id`) REFERENCES `fuel_station` (`fuelsta_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`fuelsta_id`) REFERENCES `fuel_station` (`fuelsta_id`);

--
-- Constraints for table `order_assignment`
--
ALTER TABLE `order_assignment`
  ADD CONSTRAINT `order_assignment_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_assignment_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`);

--
-- Constraints for table `order_history`
--
ALTER TABLE `order_history`
  ADD CONSTRAINT `order_history_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `order_history_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`),
  ADD CONSTRAINT `transaction_ibfk_3` FOREIGN KEY (`fuelsta_id`) REFERENCES `fuel_station` (`fuelsta_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
