-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 10:20 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `janvier`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteProperty` (IN `p_property_id` INT)   BEGIN
    DELETE FROM property
    WHERE
        property_id = p_property_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllProperties` ()   BEGIN
    SELECT * FROM property;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertProperty` (IN `p_property_id` INT, IN `p_address` VARCHAR(255), IN `p_type` VARCHAR(50), IN `p_size` INT, IN `p_bedroom_number` INT, IN `p_monthly_rent` DECIMAL(10,2), IN `p_availability_status` VARCHAR(20))   BEGIN
    INSERT INTO property (property_id, address, type, size, bedroom_number, monthly_rent, availability_status)
    VALUES (p_property_id, p_address, p_type, p_size, p_bedroom_number, p_monthly_rent, p_availability_status);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateProperty` (IN `p_property_id` INT, IN `p_new_address` VARCHAR(255), IN `p_new_type` VARCHAR(50), IN `p_new_size` INT, IN `p_new_bedroom_number` INT, IN `p_new_monthly_rent` DECIMAL(10,2), IN `p_new_availability_status` VARCHAR(20))   BEGIN
    UPDATE property
    SET
        address = p_new_address,
        type = p_new_type,
        size = p_new_size,
        bedroom_number = p_new_bedroom_number,
        monthly_rent = p_new_monthly_rent,
        availability_status = p_new_availability_status
    WHERE
        property_id = p_property_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `contract`
--

CREATE TABLE `contract` (
  `contract_id` int(11) NOT NULL,
  `property_id` int(11) DEFAULT NULL,
  `tenant_id` int(11) DEFAULT NULL,
  `lease_start_date` date DEFAULT NULL,
  `lease_end_date` date DEFAULT NULL,
  `monthly_amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contract`
--

INSERT INTO `contract` (`contract_id`, `property_id`, `tenant_id`, `lease_start_date`, `lease_end_date`, `monthly_amount`) VALUES
(1, 1, 1, '2023-09-01', '2024-08-31', '1500.00'),
(2, 2, 2, '2023-08-15', '2024-08-14', '2000.00'),
(3, 3, 3, '2023-09-15', '2024-09-14', '1200.00');

-- --------------------------------------------------------

--
-- Table structure for table `landlord`
--

CREATE TABLE `landlord` (
  `landlord_id` int(11) NOT NULL,
  `names` varchar(100) DEFAULT NULL,
  `identity_number` varchar(20) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `bank_account` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `landlord`
--

INSERT INTO `landlord` (`landlord_id`, `names`, `identity_number`, `contact`, `bank_account`) VALUES
(1, 'Alice Johnson', '1234567890', 'alice@example.com', '9876543210'),
(2, 'Bob Smith', '9876543210', 'bob@example.com', '1234567890'),
(3, 'Charlie Brown', '5555555555', 'charlie@example.com', '8888888888');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `maintenance_id` int(11) NOT NULL,
  `property_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `date_requested` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `maintenance`
--

INSERT INTO `maintenance` (`maintenance_id`, `property_id`, `description`, `date_requested`, `status`) VALUES
(1, 1, 'Leaky faucet in the kitchen', '2023-09-10', 'Pending'),
(2, 2, 'Broken window in the living room', '2023-08-25', 'In Progress'),
(3, 3, 'Heating system not working', '2023-09-05', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `tenant_id` int(11) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `tenant_id`, `amount_paid`, `payment_date`, `payment_method`) VALUES
(1, 1, '1500.00', '2023-09-05', 'Credit Card'),
(2, 2, '2000.00', '2023-08-20', 'Bank Transfer'),
(3, 3, '1200.00', '2023-09-15', 'Cash');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `property_id` int(11) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `bedroom_number` int(11) DEFAULT NULL,
  `monthly_rent` decimal(10,2) DEFAULT NULL,
  `availability_status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`property_id`, `address`, `type`, `size`, `bedroom_number`, `monthly_rent`, `availability_status`) VALUES
(1, '456 Elm St', 'House', 1600, 4, '2200.00', 'Available'),
(2, '456 Elm St', 'House', 1500, 3, '2000.00', 'Available'),
(3, '789 Oak St', 'Condo', 800, 1, '1800.00', 'Available');

--
-- Triggers `property`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertProperty` AFTER INSERT ON `property` FOR EACH ROW BEGIN
    
    
    
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tenant`
--

CREATE TABLE `tenant` (
  `tenant_id` int(11) NOT NULL,
  `names` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `lease_start_date` date DEFAULT NULL,
  `lease_end_date` date DEFAULT NULL,
  `monthly_rent_payment` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tenant`
--

INSERT INTO `tenant` (`tenant_id`, `names`, `contact`, `lease_start_date`, `lease_end_date`, `monthly_rent_payment`) VALUES
(1, 'John Doe', 'johndoe@example.com', '2023-09-01', '2024-08-31', '1500.00'),
(2, 'Jane Smith', 'janesmith@example.com', '2023-08-15', '2024-08-14', '2000.00'),
(3, 'Bob Johnson', 'bob@example.com', '2023-09-15', '2024-09-14', '1200.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`contract_id`),
  ADD KEY `property_id` (`property_id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indexes for table `landlord`
--
ALTER TABLE `landlord`
  ADD PRIMARY KEY (`landlord_id`);

--
-- Indexes for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`maintenance_id`),
  ADD KEY `property_id` (`property_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `tenant_id` (`tenant_id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`property_id`);

--
-- Indexes for table `tenant`
--
ALTER TABLE `tenant`
  ADD PRIMARY KEY (`tenant_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contract`
--
ALTER TABLE `contract`
  ADD CONSTRAINT `contract_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `property` (`property_id`),
  ADD CONSTRAINT `contract_ibfk_2` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`tenant_id`);

--
-- Constraints for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD CONSTRAINT `maintenance_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `property` (`property_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`tenant_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
