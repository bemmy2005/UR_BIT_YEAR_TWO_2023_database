-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2023 at 09:42 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rentalcardatabase`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteOldData` (IN `p_DeleteReservationsBefore` DATE, IN `p_DeleteCustomersWithNoReservations` BOOLEAN)   BEGIN
    -- Delete reservations older than the specified date in the Reservation table
    IF p_DeleteReservationsBefore IS NOT NULL THEN
        DELETE FROM Reservation
        WHERE ReservationDate < p_DeleteReservationsBefore;
    END IF;

    -- Delete customers with no reservations in the Customer table
    IF p_DeleteCustomersWithNoReservations THEN
        DELETE FROM Customer
        WHERE Customer_ID NOT IN (SELECT DISTINCT CustomerID FROM Reservation);
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllInformation` ()   BEGIN
    -- Display data from the Customer table
    SELECT * FROM Customer;
    -- Add additional SELECT statements for other tables as needed
    -- For example: SELECT * FROM Car;
    --        SELECT * FROM Reservation;
    --               SELECT * FROM ServerLog;
    --               SELECT * FROM Admin;
    --               SELECT * FROM LoyaltyProgram;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetCustomerReservationCount` ()   BEGIN
    -- Select data from the CustomerReservationCount view
    SELECT * FROM CustomerReservationCount;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertCustomer` (IN `p_FirstName` VARCHAR(50), IN `p_LastName` VARCHAR(50), IN `p_Email` VARCHAR(100), IN `p_Phone` VARCHAR(20))   BEGIN
    INSERT INTO Customer (FirstName, LastName, Email, Phone)
    VALUES (p_FirstName, p_LastName, p_Email, p_Phone);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateCustomerAndCar` (IN `p_CustomerID` INT, IN `p_NewEmail` VARCHAR(100), IN `p_CarID` INT, IN `p_NewDailyRate` DECIMAL(10,2))   BEGIN
    -- Update the customer's email in the Customer table
    UPDATE Customer
    SET Email = p_NewEmail
    WHERE Customer_ID = p_CustomerID;
    -- Update the daily rate of the car in the Car table
    UPDATE Car
    SET DailyRate = p_NewDailyRate
    WHERE CarID = p_CarID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AdminID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`AdminID`, `FirstName`, `LastName`, `Email`, `Username`, `Password`) VALUES
(1, 'deborah', 'irakoze', 'admin@example.com', 'adminuser', 'password123');

-- --------------------------------------------------------

--
-- Stand-in structure for view `allinformation`
-- (See below for the actual view)
--
CREATE TABLE `allinformation` (
`Customer_ID` int(11)
,`CustomerFirstName` varchar(50)
,`CustomerLastName` varchar(50)
,`CustomerEmail` varchar(100)
,`CustomerPhone` varchar(20)
,`CarID` int(11)
,`CarMake` varchar(50)
,`CarModel` varchar(50)
,`CarYear` int(11)
,`CarDailyRate` decimal(10,2)
,`ReservationID` int(11)
,`ReservationDate` date
,`ReturnDate` date
,`TotalCost` decimal(10,2)
,`LogID` int(11)
,`LogTimestamp` timestamp
,`LogMessage` text
,`AdminID` int(11)
,`AdminFirstName` varchar(50)
,`AdminLastName` varchar(50)
,`AdminEmail` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE `car` (
  `CarID` int(11) NOT NULL,
  `Make` varchar(50) DEFAULT NULL,
  `Model` varchar(50) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `DailyRate` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`CarID`, `Make`, `Model`, `Year`, `DailyRate`) VALUES
(1, 'Toyota', 'Camry', 2022, '55.00');

--
-- Triggers `car`
--
DELIMITER $$
CREATE TRIGGER `AfterUpdateCarDailyRate` AFTER UPDATE ON `car` FOR EACH ROW BEGIN
    IF NEW.DailyRate <> OLD.DailyRate THEN
        UPDATE Reservation
        SET TotalCost = DATEDIFF(2020-03-7, 2020-03-6) * NEW.DailyRate
        WHERE CarID = NEW.CarID;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `FirstName`, `LastName`, `Email`, `Phone`) VALUES
(1, 'John', 'Doe', 'irakoze@gmail.com', '123-456-7890');

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteCustomer` AFTER DELETE ON `customer` FOR EACH ROW BEGIN
    INSERT INTO ServerLog (LogDate, LoggedOut)
    VALUES (NOW(), CONCAT('Customer deleted - Customer ID: ', OLD.Customer_ID));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertCustomer` AFTER INSERT ON `customer` FOR EACH ROW BEGIN
    INSERT INTO ServerLog (LogDate, LoggedOn)
    VALUES (NOW(), CONCAT('New customer inserted - Customer_ID: ', NEW.Customer_ID));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateCustomerEmail` AFTER UPDATE ON `customer` FOR EACH ROW BEGIN
    IF NEW.Email <> OLD.Email THEN
        INSERT INTO ServerLog (Timestamp, LogMessage)
        VALUES (NOW(), CONCAT('Customer email updated - Customer ID: ', 20));
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `customerreservationcount`
-- (See below for the actual view)
--
CREATE TABLE `customerreservationcount` (
`Customer_ID` int(11)
,`CustomerFirstName` varchar(50)
,`CustomerLastName` varchar(50)
,`CustomerEmail` varchar(100)
,`CustomerPhone` varchar(20)
,`ReservationID` int(11)
,`ReservationDate` date
,`ReturnDate` date
,`ReservationCount` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `customerswitholdreservations`
-- (See below for the actual view)
--
CREATE TABLE `customerswitholdreservations` (
`Customer_ID` int(11)
,`CustomerFirstName` varchar(50)
,`CustomerLastName` varchar(50)
,`ReservationID` int(11)
,`ReservationDate` date
);

-- --------------------------------------------------------

--
-- Table structure for table `loyaltyprogram`
--

CREATE TABLE `loyaltyprogram` (
  `ProgramID` int(11) NOT NULL,
  `ProgramName` varchar(50) DEFAULT NULL,
  `RewardThreshold` int(11) DEFAULT NULL,
  `RewardDescription` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loyaltyprogram`
--

INSERT INTO `loyaltyprogram` (`ProgramID`, `ProgramName`, `RewardThreshold`, `RewardDescription`) VALUES
(1, 'Gold Membership', 500, 'Earn rewards after spending $500 or more.');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `ReservationID` int(11) NOT NULL,
  `CustomerID` int(11) DEFAULT NULL,
  `CarID` int(11) DEFAULT NULL,
  `ReservationDate` date DEFAULT NULL,
  `ReturnDate` date DEFAULT NULL,
  `TotalCost` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`ReservationID`, `CustomerID`, `CarID`, `ReservationDate`, `ReturnDate`, `TotalCost`) VALUES
(1, 1, 1, '2023-09-15', '2023-09-18', '160.00');

--
-- Triggers `reservation`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteReservation` AFTER DELETE ON `reservation` FOR EACH ROW BEGIN
    UPDATE Car
    SET Available = TRUE
    WHERE CarID = OLD.CarID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertReservation` AFTER INSERT ON `reservation` FOR EACH ROW BEGIN
    UPDATE Reservation
SET TotalCost = DATEDIFF(NEW.ReturnDate, NEW.ReservationDate) * (SELECT DailyRate FROM Car WHERE CarID = 25)
    WHERE ReservationID = NEW.ReservationID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `serverlog`
--

CREATE TABLE `serverlog` (
  `LogID` int(11) NOT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `LogMessage` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `serverlog`
--

INSERT INTO `serverlog` (`LogID`, `Timestamp`, `LogMessage`) VALUES
(1, '2023-09-15 08:30:00', 'Server started.');

-- --------------------------------------------------------

--
-- Stand-in structure for view `subqueryview`
-- (See below for the actual view)
--
CREATE TABLE `subqueryview` (
`Customer_ID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`Email` varchar(100)
);

-- --------------------------------------------------------

--
-- Structure for view `allinformation`
--
DROP TABLE IF EXISTS `allinformation`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `allinformation`  AS SELECT `c`.`Customer_ID` AS `Customer_ID`, `c`.`FirstName` AS `CustomerFirstName`, `c`.`LastName` AS `CustomerLastName`, `c`.`Email` AS `CustomerEmail`, `c`.`Phone` AS `CustomerPhone`, `ca`.`CarID` AS `CarID`, `ca`.`Make` AS `CarMake`, `ca`.`Model` AS `CarModel`, `ca`.`Year` AS `CarYear`, `ca`.`DailyRate` AS `CarDailyRate`, `r`.`ReservationID` AS `ReservationID`, `r`.`ReservationDate` AS `ReservationDate`, `r`.`ReturnDate` AS `ReturnDate`, `r`.`TotalCost` AS `TotalCost`, `l`.`LogID` AS `LogID`, `l`.`Timestamp` AS `LogTimestamp`, `l`.`LogMessage` AS `LogMessage`, `a`.`AdminID` AS `AdminID`, `a`.`FirstName` AS `AdminFirstName`, `a`.`LastName` AS `AdminLastName`, `a`.`Email` AS `AdminEmail` FROM ((((`customer` `c` left join `car` `ca` on(`c`.`Customer_ID` = `ca`.`CarID`)) left join `reservation` `r` on(`c`.`Customer_ID` = `r`.`CustomerID`)) left join `serverlog` `l` on(`l`.`LogID` = `r`.`ReservationID`)) left join `admin` `a` on(`a`.`AdminID` = `r`.`ReservationID`))  ;

-- --------------------------------------------------------

--
-- Structure for view `customerreservationcount`
--
DROP TABLE IF EXISTS `customerreservationcount`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customerreservationcount`  AS SELECT `c`.`Customer_ID` AS `Customer_ID`, `c`.`FirstName` AS `CustomerFirstName`, `c`.`LastName` AS `CustomerLastName`, `c`.`Email` AS `CustomerEmail`, `c`.`Phone` AS `CustomerPhone`, `r`.`ReservationID` AS `ReservationID`, `r`.`ReservationDate` AS `ReservationDate`, `r`.`ReturnDate` AS `ReturnDate`, (select count(0) from `reservation` `subr` where `subr`.`CustomerID` = `c`.`Customer_ID`) AS `ReservationCount` FROM (`customer` `c` left join `reservation` `r` on(`c`.`Customer_ID` = `r`.`CustomerID`))  ;

-- --------------------------------------------------------

--
-- Structure for view `customerswitholdreservations`
--
DROP TABLE IF EXISTS `customerswitholdreservations`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customerswitholdreservations`  AS SELECT `c`.`Customer_ID` AS `Customer_ID`, `c`.`FirstName` AS `CustomerFirstName`, `c`.`LastName` AS `CustomerLastName`, `r`.`ReservationID` AS `ReservationID`, `r`.`ReservationDate` AS `ReservationDate` FROM (`customer` `c` join `reservation` `r` on(`c`.`Customer_ID` = `r`.`CustomerID`)) WHERE `r`.`ReservationDate` < '2023-01-01''2023-01-01'  ;

-- --------------------------------------------------------

--
-- Structure for view `subqueryview`
--
DROP TABLE IF EXISTS `subqueryview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subqueryview`  AS SELECT `customer`.`Customer_ID` AS `Customer_ID`, `customer`.`FirstName` AS `FirstName`, `customer`.`LastName` AS `LastName`, `customer`.`Email` AS `Email` FROM `customer` WHERE `customer`.`Customer_ID` in (select `customer`.`Customer_ID` from `reservation` where `reservation`.`TotalCost` > 100)  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AdminID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`CarID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `loyaltyprogram`
--
ALTER TABLE `loyaltyprogram`
  ADD PRIMARY KEY (`ProgramID`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`ReservationID`),
  ADD KEY `CustomerID` (`CustomerID`),
  ADD KEY `CarID` (`CarID`);

--
-- Indexes for table `serverlog`
--
ALTER TABLE `serverlog`
  ADD PRIMARY KEY (`LogID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customer` (`Customer_ID`),
  ADD CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`CarID`) REFERENCES `car` (`CarID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
