-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2023 at 08:35 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online tailoring management system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CreateCustomerOrdersView` ()   BEGIN
    -- Create a view that shows customer information along with total order count
    CREATE OR REPLACE VIEW CustomerOrders AS
    SELECT
        c.customer_id,
        CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
        c.email,
        c.phone_number,
        o.total_orders
    FROM
        Customers c
    LEFT JOIN (
        SELECT
            customer_id,
            COUNT(*) AS total_orders
        FROM
            Orders
        GROUP BY
            customer_id
    ) o ON c.customer_id = o.customer_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteBillingAndInvoiceByCondition` (IN `condition_column` VARCHAR(255), IN `condition_value` VARCHAR(255))   BEGIN
    -- Delete data from Billing table based on the condition
    DELETE FROM Billing WHERE condition_column = condition_value;
    
    -- Delete data from Invoice table based on the condition
    DELETE FROM Invoice WHERE condition_column = condition_value;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteFabricByCondition` (IN `condition_column` VARCHAR(255), IN `condition_value` VARCHAR(255))   BEGIN
    -- Delete data from the Fabric table based on the provided condition
    DELETE FROM Fabric WHERE condition_column = condition_value;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetCustomerInfo` (OUT `customer_id` INT, OUT `names` VARCHAR(255), OUT `contact` VARCHAR(255), OUT `order_history` TEXT, OUT `preferred_fabric_choice` VARCHAR(255), OUT `payment_information` TEXT)   BEGIN
    -- SQL statements to retrieve customer information
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertOrderInfo` (IN `order_id` INT, IN `customer_id` INT, IN `order_date` DATE, IN `delivery_date` DATE, IN `status` VARCHAR(255), IN `total_amount` DECIMAL(10,2), IN `fabric_id` INT)   BEGIN
    INSERT INTO Order1 (order_id, customer_id, order_date, delivery_date, status, total_amount, fabric_id)
    VALUES (
        order_id,
        customer_id,
        order_date,
        delivery_date,
        status,
        total_amount,
        fabric_id
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateSupplierInfo` (IN `supplier_id` INT, IN `new_supplier_name` VARCHAR(255), IN `new_contact_information` VARCHAR(255))   BEGIN
    UPDATE Supplier
    SET
        supplier_name = new_supplier_name,
        contact_information = new_contact_information
    WHERE
        supplier_id = supplier_id; -- Assuming you want to update a specific supplier
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appointment_id` int(34) NOT NULL,
  `customer_id` int(21) NOT NULL,
  `appointment date` date NOT NULL,
  `purpose` varchar(23) NOT NULL,
  `supplier_id` int(12) NOT NULL,
  `status` varchar(41) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appointment_id`, `customer_id`, `appointment date`, `purpose`, `supplier_id`, `status`) VALUES
(1, 1, '0000-00-00', 'buy', 1, 'pending'),
(2, 2, '0000-00-00', 'pay', 3, 'finished');

-- --------------------------------------------------------

--
-- Stand-in structure for view `appointment_view`
-- (See below for the actual view)
--
CREATE TABLE `appointment_view` (
`appointment_id` int(34)
,`customer_id` int(21)
,`appointment date` date
,`purpose` varchar(23)
,`supplier_id` int(12)
,`status` varchar(41)
);

-- --------------------------------------------------------

--
-- Table structure for table `biling and invoice`
--

CREATE TABLE `biling and invoice` (
  `invoice_id` int(12) NOT NULL,
  `order_id` int(12) NOT NULL,
  `invoice issued date` date NOT NULL,
  `total amount` int(14) NOT NULL,
  `payment status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `biling and invoice`
--

INSERT INTO `biling and invoice` (`invoice_id`, `order_id`, `invoice issued date`, `total amount`, `payment status`) VALUES
(1, 2, '1998-07-09', 20, 'equity bank');

-- --------------------------------------------------------

--
-- Stand-in structure for view `billinginvoice_view`
-- (See below for the actual view)
--
CREATE TABLE `billinginvoice_view` (
`invoice_id` int(12)
,`order_id` int(12)
,`invoice issued date` date
,`total amount` int(14)
,`payment status` varchar(30)
);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(34) NOT NULL,
  `names` varchar(50) NOT NULL,
  `cantact` int(10) NOT NULL,
  `order history` varchar(100) NOT NULL,
  `prefered fabric choice` varchar(45) NOT NULL,
  `payment information` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `names`, `cantact`, `order history`, `prefered fabric choice`, `payment information`) VALUES
(1, 'MANZI', 786543212, 'scheduled', 'cotton', 'bk');

-- --------------------------------------------------------

--
-- Stand-in structure for view `customerordersummary`
-- (See below for the actual view)
--
CREATE TABLE `customerordersummary` (
`customer_id` int(34)
,`names` varchar(50)
,`cantact` int(10)
,`order history` varchar(100)
,`prefered fabric choice` varchar(45)
,`payment information` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `customer_view`
-- (See below for the actual view)
--
CREATE TABLE `customer_view` (
`customer_id` int(34)
,`names` varchar(50)
,`cantact` int(10)
,`order history` varchar(100)
,`prefered fabric choice` varchar(45)
,`payment information` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `deletecustomer`
-- (See below for the actual view)
--
CREATE TABLE `deletecustomer` (
`customer_id` int(34)
);

-- --------------------------------------------------------

--
-- Table structure for table `fabric`
--

CREATE TABLE `fabric` (
  `fabric_id` int(23) NOT NULL,
  `fabric type` varchar(34) NOT NULL,
  `fabric color` varchar(23) NOT NULL,
  `fabric design` varchar(45) NOT NULL,
  `price per meter` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fabric`
--

INSERT INTO `fabric` (`fabric_id`, `fabric type`, `fabric color`, `fabric design`, `price per meter`) VALUES
(1, 'fitting', 'red', 'fitting inch', 150);

-- --------------------------------------------------------

--
-- Stand-in structure for view `fabric_view`
-- (See below for the actual view)
--
CREATE TABLE `fabric_view` (
`fabric_id` int(23)
,`fabric type` varchar(34)
,`fabric color` varchar(23)
,`fabric design` varchar(45)
,`price per meter` int(5)
);

-- --------------------------------------------------------

--
-- Table structure for table `inventory item`
--

CREATE TABLE `inventory item` (
  `item_id` int(6) NOT NULL,
  `item name` varchar(23) NOT NULL,
  `description` varchar(32) NOT NULL,
  `quantity in stock` int(12) NOT NULL,
  `supplier_id` int(21) NOT NULL,
  `purchasing price` int(32) NOT NULL,
  `selling price` int(23) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory item`
--

INSERT INTO `inventory item` (`item_id`, `item name`, `description`, `quantity in stock`, `supplier_id`, `purchasing price`, `selling price`) VALUES
(1, 'cotton', 'smoth cotton', 12, 1, 300, 500);

-- --------------------------------------------------------

--
-- Stand-in structure for view `inventory_item_view`
-- (See below for the actual view)
--
CREATE TABLE `inventory_item_view` (
`item_id` int(6)
,`item name` varchar(23)
,`description` varchar(32)
,`quantity in stock` int(12)
,`supplier_id` int(21)
,`purchasing price` int(32)
,`selling price` int(23)
);

-- --------------------------------------------------------

--
-- Table structure for table `order1`
--

CREATE TABLE `order1` (
  `order_id` int(20) NOT NULL,
  `customer_id` int(34) DEFAULT NULL,
  `order date` date NOT NULL,
  `delivery date` date NOT NULL,
  `status` varchar(21) NOT NULL,
  `total amount` int(15) NOT NULL,
  `fabric_id` int(34) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order1`
--

INSERT INTO `order1` (`order_id`, `customer_id`, `order date`, `delivery date`, `status`, `total amount`, `fabric_id`) VALUES
(3, 1, '2022-03-03', '2023-01-12', 'pending', 2300, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `order_view`
-- (See below for the actual view)
--
CREATE TABLE `order_view` (
`order_id` int(20)
,`customer_id` int(34)
,`order date` date
,`delivery date` date
,`status` varchar(21)
,`total amount` int(15)
,`fabric_id` int(34)
);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(15) NOT NULL,
  `first_name` varchar(16) NOT NULL,
  `last_name` varchar(15) NOT NULL,
  `role` varchar(34) NOT NULL,
  `contact_information` int(34) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `first_name`, `last_name`, `role`, `contact_information`) VALUES
(1, 'Nshuti', 'Elie', 'tailor', 783832520);

--
-- Triggers `staff`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteStaff` AFTER DELETE ON `staff` FOR EACH ROW BEGIN
    -- You can include actions to perform after a delete here.
    -- For example, you can log the deletion or send notifications.
    -- This is a placeholder, and you can customize it as needed.
    INSERT INTO staff_delete_log (event_description, deleted_staff_id, deleted_first_name, deleted_last_name)
    VALUES ('Staff member deleted', OLD.staff_id, OLD.first_name, OLD.last_name);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertStaff` AFTER INSERT ON `staff` FOR EACH ROW BEGIN
    -- You can include actions to perform after an insert here.
    -- For example, you can send notifications or log the event.
    -- This is a placeholder, and you can customize it as needed.
    INSERT INTO staff_log (event_description, staff_id, first_name, last_name)
    VALUES ('New staff member added', NEW.staff_id, NEW.first_name, NEW.last_name);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateStaff` AFTER UPDATE ON `staff` FOR EACH ROW BEGIN
    -- You can include actions to perform after an update here.
    -- For example, you can log the update or send notifications.
    -- This is a placeholder, and you can customize it as needed.
    INSERT INTO staff_update_log (event_description, staff_id, new_first_name, new_last_name)
    VALUES ('Staff information updated', NEW.staff_id, NEW.first_name, NEW.last_name);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `staff_view`
-- (See below for the actual view)
--
CREATE TABLE `staff_view` (
`staff_id` int(15)
,`first_name` varchar(16)
,`last_name` varchar(15)
,`role` varchar(34)
,`contact_information` int(34)
);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(12) NOT NULL,
  `supplier_name` varchar(34) NOT NULL,
  `contact_information` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `supplier_name`, `contact_information`) VALUES
(1, 'Hirwa', 783832520);

--
-- Triggers `supplier`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteSupplier` AFTER DELETE ON `supplier` FOR EACH ROW BEGIN
    -- You can include actions to perform after a delete here.
    -- For example, you can log the deletion or send notifications.
    -- This is a placeholder, and you can customize it as needed.
    INSERT INTO supplier_delete_log (event_description, deleted_supplier_id, deleted_supplier_name, deleted_contact_information)
    VALUES ('Supplier deleted', OLD.supplier_id, OLD.supplier_name, OLD.contact_information);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertSupplier` AFTER INSERT ON `supplier` FOR EACH ROW BEGIN
    -- You can include actions to perform after an insert here.
    -- For example, you can send notifications or update related tables.
    -- This is a placeholder, and you can customize it as needed.
    INSERT INTO supplier_log (event_description, supplier_id, supplier_name, contact_information)
    VALUES ('New supplier created', NEW.supplier_id, NEW.supplier_name, NEW.contact_information);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateSupplier` AFTER UPDATE ON `supplier` FOR EACH ROW BEGIN
    -- You can include actions to perform after an update here.
    -- For example, you can log the update or send notifications.
    -- This is a placeholder, and you can customize it as needed.
    INSERT INTO supplier_update_log (event_description, supplier_id, new_supplier_name, new_contact_information)
    VALUES ('Supplier information updated', NEW.supplier_id, NEW.supplier_name, NEW.contact_information);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `supplier_view`
-- (See below for the actual view)
--
CREATE TABLE `supplier_view` (
`supplier_id` int(12)
,`supplier_name` varchar(34)
,`contact_information` int(12)
);

-- --------------------------------------------------------

--
-- Structure for view `appointment_view`
--
DROP TABLE IF EXISTS `appointment_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `appointment_view`  AS SELECT `appointment`.`appointment_id` AS `appointment_id`, `appointment`.`customer_id` AS `customer_id`, `appointment`.`appointment date` AS `appointment date`, `appointment`.`purpose` AS `purpose`, `appointment`.`supplier_id` AS `supplier_id`, `appointment`.`status` AS `status` FROM `appointment` ;

-- --------------------------------------------------------

--
-- Structure for view `billinginvoice_view`
--
DROP TABLE IF EXISTS `billinginvoice_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `billinginvoice_view`  AS SELECT `biling and invoice`.`invoice_id` AS `invoice_id`, `biling and invoice`.`order_id` AS `order_id`, `biling and invoice`.`invoice issued date` AS `invoice issued date`, `biling and invoice`.`total amount` AS `total amount`, `biling and invoice`.`payment status` AS `payment status` FROM `biling and invoice` ;

-- --------------------------------------------------------

--
-- Structure for view `customerordersummary`
--
DROP TABLE IF EXISTS `customerordersummary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customerordersummary`  AS SELECT `customer`.`customer_id` AS `customer_id`, `customer`.`names` AS `names`, `customer`.`cantact` AS `cantact`, `customer`.`order history` AS `order history`, `customer`.`prefered fabric choice` AS `prefered fabric choice`, `customer`.`payment information` AS `payment information` FROM `customer` WHERE `customer`.`customer_id` = (select `customer`.`customer_id` from `customer` where `customer`.`names` = 'MANZI') ;

-- --------------------------------------------------------

--
-- Structure for view `customer_view`
--
DROP TABLE IF EXISTS `customer_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customer_view`  AS SELECT `customer`.`customer_id` AS `customer_id`, `customer`.`names` AS `names`, `customer`.`cantact` AS `cantact`, `customer`.`order history` AS `order history`, `customer`.`prefered fabric choice` AS `prefered fabric choice`, `customer`.`payment information` AS `payment information` FROM `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `deletecustomer`
--
DROP TABLE IF EXISTS `deletecustomer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deletecustomer`  AS SELECT `customer`.`customer_id` AS `customer_id` FROM `customer` ;

-- --------------------------------------------------------

--
-- Structure for view `fabric_view`
--
DROP TABLE IF EXISTS `fabric_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fabric_view`  AS SELECT `fabric`.`fabric_id` AS `fabric_id`, `fabric`.`fabric type` AS `fabric type`, `fabric`.`fabric color` AS `fabric color`, `fabric`.`fabric design` AS `fabric design`, `fabric`.`price per meter` AS `price per meter` FROM `fabric` ;

-- --------------------------------------------------------

--
-- Structure for view `inventory_item_view`
--
DROP TABLE IF EXISTS `inventory_item_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `inventory_item_view`  AS SELECT `inventory item`.`item_id` AS `item_id`, `inventory item`.`item name` AS `item name`, `inventory item`.`description` AS `description`, `inventory item`.`quantity in stock` AS `quantity in stock`, `inventory item`.`supplier_id` AS `supplier_id`, `inventory item`.`purchasing price` AS `purchasing price`, `inventory item`.`selling price` AS `selling price` FROM `inventory item` ;

-- --------------------------------------------------------

--
-- Structure for view `order_view`
--
DROP TABLE IF EXISTS `order_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `order_view`  AS SELECT `order1`.`order_id` AS `order_id`, `order1`.`customer_id` AS `customer_id`, `order1`.`order date` AS `order date`, `order1`.`delivery date` AS `delivery date`, `order1`.`status` AS `status`, `order1`.`total amount` AS `total amount`, `order1`.`fabric_id` AS `fabric_id` FROM `order1` ;

-- --------------------------------------------------------

--
-- Structure for view `staff_view`
--
DROP TABLE IF EXISTS `staff_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `staff_view`  AS SELECT `staff`.`staff_id` AS `staff_id`, `staff`.`first_name` AS `first_name`, `staff`.`last_name` AS `last_name`, `staff`.`role` AS `role`, `staff`.`contact_information` AS `contact_information` FROM `staff` ;

-- --------------------------------------------------------

--
-- Structure for view `supplier_view`
--
DROP TABLE IF EXISTS `supplier_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `supplier_view`  AS SELECT `supplier`.`supplier_id` AS `supplier_id`, `supplier`.`supplier_name` AS `supplier_name`, `supplier`.`contact_information` AS `contact_information` FROM `supplier` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `biling and invoice`
--
ALTER TABLE `biling and invoice`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `fabric`
--
ALTER TABLE `fabric`
  ADD PRIMARY KEY (`fabric_id`);

--
-- Indexes for table `inventory item`
--
ALTER TABLE `inventory item`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `order1`
--
ALTER TABLE `order1`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `fabric_id` (`fabric_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appointment_id` int(34) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `biling and invoice`
--
ALTER TABLE `biling and invoice`
  MODIFY `invoice_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(34) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fabric`
--
ALTER TABLE `fabric`
  MODIFY `fabric_id` int(23) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inventory item`
--
ALTER TABLE `inventory item`
  MODIFY `item_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order1`
--
ALTER TABLE `order1`
  MODIFY `order_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplier_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order1`
--
ALTER TABLE `order1`
  ADD CONSTRAINT `order1_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `order1_ibfk_2` FOREIGN KEY (`fabric_id`) REFERENCES `fabric` (`fabric_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
