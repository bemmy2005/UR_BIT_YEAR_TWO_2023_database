-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2023 at 03:36 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `house_selling`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `alluserdata`
-- (See below for the actual view)
--
CREATE TABLE `alluserdata` (
`UserID` int(11)
,`Username` varchar(255)
,`Password` varchar(255)
,`Email` varchar(255)
,`FirstName` varchar(255)
,`LastName` varchar(255)
,`PhoneNumber` varchar(20)
,`Address` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `CategoryID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CategoryID`, `Name`) VALUES
(1, 'Real Estate');

-- --------------------------------------------------------

--
-- Table structure for table `houselisting`
--

CREATE TABLE `houselisting` (
  `ListingID` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `NumBedrooms` int(11) DEFAULT NULL,
  `NumBathrooms` int(11) DEFAULT NULL,
  `SquareFootage` int(11) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `ListingDate` date DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `SellerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `houselisting`
--

INSERT INTO `houselisting` (`ListingID`, `Title`, `Description`, `Price`, `NumBedrooms`, `NumBathrooms`, `SquareFootage`, `Location`, `ListingDate`, `Status`, `SellerID`) VALUES
(1, 'Cozy Home', 'A lovely home in a quiet neighborhood.', '250000.00', 3, 2, 1800, 'CityA, StateX', '2023-09-13', 'Active', 1);

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `ImageID` int(11) NOT NULL,
  `ImageURL` varchar(255) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `ListingID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`ImageID`, `ImageURL`, `Description`, `ListingID`) VALUES
(1, 'image1.jpg', 'Front view of the house', 1);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `ReviewID` int(11) NOT NULL,
  `Rating` int(11) DEFAULT NULL,
  `Comment` text DEFAULT NULL,
  `ListingID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`ReviewID`, `Rating`, `Comment`, `ListingID`, `UserID`) VALUES
(1, 5, 'Great house and location!', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `TransactionID` int(11) NOT NULL,
  `ListingID` int(11) DEFAULT NULL,
  `BuyerID` int(11) DEFAULT NULL,
  `TransactionDate` date DEFAULT NULL,
  `TransactionAmount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`TransactionID`, `ListingID`, `BuyerID`, `TransactionDate`, `TransactionAmount`) VALUES
(1, 1, 1, '2023-09-14', '250000.00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `Username`, `Password`, `Email`, `FirstName`, `LastName`, `PhoneNumber`, `Address`) VALUES
(1, 'user1', 'password1', 'user1@email.com', 'John', 'Doe', '9876543210', '123 Main St');

-- --------------------------------------------------------

--
-- Structure for view `alluserdata`
--
DROP TABLE IF EXISTS `alluserdata`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `alluserdata`  AS SELECT `user`.`UserID` AS `UserID`, `user`.`Username` AS `Username`, `user`.`Password` AS `Password`, `user`.`Email` AS `Email`, `user`.`FirstName` AS `FirstName`, `user`.`LastName` AS `LastName`, `user`.`PhoneNumber` AS `PhoneNumber`, `user`.`Address` AS `Address` FROM `user` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CategoryID`);

--
-- Indexes for table `houselisting`
--
ALTER TABLE `houselisting`
  ADD PRIMARY KEY (`ListingID`),
  ADD KEY `SellerID` (`SellerID`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`ImageID`),
  ADD KEY `ListingID` (`ListingID`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`ReviewID`),
  ADD KEY `ListingID` (`ListingID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`TransactionID`),
  ADD KEY `ListingID` (`ListingID`),
  ADD KEY `BuyerID` (`BuyerID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `houselisting`
--
ALTER TABLE `houselisting`
  ADD CONSTRAINT `houselisting_ibfk_1` FOREIGN KEY (`SellerID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `image_ibfk_1` FOREIGN KEY (`ListingID`) REFERENCES `houselisting` (`ListingID`);

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`ListingID`) REFERENCES `houselisting` (`ListingID`),
  ADD CONSTRAINT `review_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`ListingID`) REFERENCES `houselisting` (`ListingID`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`BuyerID`) REFERENCES `user` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
