-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2023 at 03:30 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `students attendance system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteClass` (IN `classId` INT)   BEGIN
    DELETE Classes  FROM Classes WHERE class_id = 2;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteDepartment` (IN `department_id` INT)   BEGIN
    DELETE department FROM Department
    WHERE department_id = 3;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAdminsData` ()   BEGIN
SELECT * FROM Admins;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAttendancesData` ()   BEGIN
    SELECT * FROM Attendances;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetClassesData` ()   BEGIN
SELECT * FROM Classes;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetStudents` ()   BEGIN
SELECT * FROM Students;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetTeachersData` ()   BEGIN
    SELECT * FROM Teachers;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetUseraccountsData` ()   BEGIN
SELECT * FROM User accounts;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateCourseName` (IN `courseID` INT, IN `newCourseName` VARCHAR(100))   BEGIN
    UPDATE Courses
    SET course_name = "Advanved Economics"
    WHERE course_id = 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateTeacherEmail` (IN `teacherID` INT, IN `newEmail` VARCHAR(100))   BEGIN
    UPDATE Teachers
    SET email = "janekamikazi@gmail.com"
    WHERE teacher_id = 2;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `Gender` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `password`, `first_name`, `last_name`, `email`, `Gender`) VALUES
(1, 'Alexis@250', 'Alexis_1', 'Alexis', 'KALISA', 'alexiskalis@gmail.com', 'Male'),
(2, 'Andrerut211', 'Rutayis@-2', 'Andre', 'RUTAYISIRE', 'andrerutayisire@gmail.com', 'Male');

--
-- Triggers `admins`
--
DELIMITER $$
CREATE TRIGGER `delete_username_data` AFTER DELETE ON `admins` FOR EACH ROW BEGIN
    DELETE FROM username WHERE admin_id = OLD.admin_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `adminsinformationview`
-- (See below for the actual view)
--
CREATE TABLE `adminsinformationview` (
`admin_id` int(11)
,`username` varchar(50)
,`password` varchar(100)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`email` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `adminsview`
-- (See below for the actual view)
--
CREATE TABLE `adminsview` (
`admin_id` int(11)
,`username` varchar(50)
,`email` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `allclasses`
-- (See below for the actual view)
--
CREATE TABLE `allclasses` (
`class_id` int(11)
,`class_name` varchar(50)
,`course_id` int(11)
,`teacher_id` int(11)
,`class_section` varchar(20)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `allcourses`
-- (See below for the actual view)
--
CREATE TABLE `allcourses` (
`course_id` int(11)
,`course_name` varchar(100)
,`course_code` varchar(20)
,`course_description` varchar(100)
,`teacher_id` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `attendance_date` date DEFAULT NULL,
  `status` enum('Present','Absent','Late') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendance_id`, `student_id`, `course_id`, `attendance_date`, `status`) VALUES
(1, 1, 1, '2023-08-07', 'Present'),
(2, 2, 3, '2023-07-19', 'Present'),
(3, 3, 2, '2023-08-02', 'Absent');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(50) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `class_section` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_id`, `class_name`, `course_id`, `teacher_id`, `class_section`) VALUES
(1, 'Class of Math', 1, 1, 'A'),
(2, 'Class of IT', 3, 2, 'B'),
(3, 'Class of Economics', 2, 3, 'A');

-- --------------------------------------------------------

--
-- Stand-in structure for view `classschedule`
-- (See below for the actual view)
--
CREATE TABLE `classschedule` (
`class_id` int(11)
,`class_name` varchar(50)
,`teacher_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(100) DEFAULT NULL,
  `course_code` varchar(20) DEFAULT NULL,
  `course_description` varchar(100) DEFAULT NULL,
  `teacher_id` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `course_code`, `course_description`, `teacher_id`) VALUES
(1, 'Math', 'Math 101', 'Introduction to Mathematics', '1'),
(2, 'Economics', 'Economics 102', 'Principal of Economics', '3'),
(3, 'IT', 'Information Technolo', 'Introduction to Database', '2');

--
-- Triggers `courses`
--
DELIMITER $$
CREATE TRIGGER `store_deleted_course` AFTER DELETE ON `courses` FOR EACH ROW BEGIN
    INSERT INTO deleted_courses_log (course_code, deletion_date)
    VALUES (OLD.course_code, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `coursesummary`
-- (See below for the actual view)
--
CREATE TABLE `coursesummary` (
`course_name` varchar(100)
,`course_description` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `departmentinfo`
-- (See below for the actual view)
--
CREATE TABLE `departmentinfo` (
`department_id` int(11)
,`department_name` varchar(100)
,`department_head` varchar(100)
,`location` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(100) DEFAULT NULL,
  `department_head` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_name`, `department_head`, `location`) VALUES
(1, 'Mathematics', 'John KAMILI', 'Huye'),
(2, 'Information Technology', 'Jane UMUTONI', 'Kigali'),
(3, 'BIT', 'Michael HIRWA', 'Huye');

-- --------------------------------------------------------

--
-- Stand-in structure for view `departmentview`
-- (See below for the actual view)
--
CREATE TABLE `departmentview` (
`department_id` int(11)
,`department_name` varchar(100)
,`location` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `studentinfo`
-- (See below for the actual view)
--
CREATE TABLE `studentinfo` (
`first_name` varchar(50)
,`last_name` varchar(50)
,`email` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `studentinformation`
-- (See below for the actual view)
--
CREATE TABLE `studentinformation` (
`student_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`date_of_birth` date
,`email` varchar(100)
,`username` varchar(50)
,`password` varchar(50)
,`Address` varchar(100)
,`Attendance_status` varchar(100)
,`Class_section` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Attendance_status` varchar(100) DEFAULT NULL,
  `Class_section` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `first_name`, `last_name`, `date_of_birth`, `email`, `username`, `password`, `Address`, `Attendance_status`, `Class_section`) VALUES
(1, 'Louise', 'NAYITURIKI', '2002-04-15', 'nayiturikiluis4@gmail.com', 'Louise@123', 'Loui345', 'Kgl123', 'Present', 'A'),
(2, 'Jane', 'UMUTONI', '2001-09-20', 'janeumutoni@gmail.com', 'Jne345', 'umut45', 'Gsny34', 'Present', 'A'),
(3, 'Michael', 'MANZI', '2003-02-10', 'michaelmanzi@gmail.com', 'Mich123', 'manzi356', 'Kgl1123', 'Absent', 'B');

--
-- Triggers `students`
--
DELIMITER $$
CREATE TRIGGER `track_email_changes` AFTER UPDATE ON `students` FOR EACH ROW BEGIN
    IF OLD.email <> NEW.email THEN
        INSERT INTO email_change_log (student_id, old_email, new_email, change_date)
        VALUES (OLD.student_id, OLD.email, NEW.email, NOW());
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `teaching_experiment` int(11) DEFAULT NULL,
  `subject_taught` varchar(100) DEFAULT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Department` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `first_name`, `last_name`, `date_of_birth`, `user_name`, `password`, `email`, `teaching_experiment`, `subject_taught`, `Username`, `Department`) VALUES
(1, 'John', 'KAMILI', '1987-09-09', NULL, 'jhn@123', 'johnkamiri@gmail.com', 12, 'Mathematics', 'John123', 'Finance'),
(2, 'Alice', 'KAMIKAZI', '1980-05-02', NULL, 'Alice@123', 'janekamikazi@gmail.com', 10, 'IT', 'Kamikazi250', 'BIT'),
(3, 'Francis', 'HIRWA', '1989-01-02', NULL, 'hirwa2012', 'francishirwa@gmail.com', 12, 'Economics', '@francis1', 'BIT');

--
-- Triggers `teachers`
--
DELIMITER $$
CREATE TRIGGER `track_course_taught_changes` AFTER UPDATE ON `teachers` FOR EACH ROW BEGIN
    IF OLD.Subject_taught <> NEW.Subject_taught THEN
        INSERT INTO audit_teacher_changes (teacher_id, changed_column, old_value, new_value)
        VALUES (NEW.teacher_id, 'course_taught', OLD.Subject_taught, NEW.Subject_taught);
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `teachersinformationview`
-- (See below for the actual view)
--
CREATE TABLE `teachersinformationview` (
`teacher_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`date_of_birth` date
,`user_name` varchar(50)
,`password` varchar(50)
,`email` varchar(100)
,`teaching_experiment` int(11)
,`subject_taught` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `teachersview`
-- (See below for the actual view)
--
CREATE TABLE `teachersview` (
`teacher_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(50)
,`email` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `useraccounts`
--

CREATE TABLE `useraccounts` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(128) DEFAULT NULL,
  `registration_date` date DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `useraccounts`
--

INSERT INTO `useraccounts` (`user_id`, `username`, `email`, `password`, `registration_date`, `role`) VALUES
(1, 'Alexis@250', 'alexiskalisa@gmail.com', 'Alexis_1', '2023-08-19', 'Admin'),
(2, 'Louis@123', 'nayiturikiluis@gmail.com', 'Loui345', '2023-08-19', 'Student'),
(3, '@francis1', 'francishirwa@gmail.com', 'hirwa2012', '2023-08-19', 'Teacher');

-- --------------------------------------------------------

--
-- Stand-in structure for view `useraccountsinformationview`
-- (See below for the actual view)
--
CREATE TABLE `useraccountsinformationview` (
`user_id` int(11)
,`username` varchar(50)
,`email` varchar(100)
,`password` varchar(128)
,`registration_date` date
,`role` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `useraccountsview`
-- (See below for the actual view)
--
CREATE TABLE `useraccountsview` (
`user_id` int(11)
,`username` varchar(50)
,`email` varchar(100)
,`role` varchar(50)
);

-- --------------------------------------------------------

--
-- Structure for view `adminsinformationview`
--
DROP TABLE IF EXISTS `adminsinformationview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `adminsinformationview`  AS SELECT `admins`.`admin_id` AS `admin_id`, `admins`.`username` AS `username`, `admins`.`password` AS `password`, `admins`.`first_name` AS `first_name`, `admins`.`last_name` AS `last_name`, `admins`.`email` AS `email` FROM `admins``admins`  ;

-- --------------------------------------------------------

--
-- Structure for view `adminsview`
--
DROP TABLE IF EXISTS `adminsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `adminsview`  AS SELECT `admins`.`admin_id` AS `admin_id`, `admins`.`username` AS `username`, `admins`.`email` AS `email` FROM `admins``admins`  ;

-- --------------------------------------------------------

--
-- Structure for view `allclasses`
--
DROP TABLE IF EXISTS `allclasses`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `allclasses`  AS SELECT `classes`.`class_id` AS `class_id`, `classes`.`class_name` AS `class_name`, `classes`.`course_id` AS `course_id`, `classes`.`teacher_id` AS `teacher_id`, `classes`.`class_section` AS `class_section` FROM `classes``classes`  ;

-- --------------------------------------------------------

--
-- Structure for view `allcourses`
--
DROP TABLE IF EXISTS `allcourses`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `allcourses`  AS SELECT `courses`.`course_id` AS `course_id`, `courses`.`course_name` AS `course_name`, `courses`.`course_code` AS `course_code`, `courses`.`course_description` AS `course_description`, `courses`.`teacher_id` AS `teacher_id` FROM `courses``courses`  ;

-- --------------------------------------------------------

--
-- Structure for view `classschedule`
--
DROP TABLE IF EXISTS `classschedule`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `classschedule`  AS SELECT `classes`.`class_id` AS `class_id`, `classes`.`class_name` AS `class_name`, `classes`.`teacher_id` AS `teacher_id` FROM `classes``classes`  ;

-- --------------------------------------------------------

--
-- Structure for view `coursesummary`
--
DROP TABLE IF EXISTS `coursesummary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `coursesummary`  AS SELECT `courses`.`course_name` AS `course_name`, `courses`.`course_description` AS `course_description` FROM `courses``courses`  ;

-- --------------------------------------------------------

--
-- Structure for view `departmentinfo`
--
DROP TABLE IF EXISTS `departmentinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `departmentinfo`  AS SELECT `departments`.`department_id` AS `department_id`, `departments`.`department_name` AS `department_name`, `departments`.`department_head` AS `department_head`, `departments`.`location` AS `location` FROM `departments``departments`  ;

-- --------------------------------------------------------

--
-- Structure for view `departmentview`
--
DROP TABLE IF EXISTS `departmentview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `departmentview`  AS SELECT `departments`.`department_id` AS `department_id`, `departments`.`department_name` AS `department_name`, `departments`.`location` AS `location` FROM `departments``departments`  ;

-- --------------------------------------------------------

--
-- Structure for view `studentinfo`
--
DROP TABLE IF EXISTS `studentinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `studentinfo`  AS SELECT `students`.`first_name` AS `first_name`, `students`.`last_name` AS `last_name`, `students`.`email` AS `email` FROM `students``students`  ;

-- --------------------------------------------------------

--
-- Structure for view `studentinformation`
--
DROP TABLE IF EXISTS `studentinformation`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `studentinformation`  AS SELECT `students`.`student_id` AS `student_id`, `students`.`first_name` AS `first_name`, `students`.`last_name` AS `last_name`, `students`.`date_of_birth` AS `date_of_birth`, `students`.`email` AS `email`, `students`.`username` AS `username`, `students`.`password` AS `password`, `students`.`Address` AS `Address`, `students`.`Attendance_status` AS `Attendance_status`, `students`.`Class_section` AS `Class_section` FROM `students``students`  ;

-- --------------------------------------------------------

--
-- Structure for view `teachersinformationview`
--
DROP TABLE IF EXISTS `teachersinformationview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `teachersinformationview`  AS SELECT `teachers`.`teacher_id` AS `teacher_id`, `teachers`.`first_name` AS `first_name`, `teachers`.`last_name` AS `last_name`, `teachers`.`date_of_birth` AS `date_of_birth`, `teachers`.`user_name` AS `user_name`, `teachers`.`password` AS `password`, `teachers`.`email` AS `email`, `teachers`.`teaching_experiment` AS `teaching_experiment`, `teachers`.`subject_taught` AS `subject_taught` FROM `teachers``teachers`  ;

-- --------------------------------------------------------

--
-- Structure for view `teachersview`
--
DROP TABLE IF EXISTS `teachersview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `teachersview`  AS SELECT `teachers`.`teacher_id` AS `teacher_id`, `teachers`.`first_name` AS `first_name`, `teachers`.`last_name` AS `last_name`, `teachers`.`email` AS `email` FROM `teachers``teachers`  ;

-- --------------------------------------------------------

--
-- Structure for view `useraccountsinformationview`
--
DROP TABLE IF EXISTS `useraccountsinformationview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `useraccountsinformationview`  AS SELECT `useraccounts`.`user_id` AS `user_id`, `useraccounts`.`username` AS `username`, `useraccounts`.`email` AS `email`, `useraccounts`.`password` AS `password`, `useraccounts`.`registration_date` AS `registration_date`, `useraccounts`.`role` AS `role` FROM `useraccounts``useraccounts`  ;

-- --------------------------------------------------------

--
-- Structure for view `useraccountsview`
--
DROP TABLE IF EXISTS `useraccountsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `useraccountsview`  AS SELECT `useraccounts`.`user_id` AS `user_id`, `useraccounts`.`username` AS `username`, `useraccounts`.`email` AS `email`, `useraccounts`.`role` AS `role` FROM `useraccounts``useraccounts`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`class_id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `useraccounts`
--
ALTER TABLE `useraccounts`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`),
  ADD CONSTRAINT `classes_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
