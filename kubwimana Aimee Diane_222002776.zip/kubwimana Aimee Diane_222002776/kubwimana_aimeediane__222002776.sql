-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2023 at 09:48 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kubwimana_aimeediane@_222002776`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteAttendanceRecord` (IN `p_AttendanceRecordID` INT)   BEGIN
    DELETE FROM AttendanceRecord
    WHERE AttendanceRecordID = p_AttendanceRecordID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteEmployee` (IN `p_EmployeeID` INT)   BEGIN
    DELETE FROM Employee
    WHERE EmployeeID = p_EmployeeID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAttendanceRecordInformation` ()   BEGIN
    SELECT * FROM AttendanceRecord;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayLeaveInformation` ()   BEGIN
    SELECT * FROM employee_Leave;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_attendancepolicy_Information` ()   BEGIN
    SELECT * FROM attendancepolicy;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_auditlog_Information` ()   BEGIN
    SELECT * FROM auditlog;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_department_Information` ()   BEGIN
    SELECT * FROM department;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_Employee_Information` ()   BEGIN
    SELECT * FROM Employee;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_manager_Information` ()   BEGIN
    SELECT * FROM managers;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_notification_Information` ()   BEGIN
    SELECT * FROM notification;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_report_Information` ()   BEGIN
    SELECT * FROM report;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_setting_Information` ()   BEGIN
    SELECT * FROM settings;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Display_useraccount_Information` ()   BEGIN
    SELECT * FROM useraccount;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertAttendanceRecord` (IN `p_EmployeeID` INT, IN `p_Date` DATE, IN `p_ClockInTime` TIME, IN `p_ClockOutTime` TIME, IN `p_WorkHours` DECIMAL(5,2), IN `p_OvertimeHours` DECIMAL(5,2), IN `p_LateArrival` BOOLEAN, IN `p_EarlyDeparture` BOOLEAN, IN `p_Remarks` TEXT)   BEGIN
    INSERT INTO AttendanceRecord (EmployeeID, Date, ClockInTime, ClockOutTime, WorkHours, OvertimeHours, LateArrival, EarlyDeparture, Remarks)
    VALUES (p_EmployeeID, p_Date, p_ClockInTime, p_ClockOutTime, p_WorkHours, p_OvertimeHours, p_LateArrival, p_EarlyDeparture, p_Remarks);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertAttendanceReport` (IN `p_reportID` INT(11), IN `p_ReportType` VARCHAR(50), IN `p_GenerationDateTime` DATETIME, IN `p_Parameters` TEXT, IN `p_ReportFormat` VARCHAR(20))   BEGIN
    INSERT INTO Report (reportID,
                        ReportType, 
                        GenerationDateTime, 
                        Parameters, 
                        ReportFormat)
    VALUES (p_report,
            p_ReportType, 
            p_GenerationDateTime, 
            p_Parameters, 
            p_ReportFormat);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertDepartment` (IN `p_departmentID` INT(11), IN `p_DepartmentName` VARCHAR(100), IN `p_Manager` VARCHAR(100), IN `p_Description` TEXT)   BEGIN
    INSERT INTO Department (departmentID,
                            DepartmentName, 
                            Manager, 
                            Description)
    VALUES (p_departmentID,
            p_DepartmentName,
            p_Manager, 
            p_Description);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertemployee` (IN `p_id` INT(11), IN `p_FirstName` VARCHAR(50), IN `p_LastName` VARCHAR(50), IN `p_DateOfBirth` DATE, IN `p_ContactInfo` VARCHAR(255), IN `p_DepartmentID` INT, IN `p_Position` VARCHAR(100), IN `p_Supervisor` INT, IN `p_EmploymentStatus` VARCHAR(50), IN `p_HireDate` DATE, IN `p_Salary` DECIMAL(10,2))   BEGIN
    INSERT INTO employee(
 EmployeeID,
FirstName,
LastName,
 DateOfBirth,
 ContactInfo,
 DepartmentID,
 Position,
 Supervisor,
 EmploymentStatus,
 HireDate,
 Salary )
    VALUES (p_employeeID,
        p_FirstName,
            p_LastName,
            p_DateOfBirth,
            p_ContactInfo,
            p_DepartmentID,
            p_Position,
            p_Supervisor,
            p_EmploymentStatus,
            p_HireDate,
            p_Salary);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertLeave_information` (IN `p_leaveID` INT(11), IN `p_EmployeeID` INT, IN `p_LeaveType` VARCHAR(50), IN `p_StartDate` DATE, IN `p_EndDate` DATE, IN `p_TotalLeaveDays` DECIMAL(5,2), IN `p_ApprovalStatus` VARCHAR(20), IN `p_Reason` TEXT, IN `p_SupportingDocuments` BLOB)   BEGIN
    INSERT INTO employee_Leave (leaveID,
                                EmployeeID, 
                                LeaveType, 
                                StartDate, 
                                EndDate, 
                                TotalLeaveDays,
                                ApprovalStatus, 
                                Reason, 
                                SupportingDocuments)
    VALUES (p_leaveID,
            p_EmployeeID, 
            p_LeaveType,
            p_StartDate,
            p_EndDate, 
            p_TotalLeaveDays, 
            p_ApprovalStatus, 
            p_Reason, 
            p_SupportingDocuments);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertmanager` (IN `managerID` INT(11), IN `p_Username` VARCHAR(50), IN `p_password` VARCHAR(50), IN `p_name` VARCHAR(100), IN `p_Contact` VARCHAR(255), IN `p_sex` VARCHAR(120))   BEGIN
    INSERT INTO managers(
ManagerID,
username,
password,
name,
 Contact,
sex
  )
    VALUES (p_managerID,
        p_username,
            p_password,
            p_name,
            p_Contact,
            p_sex);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertNotification` (IN `p_notificationID` INT(30), IN `p_EmployeeID` INT, IN `p_NotificationType` VARCHAR(50), IN `p_Content` TEXT, IN `p_Timestamp` DATETIME, IN `p_Status` VARCHAR(20))   BEGIN
    INSERT INTO Notification (notificationID,
                              EmployeeID, 
                              NotificationType, 
                              Content, 
                              Timestamp, Status)
    VALUES (P_notificationID,
            p_EmployeeID, 
            p_NotificationType, 
            p_Content, 
            p_Timestamp, 
            p_Status);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertUserAccount` (IN `p_userID` INT(11), IN `p_Username` VARCHAR(50), IN `p_Password` VARCHAR(255), IN `p_Role` VARCHAR(50), IN `p_EmployeeID` INT)   BEGIN
    INSERT INTO UserAccount (userID,Username, Password, Role, EmployeeID)
    VALUES ( p_userID,p_Username, p_Password, p_Role, p_EmployeeID);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_departmentdata` (IN `p_departmentID` INT(11), IN `p_departmentname` VARCHAR(50), IN `p_manager` INT(50), IN `p_description` VARCHAR(50))   BEGIN
    UPDATE department
    SET
       DepartmentName= p_new_departmentname,
      Manager= p_new_manager,
       Description=p_new_description
       
    WHERE
        DepartmentIDID= p_department;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_manager_account` (IN `p_managerID` INT(11), IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(50), IN `p_name` VARCHAR(50), IN `p_contact` VARCHAR(50), IN `p_sex` VARCHAR(11))   BEGIN
    UPDATE managers
    SET
        username = p_new_username,
       password = p_new_password,
       name=p_name,
       contact=p_contact,
       sex=p_sex
 WHERE
        managerIDID=p_managerID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ViewDepartmentWithEmployeeCount` ()   BEGIN
    SELECT
        D.DepartmentID,
        D.DepartmentName,
        D.Manager,
        D.Description,
        (SELECT COUNT(*) FROM Employee E WHERE E.DepartmentID = D.DepartmentID) AS EmployeeCount
    FROM Department D;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_manager_information`
-- (See below for the actual view)
--
CREATE TABLE `all_manager_information` (
`managerID` int(11)
,`Username` varchar(50)
,`Password` varchar(255)
,`Name` varchar(20)
,`contact` varchar(20)
,`sex` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `attendancepolicy`
--

CREATE TABLE `attendancepolicy` (
  `PolicyID` int(11) NOT NULL,
  `PolicyName` varchar(100) DEFAULT NULL,
  `MaxWorkHoursPerDay` decimal(5,2) DEFAULT NULL,
  `MinWorkHoursPerDay` decimal(5,2) DEFAULT NULL,
  `OvertimeThreshold` decimal(5,2) DEFAULT NULL,
  `LateArrivalTolerance` int(11) DEFAULT NULL,
  `EarlyDepartureTolerance` int(11) DEFAULT NULL,
  `GracePeriods` int(11) DEFAULT NULL,
  `Holidays` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendancepolicy`
--

INSERT INTO `attendancepolicy` (`PolicyID`, `PolicyName`, `MaxWorkHoursPerDay`, `MinWorkHoursPerDay`, `OvertimeThreshold`, `LateArrivalTolerance`, `EarlyDepartureTolerance`, `GracePeriods`, `Holidays`) VALUES
(2, 'Flexible', '9.00', '7.00', '45.00', 20, 20, 15, '2023-01-01, 2023-12-25'),
(3, 'obey', '7.00', '7.50', '40.00', 15, 15, 10, '2023-01-01, 2023-12-25'),
(4, 'greeting', '1.00', '7.00', '45.00', 20, 20, 15, '2023-01-01, 2023-12-25'),
(5, 'Standard', '8.00', '7.50', '40.00', 15, 15, 10, '2023-01-01, 2023-12-25'),
(6, 'Flexible', '9.00', '7.00', '45.00', 20, 20, 15, '2023-01-01, 2023-12-25'),
(7, 'obey', '7.00', '7.50', '40.00', 15, 15, 10, '2023-01-01, 2023-12-25'),
(8, 'greeting', '1.00', '7.00', '45.00', 20, 20, 15, '2023-01-01, 2023-12-25'),
(9, 'Standard', '8.00', '7.50', '40.00', 15, 15, 10, '2023-01-01, 2023-12-25'),
(10, 'Flexible', '9.00', '7.00', '45.00', 20, 20, 15, '2023-01-01, 2023-12-25'),
(11, 'obey', '7.00', '7.50', '40.00', 15, 15, 10, '2023-01-01, 2023-12-25'),
(12, 'greeting', '1.00', '7.00', '45.00', 20, 20, 15, '2023-01-01, 2023-12-25');

-- --------------------------------------------------------

--
-- Stand-in structure for view `attendancepolicyview`
-- (See below for the actual view)
--
CREATE TABLE `attendancepolicyview` (
`PolicyID` int(11)
,`PolicyName` varchar(100)
,`MaxWorkHoursPerDay` decimal(5,2)
,`MinWorkHoursPerDay` decimal(5,2)
,`OvertimeThreshold` decimal(5,2)
,`LateArrivalTolerance` int(11)
,`EarlyDepartureTolerance` int(11)
,`GracePeriods` int(11)
,`Holidays` text
);

-- --------------------------------------------------------

--
-- Table structure for table `attendancerecord`
--

CREATE TABLE `attendancerecord` (
  `AttendanceRecordID` int(11) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `ClockInTime` time DEFAULT NULL,
  `ClockOutTime` time DEFAULT NULL,
  `WorkHours` decimal(5,2) DEFAULT NULL,
  `OvertimeHours` decimal(5,2) DEFAULT NULL,
  `LateArrival` tinyint(1) DEFAULT NULL,
  `EarlyDeparture` tinyint(1) DEFAULT NULL,
  `Remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendancerecord`
--

INSERT INTO `attendancerecord` (`AttendanceRecordID`, `EmployeeID`, `Date`, `ClockInTime`, `ClockOutTime`, `WorkHours`, `OvertimeHours`, `LateArrival`, `EarlyDeparture`, `Remarks`) VALUES
(1, 1, '2023-09-01', '08:00:00', '17:00:00', '8.00', '0.00', 0, 0, NULL),
(2, 1, '2023-09-02', '08:30:00', '16:45:00', '7.25', '0.25', 1, 0, 'Meeting in the morning'),
(3, 2, '2023-09-01', '09:00:00', '18:00:00', '8.00', '1.00', 0, 1, 'Training session');

--
-- Triggers `attendancerecord`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteAttendanceRecord_information` AFTER DELETE ON `attendancerecord` FOR EACH ROW BEGIN
    UPDATE Employee E
    SET E.TotalWorkHours = E.TotalWorkHours - OLD.WorkHours
    WHERE E.EmployeeID = OLD.EmployeeID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `attendancerecordview`
-- (See below for the actual view)
--
CREATE TABLE `attendancerecordview` (
`AttendanceRecordID` int(11)
,`EmployeeID` int(11)
,`Date` date
,`ClockInTime` time
,`ClockOutTime` time
,`WorkHours` decimal(5,2)
,`OvertimeHours` decimal(5,2)
,`LateArrival` tinyint(1)
,`EarlyDeparture` tinyint(1)
,`Remarks` text
);

-- --------------------------------------------------------

--
-- Table structure for table `auditlog`
--

CREATE TABLE `auditlog` (
  `LogID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Action` varchar(50) DEFAULT NULL,
  `DateTime` datetime DEFAULT NULL,
  `IPAddress` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auditlog`
--

INSERT INTO `auditlog` (`LogID`, `UserID`, `Action`, `DateTime`, `IPAddress`) VALUES
(4, 1, 'Login', '2023-09-01 09:00:00', '192.168.1.100'),
(5, 2, 'Login', '2023-08-20 14:15:00', '192.168.1.110'),
(6, 1, 'Data Modification', '2023-09-02 10:30:00', '192.168.1.100');

-- --------------------------------------------------------

--
-- Stand-in structure for view `deleteattendancepolicy_information`
-- (See below for the actual view)
--
CREATE TABLE `deleteattendancepolicy_information` (
`PolicyID` int(11)
,`PolicyName` varchar(100)
,`MaxWorkHoursPerDay` decimal(5,2)
,`MinWorkHoursPerDay` decimal(5,2)
,`OvertimeThreshold` decimal(5,2)
,`LateArrivalTolerance` int(11)
,`EarlyDepartureTolerance` int(11)
,`GracePeriods` int(11)
,`Holidays` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `deletedepartment_information`
-- (See below for the actual view)
--
CREATE TABLE `deletedepartment_information` (
`DepartmentID` int(11)
,`DepartmentName` varchar(100)
,`Manager` int(11)
,`Description` text
);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `DepartmentID` int(11) NOT NULL,
  `DepartmentName` varchar(100) DEFAULT NULL,
  `Manager` int(11) DEFAULT NULL,
  `Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`DepartmentID`, `DepartmentName`, `Manager`, `Description`) VALUES
(2, 'Development', 2, 'Software development department'),
(3, 'Finance', 3, 'Financial department'),
(4, 'Marketing', 6, 'Marketing and advertising department'),
(5, 'Support', 6, 'Customer support department'),
(6, 'Analytics', 6, 'Data analysis department');

--
-- Triggers `department`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertDepartment` AFTER INSERT ON `department` FOR EACH ROW BEGIN
    INSERT INTO Notification (EmployeeID, NotificationType, Content, Timestamp, Status)
    VALUES (NULL, 'New Department Added', CONCAT('Department ', NEW.DepartmentName, ' has been added.'), NOW(), 'Unread');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `departmentview`
-- (See below for the actual view)
--
CREATE TABLE `departmentview` (
`DepartmentID` int(11)
,`DepartmentName` varchar(100)
,`Manager` int(11)
,`Description` text
);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EmployeeID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `ContactInfo` varchar(255) DEFAULT NULL,
  `DepartmentID` int(11) DEFAULT NULL,
  `Position` varchar(100) DEFAULT NULL,
  `Supervisor` int(11) DEFAULT NULL,
  `EmploymentStatus` varchar(50) DEFAULT NULL,
  `HireDate` date DEFAULT NULL,
  `Salary` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EmployeeID`, `FirstName`, `LastName`, `DateOfBirth`, `ContactInfo`, `DepartmentID`, `Position`, `Supervisor`, `EmploymentStatus`, `HireDate`, `Salary`) VALUES
(1, 'John', 'David', '1990-01-15', 'johndvd@gmail.com', 1, 'Manager', NULL, 'Full-time', '2020-05-10', '60000.00'),
(2, 'Jane', 'Shimwa', '1985-03-22', 'janeshimwa@gmail.com', 2, 'Developer', 1, 'Full-time', '2019-08-17', '55000.00'),
(3, 'bampire', 'mucyo', '1992-07-10', 'michael123@gmail.com', 2, 'Designer', 1, 'Full-time', '2021-01-02', '52000.00'),
(4, 'Emily', 'Berwa', '1988-12-05', 'emilybrown@gmail.com', 3, 'Accountant', 1, 'Full-time', '2018-03-20', '58000.00'),
(5, 'David', 'Lee', '1995-09-18', 'david.lee@gmail.com', 3, 'HR Specialist', 1, 'Full-time', '2020-11-30', '57000.00'),
(6, 'Sarah', 'Wilson', '1993-04-27', 'sarah.wilson@gmail.com', 4, 'Marketing Manager', 1, 'Full-time', '2017-06-12', '62000.00'),
(7, 'Robert', 'Anderson', '1987-02-09', 'robert.anderson@gmail.com', 4, 'Sales Representative', 6, 'Full-time', '2019-09-25', '56000.00'),
(8, 'Olivia', 'Davis', '1991-11-14', 'olivia.davis@gmail.com', 5, 'IT Technician', 6, 'Full-time', '2022-02-15', '54000.00'),
(9, 'William', 'Martinez', '1986-06-30', 'william.martinez@gmail.com', 5, 'Customer Support', 6, 'Full-time', '2020-08-08', '53000.00'),
(10, 'Sophia', 'Taylor', '1994-08-03', 'sophia.taylor@gmail.com', 6, 'Data Analyst', 6, 'Full-time', '2021-04-14', '59000.00');

--
-- Triggers `employee`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteEmployee` AFTER DELETE ON `employee` FOR EACH ROW BEGIN
    INSERT INTO AuditLog (UserID, Action, DateTime, IPAddress)
    VALUES (OLD.EmployeeID, 'Employee Deleted', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertEmployee` AFTER INSERT ON `employee` FOR EACH ROW BEGIN
    INSERT INTO AuditLog (UserID, Action, DateTime, IPAddress)
    VALUES (NEW.EmployeeID, 'New Employee Added', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateEmployee` AFTER UPDATE ON `employee` FOR EACH ROW BEGIN
    INSERT INTO AuditLog (UserID, Action, DateTime, IPAddress)
    VALUES (NEW.EmployeeID, 'Employee Updated', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `employeeview`
-- (See below for the actual view)
--
CREATE TABLE `employeeview` (
`EmployeeID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`DateOfBirth` date
,`ContactInfo` varchar(255)
,`DepartmentID` int(11)
,`Position` varchar(100)
,`Supervisor` int(11)
,`EmploymentStatus` varchar(50)
,`HireDate` date
,`Salary` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `employee_department`
-- (See below for the actual view)
--
CREATE TABLE `employee_department` (
`EmployeeID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`DateOfBirth` date
,`ContactInfo` varchar(255)
,`DepartmentID` int(11)
,`Position` varchar(100)
,`Supervisor` int(11)
,`EmploymentStatus` varchar(50)
,`HireDate` date
,`Salary` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `employee_leave`
--

CREATE TABLE `employee_leave` (
  `LeaveID` int(11) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `LeaveType` varchar(50) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `TotalLeaveDays` decimal(5,2) DEFAULT NULL,
  `ApprovalStatus` varchar(20) DEFAULT NULL,
  `Reason` text DEFAULT NULL,
  `SupportingDocuments` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_leave`
--

INSERT INTO `employee_leave` (`LeaveID`, `EmployeeID`, `LeaveType`, `StartDate`, `EndDate`, `TotalLeaveDays`, `ApprovalStatus`, `Reason`, `SupportingDocuments`) VALUES
(1, 1, 'wedding ceremony', '2023-09-10', '2023-09-15', '5.00', 'Approved', 'Family trip', NULL),
(2, 2, 'giving birth holiday', '2023-08-20', '2023-08-21', '2.00', 'Approved', 'Flu', NULL),
(3, 3, 'Vacation', '2023-11-05', '2023-11-12', '7.00', 'Pending', 'Annual leave', NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `leaveview`
-- (See below for the actual view)
--
CREATE TABLE `leaveview` (
`LeaveID` int(11)
,`EmployeeID` int(11)
,`LeaveType` varchar(50)
,`StartDate` date
,`EndDate` date
,`TotalLeaveDays` decimal(5,2)
,`ApprovalStatus` varchar(20)
,`Reason` text
,`SupportingDocuments` blob
);

-- --------------------------------------------------------

--
-- Table structure for table `managers`
--

CREATE TABLE `managers` (
  `managerID` int(11) NOT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `managers`
--

INSERT INTO `managers` (`managerID`, `Username`, `Password`, `Name`, `contact`, `sex`) VALUES
(1, 'keza', '123', 'byukusenge', '078008976', 'female'),
(2, 'Aimee diane', 'love12', 'rukundo diane', '0786543212', 'female'),
(3, 'mugabo', 'aaa1', 'mugabo patrick', '0780089890', 'male'),
(4, 'keza', '123', 'byukusenge', '078008976', 'female'),
(5, 'Aimee diane', 'love12', 'rukundo diane', '0786543212', 'female'),
(6, 'mugabo', 'aaa1', 'mugabo patrick', '0780089890', 'male');

--
-- Triggers `managers`
--
DELIMITER $$
CREATE TRIGGER `AfterUpdatemanager` AFTER UPDATE ON `managers` FOR EACH ROW BEGIN
    INSERT INTO managers (managerID, Username,Password,Name,contact,sex)
    VALUES (managerID, username, NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `NotificationID` int(11) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `NotificationType` varchar(50) DEFAULT NULL,
  `Content` text DEFAULT NULL,
  `Timestamp` datetime DEFAULT NULL,
  `Status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`NotificationID`, `EmployeeID`, `NotificationType`, `Content`, `Timestamp`, `Status`) VALUES
(1, 1, 'Attendance Warning', 'Late arrival today', '2023-09-01 09:30:00', 'Unread'),
(2, 2, 'Leave Approval', 'Your leave request has been approved', '2023-08-21 16:45:00', 'Read'),
(3, 3, 'Attendance Warning', 'Early departure today', '2023-09-02 16:30:00', 'Unread'),
(4, 1, 'Attendance Warning', 'Late arrival today', '2023-09-01 09:30:00', 'Unread'),
(5, 2, 'Leave Approval', 'Your leave request has been approved', '2023-08-21 16:45:00', 'Read'),
(6, 3, 'Attendance Warning', 'Early departure today', '2023-09-02 16:30:00', 'Unread');

-- --------------------------------------------------------

--
-- Stand-in structure for view `notificationview`
-- (See below for the actual view)
--
CREATE TABLE `notificationview` (
`NotificationID` int(11)
,`EmployeeID` int(11)
,`NotificationType` varchar(50)
,`Content` text
,`Timestamp` datetime
,`Status` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `reportID` int(11) NOT NULL,
  `reporttype` varchar(50) DEFAULT NULL,
  `generationdatetime` date DEFAULT NULL,
  `parameter` varchar(20) DEFAULT NULL,
  `reportformat` varchar(20) DEFAULT NULL,
  `managerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`reportID`, `reporttype`, `generationdatetime`, `parameter`, `reportformat`, `managerID`) VALUES
(7, 'Attendance Summary', '2023-09-01', 'Date Range: 2023-09-', 'PDF', 1),
(8, 'Leave Balance Report', '2023-09-02', 'Employee: John Doe', 'Excel', 1),
(9, 'Overtime Report', '2023-09-05', 'Month: September 202', 'CSV', 3),
(10, 'reward for motivated employee', '2012-09-01', 'Date Range: 2023-09-', 'word document', 2),
(11, 'Leave Balance Report', '2023-09-02', 'Employee: berwa', 'Excel', 1),
(12, 'Overtime Report', '2020-09-05', 'year:  2023', 'CSV', 2);

-- --------------------------------------------------------

--
-- Stand-in structure for view `reportview`
-- (See below for the actual view)
--
CREATE TABLE `reportview` (
`reportID` int(11)
,`reporttype` varchar(50)
,`generationdatetime` date
,`parameter` varchar(20)
,`reportformat` varchar(20)
,`managerID` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `subqueryondepartment`
-- (See below for the actual view)
--
CREATE TABLE `subqueryondepartment` (
`DepartmentID` int(11)
,`DepartmentName` varchar(100)
,`Manager` int(11)
,`Description` text
,`EmployeeCount` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_employee_information`
-- (See below for the actual view)
--
CREATE TABLE `update_employee_information` (
`EmployeeID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`DateOfBirth` date
,`ContactInfo` varchar(255)
,`DepartmentID` int(11)
,`Position` varchar(100)
,`Supervisor` int(11)
,`EmploymentStatus` varchar(50)
,`HireDate` date
,`Salary` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_leave_information`
-- (See below for the actual view)
--
CREATE TABLE `update_leave_information` (
`LeaveID` int(11)
,`EmployeeID` int(11)
,`LeaveType` varchar(50)
,`StartDate` date
,`EndDate` date
,`TotalLeaveDays` decimal(5,2)
,`ApprovalStatus` varchar(20)
,`Reason` text
,`SupportingDocuments` blob
);

-- --------------------------------------------------------

--
-- Table structure for table `useraccount`
--

CREATE TABLE `useraccount` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Role` varchar(20) DEFAULT NULL,
  `AccessPermissions` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `useraccount`
--

INSERT INTO `useraccount` (`UserID`, `Username`, `Password`, `Role`, `AccessPermissions`) VALUES
(1, 'manager', 'aaa', 'view report', 'ckeck attendance'),
(2, 'keza', '11', 'sign', 'attending'),
(3, 'admin', 'hello@', 'control', 'granting privileges');

-- --------------------------------------------------------

--
-- Stand-in structure for view `useraccountview`
-- (See below for the actual view)
--
CREATE TABLE `useraccountview` (
`UserID` int(11)
,`Username` varchar(50)
,`Password` varchar(255)
,`Role` varchar(20)
,`AccessPermissions` text
);

-- --------------------------------------------------------

--
-- Structure for view `all_manager_information`
--
DROP TABLE IF EXISTS `all_manager_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_manager_information`  AS SELECT `managers`.`managerID` AS `managerID`, `managers`.`Username` AS `Username`, `managers`.`Password` AS `Password`, `managers`.`Name` AS `Name`, `managers`.`contact` AS `contact`, `managers`.`sex` AS `sex` FROM `managers``managers`  ;

-- --------------------------------------------------------

--
-- Structure for view `attendancepolicyview`
--
DROP TABLE IF EXISTS `attendancepolicyview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `attendancepolicyview`  AS SELECT `attendancepolicy`.`PolicyID` AS `PolicyID`, `attendancepolicy`.`PolicyName` AS `PolicyName`, `attendancepolicy`.`MaxWorkHoursPerDay` AS `MaxWorkHoursPerDay`, `attendancepolicy`.`MinWorkHoursPerDay` AS `MinWorkHoursPerDay`, `attendancepolicy`.`OvertimeThreshold` AS `OvertimeThreshold`, `attendancepolicy`.`LateArrivalTolerance` AS `LateArrivalTolerance`, `attendancepolicy`.`EarlyDepartureTolerance` AS `EarlyDepartureTolerance`, `attendancepolicy`.`GracePeriods` AS `GracePeriods`, `attendancepolicy`.`Holidays` AS `Holidays` FROM `attendancepolicy``attendancepolicy`  ;

-- --------------------------------------------------------

--
-- Structure for view `attendancerecordview`
--
DROP TABLE IF EXISTS `attendancerecordview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `attendancerecordview`  AS SELECT `attendancerecord`.`AttendanceRecordID` AS `AttendanceRecordID`, `attendancerecord`.`EmployeeID` AS `EmployeeID`, `attendancerecord`.`Date` AS `Date`, `attendancerecord`.`ClockInTime` AS `ClockInTime`, `attendancerecord`.`ClockOutTime` AS `ClockOutTime`, `attendancerecord`.`WorkHours` AS `WorkHours`, `attendancerecord`.`OvertimeHours` AS `OvertimeHours`, `attendancerecord`.`LateArrival` AS `LateArrival`, `attendancerecord`.`EarlyDeparture` AS `EarlyDeparture`, `attendancerecord`.`Remarks` AS `Remarks` FROM `attendancerecord``attendancerecord`  ;

-- --------------------------------------------------------

--
-- Structure for view `deleteattendancepolicy_information`
--
DROP TABLE IF EXISTS `deleteattendancepolicy_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deleteattendancepolicy_information`  AS SELECT `attendancepolicy`.`PolicyID` AS `PolicyID`, `attendancepolicy`.`PolicyName` AS `PolicyName`, `attendancepolicy`.`MaxWorkHoursPerDay` AS `MaxWorkHoursPerDay`, `attendancepolicy`.`MinWorkHoursPerDay` AS `MinWorkHoursPerDay`, `attendancepolicy`.`OvertimeThreshold` AS `OvertimeThreshold`, `attendancepolicy`.`LateArrivalTolerance` AS `LateArrivalTolerance`, `attendancepolicy`.`EarlyDepartureTolerance` AS `EarlyDepartureTolerance`, `attendancepolicy`.`GracePeriods` AS `GracePeriods`, `attendancepolicy`.`Holidays` AS `Holidays` FROM `attendancepolicy` WHERE `attendancepolicy`.`PolicyID` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `deletedepartment_information`
--
DROP TABLE IF EXISTS `deletedepartment_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deletedepartment_information`  AS SELECT `department`.`DepartmentID` AS `DepartmentID`, `department`.`DepartmentName` AS `DepartmentName`, `department`.`Manager` AS `Manager`, `department`.`Description` AS `Description` FROM `department` WHERE `department`.`DepartmentID` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `departmentview`
--
DROP TABLE IF EXISTS `departmentview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `departmentview`  AS SELECT `department`.`DepartmentID` AS `DepartmentID`, `department`.`DepartmentName` AS `DepartmentName`, `department`.`Manager` AS `Manager`, `department`.`Description` AS `Description` FROM `department``department`  ;

-- --------------------------------------------------------

--
-- Structure for view `employeeview`
--
DROP TABLE IF EXISTS `employeeview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `employeeview`  AS SELECT `employee`.`EmployeeID` AS `EmployeeID`, `employee`.`FirstName` AS `FirstName`, `employee`.`LastName` AS `LastName`, `employee`.`DateOfBirth` AS `DateOfBirth`, `employee`.`ContactInfo` AS `ContactInfo`, `employee`.`DepartmentID` AS `DepartmentID`, `employee`.`Position` AS `Position`, `employee`.`Supervisor` AS `Supervisor`, `employee`.`EmploymentStatus` AS `EmploymentStatus`, `employee`.`HireDate` AS `HireDate`, `employee`.`Salary` AS `Salary` FROM `employee``employee`  ;

-- --------------------------------------------------------

--
-- Structure for view `employee_department`
--
DROP TABLE IF EXISTS `employee_department`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `employee_department`  AS SELECT `employee`.`EmployeeID` AS `EmployeeID`, `employee`.`FirstName` AS `FirstName`, `employee`.`LastName` AS `LastName`, `employee`.`DateOfBirth` AS `DateOfBirth`, `employee`.`ContactInfo` AS `ContactInfo`, `employee`.`DepartmentID` AS `DepartmentID`, `employee`.`Position` AS `Position`, `employee`.`Supervisor` AS `Supervisor`, `employee`.`EmploymentStatus` AS `EmploymentStatus`, `employee`.`HireDate` AS `HireDate`, `employee`.`Salary` AS `Salary` FROM `employee``employee`  ;

-- --------------------------------------------------------

--
-- Structure for view `leaveview`
--
DROP TABLE IF EXISTS `leaveview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `leaveview`  AS SELECT `employee_leave`.`LeaveID` AS `LeaveID`, `employee_leave`.`EmployeeID` AS `EmployeeID`, `employee_leave`.`LeaveType` AS `LeaveType`, `employee_leave`.`StartDate` AS `StartDate`, `employee_leave`.`EndDate` AS `EndDate`, `employee_leave`.`TotalLeaveDays` AS `TotalLeaveDays`, `employee_leave`.`ApprovalStatus` AS `ApprovalStatus`, `employee_leave`.`Reason` AS `Reason`, `employee_leave`.`SupportingDocuments` AS `SupportingDocuments` FROM `employee_leave``employee_leave`  ;

-- --------------------------------------------------------

--
-- Structure for view `notificationview`
--
DROP TABLE IF EXISTS `notificationview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `notificationview`  AS SELECT `notification`.`NotificationID` AS `NotificationID`, `notification`.`EmployeeID` AS `EmployeeID`, `notification`.`NotificationType` AS `NotificationType`, `notification`.`Content` AS `Content`, `notification`.`Timestamp` AS `Timestamp`, `notification`.`Status` AS `Status` FROM `notification``notification`  ;

-- --------------------------------------------------------

--
-- Structure for view `reportview`
--
DROP TABLE IF EXISTS `reportview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reportview`  AS SELECT `report`.`reportID` AS `reportID`, `report`.`reporttype` AS `reporttype`, `report`.`generationdatetime` AS `generationdatetime`, `report`.`parameter` AS `parameter`, `report`.`reportformat` AS `reportformat`, `report`.`managerID` AS `managerID` FROM `report``report`  ;

-- --------------------------------------------------------

--
-- Structure for view `subqueryondepartment`
--
DROP TABLE IF EXISTS `subqueryondepartment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `subqueryondepartment`  AS SELECT `d`.`DepartmentID` AS `DepartmentID`, `d`.`DepartmentName` AS `DepartmentName`, `d`.`Manager` AS `Manager`, `d`.`Description` AS `Description`, (select count(0) from `employee` `e` where `e`.`DepartmentID` = `d`.`DepartmentID`) AS `EmployeeCount` FROM `department` AS `d``d`  ;

-- --------------------------------------------------------

--
-- Structure for view `update_employee_information`
--
DROP TABLE IF EXISTS `update_employee_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_employee_information`  AS SELECT `employee`.`EmployeeID` AS `EmployeeID`, `employee`.`FirstName` AS `FirstName`, `employee`.`LastName` AS `LastName`, `employee`.`DateOfBirth` AS `DateOfBirth`, `employee`.`ContactInfo` AS `ContactInfo`, `employee`.`DepartmentID` AS `DepartmentID`, `employee`.`Position` AS `Position`, `employee`.`Supervisor` AS `Supervisor`, `employee`.`EmploymentStatus` AS `EmploymentStatus`, `employee`.`HireDate` AS `HireDate`, `employee`.`Salary` AS `Salary` FROM `employee` WHERE `employee`.`EmployeeID` = 33  ;

-- --------------------------------------------------------

--
-- Structure for view `update_leave_information`
--
DROP TABLE IF EXISTS `update_leave_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_leave_information`  AS SELECT `employee_leave`.`LeaveID` AS `LeaveID`, `employee_leave`.`EmployeeID` AS `EmployeeID`, `employee_leave`.`LeaveType` AS `LeaveType`, `employee_leave`.`StartDate` AS `StartDate`, `employee_leave`.`EndDate` AS `EndDate`, `employee_leave`.`TotalLeaveDays` AS `TotalLeaveDays`, `employee_leave`.`ApprovalStatus` AS `ApprovalStatus`, `employee_leave`.`Reason` AS `Reason`, `employee_leave`.`SupportingDocuments` AS `SupportingDocuments` FROM `employee_leave` WHERE `employee_leave`.`LeaveID` = 22  ;

-- --------------------------------------------------------

--
-- Structure for view `useraccountview`
--
DROP TABLE IF EXISTS `useraccountview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `useraccountview`  AS SELECT `useraccount`.`UserID` AS `UserID`, `useraccount`.`Username` AS `Username`, `useraccount`.`Password` AS `Password`, `useraccount`.`Role` AS `Role`, `useraccount`.`AccessPermissions` AS `AccessPermissions` FROM `useraccount``useraccount`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendancepolicy`
--
ALTER TABLE `attendancepolicy`
  ADD PRIMARY KEY (`PolicyID`);

--
-- Indexes for table `attendancerecord`
--
ALTER TABLE `attendancerecord`
  ADD PRIMARY KEY (`AttendanceRecordID`),
  ADD KEY `EmployeeID` (`EmployeeID`);

--
-- Indexes for table `auditlog`
--
ALTER TABLE `auditlog`
  ADD PRIMARY KEY (`LogID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`DepartmentID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EmployeeID`);

--
-- Indexes for table `employee_leave`
--
ALTER TABLE `employee_leave`
  ADD PRIMARY KEY (`LeaveID`),
  ADD KEY `EmployeeID` (`EmployeeID`);

--
-- Indexes for table `managers`
--
ALTER TABLE `managers`
  ADD PRIMARY KEY (`managerID`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`NotificationID`),
  ADD KEY `EmployeeID` (`EmployeeID`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`reportID`),
  ADD KEY `managerID` (`managerID`);

--
-- Indexes for table `useraccount`
--
ALTER TABLE `useraccount`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendancepolicy`
--
ALTER TABLE `attendancepolicy`
  MODIFY `PolicyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `attendancerecord`
--
ALTER TABLE `attendancerecord`
  MODIFY `AttendanceRecordID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `auditlog`
--
ALTER TABLE `auditlog`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `DepartmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `EmployeeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `employee_leave`
--
ALTER TABLE `employee_leave`
  MODIFY `LeaveID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `managers`
--
ALTER TABLE `managers`
  MODIFY `managerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `NotificationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `reportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `useraccount`
--
ALTER TABLE `useraccount`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendancerecord`
--
ALTER TABLE `attendancerecord`
  ADD CONSTRAINT `attendancerecord_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employee` (`EmployeeID`);

--
-- Constraints for table `auditlog`
--
ALTER TABLE `auditlog`
  ADD CONSTRAINT `auditlog_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `useraccount` (`UserID`);

--
-- Constraints for table `employee_leave`
--
ALTER TABLE `employee_leave`
  ADD CONSTRAINT `employee_leave_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employee` (`EmployeeID`);

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employee` (`EmployeeID`);

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `report_ibfk_1` FOREIGN KEY (`managerID`) REFERENCES `managers` (`managerID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
