-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2023 at 10:37 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostel_reservation_management_system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteDataBasedOnCondition` ()   BEGIN
    -- Delete reservations with 'Cancelled' status from the Reservations table
    DELETE FROM Reservations WHERE CancellationStatus = 'Cancelled';

    -- Delete customers who have no reservations from the Customers table
    DELETE FROM Customers WHERE CustomerID NOT IN (SELECT DISTINCT CustomerID FROM Reservations);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetCustomerReservationHistory` (IN `p_CustomerID` INT)   BEGIN
 SELECT CONCAT(R.RoomID, ' - ', R.CheckInDate, ' to ', R.CheckOutDate) AS Reservation FROM Reservations R WHERE R.CustomerID = p_CustomerID;
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertDataFromView` ()   BEGIN
    -- Insert data into the "Customers" table using the view
    INSERT INTO Customers (FirstName, LastName, Email)
    SELECT FirstName, LastName, Email
    FROM InsertView
    WHERE TableName = 'Customers';

    -- Insert data into the "Rooms" table using the view
    INSERT INTO Rooms (RoomNumber, RoomType, AvailabilityStatus)
    SELECT RoomNumber, RoomType, AvailabilityStatus
    FROM InsertView
    WHERE TableName = 'Rooms';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateCustomerAndRoom` (IN `p_CustomerID` INT, IN `p_NewPhoneNumber` VARCHAR(20), IN `p_NewAddress` TEXT, IN `p_RoomID` INT, IN `p_NewAvailabilityStatus` VARCHAR(20))   BEGIN
 -- Update customer information UPDATE Customers SET PhoneNumber = p_NewPhoneNumber, Address = p_NewAddress WHERE CustomerID = p_CustomerID;
 -- Update room availability status UPDATE Rooms SET AvailabilityStatus = p_NewAvailabilityStatus WHERE RoomID = p_RoomID;
 END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CustomerID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `PaymentInformation` text DEFAULT NULL,
  `Preferences` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CustomerID`, `FirstName`, `LastName`, `Email`, `PhoneNumber`, `Username`, `Password`, `Address`, `PaymentInformation`, `Preferences`) VALUES
(1, 'John', 'Doe', 'johndoe@54.com', '+9998887777', 'johndoe', 'hashedpassword1', '456 New St', 'Credit Card: 1234', 'Non-smoking room, King-sized bed'),
(2, 'Jane', 'Smith', 'janesmith@email.com', '+9876543210', 'janesmith', 'hashedpassword2', '456 Elm St', 'Credit Card: 5678', 'Dormitory, Female-only'),
(3, 'Bob', 'Johnson', 'bobjohnson@ele.com', '+1122334455', 'bobjohnson', 'hashedpassword3', '789 Oak St', 'PayPal: bob@example.com', 'Private room, Ocean view'),
(4, 'John', 'Doe', 'johndoe@email.com', NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'John', 'Doe', 'johndoe@email.com', NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'John', 'Doe', 'johndoe@email.com', NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Triggers `customers`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteCustomer` AFTER DELETE ON `customers` FOR EACH ROW BEGIN 
DELETE FROM Reservations WHERE CustomerID = OLD.CustomerID;
 END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateCustomerAddress` AFTER UPDATE ON `customers` FOR EACH ROW BEGIN 
IF OLD.Address != NEW.Address THEN INSERT INTO CustomerAddressChangeLog (CustomerID, OldAddress, NewAddress, ChangeDate)
 VALUES (NEW.CustomerID, OLD.Address, NEW.Address, NOW());
 END IF;
 END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `customerupdateview`
-- (See below for the actual view)
--
CREATE TABLE `customerupdateview` (
`CustomerID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`Email` varchar(100)
,`PhoneNumber` varchar(20)
,`Username` varchar(50)
,`Password` varchar(100)
,`Address` text
,`PaymentInformation` text
,`Preferences` text
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `display_view`
-- (See below for the actual view)
--
CREATE TABLE `display_view` (
`FirstName` varchar(50)
,`LastName` varchar(50)
,`Email` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertview`
-- (See below for the actual view)
--
CREATE TABLE `insertview` (
`TableName` varchar(9)
,`FirstName` varchar(4)
,`LastName` varchar(6)
,`Email` varchar(17)
);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `PaymentID` int(11) NOT NULL,
  `ReservationID` int(11) DEFAULT NULL,
  `PaymentMethod` varchar(50) DEFAULT NULL,
  `Amount` decimal(10,2) DEFAULT NULL,
  `TransactionDate` date DEFAULT NULL,
  `TransactionStatus` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`PaymentID`, `ReservationID`, `PaymentMethod`, `Amount`, `TransactionDate`, `TransactionStatus`) VALUES
(1, 1, 'Credit Card', 125.00, '2023-09-02', 'Success'),
(2, 2, 'Credit Card', 400.00, '2023-09-03', 'Success'),
(3, 3, 'PayPal', 80.00, '2023-09-04', 'Success');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `ReservationID` int(11) NOT NULL,
  `CustomerID` int(11) DEFAULT NULL,
  `RoomID` int(11) DEFAULT NULL,
  `CheckInDate` date DEFAULT NULL,
  `CheckOutDate` date DEFAULT NULL,
  `BookingDate` date DEFAULT NULL,
  `TotalPrice` decimal(10,2) DEFAULT NULL,
  `PaymentStatus` varchar(20) DEFAULT NULL,
  `CancellationStatus` varchar(20) DEFAULT NULL,
  `CancellationReason` text DEFAULT NULL,
  `SpecialRequests` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`ReservationID`, `CustomerID`, `RoomID`, `CheckInDate`, `CheckOutDate`, `BookingDate`, `TotalPrice`, `PaymentStatus`, `CancellationStatus`, `CancellationReason`, `SpecialRequests`) VALUES
(1, 1, 1, '2023-10-15', '2023-10-20', '2023-09-01', 125.00, 'Paid', 'Not Cancelled', NULL, 'Near the window, extra blankets'),
(2, 2, 2, '2023-11-05', '2023-11-10', '2023-09-02', 400.00, 'Paid', 'Not Cancelled', NULL, 'Late check-in requested'),
(3, 3, 3, '2023-12-01', '2023-12-05', '2023-09-03', 80.00, 'Paid', 'Not Cancelled', NULL, 'Ground floor, close to the exit'),
(4, 3, 3, '2023-12-01', '2023-12-05', '2023-09-03', 80.00, 'Paid', 'Not Cancelled', NULL, 'Ground floor, close to the exit'),
(5, 1, 1, '2023-10-15', '2023-10-20', '2023-09-01', 125.00, 'Paid', 'Not Cancelled', NULL, 'Near the window, extra blankets'),
(6, 2, 2, '2023-11-05', '2023-11-10', '2023-09-02', 400.00, 'Paid', 'Not Cancelled', NULL, 'Late check-in requested'),
(7, 3, 3, '2023-12-01', '2023-12-05', '2023-09-03', 80.00, 'Paid', 'Not Cancelled', NULL, 'Ground floor, close to the exit');

--
-- Triggers `reservations`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteReservation` AFTER DELETE ON `reservations` FOR EACH ROW BEGIN
 UPDATE Rooms SET AvailabilityStatus = 'Available' WHERE RoomID = OLD.RoomID; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertReservation` AFTER INSERT ON `reservations` FOR EACH ROW BEGIN 
UPDATE Rooms SET AvailabilityStatus = 'Booked' WHERE RoomID = NEW.RoomID; 
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateReservation` AFTER UPDATE ON `reservations` FOR EACH ROW BEGIN
 IF NEW.CancellationStatus = 'Cancelled' THEN UPDATE Rooms SET AvailabilityStatus = 'Available' WHERE RoomID = OLD.RoomID;
 END IF;
 END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `RoomID` int(11) NOT NULL,
  `RoomType` varchar(50) DEFAULT NULL,
  `Capacity` int(11) DEFAULT NULL,
  `PricePerNight` decimal(10,2) DEFAULT NULL,
  `AvailabilityStatus` varchar(20) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Facilities` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`RoomID`, `RoomType`, `Capacity`, `PricePerNight`, `AvailabilityStatus`, `Description`, `Facilities`) VALUES
(1, 'Dormitory', 6, 25.00, 'Available', 'Cozy dormitory with bunk beds', 'Free Wi-Fi, Shared bathroom'),
(2, 'Private', 2, 80.00, 'Booked', 'Private room with balcony', 'Ensuite bathroom, TV, Mini-fridge'),
(3, 'Dormitory', 8, 20.00, 'Available', 'Spacious dormitory for large groups', 'Lockers, Common area');

--
-- Triggers `rooms`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertReview` AFTER INSERT ON `rooms` FOR EACH ROW BEGIN 
DECLARE avgRating DECIMAL(3,2); 
SELECT AVG(Rating) INTO avgRating FROM rooms WHERE RoomID = NEW.RoomID;
 UPDATE Rooms SET AverageRating = avgRating WHERE RoomID = NEW.RoomID;
 END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `StaffID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `Role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `FirstName`, `LastName`, `Email`, `PhoneNumber`, `Username`, `Password`, `Role`) VALUES
(1, 'Alice', 'Smith', 'alice@example.com', '+1122334455', 'alice_staff', 'hashedpassword4', 'Manager'),
(2, 'David', 'Lee', 'david@example.com', '+9988776655', 'david_staff', 'hashedpassword5', 'Receptionist');

-- --------------------------------------------------------

--
-- Structure for view `customerupdateview`
--
DROP TABLE IF EXISTS `customerupdateview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customerupdateview`  AS SELECT `customers`.`CustomerID` AS `CustomerID`, `customers`.`FirstName` AS `FirstName`, `customers`.`LastName` AS `LastName`, `customers`.`Email` AS `Email`, `customers`.`PhoneNumber` AS `PhoneNumber`, `customers`.`Username` AS `Username`, `customers`.`Password` AS `Password`, `customers`.`Address` AS `Address`, `customers`.`PaymentInformation` AS `PaymentInformation`, `customers`.`Preferences` AS `Preferences` FROM `customers` ;

-- --------------------------------------------------------

--
-- Structure for view `display_view`
--
DROP TABLE IF EXISTS `display_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `display_view`  AS SELECT `customers`.`FirstName` AS `FirstName`, `customers`.`LastName` AS `LastName`, `customers`.`Email` AS `Email` FROM `customers` ;

-- --------------------------------------------------------

--
-- Structure for view `insertview`
--
DROP TABLE IF EXISTS `insertview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertview`  AS SELECT 'Customers' AS `TableName`, 'John' AS `FirstName`, 'Doe' AS `LastName`, 'johndoe@email.com' AS `Email`union all select 'Rooms' AS `TableName`,'101' AS `RoomNumber`,'Single' AS `RoomType`,'Available' AS `AvailabilityStatus`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustomerID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `ReservationID` (`ReservationID`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`ReservationID`),
  ADD KEY `CustomerID` (`CustomerID`),
  ADD KEY `RoomID` (`RoomID`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`RoomID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`StaffID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `PaymentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `ReservationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `RoomID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `StaffID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`ReservationID`) REFERENCES `reservations` (`ReservationID`);

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customers` (`CustomerID`),
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`RoomID`) REFERENCES `rooms` (`RoomID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
