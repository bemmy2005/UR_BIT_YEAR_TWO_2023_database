-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2023 at 09:19 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_platform_for_renting_tools_or_equipment`
--

-- --------------------------------------------------------

--
-- Table structure for table `delivery_man`
--

CREATE TABLE `delivery_man` (
  `delivery_man_id` int(11) NOT NULL,
  `delivery_man_name` varchar(50) NOT NULL,
  `phone_number` varchar(10) DEFAULT NULL,
  `EMAIL` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `delivery_man`
--

INSERT INTO `delivery_man` (`delivery_man_id`, `delivery_man_name`, `phone_number`, `EMAIL`) VALUES
(1, 'Doe', '123-456-78', 'doe@email.'),
(2, 'Dorcas', '987-654-32', 'Dorcas@ema'),
(3, 'Smith', '555-444-33', 'smith@emai');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL,
  `location_name` varchar(50) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tool_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`location_id`, `location_name`, `user_id`, `tool_id`) VALUES
(1, 'Kigali', NULL, NULL),
(2, 'NYANZA', NULL, NULL),
(3, 'Gisenyi', NULL, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `locations`
-- (See below for the actual view)
--
CREATE TABLE `locations` (
`location_id` int(11)
,`location_name` varchar(50)
,`user_id` int(11)
,`tool_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `rental`
-- (See below for the actual view)
--
CREATE TABLE `rental` (
`rental_id` int(11)
,`rental_start_date` date
,`rental_end_date` date
,`total_cost` int(11)
,`user_id` int(11)
,`tool_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

CREATE TABLE `rentals` (
  `rental_id` int(11) NOT NULL,
  `rental_start_date` date DEFAULT NULL,
  `rental_end_date` date DEFAULT NULL,
  `total_cost` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tool_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`rental_id`, `rental_start_date`, `rental_end_date`, `total_cost`, `user_id`, `tool_id`) VALUES
(1, '2023-09-08', '2023-09-10', 100, NULL, NULL),
(2, '2023-09-10', '2023-09-12', 200, NULL, NULL),
(3, '2023-09-12', '2023-09-14', 300, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tool_equipment`
--

CREATE TABLE `tool_equipment` (
  `tool_id` int(11) NOT NULL,
  `tool_name` varchar(50) NOT NULL,
  `tool_price` int(11) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tool_equipment`
--

INSERT INTO `tool_equipment` (`tool_id`, `tool_name`, `tool_price`, `description`) VALUES
(1, 'Screwdriver', 150, 'A tool used to turn screws'),
(2, 'Hammer', 20, 'A tool used to pound nails'),
(3, 'Saw', 30, 'A tool used to cut wood');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `transaction_name` varchar(50) NOT NULL,
  `transaction_date` date DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tool_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `transaction_name`, `transaction_date`, `amount`, `user_id`, `tool_id`) VALUES
(1, 'Transaction 1', '2023-09-08', 100, NULL, NULL),
(2, 'Transaction 2', '2023-09-10', 200, NULL, NULL),
(3, 'Transaction 3', '2023-09-12', 300, NULL, NULL);

--
-- Triggers `transaction`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertTransaction` AFTER INSERT ON `transaction` FOR EACH ROW BEGIN
    INSERT INTO transaction_audit (transaction_id, action, action_date)
    VALUES (NEW.transaction_id, 'INSERT', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateTransaction` AFTER UPDATE ON `transaction` FOR EACH ROW BEGIN
    INSERT INTO transaction_audit (transaction_id, action, action_date)
    VALUES (NEW.transaction_id, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `PHONE_NUMBER` int(10) DEFAULT NULL,
  `address` varchar(50) NOT NULL,
  `EMAIL` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `PHONE_NUMBER`, `address`, `EMAIL`) VALUES
(1, 'JOHN', 78888, 'KIYOVU', 'john@gmail'),
(2, 'JANE', 78777, 'KICUKIRO', 'jane@gmail'),
(3, 'JACK', 78666, 'KARONGI', 'jack@gmail');

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertUser` AFTER INSERT ON `user` FOR EACH ROW BEGIN
    INSERT INTO user_audit (user_id, action, action_date)
    VALUES (NEW.user_id, 'INSERT', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateUser` AFTER UPDATE ON `user` FOR EACH ROW BEGIN
    INSERT INTO user_audit (user_id, action, action_date)
    VALUES (NEW.user_id, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_deliveryman`
-- (See below for the actual view)
--
CREATE TABLE `view_deliveryman` (
`delivery_man_id` int(11)
,`delivery_man_name` varchar(50)
,`phone_number` varchar(10)
,`EMAIL` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_rental`
-- (See below for the actual view)
--
CREATE TABLE `view_rental` (
`rental_id` int(11)
,`rental_start_date` date
,`rental_end_date` date
,`total_cost` int(11)
,`user_id` int(11)
,`tool_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_tool`
-- (See below for the actual view)
--
CREATE TABLE `view_tool` (
`tool_id` int(11)
,`tool_name` varchar(50)
,`tool_price` int(11)
,`description` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_transaction`
-- (See below for the actual view)
--
CREATE TABLE `view_transaction` (
`transaction_id` int(11)
,`transaction_name` varchar(50)
,`transaction_date` date
,`amount` int(11)
,`user_id` int(11)
,`tool_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_user`
-- (See below for the actual view)
--
CREATE TABLE `view_user` (
`user_id` int(50)
,`user_name` varchar(50)
,`PHONE_NUMBER` int(10)
,`address` varchar(50)
,`EMAIL` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `_user`
-- (See below for the actual view)
--
CREATE TABLE `_user` (
`user_id` int(50)
,`user_name` varchar(50)
,`PHONE_NUMBER` int(10)
,`address` varchar(50)
,`EMAIL` varchar(10)
);

-- --------------------------------------------------------

--
-- Structure for view `locations`
--
DROP TABLE IF EXISTS `locations`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `locations`  AS SELECT `location`.`location_id` AS `location_id`, `location`.`location_name` AS `location_name`, `location`.`user_id` AS `user_id`, `location`.`tool_id` AS `tool_id` FROM `location` ;

-- --------------------------------------------------------

--
-- Structure for view `rental`
--
DROP TABLE IF EXISTS `rental`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `rental`  AS SELECT `rentals`.`rental_id` AS `rental_id`, `rentals`.`rental_start_date` AS `rental_start_date`, `rentals`.`rental_end_date` AS `rental_end_date`, `rentals`.`total_cost` AS `total_cost`, `rentals`.`user_id` AS `user_id`, `rentals`.`tool_id` AS `tool_id` FROM `rentals` ;

-- --------------------------------------------------------

--
-- Structure for view `view_deliveryman`
--
DROP TABLE IF EXISTS `view_deliveryman`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_deliveryman`  AS SELECT `delivery_man`.`delivery_man_id` AS `delivery_man_id`, `delivery_man`.`delivery_man_name` AS `delivery_man_name`, `delivery_man`.`phone_number` AS `phone_number`, `delivery_man`.`EMAIL` AS `EMAIL` FROM `delivery_man` ;

-- --------------------------------------------------------

--
-- Structure for view `view_rental`
--
DROP TABLE IF EXISTS `view_rental`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_rental`  AS SELECT `rentals`.`rental_id` AS `rental_id`, `rentals`.`rental_start_date` AS `rental_start_date`, `rentals`.`rental_end_date` AS `rental_end_date`, `rentals`.`total_cost` AS `total_cost`, `rentals`.`user_id` AS `user_id`, `rentals`.`tool_id` AS `tool_id` FROM `rentals` ;

-- --------------------------------------------------------

--
-- Structure for view `view_tool`
--
DROP TABLE IF EXISTS `view_tool`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_tool`  AS SELECT `tool_equipment`.`tool_id` AS `tool_id`, `tool_equipment`.`tool_name` AS `tool_name`, `tool_equipment`.`tool_price` AS `tool_price`, `tool_equipment`.`description` AS `description` FROM `tool_equipment` ;

-- --------------------------------------------------------

--
-- Structure for view `view_transaction`
--
DROP TABLE IF EXISTS `view_transaction`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_transaction`  AS SELECT `transaction`.`transaction_id` AS `transaction_id`, `transaction`.`transaction_name` AS `transaction_name`, `transaction`.`transaction_date` AS `transaction_date`, `transaction`.`amount` AS `amount`, `transaction`.`user_id` AS `user_id`, `transaction`.`tool_id` AS `tool_id` FROM `transaction` ;

-- --------------------------------------------------------

--
-- Structure for view `view_user`
--
DROP TABLE IF EXISTS `view_user`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_user`  AS SELECT `user`.`user_id` AS `user_id`, `user`.`user_name` AS `user_name`, `user`.`PHONE_NUMBER` AS `PHONE_NUMBER`, `user`.`address` AS `address`, `user`.`EMAIL` AS `EMAIL` FROM `user` ;

-- --------------------------------------------------------

--
-- Structure for view `_user`
--
DROP TABLE IF EXISTS `_user`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `_user`  AS SELECT `user`.`user_id` AS `user_id`, `user`.`user_name` AS `user_name`, `user`.`PHONE_NUMBER` AS `PHONE_NUMBER`, `user`.`address` AS `address`, `user`.`EMAIL` AS `EMAIL` FROM `user` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `delivery_man`
--
ALTER TABLE `delivery_man`
  ADD PRIMARY KEY (`delivery_man_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `tool_id` (`tool_id`);

--
-- Indexes for table `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`rental_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `tool_id` (`tool_id`);

--
-- Indexes for table `tool_equipment`
--
ALTER TABLE `tool_equipment`
  ADD PRIMARY KEY (`tool_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `tool_id` (`tool_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `location_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `location_ibfk_2` FOREIGN KEY (`tool_id`) REFERENCES `tool_equipment` (`tool_id`);

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `rentals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `rentals_ibfk_2` FOREIGN KEY (`tool_id`) REFERENCES `tool_equipment` (`tool_id`);

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`tool_id`) REFERENCES `tool_equipment` (`tool_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
