-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 11:14 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hitimana_fabrice_222010357`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertHealthyRecordData` (IN `p_UserID` INT, IN `p_RecordDate` DATE, IN `p_Height` DECIMAL(5,2), IN `p_Weight` DECIMAL(5,2), IN `p_BloodPressureSystolic` INT, IN `p_BloodPressureDiastolic` INT, IN `p_HeartRate` INT, IN `p_BloodSugarLevel` DECIMAL(5,2), IN `p_CholesterolLevel` DECIMAL(5,2))   BEGIN
    INSERT INTO HealthyRecords (UserID, Date, Height, Weight, BloodPressureSystolic, BloodPressureDiastolic, HeartRate, BloodSugarLevel, CholesterolLevel)
    VALUES (p_UserID, p_RecordDate, p_Height, p_Weight, p_BloodPressureSystolic, p_BloodPressureDiastolic, p_HeartRate, p_BloodSugarLevel, p_CholesterolLevel);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `AppointmentID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `DoctorName` varchar(100) DEFAULT NULL,
  `AppointmentDate` date DEFAULT NULL,
  `AppointmentTime` time DEFAULT NULL,
  `Purpose` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`AppointmentID`, `UserID`, `DoctorName`, `AppointmentDate`, `AppointmentTime`, `Purpose`) VALUES
(1, 1, 'Dr. Smith', '2023-09-10', '10:00:00', 'General checkup'),
(2, 2, 'Dr Fabrice', '2023-10-23', '12:00:00', 'Several Checkup'),
(3, 3, 'Dr Kanimba', '2023-12-01', '08:00:00', 'Cesarienne'),
(4, 4, 'Dr Aline', '2023-12-25', '15:00:00', 'Checking Kidney Cancer');

-- --------------------------------------------------------

--
-- Table structure for table `dietlogs`
--

CREATE TABLE `dietlogs` (
  `LogID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `MealType` varchar(20) DEFAULT NULL,
  `FoodItem` varchar(100) DEFAULT NULL,
  `Quantity` decimal(6,2) DEFAULT NULL,
  `CaloriesConsumed` decimal(6,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dietlogs`
--

INSERT INTO `dietlogs` (`LogID`, `UserID`, `Date`, `MealType`, `FoodItem`, `Quantity`, `CaloriesConsumed`) VALUES
(1, 1, '2023-09-04', 'Breakfast', 'Oatmeal', '200.00', '300.00'),
(2, 2, '2023-10-05', 'Lunch', 'Grilled Chicken Salad', '460.00', '550.00'),
(3, 3, '2023-11-07', 'Nightfood', 'Irish potatoes', '240.00', '450.00'),
(4, 4, '2023-12-15', 'Breakfast', 'Rice', '350.00', '250.00');

-- --------------------------------------------------------

--
-- Table structure for table `exerciselogs`
--

CREATE TABLE `exerciselogs` (
  `LogID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `ExerciseType` varchar(50) DEFAULT NULL,
  `DurationMinutes` int(11) DEFAULT NULL,
  `CaloriesBurned` decimal(6,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `exerciselogs`
--

INSERT INTO `exerciselogs` (`LogID`, `UserID`, `Date`, `ExerciseType`, `DurationMinutes`, `CaloriesBurned`) VALUES
(1, 1, '2023-09-03', 'Running', 45, '350.00'),
(2, 2, '2023-10-03', 'Swimming', 30, '400.50'),
(3, 3, '2023-11-03', 'Playing', 50, '500.00'),
(4, 4, '2023-12-05', 'Praying', 65, '700.00');

-- --------------------------------------------------------

--
-- Table structure for table `healthyrecords`
--

CREATE TABLE `healthyrecords` (
  `RecordID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Height` decimal(5,2) DEFAULT NULL,
  `Weight` decimal(5,2) DEFAULT NULL,
  `BloodPressureSystolic` int(11) DEFAULT NULL,
  `BloodPressureDiastolic` int(11) DEFAULT NULL,
  `HeartRate` int(11) DEFAULT NULL,
  `BloodSugarLevel` decimal(5,2) DEFAULT NULL,
  `CholesterolLevel` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `healthyrecords`
--

INSERT INTO `healthyrecords` (`RecordID`, `UserID`, `Date`, `Height`, `Weight`, `BloodPressureSystolic`, `BloodPressureDiastolic`, `HeartRate`, `BloodSugarLevel`, `CholesterolLevel`) VALUES
(1, 1, '2023-09-01', '175.50', '75.30', 120, 80, 70, '95.50', '150.00'),
(2, 2, '2023-10-01', '180.60', '74.80', 140, 70, 60, '89.60', '180.50'),
(3, 3, '2023-10-25', '190.50', '85.20', 130, 90, 30, '98.50', '140.00');

-- --------------------------------------------------------

--
-- Table structure for table `medicationlogs`
--

CREATE TABLE `medicationlogs` (
  `LogID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `MedicationName` varchar(100) DEFAULT NULL,
  `Dosage` varchar(50) DEFAULT NULL,
  `Frequency` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medicationlogs`
--

INSERT INTO `medicationlogs` (`LogID`, `UserID`, `Date`, `MedicationName`, `Dosage`, `Frequency`) VALUES
(1, 1, '2023-09-05', 'Aspirin', '1 tablet', 'Once daily'),
(2, 2, '2023-09-06', 'Amitriptyline', '2 tablets', 'Twice daily'),
(3, 3, '2023-10-07', 'Adderall', '3 tablets', 'Once daily'),
(4, 4, '2023-11-09', 'Atorvastatin', '5 tablets', 'Twice daily');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `Patient_ID` int(11) NOT NULL,
  `Patient_F_Name` varchar(40) DEFAULT NULL,
  `Patient_l_Name` varchar(40) DEFAULT NULL,
  `Patient_BOB_Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`Patient_ID`, `Patient_F_Name`, `Patient_l_Name`, `Patient_BOB_Date`) VALUES
(1, 'Aline', 'Uwera', '0000-00-00'),
(2, 'Aline', 'Uwera', '0000-00-00'),
(3, 'Cesal', 'Uwacu', '0000-00-00'),
(4, 'Dominique', 'Nzayisenga', '0000-00-00'),
(5, 'Eugenie', 'Mukamana', '0000-00-00');

--
-- Triggers `patients`
--
DELIMITER $$
CREATE TRIGGER `AfterDeletePatient` AFTER DELETE ON `patients` FOR EACH ROW BEGIN
    
    INSERT INTO PatientDeletionLog (PatientID, DeletionDate)
    VALUES (OLD.Patient_ID, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `userinsertview`
-- (See below for the actual view)
--
CREATE TABLE `userinsertview` (
`UserID` binary(0)
,`Username` binary(0)
,`Password` binary(0)
,`Email` binary(0)
,`Name` binary(0)
,`Age` binary(0)
,`Gender` binary(0)
,`ContactNumber` binary(0)
,`Address` binary(0)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `ContactNumber` varchar(20) DEFAULT NULL,
  `Address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Username`, `Password`, `Email`, `Name`, `Age`, `Gender`, `ContactNumber`, `Address`) VALUES
(1, 'user1', 'hashed_password1', 'user1@example.com', 'John Doe', 30, 'Male', '555-123-4567', '123 Main St'),
(2, 'user2', 'hashed_password2', 'jshema01@gmail.com', 'Shema Christian', 25, 'Male', '0785645660', '2345 KNY'),
(3, 'user3', 'hashed_password', 'rukundo04@gmail.com', 'Rukundo Vivens', 22, 'Male', '0789512109', '567gknk'),
(4, 'user4', 'hashed_password6', 'alice12@gmail.com', 'Umwari Alice', 20, 'Female', '0723461759', '567NYBHRW');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertUsers` AFTER INSERT ON `users` FOR EACH ROW BEGIN
    
    INSERT INTO UserActivityLog (UserID, Action, Timestamp)
    VALUES (NEW.UserID, 'User Created', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateUsers` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
    
    INSERT INTO UserActivityLog (UserID, Action, Timestamp)
    VALUES (NEW.UserID, 'User Updated', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `usersview`
-- (See below for the actual view)
--
CREATE TABLE `usersview` (
`UserID` int(11)
,`Username` varchar(50)
,`Email` varchar(100)
);

-- --------------------------------------------------------

--
-- Structure for view `userinsertview`
--
DROP TABLE IF EXISTS `userinsertview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `userinsertview`  AS SELECT NULL AS `UserID`, NULL AS `Username`, NULL AS `Password`, NULL AS `Email`, NULL AS `Name`, NULL AS `Age`, NULL AS `Gender`, NULL AS `ContactNumber`, NULL AS `Address``Address`  ;

-- --------------------------------------------------------

--
-- Structure for view `usersview`
--
DROP TABLE IF EXISTS `usersview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `usersview`  AS SELECT `users`.`UserID` AS `UserID`, `users`.`Username` AS `Username`, `users`.`Email` AS `Email` FROM `users``users`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`AppointmentID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `dietlogs`
--
ALTER TABLE `dietlogs`
  ADD PRIMARY KEY (`LogID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `exerciselogs`
--
ALTER TABLE `exerciselogs`
  ADD PRIMARY KEY (`LogID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `healthyrecords`
--
ALTER TABLE `healthyrecords`
  ADD PRIMARY KEY (`RecordID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `medicationlogs`
--
ALTER TABLE `medicationlogs`
  ADD PRIMARY KEY (`LogID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`Patient_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `AppointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dietlogs`
--
ALTER TABLE `dietlogs`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `exerciselogs`
--
ALTER TABLE `exerciselogs`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `healthyrecords`
--
ALTER TABLE `healthyrecords`
  MODIFY `RecordID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `medicationlogs`
--
ALTER TABLE `medicationlogs`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `dietlogs`
--
ALTER TABLE `dietlogs`
  ADD CONSTRAINT `dietlogs_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `exerciselogs`
--
ALTER TABLE `exerciselogs`
  ADD CONSTRAINT `exerciselogs_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `healthyrecords`
--
ALTER TABLE `healthyrecords`
  ADD CONSTRAINT `healthyrecords_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `medicationlogs`
--
ALTER TABLE `medicationlogs`
  ADD CONSTRAINT `medicationlogs_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
