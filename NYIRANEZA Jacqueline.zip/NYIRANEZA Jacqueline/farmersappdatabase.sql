-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2023 at 06:26 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `farmersappdatabase`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteOrdersByStatus` (IN `p_OrderStatus` VARCHAR(20))   BEGIN
    DELETE FROM Orders
    WHERE OrderStatus = p_OrderStatus;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllFarmersInfo` ()   BEGIN
    SELECT * FROM Farmers;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FarmersWithHighestFarmSizes` ()   BEGIN
    SELECT FarmerID, FirstName, LastName, FarmSize
    FROM Farmers
    WHERE FarmSize = (SELECT MAX(FarmSize) FROM Farmers);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertFarmer` (IN `p_FirstName` VARCHAR(50), IN `p_LastName` VARCHAR(50), IN `p_ContactNumber` VARCHAR(20), IN `p_Email` VARCHAR(100), IN `p_FarmLocation` VARCHAR(255), IN `p_FarmSize` DECIMAL(10,2), IN `p_MembershipStatus` VARCHAR(20))   BEGIN
    INSERT INTO Farmers (FirstName, LastName, ContactNumber, Email, FarmLocation, FarmSize, MembershipStatus)
    VALUES (p_FirstName, p_LastName, p_ContactNumber, p_Email, p_FarmLocation, p_FarmSize, p_MembershipStatus);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateFarmerEmail` (IN `p_FarmerID` INT, IN `p_NewEmail` VARCHAR(100))   BEGIN
    UPDATE Farmers
    SET Email = p_NewEmail
    WHERE FarmerID = p_FarmerID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `allfarmersinfo`
-- (See below for the actual view)
--
CREATE TABLE `allfarmersinfo` (
`FarmerID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`ContactNumber` varchar(20)
,`Email` varchar(100)
,`FarmLocation` varchar(255)
,`FarmSize` decimal(10,2)
,`MembershipStatus` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `analyticsusagedata`
--

CREATE TABLE `analyticsusagedata` (
  `AnalyticsID` int(11) NOT NULL,
  `Date` date DEFAULT NULL,
  `ProductsViewed` int(11) DEFAULT NULL,
  `ProductsPurchased` int(11) DEFAULT NULL,
  `SearchQueries` int(11) DEFAULT NULL,
  `AppUsageStatistics` text DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `deleteordersbystatus`
-- (See below for the actual view)
--
CREATE TABLE `deleteordersbystatus` (
`OrderID` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `farmers`
--

CREATE TABLE `farmers` (
  `FarmerID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `ContactNumber` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `FarmLocation` varchar(255) DEFAULT NULL,
  `FarmSize` decimal(10,2) DEFAULT NULL,
  `MembershipStatus` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farmers`
--

INSERT INTO `farmers` (`FarmerID`, `FirstName`, `LastName`, `ContactNumber`, `Email`, `FarmLocation`, `FarmSize`, `MembershipStatus`) VALUES
(1, 'John', 'Doe', '123-456-7890', 'updated_email@example.com', '123 Main St', 50.50, 'Premium'),
(2, 'Alice', 'Johnson', '987-654-3210', 'alice@example.com', '456 Elm St', 75.50, 'Free'),
(3, 'Alice', 'Johnson', '987-654-3210', 'alice@example.com', '456 Elm St', 75.50, 'Free');

--
-- Triggers `farmers`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteFarmer` AFTER DELETE ON `farmers` FOR EACH ROW BEGIN
    DELETE FROM Orders WHERE FarmerID = OLD.FarmerID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertFarmer` AFTER INSERT ON `farmers` FOR EACH ROW BEGIN
    INSERT INTO FarmerAudit (Action, FarmerID, RegistrationDate)
    VALUES ('Insert', NEW.FarmerID, NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateFarmer` AFTER UPDATE ON `farmers` FOR EACH ROW BEGIN
    INSERT INTO FarmerAudit (Action, FarmerID, FieldChanged, OldValue, NewValue, ChangeDate)
    VALUES ('Update', NEW.FarmerID, 'Email', OLD.Email, NEW.Email, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `farmersassociations`
--

CREATE TABLE `farmersassociations` (
  `AssociationID` int(11) NOT NULL,
  `AssociationName` varchar(100) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `ContactPerson` varchar(100) DEFAULT NULL,
  `ContactEmail` varchar(100) DEFAULT NULL,
  `ContactPhone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farmersassociations`
--

INSERT INTO `farmersassociations` (`AssociationID`, `AssociationName`, `Location`, `ContactPerson`, `ContactEmail`, `ContactPhone`) VALUES
(1, 'Farmers United', '456 Oak St', 'Jane Smith', 'jane@example.com', '987-654-3210');

-- --------------------------------------------------------

--
-- Stand-in structure for view `farmerswithhighestfarmsizes`
-- (See below for the actual view)
--
CREATE TABLE `farmerswithhighestfarmsizes` (
`FarmerID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`FarmSize` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `feedbacksupport`
--

CREATE TABLE `feedbacksupport` (
  `FeedbackID` int(11) NOT NULL,
  `FeedbackType` varchar(50) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `geolocationdata`
--

CREATE TABLE `geolocationdata` (
  `LocationID` int(11) NOT NULL,
  `Latitude` decimal(9,6) DEFAULT NULL,
  `Longitude` decimal(9,6) DEFAULT NULL,
  `LocationName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertintofarmers`
-- (See below for the actual view)
--
CREATE TABLE `insertintofarmers` (
`FarmerID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`ContactNumber` varchar(20)
,`Email` varchar(100)
,`FarmLocation` varchar(255)
,`FarmSize` decimal(10,2)
,`MembershipStatus` varchar(20)
);

-- --------------------------------------------------------

--
-- Table structure for table `messaging`
--

CREATE TABLE `messaging` (
  `MessageID` int(11) NOT NULL,
  `MessageContent` text DEFAULT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ReadStatus` tinyint(1) DEFAULT NULL,
  `SenderID` int(11) DEFAULT NULL,
  `ReceiverID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `TotalPrice` decimal(10,2) DEFAULT NULL,
  `OrderDate` date DEFAULT NULL,
  `OrderStatus` varchar(20) DEFAULT NULL,
  `FarmerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `Quantity`, `TotalPrice`, `OrderDate`, `OrderStatus`, `FarmerID`) VALUES
(1, 100, 1099.00, '2023-09-15', 'Completed', 1);

-- --------------------------------------------------------

--
-- Table structure for table `paymenttransactions`
--

CREATE TABLE `paymenttransactions` (
  `TransactionID` int(11) NOT NULL,
  `PaymentMethod` varchar(50) DEFAULT NULL,
  `Amount` decimal(10,2) DEFAULT NULL,
  `PaymentStatus` varchar(20) DEFAULT NULL,
  `PaymentDate` date DEFAULT NULL,
  `OrderID` int(11) DEFAULT NULL,
  `FarmerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paymenttransactions`
--

INSERT INTO `paymenttransactions` (`TransactionID`, `PaymentMethod`, `Amount`, `PaymentStatus`, `PaymentDate`, `OrderID`, `FarmerID`) VALUES
(1, 'Credit Card', 1099.00, 'Paid', '2023-09-15', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductID` int(11) NOT NULL,
  `ProductName` varchar(100) DEFAULT NULL,
  `Category` varchar(50) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `UnitOfMeasurement` varchar(20) DEFAULT NULL,
  `Availability` tinyint(1) DEFAULT NULL,
  `FarmerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `ProductName`, `Category`, `Description`, `Price`, `UnitOfMeasurement`, `Availability`, `FarmerID`) VALUES
(1, 'Wheat', 'Crops', 'High-quality wheat grains', 10.99, 'kg', 1, 1);

--
-- Triggers `products`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteProduct` AFTER DELETE ON `products` FOR EACH ROW BEGIN
    UPDATE Farmers
    SET ProductCount = ProductCount - 1
    WHERE FarmerID = OLD.FarmerID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertProduct` AFTER INSERT ON `products` FOR EACH ROW BEGIN
    UPDATE Farmers
    SET ProductCount = ProductCount + 1
    WHERE FarmerID = NEW.FarmerID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `promotionsdiscounts`
--

CREATE TABLE `promotionsdiscounts` (
  `PromotionID` int(11) NOT NULL,
  `DiscountPercentage` decimal(5,2) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `ProductID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `ReviewID` int(11) NOT NULL,
  `Rating` int(11) DEFAULT NULL,
  `Comment` text DEFAULT NULL,
  `ProductID` int(11) DEFAULT NULL,
  `FarmerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`ReviewID`, `Rating`, `Comment`, `ProductID`, `FarmerID`) VALUES
(1, 5, 'Excellent product!', 1, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatefarmerinfo`
-- (See below for the actual view)
--
CREATE TABLE `updatefarmerinfo` (
`FarmerID` int(11)
,`FirstName` varchar(50)
,`LastName` varchar(50)
,`Email` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `AccountType` varchar(20) DEFAULT NULL,
  `ProfilePictureURL` varchar(255) DEFAULT NULL,
  `LastLoginDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure for view `allfarmersinfo`
--
DROP TABLE IF EXISTS `allfarmersinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `allfarmersinfo`  AS SELECT `farmers`.`FarmerID` AS `FarmerID`, `farmers`.`FirstName` AS `FirstName`, `farmers`.`LastName` AS `LastName`, `farmers`.`ContactNumber` AS `ContactNumber`, `farmers`.`Email` AS `Email`, `farmers`.`FarmLocation` AS `FarmLocation`, `farmers`.`FarmSize` AS `FarmSize`, `farmers`.`MembershipStatus` AS `MembershipStatus` FROM `farmers` ;

-- --------------------------------------------------------

--
-- Structure for view `deleteordersbystatus`
--
DROP TABLE IF EXISTS `deleteordersbystatus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deleteordersbystatus`  AS SELECT `orders`.`OrderID` AS `OrderID` FROM `orders` WHERE `orders`.`OrderStatus` = 'Cancelled' ;

-- --------------------------------------------------------

--
-- Structure for view `farmerswithhighestfarmsizes`
--
DROP TABLE IF EXISTS `farmerswithhighestfarmsizes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `farmerswithhighestfarmsizes`  AS SELECT `farmers`.`FarmerID` AS `FarmerID`, `farmers`.`FirstName` AS `FirstName`, `farmers`.`LastName` AS `LastName`, `farmers`.`FarmSize` AS `FarmSize` FROM `farmers` WHERE `farmers`.`FarmSize` = (select max(`farmers`.`FarmSize`) from `farmers`) ;

-- --------------------------------------------------------

--
-- Structure for view `insertintofarmers`
--
DROP TABLE IF EXISTS `insertintofarmers`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertintofarmers`  AS SELECT `farmers`.`FarmerID` AS `FarmerID`, `farmers`.`FirstName` AS `FirstName`, `farmers`.`LastName` AS `LastName`, `farmers`.`ContactNumber` AS `ContactNumber`, `farmers`.`Email` AS `Email`, `farmers`.`FarmLocation` AS `FarmLocation`, `farmers`.`FarmSize` AS `FarmSize`, `farmers`.`MembershipStatus` AS `MembershipStatus` FROM `farmers` ;

-- --------------------------------------------------------

--
-- Structure for view `updatefarmerinfo`
--
DROP TABLE IF EXISTS `updatefarmerinfo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatefarmerinfo`  AS SELECT `farmers`.`FarmerID` AS `FarmerID`, `farmers`.`FirstName` AS `FirstName`, `farmers`.`LastName` AS `LastName`, `farmers`.`Email` AS `Email` FROM `farmers` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `analyticsusagedata`
--
ALTER TABLE `analyticsusagedata`
  ADD PRIMARY KEY (`AnalyticsID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `farmers`
--
ALTER TABLE `farmers`
  ADD PRIMARY KEY (`FarmerID`);

--
-- Indexes for table `farmersassociations`
--
ALTER TABLE `farmersassociations`
  ADD PRIMARY KEY (`AssociationID`);

--
-- Indexes for table `feedbacksupport`
--
ALTER TABLE `feedbacksupport`
  ADD PRIMARY KEY (`FeedbackID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `geolocationdata`
--
ALTER TABLE `geolocationdata`
  ADD PRIMARY KEY (`LocationID`);

--
-- Indexes for table `messaging`
--
ALTER TABLE `messaging`
  ADD PRIMARY KEY (`MessageID`),
  ADD KEY `SenderID` (`SenderID`),
  ADD KEY `ReceiverID` (`ReceiverID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `FarmerID` (`FarmerID`);

--
-- Indexes for table `paymenttransactions`
--
ALTER TABLE `paymenttransactions`
  ADD PRIMARY KEY (`TransactionID`),
  ADD KEY `OrderID` (`OrderID`),
  ADD KEY `FarmerID` (`FarmerID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductID`),
  ADD KEY `FarmerID` (`FarmerID`);

--
-- Indexes for table `promotionsdiscounts`
--
ALTER TABLE `promotionsdiscounts`
  ADD PRIMARY KEY (`PromotionID`),
  ADD KEY `ProductID` (`ProductID`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`ReviewID`),
  ADD KEY `ProductID` (`ProductID`),
  ADD KEY `FarmerID` (`FarmerID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `analyticsusagedata`
--
ALTER TABLE `analyticsusagedata`
  MODIFY `AnalyticsID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `farmers`
--
ALTER TABLE `farmers`
  MODIFY `FarmerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `farmersassociations`
--
ALTER TABLE `farmersassociations`
  MODIFY `AssociationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedbacksupport`
--
ALTER TABLE `feedbacksupport`
  MODIFY `FeedbackID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `geolocationdata`
--
ALTER TABLE `geolocationdata`
  MODIFY `LocationID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messaging`
--
ALTER TABLE `messaging`
  MODIFY `MessageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `paymenttransactions`
--
ALTER TABLE `paymenttransactions`
  MODIFY `TransactionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `promotionsdiscounts`
--
ALTER TABLE `promotionsdiscounts`
  MODIFY `PromotionID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `ReviewID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `analyticsusagedata`
--
ALTER TABLE `analyticsusagedata`
  ADD CONSTRAINT `analyticsusagedata_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `feedbacksupport`
--
ALTER TABLE `feedbacksupport`
  ADD CONSTRAINT `feedbacksupport_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `messaging`
--
ALTER TABLE `messaging`
  ADD CONSTRAINT `messaging_ibfk_1` FOREIGN KEY (`SenderID`) REFERENCES `farmers` (`FarmerID`),
  ADD CONSTRAINT `messaging_ibfk_2` FOREIGN KEY (`ReceiverID`) REFERENCES `farmers` (`FarmerID`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`FarmerID`) REFERENCES `farmers` (`FarmerID`);

--
-- Constraints for table `paymenttransactions`
--
ALTER TABLE `paymenttransactions`
  ADD CONSTRAINT `paymenttransactions_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`),
  ADD CONSTRAINT `paymenttransactions_ibfk_2` FOREIGN KEY (`FarmerID`) REFERENCES `farmers` (`FarmerID`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`FarmerID`) REFERENCES `farmers` (`FarmerID`);

--
-- Constraints for table `promotionsdiscounts`
--
ALTER TABLE `promotionsdiscounts`
  ADD CONSTRAINT `promotionsdiscounts_ibfk_1` FOREIGN KEY (`ProductID`) REFERENCES `products` (`ProductID`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`ProductID`) REFERENCES `products` (`ProductID`),
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`FarmerID`) REFERENCES `farmers` (`FarmerID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
