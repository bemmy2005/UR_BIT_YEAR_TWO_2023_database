-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 02:05 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookingticketmanagementsystem`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Deleteevent` (IN `p_eventid` INT)   BEGIN
    DELETE FROM user
    WHERE eventid = p_eventid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Deleteuser` (IN `p_userid` INT)   BEGIN
    DELETE FROM user
    WHERE userid = p_userid;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplaybookingInformation` ()   BEGIN
    SELECT * FROM booking;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayeventInformation` ()   BEGIN
    SELECT * FROM event;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplaynotificationInformation` ()   BEGIN
    SELECT * FROM notification;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayorganizerInformation` ()   BEGIN
    SELECT * FROM organizer;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplaypaymentInformation` ()   BEGIN
    SELECT * FROM payment;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayreportInformation` ()   BEGIN
    SELECT * FROM report;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayreviewInformation` ()   BEGIN
    SELECT * FROM review;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayticketInformation` ()   BEGIN
    SELECT * FROM ticket;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplaytransactionInformation` ()   BEGIN
    SELECT * FROM transaction;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayuserInformation` ()   BEGIN
    SELECT * FROM user;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayvenueInformation` ()   BEGIN
    SELECT * FROM venue;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertbookingid` (IN `p_bookingid` INT, IN `p_userid` INT, IN `p_eventid` INT, IN `p_bookingdateandtime` DATE, IN `p_numberofticket` INT, IN `p_totalprice` INT, IN `p_bookingtatus` VARCHAR(50))   BEGIN
    INSERT INTO booking(
bookingid,
userid,
eventid,
bookingdateandtime,
numberofticket,
totalprice,
 bookingstatus )
    VALUES (p_bookingid,
p_userid,
p_eventid,
p_bookingdateandtime,
p_numberofticket,
p_totalprice,
p_bookingstatus);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertevent` (IN `p_eventid` INT, IN `p_eventname` VARCHAR(40), IN `p_eventdate` DATE, IN `p_eventtime` INT(11), IN `p_eventlocation` VARCHAR(30), IN `p_eventdescription` VARCHAR(50), IN `p_eventcapacity` VARCHAR(30), IN `p_ticketprice` INT(11), IN `p_eventorganizer` VARCHAR(50))   BEGIN
    INSERT INTO event (eventid,eventname,eventdate,eventtime, eventlocation ,eventdescription,eventcapacity, ticketprice,eventorganizer)
    VALUES (p_eventid,p_eventname,p_eventdate,p_eventtime, p_eventlocation ,p_eventdescription,p_eventcapacity, p_ticketprice,p_eventorganizer);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertnotification` (IN `p_notificationid` INT(11), IN `p_userid` INT(11), IN `p_notificationtype` VARCHAR(30), IN `p_notificationmessage` VARCHAR(50), IN `p_notificationdateandtime` DATE, IN `p_notificationstatus` VARCHAR(50))   BEGIN
    INSERT INTO notification(
notificationid,
userid,
notificationtype,
notificationmessage,
notificationdateandtime,
notificationstatus )
    VALUES (p_notificationid,
p_userid,
p_notificationtype,
p_notificationdateandtime,
p_notificationstatus);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertorganizer` (IN `p_organizer` INT(11), IN `p_organizername` VARCHAR(50), IN `p_organizercontactinformation` INT(11), IN `p_organizerevents` VARCHAR(50))   BEGIN
    INSERT INTO organizer(
organizeridid,
organizername,
organizercontactinformation ,
organizerevents)
    VALUES (p_organizerid,
p_organizername,
p_organizercontactinformation,
p_organizerevents);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertpayment` (IN `p_paymentid` INT, IN `p_bookingid` INT, IN `p_paymentdateandtime` DATE, IN `p_paymentamount` INT, IN `p_paymentmethod` VARCHAR(30), IN `p_transactionstatus` VARCHAR(50))   BEGIN
    INSERT INTO payment (paymentid,bookingid,paymentdateandtime,paymentamount,paymentmethod ,transactionstatus)
    VALUES ( p_paymentid,p_bookingid,p_paymentdateandtime,p_paymentamount,p_paymentmethod,p_transactionstatus);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertreport` (IN `p_reportid` INT, IN `p_reporttype` VARCHAR(50), IN `p_reportgenerationdateandtime` DATE, IN `p_reportcontent` VARCHAR(50))   BEGIN
    INSERT INTO report  (reportid,reporttype,reportgenerationdateandtime,reportcontent)
    VALUES ( p_reportid,p_reporttype,p_reportgenerationdateandtime,p_reportcontent);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertreview` (IN `p_reviewid` INT, IN `p_usedid` INT, IN `p_eventid` INT, IN `p_reviewtext` VARCHAR(50), IN `p_rating` INT)   BEGIN
    INSERT INTO review (reviewid,usedid,eventid,reviewtext,rating)
    VALUES ( p_reviewid,p_usedid,p_eventid,p_reviewtext,p_rating);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertticket` (IN `p_ticketidid` INT, IN `p_tickettype` VARCHAR(40), IN `p_eventid` INT, IN `p_seatnumber` INT(11), IN `p_ticketprice` INT(11), IN `p_purchasedate` DATE, IN `p_ticketstatus` VARCHAR(30), IN `p_userid` INT(11))   BEGIN
    INSERT INTO event (ticketid,tickettype,eventid,seatnumber,ticketprice,purchasedate,ticketstatus,userid)
    VALUES (p_ticketid,p_tickettype,p_eventid,p_seatnumber, p_ticketprice,p_purchasedate,p_userid);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Inserttransaction` (IN `p_transactionid` INT(11), IN `p_userid` INT(11), IN `p_transactiontype` VARCHAR(50), IN `p_transactiondateandtime` DATE, IN `p_transactionamount` INT(11), IN `p_transactionstatus` VARCHAR(50))   BEGIN
    INSERT INTO transaction(
transactionid,
transactionname,
transactiontype,
transactiondateandtime,
transactionamount,
transactionstatus)
    VALUES (p_transactionid,
p_transactionname,
p_transactiontype,
p_transactiondateandtime,
p_transactionamount,
p_transactionstatus );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertUSER` (IN `p_userid` INT, IN `p_username` VARCHAR(50), IN `p_password` VARCHAR(50), IN `p_fullname` VARCHAR(50), IN `p_email` VARCHAR(50), IN `p_phonenumber` INT(50), IN `p_address` VARCHAR(50), IN `p_payment` INT(50))   BEGIN
    INSERT INTO user (userid,username,password,fullname, email,phonenumber, address, payment)
    VALUES ( p_userid,p_username,p_password,p_fullname,p_email,p_phonenumber,p_address,p_payment);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertvenue` (IN `p_venueid` INT(11), IN `p_venuename` VARCHAR(50), IN `p_venueaddress` VARCHAR(40), IN `p_venuecapacity` VARCHAR(30), IN `p_venuefacilities` VARCHAR(40), IN `p_venuecontactinformation` INT(11))   BEGIN
    INSERT INTO venue(
venueid,
venuename,
venueaddress,
venuecapacity,
venuecapacity,
venuefacilities,
 venuecontactinformation )
    VALUES (p_venueid,
p_venuename,
p_venueaddress,
p_venuecapacity,
p_venuefacilities,
p_venuecontactinformation );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Update_report` (IN `p_reportid` INT(11), IN `p_reporttype` VARCHAR(50), IN `p_reportgenerationdateandtime` DATE, IN `p_reportcontent` VARCHAR(50))   BEGIN
    UPDATE report
    SET
DepartmentName= p_new_reporttype,
      Manager= p_new_reportgenerationdateandtime,
       Description=p_new_reportcontent

    WHERE
reportidID= p_report;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ViewreportWithuser` ()   BEGIN
    SELECT
D.reportid,
D.reporttype,
D.reportgenerationdateandtime,
D.reportcontent,
        (SELECT COUNT(*) FROM user E WHERE E.reportid = D.reoprtid) AS user
    FROM report D;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `anotherview`
-- (See below for the actual view)
--
CREATE TABLE `anotherview` (
`userid` int(11)
,`username` varchar(40)
,`password` varchar(50)
,`fullname` varchar(50)
,`email` varchar(50)
,`phonenumber` int(11)
,`address` varchar(50)
,`payment` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bookingid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `eventid` int(11) DEFAULT NULL,
  `bookingdateandtime` date DEFAULT NULL,
  `numberofticket` int(11) DEFAULT NULL,
  `totalprice` int(11) DEFAULT NULL,
  `bookingstatus` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bookingid`, `userid`, `eventid`, `bookingdateandtime`, `numberofticket`, `totalprice`, `bookingstatus`) VALUES
(1, 5, 3, '2023-02-12', 10, 10000, 'confirmed'),
(2, 4, 2, '2023-06-23', 11, 50000, 'pending'),
(3, 3, 1, '2023-07-26', 4, 20000, 'cancelled'),
(4, 2, 4, '2023-07-26', 6, 10000, 'pending'),
(5, 1, 5, '2023-09-21', 8, 50000, 'confirmed');

-- --------------------------------------------------------

--
-- Stand-in structure for view `bookingview`
-- (See below for the actual view)
--
CREATE TABLE `bookingview` (
`bookingid` int(11)
,`userid` int(11)
,`eventid` int(11)
,`bookingdateandtime` date
,`numberofticket` int(11)
,`totalprice` int(11)
,`bookingstatus` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `eventid` int(11) NOT NULL,
  `eventname` varchar(40) DEFAULT NULL,
  `eventdate` date DEFAULT NULL,
  `eventtime` int(11) DEFAULT NULL,
  `eventlocation` varchar(30) DEFAULT NULL,
  `eventdescription` varchar(50) DEFAULT NULL,
  `eventcapacity` varchar(30) DEFAULT NULL,
  `ticketprice` int(11) DEFAULT NULL,
  `eventorganizer` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`eventid`, `eventname`, `eventdate`, `eventtime`, `eventlocation`, `eventdescription`, `eventcapacity`, `ticketprice`, `eventorganizer`) VALUES
(1, 'musicfestival', '2023-03-12', 3, 'arena', 'harmonyfest2023', '100peaple', 10000, 'sunrise'),
(2, 'sport', '2023-08-22', 7, 'stadeumuganda', 'championlegue', '1000peaple', 20000, 'frank'),
(3, 'conference', '2023-01-02', 1, 'rusizi', 'innovativeandcreativity', '1000peaple', 10000, 'debora'),
(4, 'expo', '2023-01-02', 1, 'kigali', 'fashion', '2000peaple', 1000, 'prince'),
(5, 'gospel', '2022-01-02', 1, 'gisenyi', 'praiseandworship', '200peaple', 10000, 'peace');

-- --------------------------------------------------------

--
-- Stand-in structure for view `eventview`
-- (See below for the actual view)
--
CREATE TABLE `eventview` (
`eventid` int(11)
,`eventname` varchar(40)
,`eventdate` date
,`eventtime` int(11)
,`eventlocation` varchar(30)
,`eventdescription` varchar(50)
,`eventcapacity` varchar(30)
,`ticketprice` int(11)
,`eventorganizer` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `newview`
-- (See below for the actual view)
--
CREATE TABLE `newview` (
`userid` int(11)
,`username` varchar(40)
,`password` varchar(50)
,`fullname` varchar(50)
,`email` varchar(50)
,`phonenumber` int(11)
,`address` varchar(50)
,`payment` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notificationid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `notificationtype` varchar(30) DEFAULT NULL,
  `notificationmessage` varchar(50) DEFAULT NULL,
  `notificationdateandtime` date DEFAULT NULL,
  `notificationstatus` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notificationid`, `userid`, `notificationtype`, `notificationmessage`, `notificationdateandtime`, `notificationstatus`) VALUES
(1, 5, 'bookingconfirmed', 'booking', '1999-06-03', 'read'),
(2, 4, 'failed', 'cancelled', '1998-06-13', 'unread'),
(3, 3, 'failed', 'cancelled', '1998-06-13', 'unread'),
(4, 2, 'successful', 'completed', '1998-08-13', 'read'),
(5, 1, 'successful', 'completed', '1997-05-23', 'read');

--
-- Triggers `notification`
--
DELIMITER $$
CREATE TRIGGER `AfterUpdatenotification` AFTER UPDATE ON `notification` FOR EACH ROW BEGIN
    INSERT INTO notification (notificationid, userid,notificationtype,notificationmessage ,notificationDateTime, notificationstatus)
    VALUES (NEW.notificationid, 'notification Updated', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `notificationview`
-- (See below for the actual view)
--
CREATE TABLE `notificationview` (
`notificationid` int(11)
,`userid` int(11)
,`notificationtype` varchar(30)
,`notificationmessage` varchar(50)
,`notificationdateandtime` date
,`notificationstatus` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `organizer`
--

CREATE TABLE `organizer` (
  `organizerid` int(11) NOT NULL,
  `organizername` varchar(50) DEFAULT NULL,
  `organizercontactinformation` int(11) DEFAULT NULL,
  `organizerevents` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `organizer`
--

INSERT INTO `organizer` (`organizerid`, `organizername`, `organizercontactinformation`, `organizerevents`) VALUES
(6, 'gedeon', 789053258, 'sport'),
(7, 'prince', 789054258, 'conference'),
(8, 'peace', 789054218, 'festival'),
(9, 'fred', 788954218, 'expo'),
(10, 'sunrise', 788954212, 'gospel');

-- --------------------------------------------------------

--
-- Stand-in structure for view `organizerview`
-- (See below for the actual view)
--
CREATE TABLE `organizerview` (
`organizerid` int(11)
,`organizername` varchar(50)
,`organizercontactinformation` int(11)
,`organizerevents` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paymentid` int(11) NOT NULL,
  `bookingid` int(11) DEFAULT NULL,
  `paymentdateandtime` date DEFAULT NULL,
  `paymentamount` int(11) DEFAULT NULL,
  `paymentmethod` varchar(30) DEFAULT NULL,
  `transactionstatus` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`paymentid`, `bookingid`, `paymentdateandtime`, `paymentamount`, `paymentmethod`, `transactionstatus`) VALUES
(1, 2, '2022-09-13', 600, 'creditcard', 'successful'),
(2, 3, '2000-09-15', 200, 'momopay', 'failed'),
(3, 4, '2009-07-29', 500, 'mocash', 'pending'),
(4, 5, '2008-06-28', 100, 'creditcard', 'failed'),
(5, 1, '2008-08-08', 2000, 'momopay', 'pending');

--
-- Triggers `payment`
--
DELIMITER $$
CREATE TRIGGER `AfterDeletepayment` AFTER DELETE ON `payment` FOR EACH ROW BEGIN
    INSERT INTO payment (paymentid, bookingid, paymentDateandTime,paymentamount,paymentmethod, transactionstatus)
    VALUES (OLD.paymentid, 'payment Deleted', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `paymentview`
-- (See below for the actual view)
--
CREATE TABLE `paymentview` (
`paymentid` int(11)
,`bookingid` int(11)
,`paymentdateandtime` date
,`paymentamount` int(11)
,`paymentmethod` varchar(30)
,`transactionstatus` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `reportid` int(11) NOT NULL,
  `reporttype` varchar(50) DEFAULT NULL,
  `reportgenerationdateandtime` date DEFAULT NULL,
  `reportcontent` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`reportid`, `reporttype`, `reportgenerationdateandtime`, `reportcontent`) VALUES
(6, 'salesreport', '2000-08-09', 'financialreport'),
(7, 'attendance', '2009-06-07', 'projectstatusreport'),
(8, 'salesreport', '2019-06-07', 'marketresearchreport'),
(9, 'salesreport', '2019-06-07', 'employesperformancereport'),
(10, 'attendancereport', '2019-12-30', 'employesperformancereport');

-- --------------------------------------------------------

--
-- Stand-in structure for view `reportview`
-- (See below for the actual view)
--
CREATE TABLE `reportview` (
`reportid` int(11)
,`reporttype` varchar(50)
,`reportgenerationdateandtime` date
,`reportcontent` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `reviewid` int(11) NOT NULL,
  `usedid` int(11) DEFAULT NULL,
  `eventid` int(11) DEFAULT NULL,
  `reviewtext` varchar(30) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`reviewid`, `usedid`, `eventid`, `reviewtext`, `rating`) VALUES
(1, 5, 2, 'positivereview', 1),
(2, 4, 4, 'negativereview', 0),
(3, 3, 1, 'neutralreview', 1),
(4, 2, 5, 'shortandpositiveereview', 1),
(5, 1, 3, 'positiveereview', 1);

--
-- Triggers `review`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertreview` AFTER INSERT ON `review` FOR EACH ROW BEGIN
    INSERT INTO review (reviewid, usedid, eventid, reviewtext, rating)
    VALUES (NULL, 'New review Added', CONCAT('review ', ' has been added.'), NOW(), 'Unread');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `reviewview`
-- (See below for the actual view)
--
CREATE TABLE `reviewview` (
`reviewid` int(11)
,`usedid` int(11)
,`eventid` int(11)
,`reviewtext` varchar(30)
,`rating` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `someeventview`
-- (See below for the actual view)
--
CREATE TABLE `someeventview` (
`eventid` int(11)
,`eventname` varchar(40)
,`eventdate` date
,`eventtime` int(11)
,`eventlocation` varchar(30)
,`eventdescription` varchar(50)
,`eventcapacity` varchar(30)
,`ticketprice` int(11)
,`eventorganizer` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `ticketid` int(11) NOT NULL,
  `tickettype` varchar(50) DEFAULT NULL,
  `eventid` int(11) DEFAULT NULL,
  `seatnumber` int(11) DEFAULT NULL,
  `ticketprice` int(11) DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `ticketstatus` varchar(50) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`ticketid`, `tickettype`, `eventid`, `seatnumber`, `ticketprice`, `purchasedate`, `ticketstatus`, `userid`) VALUES
(1, 'vip', 3, 9, 30000, '2023-10-10', 'booked', 5),
(2, 'generaladmission', 2, 8, 20000, '2023-05-12', 'cancelled', 4),
(3, 'general', 2, 8, 10000, '2023-08-22', 'sold', 3),
(4, 'vip', 1, 6, 30000, '2023-02-23', 'cancelled', 2),
(5, 'general', 5, 5, 10000, '2023-01-23', 'booked', 1);

--
-- Triggers `ticket`
--
DELIMITER $$
CREATE TRIGGER `AfterUpdateticket` AFTER UPDATE ON `ticket` FOR EACH ROW BEGIN
    INSERT INTO ticket (ticketid, tickettype,eventid,seatnumber ,ticketprice,purchasedate,ticketstatus,userid)
    VALUES (NEW.ticketid, 'ticket Updated', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `ticketview`
-- (See below for the actual view)
--
CREATE TABLE `ticketview` (
`ticketid` int(11)
,`tickettype` varchar(50)
,`eventid` int(11)
,`seatnumber` int(11)
,`ticketprice` int(11)
,`purchasedate` date
,`ticketstatus` varchar(50)
,`userid` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transactionid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `transactiontype` varchar(50) DEFAULT NULL,
  `transactiondateandtime` date DEFAULT NULL,
  `transactionamount` int(11) DEFAULT NULL,
  `transactionstatus` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transactionid`, `userid`, `transactiontype`, `transactiondateandtime`, `transactionamount`, `transactionstatus`) VALUES
(6, 1, 'ticketpurchased', '2000-02-12', 500, 'completed'),
(7, 2, 'refund', '2002-09-22', 50, 'onhold'),
(8, 3, 'ticketpurchased', '2007-07-30', 1000, 'pending'),
(9, 4, 'ticketpurchased', '2009-09-14', 100, 'failed'),
(10, 5, 'refund', '2009-12-24', 123, 'completed');

--
-- Triggers `transaction`
--
DELIMITER $$
CREATE TRIGGER `AfterDeletetransaction` AFTER DELETE ON `transaction` FOR EACH ROW BEGIN
    INSERT INTO transaction (transactionid, userid,transactiontype,transactionDateandTime,transactionamount,transactionstatus)
    VALUES (OLD.transactionid, 'transaction Deleted', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `transactionview`
-- (See below for the actual view)
--
CREATE TABLE `transactionview` (
`transactionid` int(11)
,`userid` int(11)
,`transactiontype` varchar(50)
,`transactiondateandtime` date
,`transactionamount` int(11)
,`transactionstatus` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_event_information`
-- (See below for the actual view)
--
CREATE TABLE `update_event_information` (
`eventid` int(11)
,`eventname` varchar(40)
,`eventdate` date
,`eventtime` int(11)
,`eventlocation` varchar(30)
,`eventdescription` varchar(50)
,`eventcapacity` varchar(30)
,`ticketprice` int(11)
,`eventorganizer` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `update_user_information`
-- (See below for the actual view)
--
CREATE TABLE `update_user_information` (
`userid` int(11)
,`username` varchar(40)
,`password` varchar(50)
,`fullname` varchar(50)
,`email` varchar(50)
,`phonenumber` int(11)
,`address` varchar(50)
,`payment` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phonenumber` int(11) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `payment` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `fullname`, `email`, `phonenumber`, `address`, `payment`) VALUES
(1, 'aline', 'abayisenga', 'abayisengaaline', 'aline@gmail.com', 798989898, 'kigali', 1000),
(2, 'noella', 'uwera', 'uweranoella', 'uwera@gmail.com', 798989898, 'gisenyi', 2000),
(3, 'queen', 'ishimwe', 'ishimwefideline', 'ishimwe@gmail.com', 798989898, 'gicumbi', 5000),
(4, 'fred', 'mugisha', 'mugishafred', 'mugisha@gmail.com', 798989348, 'mainstreet', 6000),
(5, 'penuel', 'irumva', 'irumvapenuel', 'irumva@gmail.com', 712389348, 'bujumburra', 4000);

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertyuser` AFTER INSERT ON `user` FOR EACH ROW BEGIN
    INSERT INTO AuditLog (Userid, username, password, fullname,email,phonenumber,address,payment)
    VALUES (NEW.userid, 'New user Added', NOW(), INET6_ATON('127.0.0.1'));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE `venue` (
  `venueid` int(11) NOT NULL,
  `venuename` varchar(50) DEFAULT NULL,
  `venueaddress` varchar(40) DEFAULT NULL,
  `venuecapacity` varchar(30) DEFAULT NULL,
  `venuefacilities` varchar(40) DEFAULT NULL,
  `venuecontactinformation` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` (`venueid`, `venuename`, `venueaddress`, `venuecapacity`, `venuefacilities`, `venuecontactinformation`) VALUES
(1, 'conference', 'kigaliarena', 'small', 'conferencecentre', 789898982),
(2, 'festival', 'gisengibich', 'medium', 'concerthall', 789892282),
(3, 'sport', 'kigali', 'large', 'sportarena', 789892278),
(4, 'sport', 'kigali', 'large', 'sportarena', 789892278),
(5, 'expo', 'kigali', 'large', 'expogikondo', 789892234);

-- --------------------------------------------------------

--
-- Stand-in structure for view `venueview`
-- (See below for the actual view)
--
CREATE TABLE `venueview` (
`venueid` int(11)
,`venuename` varchar(50)
,`venueaddress` varchar(40)
,`venuecapacity` varchar(30)
,`venuefacilities` varchar(40)
,`venuecontactinformation` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `anotherview`
--
DROP TABLE IF EXISTS `anotherview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `anotherview`  AS SELECT `user`.`userid` AS `userid`, `user`.`username` AS `username`, `user`.`password` AS `password`, `user`.`fullname` AS `fullname`, `user`.`email` AS `email`, `user`.`phonenumber` AS `phonenumber`, `user`.`address` AS `address`, `user`.`payment` AS `payment` FROM `user` WHERE `user`.`userid` in (1,4) ;

-- --------------------------------------------------------

--
-- Structure for view `bookingview`
--
DROP TABLE IF EXISTS `bookingview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bookingview`  AS SELECT `booking`.`bookingid` AS `bookingid`, `booking`.`userid` AS `userid`, `booking`.`eventid` AS `eventid`, `booking`.`bookingdateandtime` AS `bookingdateandtime`, `booking`.`numberofticket` AS `numberofticket`, `booking`.`totalprice` AS `totalprice`, `booking`.`bookingstatus` AS `bookingstatus` FROM `booking` ;

-- --------------------------------------------------------

--
-- Structure for view `eventview`
--
DROP TABLE IF EXISTS `eventview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `eventview`  AS SELECT `event`.`eventid` AS `eventid`, `event`.`eventname` AS `eventname`, `event`.`eventdate` AS `eventdate`, `event`.`eventtime` AS `eventtime`, `event`.`eventlocation` AS `eventlocation`, `event`.`eventdescription` AS `eventdescription`, `event`.`eventcapacity` AS `eventcapacity`, `event`.`ticketprice` AS `ticketprice`, `event`.`eventorganizer` AS `eventorganizer` FROM `event` ;

-- --------------------------------------------------------

--
-- Structure for view `newview`
--
DROP TABLE IF EXISTS `newview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `newview`  AS SELECT `user`.`userid` AS `userid`, `user`.`username` AS `username`, `user`.`password` AS `password`, `user`.`fullname` AS `fullname`, `user`.`email` AS `email`, `user`.`phonenumber` AS `phonenumber`, `user`.`address` AS `address`, `user`.`payment` AS `payment` FROM `user` ;

-- --------------------------------------------------------

--
-- Structure for view `notificationview`
--
DROP TABLE IF EXISTS `notificationview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `notificationview`  AS SELECT `notification`.`notificationid` AS `notificationid`, `notification`.`userid` AS `userid`, `notification`.`notificationtype` AS `notificationtype`, `notification`.`notificationmessage` AS `notificationmessage`, `notification`.`notificationdateandtime` AS `notificationdateandtime`, `notification`.`notificationstatus` AS `notificationstatus` FROM `notification` ;

-- --------------------------------------------------------

--
-- Structure for view `organizerview`
--
DROP TABLE IF EXISTS `organizerview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `organizerview`  AS SELECT `organizer`.`organizerid` AS `organizerid`, `organizer`.`organizername` AS `organizername`, `organizer`.`organizercontactinformation` AS `organizercontactinformation`, `organizer`.`organizerevents` AS `organizerevents` FROM `organizer` ;

-- --------------------------------------------------------

--
-- Structure for view `paymentview`
--
DROP TABLE IF EXISTS `paymentview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `paymentview`  AS SELECT `payment`.`paymentid` AS `paymentid`, `payment`.`bookingid` AS `bookingid`, `payment`.`paymentdateandtime` AS `paymentdateandtime`, `payment`.`paymentamount` AS `paymentamount`, `payment`.`paymentmethod` AS `paymentmethod`, `payment`.`transactionstatus` AS `transactionstatus` FROM `payment` ;

-- --------------------------------------------------------

--
-- Structure for view `reportview`
--
DROP TABLE IF EXISTS `reportview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reportview`  AS SELECT `report`.`reportid` AS `reportid`, `report`.`reporttype` AS `reporttype`, `report`.`reportgenerationdateandtime` AS `reportgenerationdateandtime`, `report`.`reportcontent` AS `reportcontent` FROM `report` ;

-- --------------------------------------------------------

--
-- Structure for view `reviewview`
--
DROP TABLE IF EXISTS `reviewview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reviewview`  AS SELECT `review`.`reviewid` AS `reviewid`, `review`.`usedid` AS `usedid`, `review`.`eventid` AS `eventid`, `review`.`reviewtext` AS `reviewtext`, `review`.`rating` AS `rating` FROM `review` ;

-- --------------------------------------------------------

--
-- Structure for view `someeventview`
--
DROP TABLE IF EXISTS `someeventview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `someeventview`  AS SELECT `event`.`eventid` AS `eventid`, `event`.`eventname` AS `eventname`, `event`.`eventdate` AS `eventdate`, `event`.`eventtime` AS `eventtime`, `event`.`eventlocation` AS `eventlocation`, `event`.`eventdescription` AS `eventdescription`, `event`.`eventcapacity` AS `eventcapacity`, `event`.`ticketprice` AS `ticketprice`, `event`.`eventorganizer` AS `eventorganizer` FROM `event` WHERE `event`.`eventid` in (2,5) ;

-- --------------------------------------------------------

--
-- Structure for view `ticketview`
--
DROP TABLE IF EXISTS `ticketview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ticketview`  AS SELECT `ticket`.`ticketid` AS `ticketid`, `ticket`.`tickettype` AS `tickettype`, `ticket`.`eventid` AS `eventid`, `ticket`.`seatnumber` AS `seatnumber`, `ticket`.`ticketprice` AS `ticketprice`, `ticket`.`purchasedate` AS `purchasedate`, `ticket`.`ticketstatus` AS `ticketstatus`, `ticket`.`userid` AS `userid` FROM `ticket` ;

-- --------------------------------------------------------

--
-- Structure for view `transactionview`
--
DROP TABLE IF EXISTS `transactionview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `transactionview`  AS SELECT `transaction`.`transactionid` AS `transactionid`, `transaction`.`userid` AS `userid`, `transaction`.`transactiontype` AS `transactiontype`, `transaction`.`transactiondateandtime` AS `transactiondateandtime`, `transaction`.`transactionamount` AS `transactionamount`, `transaction`.`transactionstatus` AS `transactionstatus` FROM `transaction` ;

-- --------------------------------------------------------

--
-- Structure for view `update_event_information`
--
DROP TABLE IF EXISTS `update_event_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_event_information`  AS SELECT `event`.`eventid` AS `eventid`, `event`.`eventname` AS `eventname`, `event`.`eventdate` AS `eventdate`, `event`.`eventtime` AS `eventtime`, `event`.`eventlocation` AS `eventlocation`, `event`.`eventdescription` AS `eventdescription`, `event`.`eventcapacity` AS `eventcapacity`, `event`.`ticketprice` AS `ticketprice`, `event`.`eventorganizer` AS `eventorganizer` FROM `event` WHERE `event`.`eventid` = 2 ;

-- --------------------------------------------------------

--
-- Structure for view `update_user_information`
--
DROP TABLE IF EXISTS `update_user_information`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `update_user_information`  AS SELECT `user`.`userid` AS `userid`, `user`.`username` AS `username`, `user`.`password` AS `password`, `user`.`fullname` AS `fullname`, `user`.`email` AS `email`, `user`.`phonenumber` AS `phonenumber`, `user`.`address` AS `address`, `user`.`payment` AS `payment` FROM `user` WHERE `user`.`userid` = 3 ;

-- --------------------------------------------------------

--
-- Structure for view `venueview`
--
DROP TABLE IF EXISTS `venueview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `venueview`  AS SELECT `venue`.`venueid` AS `venueid`, `venue`.`venuename` AS `venuename`, `venue`.`venueaddress` AS `venueaddress`, `venue`.`venuecapacity` AS `venuecapacity`, `venue`.`venuefacilities` AS `venuefacilities`, `venue`.`venuecontactinformation` AS `venuecontactinformation` FROM `venue` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingid`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`eventid`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notificationid`);

--
-- Indexes for table `organizer`
--
ALTER TABLE `organizer`
  ADD PRIMARY KEY (`organizerid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paymentid`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`reportid`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`reviewid`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`ticketid`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transactionid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `venue`
--
ALTER TABLE `venue`
  ADD PRIMARY KEY (`venueid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
