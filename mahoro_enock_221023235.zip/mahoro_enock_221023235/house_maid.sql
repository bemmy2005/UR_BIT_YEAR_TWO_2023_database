-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 04:06 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `house_maid`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `customepayment` ()   BEGIN
    SELECT
        customer.customerName,
        (
            SELECT COUNT(*)
            FROM manager
            WHERE managerID = manager.managerID
        ) AS managerCount
    FROM
        manager;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteCustomerByCondition` (IN `p_ConditionValue` VARCHAR(50))   BEGIN
    DELETE FROM customer
    WHERE
        email = p_ConditionValue;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllhouse_maidInfo` ()   BEGIN
    -- Display data from the "customer" table
    SELECT * FROM customer;
    
    -- Display data from the "manager" table
    SELECT * FROM manager;
    
    -- Display data from the "worker" table
    SELECT * FROM worker;
    
    -- Display data from the "government" table
    SELECT * FROM government;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertCustomer` (IN `p_customer_id` INT, IN `p_last_name` VARCHAR(255), IN `p_first_name` VARCHAR(255), IN `p_email` VARCHAR(255), IN `p_phone` VARCHAR(20), IN `p_address` VARCHAR(255), IN `p_payment_method` VARCHAR(255))   BEGIN
    INSERT INTO customer (
        customer_id,
        last_name,
        first_name,
        email,
        phone,
        address,
        payment_method
    ) VALUES (
        p_customer_id,
        p_last_name,
        p_first_name,
        p_email,
        p_phone,
        p_address,
        p_payment_method
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertgovernment` (`Government_Name` VARCHAR(255), `Governmente_mail` VARCHAR(50))   BEGIN
   
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertManager` (IN `p_manager_id` INT, IN `p_manager_name` VARCHAR(255), IN `p_manager_sex` VARCHAR(10), IN `p_manager_age` INT, IN `p_manager_email` VARCHAR(255), IN `p_manager_address` VARCHAR(255), IN `p_manager_contact` VARCHAR(255))   BEGIN
    INSERT INTO manager (
        manager_id,
        manager_name,
        manager_sex,
        manager_age,
        manager_email,
        manager_address,
        manager_contact
    ) VALUES (
        p_manager_id,
        p_manager_name,
        p_manager_sex,
        p_manager_age,
        p_manager_email,
        p_manager_address,
        p_manager_contact
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertWorker` (IN `p_worker_id` INT, IN `p_first_name` VARCHAR(255), IN `p_last_name` VARCHAR(255), IN `p_phone` VARCHAR(20), IN `p_sex` VARCHAR(10), IN `p_age` INT, IN `p_manager_id` INT)   BEGIN
    INSERT INTO worker (
        worker_id,
        first_name,
        last_name,
        phone,
        sex,
        age,
        manager_id
    ) VALUES (
        p_worker_id,
        p_first_name,
        p_last_name,
        p_phone,
        p_sex,
        p_age,
        p_manager_id
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdatemanagerInfo` (IN `p_managerID` INT, IN `p_newmanagerName` VARCHAR(20), IN `p_NewAddress` VARCHAR(20), IN `p_NewPhone` VARCHAR(30), IN `p_NewEmail` VARCHAR(50), IN `p_newsex` VARCHAR(50), IN `p_newage` VARCHAR(50))   BEGIN
    UPDATE manager
    SET
        managerName = p_NewmanagerName,
        Address = p_NewAddress,
        Phone = p_NewPhone,
        Email = p_NewEmail,
        Sex   = p_newsex,
        Age  = p_newage
    WHERE
        managerID = p_managerID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateworkerInfo` (IN `p_workerID` INT, IN `p_NewFirstName` VARCHAR(20), IN `p_NewLastName` VARCHAR(20), IN `p_Newage` VARCHAR(30), IN `p_NewPhone` VARCHAR(20), IN `p_Newaddress` VARCHAR(20), IN `p_Newsex` VARCHAR(20))   BEGIN
    UPDATE worker
    SET
        FirstName = p_NewFirstName,
        LastName = p_NewLastName,
        age = p_Newage,
        Phone = p_NewPhone,
        sex = p_Newsex,
        address = p_Newaddress
    WHERE
        workerID = p_workerID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `payment_method` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `last_name`, `first_name`, `email`, `phone`, `address`, `payment_method`) VALUES
(1, 'Doe', 'John', 'johndoe@email.com', '123-456-78', '123 Main St', 'Credit Car'),
(2, 'Enock', 'mahoro', 'enockmahoro04@gmail.com', '0785433761', 'kirehe/rwanda', 'momo'),
(3, 'kwizera', 'bonheur', 'kwizera@gmail.com', '0723828461', 'huye/rwanda', 'bk'),
(4, 'murazayesu', 'jackson', 'muraza@gmail.com', '0783266818', 'kigali/rwanda', 'ecqwity');

--
-- Triggers `customer`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertcustomer` AFTER INSERT ON `customer` FOR EACH ROW BEGIN
    INSERT INTO customer (customer_id, Action, Timestamp)
    VALUES (NEW.customer_id, 'INSERT', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AftercustomerDelete` AFTER DELETE ON `customer` FOR EACH ROW BEGIN
    -- Insert a log record into the customerDeleteLog table
    INSERT INTO customerDeletename (customer_id, Deletedname)
    VALUES (OLD.customer_id, NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AftercustomerUpdate` AFTER UPDATE ON `customer` FOR EACH ROW BEGIN
    -- Insert ID record into the customerUpdateid table
    INSERT INTO customerUpdateid (customerID, Updatedname)
    VALUES (NEW.customer_id, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `government`
--

CREATE TABLE `government` (
  `government_id` int(11) NOT NULL,
  `government_name` varchar(50) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `address` varchar(40) NOT NULL,
  `phone_number` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `government`
--

INSERT INTO `government` (`government_id`, `government_name`, `email`, `address`, `phone_number`) VALUES
(1, 'RDB', 'rdbinfo@gmail.com', 'kigali/rwanda', '4532'),
(2, 'RDB', 'rdbinfo@gmail.com', 'kigali/rwanda', '4532');

--
-- Triggers `government`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertGovernment` AFTER INSERT ON `government` FOR EACH ROW BEGIN
    -- Log the insert operation into a government_audit table
    INSERT INTO government_audit (
        action_type,
        government_id,
        government_name,
        timestamp
    ) VALUES (
        'INSERT',
        NEW.government_id,
        NEW.government_name,
        NOW()
    );
    
    -- You can add more logic here if needed, such as sending notifications.
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AftergovernmentDelete` AFTER DELETE ON `government` FOR EACH ROW BEGIN
    
    INSERT INTO governmentDeleteemail (government_id, Deletedname)
    VALUES (OLD.government_id, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_customerview`
-- (See below for the actual view)
--
CREATE TABLE `insert_customerview` (
`customer_id` int(11)
,`last_name` varchar(50)
,`first_name` varchar(25)
,`email` varchar(100)
,`phone` varchar(10)
,`address` varchar(50)
,`payment_method` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_governmentview`
-- (See below for the actual view)
--
CREATE TABLE `insert_governmentview` (
`government_id` int(11)
,`government_name` varchar(50)
,`email` varchar(40)
,`address` varchar(40)
,`phone_number` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_managerview`
-- (See below for the actual view)
--
CREATE TABLE `insert_managerview` (
`manager_id` int(11)
,`manager_name` varchar(20)
,`manager_sex` varchar(15)
,`manager_age` varchar(20)
,`manager_email` varchar(50)
,`manager_address` varchar(30)
,`manager_contact` varchar(50)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_workerview`
-- (See below for the actual view)
--
CREATE TABLE `insert_workerview` (
`worker_id` int(11)
,`first_name` varchar(50)
,`last_name` varchar(40)
,`phone` varchar(10)
,`sex` varchar(20)
,`age` varchar(50)
,`manager_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `manager_id` int(11) NOT NULL,
  `manager_name` varchar(20) NOT NULL,
  `manager_sex` varchar(15) NOT NULL,
  `manager_age` varchar(20) DEFAULT NULL,
  `manager_email` varchar(50) NOT NULL,
  `manager_address` varchar(30) NOT NULL,
  `manager_contact` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`manager_id`, `manager_name`, `manager_sex`, `manager_age`, `manager_email`, `manager_address`, `manager_contact`) VALUES
(1, 'norbert', 'male', '25', 'rukundo@gmail.com', 'ngoma/rwanda', '0780589589'),
(10, 'John Doe', 'Male', '35', 'johndoe@email.com', '123 Main St', '123-456-7890');

-- --------------------------------------------------------

--
-- Table structure for table `worker`
--

CREATE TABLE `worker` (
  `worker_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `age` varchar(50) NOT NULL,
  `manager_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `worker`
--

INSERT INTO `worker` (`worker_id`, `first_name`, `last_name`, `phone`, `sex`, `age`, `manager_id`) VALUES
(1, 'Alice', 'Smith', '123-456-78', 'Female', '28', 1),
(2, 'irakoze', 'godrey', '0781483835', 'male', '23', 1),
(3, 'ngoma', 'osborne', '0782345652', 'male', '28', 1),
(4, 'iradukunda', 'theogene', '0725436781', 'male', '21', 1);

--
-- Triggers `worker`
--
DELIMITER $$
CREATE TRIGGER `AfterworkerUpdate` AFTER UPDATE ON `worker` FOR EACH ROW BEGIN
    -- Insert a log record into the workerUpdateaddress table
    INSERT INTO workerUpdatename (workerID, Updatedname)
    VALUES (NEW.worker_id, NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `workersdetails`
-- (See below for the actual view)
--
CREATE TABLE `workersdetails` (
`id` int(11)
,`name` varchar(50)
,`last` varchar(40)
,`contact` varchar(10)
,`gender` varchar(20)
,`age` varchar(50)
,`manager` int(11)
,`manager_info` varchar(20)
);

-- --------------------------------------------------------

--
-- Structure for view `insert_customerview`
--
DROP TABLE IF EXISTS `insert_customerview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_customerview`  AS SELECT `customer`.`customer_id` AS `customer_id`, `customer`.`last_name` AS `last_name`, `customer`.`first_name` AS `first_name`, `customer`.`email` AS `email`, `customer`.`phone` AS `phone`, `customer`.`address` AS `address`, `customer`.`payment_method` AS `payment_method` FROM `customer` WHERE `customer`.`customer_id` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_governmentview`
--
DROP TABLE IF EXISTS `insert_governmentview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_governmentview`  AS SELECT `government`.`government_id` AS `government_id`, `government`.`government_name` AS `government_name`, `government`.`email` AS `email`, `government`.`address` AS `address`, `government`.`phone_number` AS `phone_number` FROM `government` WHERE `government`.`government_id` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_managerview`
--
DROP TABLE IF EXISTS `insert_managerview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_managerview`  AS SELECT `manager`.`manager_id` AS `manager_id`, `manager`.`manager_name` AS `manager_name`, `manager`.`manager_sex` AS `manager_sex`, `manager`.`manager_age` AS `manager_age`, `manager`.`manager_email` AS `manager_email`, `manager`.`manager_address` AS `manager_address`, `manager`.`manager_contact` AS `manager_contact` FROM `manager` WHERE `manager`.`manager_id` = 11  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_workerview`
--
DROP TABLE IF EXISTS `insert_workerview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_workerview`  AS SELECT `worker`.`worker_id` AS `worker_id`, `worker`.`first_name` AS `first_name`, `worker`.`last_name` AS `last_name`, `worker`.`phone` AS `phone`, `worker`.`sex` AS `sex`, `worker`.`age` AS `age`, `worker`.`manager_id` AS `manager_id` FROM `worker` WHERE `worker`.`worker_id` = 22  ;

-- --------------------------------------------------------

--
-- Structure for view `workersdetails`
--
DROP TABLE IF EXISTS `workersdetails`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `workersdetails`  AS SELECT `worker`.`worker_id` AS `id`, `worker`.`first_name` AS `name`, `worker`.`last_name` AS `last`, `worker`.`phone` AS `contact`, `worker`.`sex` AS `gender`, `worker`.`age` AS `age`, `worker`.`manager_id` AS `manager`, (select `manager`.`manager_name` AS `name` from `manager` where `manager`.`manager_id` = `worker`.`manager_id`) AS `manager_info` FROM `worker``worker`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `government`
--
ALTER TABLE `government`
  ADD PRIMARY KEY (`government_id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`manager_id`);

--
-- Indexes for table `worker`
--
ALTER TABLE `worker`
  ADD PRIMARY KEY (`worker_id`),
  ADD KEY `manager_id` (`manager_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `government`
--
ALTER TABLE `government`
  MODIFY `government_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `manager_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `worker`
--
ALTER TABLE `worker`
  MODIFY `worker_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `worker`
--
ALTER TABLE `worker`
  ADD CONSTRAINT `worker_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `manager` (`manager_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
