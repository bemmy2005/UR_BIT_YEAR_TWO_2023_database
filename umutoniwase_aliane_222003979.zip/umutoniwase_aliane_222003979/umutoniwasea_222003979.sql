-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 10:39 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `umutoniwasea_222003979`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DELETEcustomersbyfirst_name`(
IN t_first_name VARCHAR(100)
)
BEGIN
DELETE FROM customers
WHERE first_name =t_first_name;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DELETEreviewbyrating`(
IN t_rating VARCHAR(100)
)
BEGIN
DELETE FROM review
WHERE rating =t_rating;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displaycustomersdata`()
BEGIN
SELECT* FROM customers;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayhoteldata`()
BEGIN
SELECT* FROM hotel;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displaypaymentsdata`()
BEGIN
SELECT* FROM payments;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayreservationsdata`()
BEGIN
SELECT* FROM reservations;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayreviewdata`()
BEGIN
SELECT* FROM review;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Displayroomsdata`()
BEGIN
SELECT* FROM rooms;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertcustomers`(
IN First_name varchar(100),
IN Last_name varchar(100),
IN Email varchar(100),
IN Phone varchar(100),
IN Address varchar(100) 
)
BEGIN
INSERT INTO customers (first_name, last_name, email, phone, address)
VALUES
(customers_first_name, customers_last_name, customers_email, customers_phone, customers_address);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Inserthotel`(
IN Name varchar(100),
IN Address varchar(100),
IN City varchar(100),
IN Country varchar(100),
IN Phone varchar(100),
IN Email varchar(100)
)
BEGIN
INSERT INTO hotel (name, address, city, country, phone, email)
VALUES
(hotel_name, hotel_address, hotel_city, hotel_country, hotel_phone, hotel_email);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertpayments`(
IN Payment_date varchar(100),
IN Payment_amount varchar(100),
IN Payment_method varchar(100),
IN Reservation_id int
)
BEGIN
INSERT INTO payments (payment_date, payment_amount, payment_method, reservation_id)
VALUES
(payments_payment_date, payments_payment_amount, payments_payment_method, payments_reservation_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertreservations`(
IN Checkin_date varchar(100),
IN Checkout_date varchar(100),
IN Total_price varchar(100),
IN Status varchar(100),
IN Customer_id int,
IN Room_id int
)
BEGIN
INSERT INTO reservations (checkin_date, checkout_date, total_price, status, customer_id, room_id)
VALUES
(reservations_checkin_date, reservations_checkout_date, reservations_total_price, reservations_status, reservations_customer_id, reservations_room_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertreview`(
IN Review_text varchar(100),
IN Date_posted varchar(100),
IN Rating varchar(100),
IN Customer_id int,
IN Hotel_id int
)
BEGIN
INSERT INTO review (review_text, date_posted, rating, customer_id, hotel_id)
VALUES 
(review_review_text, review_date_posted, review_rating, review_customer_id, review_hotel_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertrooms`(
IN Room_type varchar(100),
IN Price_per_night int,
IN Is_available varchar(100),
IN Hotel_id int
)
BEGIN
INSERT INTO rooms (room_type, price_per_night, is_available, hotel_id)
VALUES
(rooms_room_type, rooms_price_per_night, rooms_is_available, rooms_hotel_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatecustomers`(
IN t_customer_id INT,
IN t_newaddress VARCHAR(100),
IN t_newemail VARCHAR(100)
)
BEGIN
UPDATE hotel
SET address =t_newaddress, email =t_newemail
WHERE customer_id = t_customer_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatehotel`(
IN t_hotel_id INT,
IN t_newname VARCHAR(100),
IN t_newphone VARCHAR(100)
)
BEGIN
UPDATE hotel
SET name =t_newname, phone =t_newphone
WHERE hotel_id = t_hotel_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `Customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `First_name` varchar(100) NOT NULL,
  `Last_name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  PRIMARY KEY (`Customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`Customer_id`, `First_name`, `Last_name`, `Email`, `Phone`, `Address`) VALUES
(1, 'fred', 'gisa', 'gisa35@gmail.com', '0786734620', 'muhanga'),
(2, 'peter', 'parker', 'parker123@gmail.com', '0798712781', 'huye');

--
-- Triggers `customers`
--
DROP TRIGGER IF EXISTS `AfterInsertcustomers`;
DELIMITER //
CREATE TRIGGER `AfterInsertcustomers` AFTER INSERT ON `customers`
 FOR EACH ROW BEGIN
INSERT INTO customers_audit(customer_id,action,action_date)
VALUES
(NEW.customer_id,'INSERT',NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `customers_view`
--
CREATE TABLE IF NOT EXISTS `customers_view` (
`Customer_id` int(11)
,`First_name` varchar(100)
,`Last_name` varchar(100)
,`Email` varchar(100)
,`Phone` varchar(100)
,`Address` varchar(100)
);
-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE IF NOT EXISTS `hotel` (
  `Hotel_id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(100) NOT NULL,
  `Country` varchar(100) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  PRIMARY KEY (`Hotel_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`Hotel_id`, `Name`, `Address`, `City`, `Country`, `Phone`, `Email`) VALUES
(1, 'moonvilla', 'kacyiru', 'kigali', 'rwanda', '0788903746', 'villa@gmail.com');

--
-- Triggers `hotel`
--
DROP TRIGGER IF EXISTS `AfterDeletehotel`;
DELIMITER //
CREATE TRIGGER `AfterDeletehotel` AFTER DELETE ON `hotel`
 FOR EACH ROW BEGIN
INSERT INTO hotel_audit(hotel_id,action,action_date)
VALUES
(OLD. hotel_id,'DELETE',NOW());
END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `AfterUpdatehotel`;
DELIMITER //
CREATE TRIGGER `AfterUpdatehotel` AFTER UPDATE ON `hotel`
 FOR EACH ROW BEGIN
INSERT INTO hotel_audit(hotel_id, action, action_date)
VALUES
(NEW.hotel_id, 'UPDATE', NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `hotel_view`
--
CREATE TABLE IF NOT EXISTS `hotel_view` (
`Hotel_id` int(11)
,`Name` varchar(100)
,`Address` varchar(100)
,`City` varchar(100)
,`Country` varchar(100)
,`Phone` varchar(100)
,`Email` varchar(100)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_customersview`
--
CREATE TABLE IF NOT EXISTS `insert_customersview` (
`Customer_id` int(11)
,`First_name` varchar(100)
,`Last_name` varchar(100)
,`Email` varchar(100)
,`Phone` varchar(100)
,`Address` varchar(100)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_hotelview`
--
CREATE TABLE IF NOT EXISTS `insert_hotelview` (
`Hotel_id` int(11)
,`Name` varchar(100)
,`Address` varchar(100)
,`City` varchar(100)
,`Country` varchar(100)
,`Phone` varchar(100)
,`Email` varchar(100)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_paymentsview`
--
CREATE TABLE IF NOT EXISTS `insert_paymentsview` (
`Payment_id` int(11)
,`Payment_date` varchar(100)
,`Payment_amount` varchar(100)
,`Payment_method` varchar(100)
,`Reservation_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_reservationsview`
--
CREATE TABLE IF NOT EXISTS `insert_reservationsview` (
`Reservation_id` int(11)
,`Checkin_date` varchar(100)
,`Checkout_date` varchar(100)
,`Total_price` varchar(100)
,`Status` varchar(100)
,`Customer_id` int(11)
,`Room_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_reviewview`
--
CREATE TABLE IF NOT EXISTS `insert_reviewview` (
`Review_id` int(11)
,`Review_text` varchar(100)
,`Date_posted` varchar(100)
,`Rating` varchar(100)
,`Customer_id` int(11)
,`Hotel_id` int(11)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_roomsview`
--
CREATE TABLE IF NOT EXISTS `insert_roomsview` (
`Room_id` int(11)
,`Room_type` varchar(100)
,`Price_per_night` int(11)
,`Is_available` varchar(100)
,`Hotel_id` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `Payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `Payment_date` varchar(100) NOT NULL,
  `Payment_amount` varchar(100) NOT NULL,
  `Payment_method` varchar(100) NOT NULL,
  `Reservation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Payment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`Payment_id`, `Payment_date`, `Payment_amount`, `Payment_method`, `Reservation_id`) VALUES
(1, '023-05-14', '60000', 'cash', 234);

--
-- Triggers `payments`
--
DROP TRIGGER IF EXISTS `AfterInsertpayments`;
DELIMITER //
CREATE TRIGGER `AfterInsertpayments` AFTER INSERT ON `payments`
 FOR EACH ROW BEGIN
INSERT INTO payments_audit(payment_id,action,action_date)
VALUES
(NEW.payment_id,'INSERT',NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `payments_view`
--
CREATE TABLE IF NOT EXISTS `payments_view` (
`Payment_id` int(11)
,`Payment_date` varchar(100)
,`Payment_amount` varchar(100)
,`Payment_method` varchar(100)
,`Reservation_id` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE IF NOT EXISTS `reservations` (
  `Reservation_id` int(11) NOT NULL AUTO_INCREMENT,
  `Checkin_date` varchar(100) NOT NULL,
  `Checkout_date` varchar(100) NOT NULL,
  `Total_price` varchar(100) NOT NULL,
  `Status` varchar(100) NOT NULL,
  `Customer_id` int(11) DEFAULT NULL,
  `Room_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Reservation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`Reservation_id`, `Checkin_date`, `Checkout_date`, `Total_price`, `Status`, `Customer_id`, `Room_id`) VALUES
(1, '023-05-12', '023-05-14', '60000', 'single', 123, 1),
(2, '023-06-23', '023-06-29', '560000', 'couple', 234, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `reservations_view`
--
CREATE TABLE IF NOT EXISTS `reservations_view` (
`Reservation_id` int(11)
,`Checkin_date` varchar(100)
,`Checkout_date` varchar(100)
,`Total_price` varchar(100)
,`Status` varchar(100)
,`Customer_id` int(11)
,`Room_id` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE IF NOT EXISTS `review` (
  `Review_id` int(11) NOT NULL AUTO_INCREMENT,
  `Review_text` varchar(100) NOT NULL,
  `Date_posted` varchar(100) NOT NULL,
  `Rating` varchar(100) NOT NULL,
  `Customer_id` int(11) DEFAULT NULL,
  `Hotel_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Review_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`Review_id`, `Review_text`, `Date_posted`, `Rating`, `Customer_id`, `Hotel_id`) VALUES
(1, 'facebook', '023-06-21', 'good', 123, 1);

--
-- Triggers `review`
--
DROP TRIGGER IF EXISTS `AfterDeletereview`;
DELIMITER //
CREATE TRIGGER `AfterDeletereview` AFTER DELETE ON `review`
 FOR EACH ROW BEGIN
INSERT INTO review_audit(review_id,action,action_date)
VALUES
(review_id,'DELETE',NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `review_view`
--
CREATE TABLE IF NOT EXISTS `review_view` (
`Review_id` int(11)
,`Review_text` varchar(100)
,`Date_posted` varchar(100)
,`Rating` varchar(100)
,`Customer_id` int(11)
,`Hotel_id` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE IF NOT EXISTS `rooms` (
  `Room_id` int(11) NOT NULL AUTO_INCREMENT,
  `Room_type` varchar(100) NOT NULL,
  `Price_per_night` int(11) NOT NULL,
  `Is_available` varchar(100) NOT NULL,
  `Hotel_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Room_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`Room_id`, `Room_type`, `Price_per_night`, `Is_available`, `Hotel_id`) VALUES
(1, 'single', 30000, 'yes', 1),
(2, 'double', 80000, 'yes', 1);

--
-- Triggers `rooms`
--
DROP TRIGGER IF EXISTS `AfterUpdaterooms`;
DELIMITER //
CREATE TRIGGER `AfterUpdaterooms` AFTER INSERT ON `rooms`
 FOR EACH ROW BEGIN
INSERT INTO rooms_audit(room_id,action,action_date)
VALUES
(NEW.room_id,'UPDATE',NOW());
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `rooms_view`
--
CREATE TABLE IF NOT EXISTS `rooms_view` (
`Room_id` int(11)
,`Room_type` varchar(100)
,`Price_per_night` int(11)
,`Is_available` varchar(100)
,`Hotel_id` int(11)
);
-- --------------------------------------------------------

--
-- Structure for view `customers_view`
--
DROP TABLE IF EXISTS `customers_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `customers_view` AS select `customers`.`Customer_id` AS `Customer_id`,`customers`.`First_name` AS `First_name`,`customers`.`Last_name` AS `Last_name`,`customers`.`Email` AS `Email`,`customers`.`Phone` AS `Phone`,`customers`.`Address` AS `Address` from `customers`;

-- --------------------------------------------------------

--
-- Structure for view `hotel_view`
--
DROP TABLE IF EXISTS `hotel_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `hotel_view` AS select `hotel`.`Hotel_id` AS `Hotel_id`,`hotel`.`Name` AS `Name`,`hotel`.`Address` AS `Address`,`hotel`.`City` AS `City`,`hotel`.`Country` AS `Country`,`hotel`.`Phone` AS `Phone`,`hotel`.`Email` AS `Email` from `hotel`;

-- --------------------------------------------------------

--
-- Structure for view `insert_customersview`
--
DROP TABLE IF EXISTS `insert_customersview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_customersview` AS select `customers`.`Customer_id` AS `Customer_id`,`customers`.`First_name` AS `First_name`,`customers`.`Last_name` AS `Last_name`,`customers`.`Email` AS `Email`,`customers`.`Phone` AS `Phone`,`customers`.`Address` AS `Address` from `customers` where (`customers`.`Customer_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_hotelview`
--
DROP TABLE IF EXISTS `insert_hotelview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_hotelview` AS select `hotel`.`Hotel_id` AS `Hotel_id`,`hotel`.`Name` AS `Name`,`hotel`.`Address` AS `Address`,`hotel`.`City` AS `City`,`hotel`.`Country` AS `Country`,`hotel`.`Phone` AS `Phone`,`hotel`.`Email` AS `Email` from `hotel` where (`hotel`.`Hotel_id` = 1);

-- --------------------------------------------------------

--
-- Structure for view `insert_paymentsview`
--
DROP TABLE IF EXISTS `insert_paymentsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_paymentsview` AS select `payments`.`Payment_id` AS `Payment_id`,`payments`.`Payment_date` AS `Payment_date`,`payments`.`Payment_amount` AS `Payment_amount`,`payments`.`Payment_method` AS `Payment_method`,`payments`.`Reservation_id` AS `Reservation_id` from `payments` where (`payments`.`Payment_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_reservationsview`
--
DROP TABLE IF EXISTS `insert_reservationsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_reservationsview` AS select `reservations`.`Reservation_id` AS `Reservation_id`,`reservations`.`Checkin_date` AS `Checkin_date`,`reservations`.`Checkout_date` AS `Checkout_date`,`reservations`.`Total_price` AS `Total_price`,`reservations`.`Status` AS `Status`,`reservations`.`Customer_id` AS `Customer_id`,`reservations`.`Room_id` AS `Room_id` from `reservations` where (`reservations`.`Reservation_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_reviewview`
--
DROP TABLE IF EXISTS `insert_reviewview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_reviewview` AS select `review`.`Review_id` AS `Review_id`,`review`.`Review_text` AS `Review_text`,`review`.`Date_posted` AS `Date_posted`,`review`.`Rating` AS `Rating`,`review`.`Customer_id` AS `Customer_id`,`review`.`Hotel_id` AS `Hotel_id` from `review` where (`review`.`Review_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `insert_roomsview`
--
DROP TABLE IF EXISTS `insert_roomsview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_roomsview` AS select `rooms`.`Room_id` AS `Room_id`,`rooms`.`Room_type` AS `Room_type`,`rooms`.`Price_per_night` AS `Price_per_night`,`rooms`.`Is_available` AS `Is_available`,`rooms`.`Hotel_id` AS `Hotel_id` from `rooms` where (`rooms`.`Room_id` = 2);

-- --------------------------------------------------------

--
-- Structure for view `payments_view`
--
DROP TABLE IF EXISTS `payments_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `payments_view` AS select `payments`.`Payment_id` AS `Payment_id`,`payments`.`Payment_date` AS `Payment_date`,`payments`.`Payment_amount` AS `Payment_amount`,`payments`.`Payment_method` AS `Payment_method`,`payments`.`Reservation_id` AS `Reservation_id` from `payments`;

-- --------------------------------------------------------

--
-- Structure for view `reservations_view`
--
DROP TABLE IF EXISTS `reservations_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `reservations_view` AS select `reservations`.`Reservation_id` AS `Reservation_id`,`reservations`.`Checkin_date` AS `Checkin_date`,`reservations`.`Checkout_date` AS `Checkout_date`,`reservations`.`Total_price` AS `Total_price`,`reservations`.`Status` AS `Status`,`reservations`.`Customer_id` AS `Customer_id`,`reservations`.`Room_id` AS `Room_id` from `reservations`;

-- --------------------------------------------------------

--
-- Structure for view `review_view`
--
DROP TABLE IF EXISTS `review_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `review_view` AS select `review`.`Review_id` AS `Review_id`,`review`.`Review_text` AS `Review_text`,`review`.`Date_posted` AS `Date_posted`,`review`.`Rating` AS `Rating`,`review`.`Customer_id` AS `Customer_id`,`review`.`Hotel_id` AS `Hotel_id` from `review`;

-- --------------------------------------------------------

--
-- Structure for view `rooms_view`
--
DROP TABLE IF EXISTS `rooms_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `rooms_view` AS select `rooms`.`Room_id` AS `Room_id`,`rooms`.`Room_type` AS `Room_type`,`rooms`.`Price_per_night` AS `Price_per_night`,`rooms`.`Is_available` AS `Is_available`,`rooms`.`Hotel_id` AS `Hotel_id` from `rooms`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
