-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 07:04 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seeds_management_system`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteemployeeOrfarm` (IN `tableName` VARCHAR(50), IN `columnName` VARCHAR(50), IN `conditionValue` VARCHAR(100))   BEGIN
    DECLARE tableNameLowercase VARCHAR(50);
    SET tableNameLowercase = LOWER(tableName);
    SET @deleteQuery = CONCAT('DELETE FROM ', tableNameLowercase, ' WHERE ', columnName, ' = ?');
    PREPARE stmt FROM @deleteQuery;
    EXECUTE stmt USING conditionValue;
    DEALLOCATE PREPARE stmt;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllTablesData` ()   BEGIN
select*from crop;
select*from farm;
select*from employee;
select*from seed_lot;
select*from login;
select*from seed;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplaySeedData` ()   BEGIN
    SELECT * FROM seed;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetseedInseed_lot` (IN `seed_lot_name` VARCHAR(100))   BEGIN
    SELECT Seed_type,quantity 
    FROM seed
    WHERE seed_id IN (
        SELECT seed_id
        FROM seed_lot
        WHERE seed_lot_id = (SELECT seed_lot_id FROM seed_lot WHERE seed_lot = seed_lot)
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertcrop` (IN `crop_name` VARCHAR(255), IN `seed_id` INT, IN `variety` VARCHAR(255), IN `planting_date` DATE, IN `harvest_date` DATE, IN `yield` INT, IN `market_value` DOUBLE, IN `pest_resistance` VARCHAR(255))   BEGIN
INSERT INTO crop (crop_name, seed_id,variety, planting_date, harvest_date, yield, market_value, pest_resistance)
VALUES(cropname, seedid,variety, plantingdate, harvestdate, yield, marketvalue, pestresistance);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertemployee` (`employee_id` INT, IN `employee_name` VARCHAR(255), IN `job_title` VARCHAR(255), IN `phone_number` VARCHAR(255), IN `email_address` VARCHAR(255), IN `address` VARCHAR(255), IN `date_of_birth` DATE, IN `education` VARCHAR(255), IN `training` VARCHAR(255), IN `role` VARCHAR(255), IN `permissions` VARCHAR(255))   BEGIN
INSERT INTO employee (employee_name, job_title, phone_number, email_address, address, date_of_birth, education, training, role, permissions)
VALUES (employeename, jobtitle, phonenumber, emailaddress, address, dateofbirth, education, training, role, permissions);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertfarm` (IN `farm_id` INT, IN `farm_name` VARCHAR(255), IN `location` VARCHAR(255), IN `owner` VARCHAR(255), IN `size` INT, IN `employee_id` INT, IN `soil_type` VARCHAR(255), IN `irrigation_system` VARCHAR(255), IN `crop_rotation_schedule` VARCHAR(255))   BEGIN
INSERT INTO farm (farm_id ,farm_name, location, owner, size,employee_id ,
 soil_type, irrigation_system, crop_rotation_schedule)
VALUES (farm_id ,farm_name, location, owner, size,employee_id ,
 soil_type, irrigation_system, crop_rotation_schedule);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertlogin` (IN `login_id` INT, IN `username` VARCHAR(255), IN `password` VARCHAR(255), IN `role` VARCHAR(255), IN `permissions` VARCHAR(255), IN `employee_id` INT)   BEGIN
INSERT INTO login ( login_id,username, password, role, permissions,employee_id)
VALUES (001,'pierre', 'password123', 'Farmer', 'All',1);

    INSERT INTO login ( login_id,username, password, role, permissions,employee_id) 
    VALUES (loginid,username, password, role, permissions,employeeid);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Insertseed` (IN `seed_type` VARCHAR(255), `INvariety` VARCHAR(255), IN `germination_rate` DOUBLE, IN `quantity` INT, IN `location` VARCHAR(255), IN `country_of_origin` VARCHAR(255), IN `breeder` VARCHAR(255), IN `date_harvested` DATE, IN `date_processed` DATE, `INstorage_conditions` VARCHAR(255), IN `treatment_information` VARCHAR(255), IN `germination_test_results` VARCHAR(255))   BEGIN
INSERT INTO seed (seed_type, variety, germination_rate, quantity, location, country_of_origin, breeder, date_harvested, date_processed, storage_conditions, treatment_information, germination_test_results)
VALUES(seedtype, variety, germinationrate, quantity, location, countryoforigin, breeder, dateharvested, dateprocessed, storageconditions, treatmentinformation, germinationtestresults);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertSEED_LOT` (IN `seed_lot_number` INT, IN `seed_id` INT, IN `production_date` DATE, IN `supplier` VARCHAR(255), IN `lot_size` INT)   BEGIN
INSERT INTO seed_lot (seed_lot_number, seed_id, production_date, supplier, lot_size)
VALUES (seed_lotnumber, seedid, productiondate, supplier, lotsize);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateFarmData` (IN `farmId` INT, IN `newFarmName` VARCHAR(255), IN `newLocation` VARCHAR(255))   BEGIN
    UPDATE farm
    SET farm_name = newFarmName, location = newLocation
    WHERE farm_id = farmId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateSeedData` (IN `seedId` INT, IN `newGerminationRate` DOUBLE, IN `newQuantity` INT)   BEGIN
    UPDATE seed
    SET germination_rate = newGerminationRate, quantity = newQuantity
    WHERE seed_id = seedId;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `crop`
--

CREATE TABLE `crop` (
  `crop_id` int(11) NOT NULL,
  `crop_name` varchar(255) NOT NULL,
  `seed_id` int(11) NOT NULL,
  `variety` varchar(255) NOT NULL,
  `planting_date` date NOT NULL,
  `harvest_date` date NOT NULL,
  `yield` int(11) NOT NULL,
  `market_value` double NOT NULL,
  `pest_resistance` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `crop`
--

INSERT INTO `crop` (`crop_id`, `crop_name`, `seed_id`, `variety`, `planting_date`, `harvest_date`, `yield`, `market_value`, `pest_resistance`) VALUES
(4, 'avocadoes', 1, 'Roundup Ready', '2023-09-01', '2026-10-31', 1000, 5, 'Yes'),
(5, 'Soybeans', 2, 'Incredible', '2023-09-02', '0000-00-00', 1500, 10, 'No'),
(6, 'Wheat', 3, 'Hard Red Spring', '2023-09-03', '2024-01-31', 2000, 7, 'Yes');

-- --------------------------------------------------------

--
-- Stand-in structure for view `crop_with_date_inserted`
-- (See below for the actual view)
--
CREATE TABLE `crop_with_date_inserted` (
`crop_id` int(11)
,`crop_name` varchar(255)
,`seed_id` int(11)
,`variety` varchar(255)
,`planting_date` date
,`harvest_date` date
,`yield` int(11)
,`market_value` double
,`pest_resistance` varchar(255)
,`days_since_harvested` double
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `delete_view`
-- (See below for the actual view)
--
CREATE TABLE `delete_view` (
`variety` varchar(255)
,`location` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `education` varchar(255) NOT NULL,
  `training` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `permissions` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `employee_name`, `job_title`, `phone_number`, `email_address`, `address`, `date_of_birth`, `education`, `training`, `role`, `permissions`) VALUES
(1, 'ndayiringiye', 'Farmer', '0785551212', 'ndayir@gmail.com', 'huye', '1970-01-01', 'High school diploma', '4 years of farming experience', 'Farmer', 'All'),
(2, 'Jane', 'Seed sales representative', '0795552323', 'jane@gmail.com', 'musanze', '1980-02-02', 'Bachelors degree in agriculture', '2 years of sales experience', 'Sales representative', 'Read-only'),
(3, 'John', 'Farmer', '0725551212', 'john@gmail.com', 'burera', '1970-01-01', 'High school diploma', '4 years of farming experience', 'Farmer', 'All');

--
-- Triggers `employee`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteemployee` AFTER DELETE ON `employee` FOR EACH ROW BEGIN
    INSERT INTO employee_audit (employee_id, action, action_date)
    VALUES (OLD.employee_id, 'DELETE', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateemployee` AFTER UPDATE ON `employee` FOR EACH ROW BEGIN
    INSERT INTO employee_audit (employee_id, action, action_date)
    VALUES (NEW.employee_id, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `employee_with_date_of_birth`
-- (See below for the actual view)
--
CREATE TABLE `employee_with_date_of_birth` (
`employee_id` int(11)
,`employee_name` varchar(255)
,`job_title` varchar(255)
,`phone_number` varchar(255)
,`email_address` varchar(255)
,`address` varchar(255)
,`date_of_birth` date
,`education` varchar(255)
,`training` varchar(255)
,`role` varchar(255)
,`permissions` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `farm`
--

CREATE TABLE `farm` (
  `farm_id` int(11) NOT NULL,
  `farm_name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `soil_type` varchar(255) NOT NULL,
  `irrigation_system` varchar(255) NOT NULL,
  `crop_rotation_schedule` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farm`
--

INSERT INTO `farm` (`farm_id`, `farm_name`, `location`, `owner`, `size`, `employee_id`, `soil_type`, `irrigation_system`, `crop_rotation_schedule`) VALUES
(1, 'byumba', 'rwanda', 'ndayisenga', 1500, 1, 'Sand', 'Center pivot', 'Corn, soybeans, wheat'),
(2, 'ngoma', 'rwanda', 'gisa', 2000, 2, 'Loam', 'Sprinkler', 'Soybeans, corn, wheat'),
(3, 'kabale', 'uganda', 'Mike Jones', 3000, 3, 'Clay', 'Drip irrigation', 'Wheat, corn, soybeans');

--
-- Triggers `farm`
--
DELIMITER $$
CREATE TRIGGER `AfterInsertfarm` AFTER INSERT ON `farm` FOR EACH ROW BEGIN
    INSERT INTO farm_audit (farm_id, action, action_date)
    VALUES (NEW.farm_id, 'INSERT', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `farms_with_highest_yield`
-- (See below for the actual view)
--
CREATE TABLE `farms_with_highest_yield` (
`farm_id` int(11)
,`farm_name` varchar(255)
,`location` varchar(255)
,`owner` varchar(255)
,`size` int(11)
,`crop_rotation_schedule` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `farm_with_size`
-- (See below for the actual view)
--
CREATE TABLE `farm_with_size` (
`farm_id` int(11)
,`farm_name` varchar(255)
,`location` varchar(255)
,`owner` varchar(255)
,`size` int(11)
,`employee_id` int(11)
,`soil_type` varchar(255)
,`irrigation_system` varchar(255)
,`crop_rotation_schedule` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_crop_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_crop_view` (
`crop_name` varchar(255)
,`seed_id` int(11)
,`variety` varchar(255)
,`planting_date` date
,`harvest_date` date
,`yield` int(11)
,`market_value` double
,`pest_resistance` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_employee_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_employee_view` (
`employee_name` varchar(255)
,`job_title` varchar(255)
,`phone_number` varchar(255)
,`email_address` varchar(255)
,`address` varchar(255)
,`date_of_birth` date
,`education` varchar(255)
,`training` varchar(255)
,`role` varchar(255)
,`permissions` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_farm_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_farm_view` (
`farm_name` varchar(255)
,`location` varchar(255)
,`owner` varchar(255)
,`size` int(11)
,`soil_type` varchar(255)
,`irrigation_system` varchar(255)
,`crop_rotation_schedule` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_seed_lot_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_seed_lot_view` (
`seed_lot_number` int(11)
,`seed_id` int(11)
,`production_date` date
,`supplier` varchar(255)
,`lot_size` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insert_seed_view`
-- (See below for the actual view)
--
CREATE TABLE `insert_seed_view` (
`seed_type` varchar(255)
,`variety` varchar(255)
,`germination_rate` double
,`quantity` int(11)
,`location` varchar(255)
,`country_of_origin` varchar(255)
,`breeder` varchar(255)
,`date_harvested` date
,`date_processed` date
,`storage_conditions` varchar(255)
,`treatment_information` varchar(255)
,`germination_test_results` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `permissions` varchar(255) NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `username`, `password`, `role`, `permissions`, `employee_id`) VALUES
(1, 'pierre', 'password123', 'Farmer', 'All', 1),
(2, 'jane', 'password456', 'Sales representative', 'Read-only', 2),
(3, 'mike', 'password789', 'Processing technician', 'Read-only', 3);

--
-- Triggers `login`
--
DELIMITER $$
CREATE TRIGGER `AfterDeletelogin` AFTER DELETE ON `login` FOR EACH ROW BEGIN
    INSERT INTO login_audit (login_id, action, action_date)
    VALUES (OLD.login_id, 'DELETE', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertlogin` AFTER INSERT ON `login` FOR EACH ROW BEGIN
    INSERT INTO login_audit (login_id, action, action_date)
    VALUES (NEW.login_id, 'INSERT', NOW());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdatelogin` AFTER UPDATE ON `login` FOR EACH ROW BEGIN
    INSERT INTO login_audit (login_id, action, action_date)
    VALUES (NEW.login_id, 'UPDATE', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `login_with_permissions`
-- (See below for the actual view)
--
CREATE TABLE `login_with_permissions` (
`login_id` int(11)
,`username` varchar(255)
,`password` varchar(255)
,`role` varchar(255)
,`permissions` varchar(255)
,`employee_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `seed`
--

CREATE TABLE `seed` (
  `seed_id` int(11) NOT NULL,
  `seed_type` varchar(255) NOT NULL,
  `variety` varchar(255) NOT NULL,
  `germination_rate` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `location` varchar(255) NOT NULL,
  `country_of_origin` varchar(255) NOT NULL,
  `breeder` varchar(255) NOT NULL,
  `date_harvested` date NOT NULL,
  `date_processed` date NOT NULL,
  `storage_conditions` varchar(255) NOT NULL,
  `treatment_information` varchar(255) NOT NULL,
  `germination_test_results` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seed`
--

INSERT INTO `seed` (`seed_id`, `seed_type`, `variety`, `germination_rate`, `quantity`, `location`, `country_of_origin`, `breeder`, `date_harvested`, `date_processed`, `storage_conditions`, `treatment_information`, `germination_test_results`) VALUES
(1, 'Corn', 'Roundup Ready', 95, 10000, 'bugesera', 'rwanda', 'RAB', '2023-08-29', '2023-08-30', 'Dry', 'Pesticide', 'Fail'),
(2, 'Soybeans', 'Incredible', 90, 20000, 'rwamagana', 'rwanda', 'RAB', '2023-08-30', '2023-06-29', 'Cool', 'Fungicide', 'Fail'),
(3, 'Wheat', 'Hard Red Spring', 85, 30000, 'musanze', 'rwanda', 'MINAGRI', '2023-05-20', '2023-08-10', 'Warm', 'Insecticide', 'Pass');

-- --------------------------------------------------------

--
-- Stand-in structure for view `seed_harvested_in_2023`
-- (See below for the actual view)
--
CREATE TABLE `seed_harvested_in_2023` (
`seed_id` int(11)
,`seed_type` varchar(255)
,`variety` varchar(255)
,`germination_rate` double
,`quantity` int(11)
,`location` varchar(255)
,`country_of_origin` varchar(255)
,`breeder` varchar(255)
,`date_harvested` date
,`date_processed` date
,`storage_conditions` varchar(255)
,`treatment_information` varchar(255)
,`germination_test_results` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `seed_lot`
--

CREATE TABLE `seed_lot` (
  `seed_lot_number` int(11) NOT NULL,
  `seed_id` int(11) NOT NULL,
  `production_date` date NOT NULL,
  `supplier` varchar(255) NOT NULL,
  `lot_size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seed_lot`
--

INSERT INTO `seed_lot` (`seed_lot_number`, `seed_id`, `production_date`, `supplier`, `lot_size`) VALUES
(1, 1, '2023-08-29', 'NYAMATA  Seed Company', 10000),
(2, 2, '2023-08-28', 'GISHARI  CropScience', 20000),
(3, 3, '2023-08-27', ' NYAKINAMA', 30000);

-- --------------------------------------------------------

--
-- Stand-in structure for view `seed_lot_with_production_date`
-- (See below for the actual view)
--
CREATE TABLE `seed_lot_with_production_date` (
`seed_lot_number` int(11)
,`seed_id` int(11)
,`production_date` date
,`supplier` varchar(255)
,`lot_size` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_crop`
-- (See below for the actual view)
--
CREATE TABLE `view_crop` (
`crop_id` int(11)
,`crop_name` varchar(255)
,`seed_id` int(11)
,`variety` varchar(255)
,`planting_date` date
,`harvest_date` date
,`yield` int(11)
,`market_value` double
,`pest_resistance` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_employee`
-- (See below for the actual view)
--
CREATE TABLE `view_employee` (
`employee_id` int(11)
,`employee_name` varchar(255)
,`job_title` varchar(255)
,`phone_number` varchar(255)
,`email_address` varchar(255)
,`address` varchar(255)
,`date_of_birth` date
,`education` varchar(255)
,`training` varchar(255)
,`role` varchar(255)
,`permissions` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_seed_lot`
-- (See below for the actual view)
--
CREATE TABLE `view_seed_lot` (
`seed_lot_number` int(11)
,`seed_id` int(11)
,`production_date` date
,`supplier` varchar(255)
,`lot_size` int(11)
);

-- --------------------------------------------------------

--
-- Structure for view `crop_with_date_inserted`
--
DROP TABLE IF EXISTS `crop_with_date_inserted`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `crop_with_date_inserted`  AS SELECT `crop`.`crop_id` AS `crop_id`, `crop`.`crop_name` AS `crop_name`, `crop`.`seed_id` AS `seed_id`, `crop`.`variety` AS `variety`, `crop`.`planting_date` AS `planting_date`, `crop`.`harvest_date` AS `harvest_date`, `crop`.`yield` AS `yield`, `crop`.`market_value` AS `market_value`, `crop`.`pest_resistance` AS `pest_resistance`, curdate() - '2023-09-02' AS `days_since_harvested` FROM `crop``crop`  ;

-- --------------------------------------------------------

--
-- Structure for view `delete_view`
--
DROP TABLE IF EXISTS `delete_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `delete_view`  AS SELECT `seed`.`variety` AS `variety`, `seed`.`location` AS `location` FROM `seed` WHERE `seed`.`seed_id` = 1 union all select `crop`.`variety` AS `variety`,`crop`.`yield` AS `yield` from `crop` where `crop`.`crop_id` = 1  ;

-- --------------------------------------------------------

--
-- Structure for view `employee_with_date_of_birth`
--
DROP TABLE IF EXISTS `employee_with_date_of_birth`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `employee_with_date_of_birth`  AS SELECT `employee`.`employee_id` AS `employee_id`, `employee`.`employee_name` AS `employee_name`, `employee`.`job_title` AS `job_title`, `employee`.`phone_number` AS `phone_number`, `employee`.`email_address` AS `email_address`, `employee`.`address` AS `address`, `employee`.`date_of_birth` AS `date_of_birth`, `employee`.`education` AS `education`, `employee`.`training` AS `training`, `employee`.`role` AS `role`, `employee`.`permissions` AS `permissions` FROM `employee` WHERE `employee`.`date_of_birth` between '1950-01-01' and '2023-12-31''2023-12-31'  ;

-- --------------------------------------------------------

--
-- Structure for view `farms_with_highest_yield`
--
DROP TABLE IF EXISTS `farms_with_highest_yield`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `farms_with_highest_yield`  AS SELECT `farm`.`farm_id` AS `farm_id`, `farm`.`farm_name` AS `farm_name`, `farm`.`location` AS `location`, `farm`.`owner` AS `owner`, `farm`.`size` AS `size`, `farm`.`crop_rotation_schedule` AS `crop_rotation_schedule` FROM `farm` WHERE `farm`.`farm_id` in (select `farm`.`farm_id` from `crop` where `crop`.`yield` = (select max(`crop`.`yield`) from `crop`))  ;

-- --------------------------------------------------------

--
-- Structure for view `farm_with_size`
--
DROP TABLE IF EXISTS `farm_with_size`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `farm_with_size`  AS SELECT `farm`.`farm_id` AS `farm_id`, `farm`.`farm_name` AS `farm_name`, `farm`.`location` AS `location`, `farm`.`owner` AS `owner`, `farm`.`size` AS `size`, `farm`.`employee_id` AS `employee_id`, `farm`.`soil_type` AS `soil_type`, `farm`.`irrigation_system` AS `irrigation_system`, `farm`.`crop_rotation_schedule` AS `crop_rotation_schedule` FROM `farm` WHERE `farm`.`size` between 1000 and 1000010000  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_crop_view`
--
DROP TABLE IF EXISTS `insert_crop_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_crop_view`  AS SELECT `crop`.`crop_name` AS `crop_name`, `crop`.`seed_id` AS `seed_id`, `crop`.`variety` AS `variety`, `crop`.`planting_date` AS `planting_date`, `crop`.`harvest_date` AS `harvest_date`, `crop`.`yield` AS `yield`, `crop`.`market_value` AS `market_value`, `crop`.`pest_resistance` AS `pest_resistance` FROM `crop``crop`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_employee_view`
--
DROP TABLE IF EXISTS `insert_employee_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_employee_view`  AS SELECT `employee`.`employee_name` AS `employee_name`, `employee`.`job_title` AS `job_title`, `employee`.`phone_number` AS `phone_number`, `employee`.`email_address` AS `email_address`, `employee`.`address` AS `address`, `employee`.`date_of_birth` AS `date_of_birth`, `employee`.`education` AS `education`, `employee`.`training` AS `training`, `employee`.`role` AS `role`, `employee`.`permissions` AS `permissions` FROM `employee``employee`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_farm_view`
--
DROP TABLE IF EXISTS `insert_farm_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_farm_view`  AS SELECT `farm`.`farm_name` AS `farm_name`, `farm`.`location` AS `location`, `farm`.`owner` AS `owner`, `farm`.`size` AS `size`, `farm`.`soil_type` AS `soil_type`, `farm`.`irrigation_system` AS `irrigation_system`, `farm`.`crop_rotation_schedule` AS `crop_rotation_schedule` FROM `farm``farm`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_seed_lot_view`
--
DROP TABLE IF EXISTS `insert_seed_lot_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_seed_lot_view`  AS SELECT `seed_lot`.`seed_lot_number` AS `seed_lot_number`, `seed_lot`.`seed_id` AS `seed_id`, `seed_lot`.`production_date` AS `production_date`, `seed_lot`.`supplier` AS `supplier`, `seed_lot`.`lot_size` AS `lot_size` FROM `seed_lot``seed_lot`  ;

-- --------------------------------------------------------

--
-- Structure for view `insert_seed_view`
--
DROP TABLE IF EXISTS `insert_seed_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insert_seed_view`  AS SELECT `seed`.`seed_type` AS `seed_type`, `seed`.`variety` AS `variety`, `seed`.`germination_rate` AS `germination_rate`, `seed`.`quantity` AS `quantity`, `seed`.`location` AS `location`, `seed`.`country_of_origin` AS `country_of_origin`, `seed`.`breeder` AS `breeder`, `seed`.`date_harvested` AS `date_harvested`, `seed`.`date_processed` AS `date_processed`, `seed`.`storage_conditions` AS `storage_conditions`, `seed`.`treatment_information` AS `treatment_information`, `seed`.`germination_test_results` AS `germination_test_results` FROM `seed``seed`  ;

-- --------------------------------------------------------

--
-- Structure for view `login_with_permissions`
--
DROP TABLE IF EXISTS `login_with_permissions`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `login_with_permissions`  AS SELECT `login`.`login_id` AS `login_id`, `login`.`username` AS `username`, `login`.`password` AS `password`, `login`.`role` AS `role`, `login`.`permissions` AS `permissions`, `login`.`employee_id` AS `employee_id` FROM `login` WHERE `login`.`permissions` = 'All''All'  ;

-- --------------------------------------------------------

--
-- Structure for view `seed_harvested_in_2023`
--
DROP TABLE IF EXISTS `seed_harvested_in_2023`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `seed_harvested_in_2023`  AS SELECT `seed`.`seed_id` AS `seed_id`, `seed`.`seed_type` AS `seed_type`, `seed`.`variety` AS `variety`, `seed`.`germination_rate` AS `germination_rate`, `seed`.`quantity` AS `quantity`, `seed`.`location` AS `location`, `seed`.`country_of_origin` AS `country_of_origin`, `seed`.`breeder` AS `breeder`, `seed`.`date_harvested` AS `date_harvested`, `seed`.`date_processed` AS `date_processed`, `seed`.`storage_conditions` AS `storage_conditions`, `seed`.`treatment_information` AS `treatment_information`, `seed`.`germination_test_results` AS `germination_test_results` FROM `seed` WHERE `seed`.`date_harvested` between '2023-01-01' and '2023-12-31''2023-12-31'  ;

-- --------------------------------------------------------

--
-- Structure for view `seed_lot_with_production_date`
--
DROP TABLE IF EXISTS `seed_lot_with_production_date`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `seed_lot_with_production_date`  AS SELECT `seed_lot`.`seed_lot_number` AS `seed_lot_number`, `seed_lot`.`seed_id` AS `seed_id`, `seed_lot`.`production_date` AS `production_date`, `seed_lot`.`supplier` AS `supplier`, `seed_lot`.`lot_size` AS `lot_size` FROM `seed_lot` WHERE `seed_lot`.`production_date` between '1950-01-01' and '2023-12-31''2023-12-31'  ;

-- --------------------------------------------------------

--
-- Structure for view `view_crop`
--
DROP TABLE IF EXISTS `view_crop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_crop`  AS SELECT `crop`.`crop_id` AS `crop_id`, `crop`.`crop_name` AS `crop_name`, `crop`.`seed_id` AS `seed_id`, `crop`.`variety` AS `variety`, `crop`.`planting_date` AS `planting_date`, `crop`.`harvest_date` AS `harvest_date`, `crop`.`yield` AS `yield`, `crop`.`market_value` AS `market_value`, `crop`.`pest_resistance` AS `pest_resistance` FROM `crop``crop`  ;

-- --------------------------------------------------------

--
-- Structure for view `view_employee`
--
DROP TABLE IF EXISTS `view_employee`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_employee`  AS SELECT `employee`.`employee_id` AS `employee_id`, `employee`.`employee_name` AS `employee_name`, `employee`.`job_title` AS `job_title`, `employee`.`phone_number` AS `phone_number`, `employee`.`email_address` AS `email_address`, `employee`.`address` AS `address`, `employee`.`date_of_birth` AS `date_of_birth`, `employee`.`education` AS `education`, `employee`.`training` AS `training`, `employee`.`role` AS `role`, `employee`.`permissions` AS `permissions` FROM `employee``employee`  ;

-- --------------------------------------------------------

--
-- Structure for view `view_seed_lot`
--
DROP TABLE IF EXISTS `view_seed_lot`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_seed_lot`  AS SELECT `seed_lot`.`seed_lot_number` AS `seed_lot_number`, `seed_lot`.`seed_id` AS `seed_id`, `seed_lot`.`production_date` AS `production_date`, `seed_lot`.`supplier` AS `supplier`, `seed_lot`.`lot_size` AS `lot_size` FROM `seed_lot``seed_lot`  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `crop`
--
ALTER TABLE `crop`
  ADD PRIMARY KEY (`crop_id`),
  ADD KEY `seed_id` (`seed_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `farm`
--
ALTER TABLE `farm`
  ADD PRIMARY KEY (`farm_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`login_id`),
  ADD KEY `employee_id` (`employee_id`);

--
-- Indexes for table `seed`
--
ALTER TABLE `seed`
  ADD PRIMARY KEY (`seed_id`);

--
-- Indexes for table `seed_lot`
--
ALTER TABLE `seed_lot`
  ADD PRIMARY KEY (`seed_lot_number`),
  ADD KEY `seed_id` (`seed_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `crop`
--
ALTER TABLE `crop`
  MODIFY `crop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `farm`
--
ALTER TABLE `farm`
  MODIFY `farm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seed`
--
ALTER TABLE `seed`
  MODIFY `seed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `seed_lot`
--
ALTER TABLE `seed_lot`
  MODIFY `seed_lot_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `crop`
--
ALTER TABLE `crop`
  ADD CONSTRAINT `crop_ibfk_1` FOREIGN KEY (`seed_id`) REFERENCES `seed` (`seed_id`);

--
-- Constraints for table `farm`
--
ALTER TABLE `farm`
  ADD CONSTRAINT `farm_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`);

--
-- Constraints for table `login`
--
ALTER TABLE `login`
  ADD CONSTRAINT `login_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`);

--
-- Constraints for table `seed_lot`
--
ALTER TABLE `seed_lot`
  ADD CONSTRAINT `seed_lot_ibfk_1` FOREIGN KEY (`seed_id`) REFERENCES `seed` (`seed_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
