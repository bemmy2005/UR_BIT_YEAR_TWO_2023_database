-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2023 at 08:07 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `touristconnect`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteActivityByName` (IN `p_ActivityName` VARCHAR(255))   BEGIN
  DECLARE v_ActivityID INT;
    SELECT Activity_ID INTO v_ActivityID
  FROM Activity
  WHERE Name = p_ActivityName;
  DELETE FROM Activity
  WHERE Activity_ID = v_ActivityID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeletePlace` (IN `p_PlaceID` INT)   BEGIN
  DELETE FROM Place
  WHERE Place_ID = p_PlaceID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteTourist` (IN `p_TouristID` INT)   BEGIN
  DELETE FROM Tourist
  WHERE Tourist_ID = p_TouristID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DisplayAllData` ()   BEGIN
SELECT * FROM Tourist;
SELECT * FROM Place;
SELECT * FROM Application;
SELECT * FROM Activity;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertData` (IN `p_TouristID` INT, IN `p_Name` VARCHAR(255), IN `p_Phone` VARCHAR(15), IN `p_Email` VARCHAR(255), IN `p_PlaceID` INT, IN `p_PlaceName` VARCHAR(255), IN `p_PlaceDescription` TEXT, IN `p_PlaceLocation` VARCHAR(255), IN `p_ApplicationID` INT, IN `p_ApplicationTouristID` INT, IN `p_ApplicationPlaceID` INT, IN `p_ActivityID` INT, IN `p_ActivityName` VARCHAR(255), IN `p_ActivityDescription` TEXT, IN `p_ActivityPlaceID` INT, IN `p_ActivityPrice` DECIMAL(10,2), IN `p_ActivityDate` DATE, IN `p_ActivityDuration` INT)   BEGIN
    INSERT INTO Tourist (TouristID, Name, Phone, Email)
    VALUES (1, 'bonheur itangishaka', '0780482542', 'bonheuritangishaka72@gmail.com');
    INSERT INTO Place (PlaceID, Name, Description, Location)
    VALUES (1, 'Volcano national park', 'Rwanda volcano park', 'Northern province');
    INSERT INTO Application (ApplicationID, TouristID, PlaceID)
    VALUES (1,1,1);
    INSERT INTO Activity (ActivityID, Name, Description, PlaceID, Price, Date, Duration)
    VALUES ('1', 'Museum visit', 'Explore muslim history', '2', '$50', '17/12/2023', '3');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TouristWithApplications` ()   BEGIN
    SELECT t.touristID, t.name AS touristName, t.phone AS touristPhone, t.email AS touristEmail,
           a.applicationId, a.placeid AS appliedPlaceId,
           (SELECT p.name FROM place p WHERE p.placeid = a.placeid) AS appliedPlaceName
    FROM tourist t
    INNER JOIN application a ON t.touristID = a.touristID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateTouristAndPlace` (IN `tourist_id` INT, IN `new_tourist_name` VARCHAR(255), IN `new_phone` VARCHAR(20), IN `new_email` VARCHAR(255), IN `place_id` INT, IN `new_place_name` VARCHAR(255), IN `new_description` VARCHAR(255), IN `new_location` VARCHAR(255))   BEGIN
UPDATE tourist
SET name = 'Irumva jackson', phone = '0786912048 ', email = 'jackson@gmail.com '
WHERE touristID = '4 ';
UPDATE place
SET name = 'lakekivu ', description = 'Rwanda largest lake ', location = 'Gisenyi Rwanda '
WHERE placeid = '5 ';
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `ActivityID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `PlaceID` int(11) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Duration` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`ActivityID`, `Name`, `Description`, `PlaceID`, `Price`, `Date`, `Duration`) VALUES
(1, 'Museum visit', 'Explore muslim history', 2, 0.00, '0000-00-00', 3),
(2, 'Wild animal visit', 'Explore life of animals', 1, 0.00, '0000-00-00', 2),
(3, 'Memorial visit', 'Explore history of genocide', 3, 0.00, '0000-00-00', 2),
(7, 'forest visit', 'explore forest', 1, 0.00, '0000-00-00', 4);

-- --------------------------------------------------------

--
-- Stand-in structure for view `alldata`
-- (See below for the actual view)
--
CREATE TABLE `alldata` (
`TouristID` int(11)
,`Name` varchar(255)
,`Phone` mediumtext
,`Email` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `ApplicationID` int(11) NOT NULL,
  `TouristID` int(11) DEFAULT NULL,
  `PlaceID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`ApplicationID`, `TouristID`, `PlaceID`) VALUES
(1, 1, 1),
(6, 1, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `deletetourist`
-- (See below for the actual view)
--
CREATE TABLE `deletetourist` (
`TouristID` int(11)
,`Name` varchar(255)
,`Phone` varchar(15)
,`Email` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `deletetouristandplace`
-- (See below for the actual view)
--
CREATE TABLE `deletetouristandplace` (
`touristID` int(11)
,`touristName` varchar(255)
,`touristPhone` varchar(15)
,`touristEmail` varchar(255)
,`placeid` int(11)
,`placeName` varchar(255)
,`placeDescription` text
,`placeLocation` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertactivitydata`
-- (See below for the actual view)
--
CREATE TABLE `insertactivitydata` (
`ActivityID` int(11)
,`Name` varchar(255)
,`Description` text
,`PlaceID` int(11)
,`Price` decimal(10,2)
,`Date` date
,`Duration` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertapplicationdata`
-- (See below for the actual view)
--
CREATE TABLE `insertapplicationdata` (
`ApplicationID` int(11)
,`TouristID` int(11)
,`PlaceID` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `insertplacedata`
-- (See below for the actual view)
--
CREATE TABLE `insertplacedata` (
`PlaceID` int(11)
,`Name` varchar(255)
,`Description` text
,`Location` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `inserttouristdata`
-- (See below for the actual view)
--
CREATE TABLE `inserttouristdata` (
`TouristID` int(11)
,`Name` varchar(255)
,`Phone` varchar(15)
,`Email` varchar(255)
);

-- --------------------------------------------------------

--
-- Table structure for table `place`
--

CREATE TABLE `place` (
  `PlaceID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `place`
--

INSERT INTO `place` (`PlaceID`, `Name`, `Description`, `Location`) VALUES
(1, 'Volcano national park', 'Rwanda volcano park', 'Northern province'),
(2, 'Muslim site', 'Anciety muslim', 'southern province'),
(3, 'Gisozi memorial site', 'Genocide memorial place', 'kigali city'),
(5, 'jackson', 'national forest south', 'southern province');

--
-- Triggers `place`
--
DELIMITER $$
CREATE TRIGGER `AfterDeletePlace` AFTER DELETE ON `place` FOR EACH ROW BEGIN
    INSERT INTO place(PlaceID, Name, Description, Location, Price, Date)
    VALUES (1, 'VOLCANO NATIONAL PARK', 'NATIONAL PARK VISITS', 'NORTH RWANDA', 200.00, '2023-09-05');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertPlace` AFTER INSERT ON `place` FOR EACH ROW BEGIN
    INSERT INTO place (PlaceID, Name, Description, Location)
    VALUES (1, 'Volcano national park', 'Rwanda volcano park', 'Northern province');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdatePlace` AFTER UPDATE ON `place` FOR EACH ROW BEGIN
    INSERT INTO tourist (TouristID, Name, Phone, Email)
    VALUES (1, 'bonheur itangishaka', '0780482542', 'bonheuritangishaka72@gmail.com');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tourist`
--

CREATE TABLE `tourist` (
  `TouristID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tourist`
--

INSERT INTO `tourist` (`TouristID`, `Name`, `Phone`, `Email`) VALUES
(1, 'bonheur itangishaka', '0780482542', 'itangishaka@gmail.com'),
(2, 'niyitunga francois', '0790746153', 'daniel@gmail.com'),
(3, 'daniel ndererimana', '0781046502', 'daniel72@gmail.com'),
(4, 'bonheur', '0734548677', 'daniel@gmail.com');

--
-- Triggers `tourist`
--
DELIMITER $$
CREATE TRIGGER `AfterDeleteTourist` AFTER DELETE ON `tourist` FOR EACH ROW BEGIN
    INSERT INTO tourist(TouristID, Name, Phone, Email)
    VALUES (1, 'John Irumva', 0783453756, 'john@example.com');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterInsertTourist` AFTER INSERT ON `tourist` FOR EACH ROW BEGIN
INSERT INTO tourist (TouristID, Name, Phone, Email)
VALUES (1, 'bonheur itangishaka', '0780482542', 'bonheuritangishaka72@gmail.com');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `AfterUpdateTourist` AFTER UPDATE ON `tourist` FOR EACH ROW BEGIN
    INSERT INTO tourist (TouristID, Name, Phone, Email)
    VALUES (1, 'bonheur itangishaka', '0780482542', 'bonheuritangishaka72@gmail.com');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `touristwithapplications`
-- (See below for the actual view)
--
CREATE TABLE `touristwithapplications` (
`touristID` int(11)
,`touristName` varchar(255)
,`touristPhone` varchar(15)
,`touristEmail` varchar(255)
,`applicationId` int(11)
,`appliedPlaceId` int(11)
,`appliedPlaceName` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `updateplacename`
-- (See below for the actual view)
--
CREATE TABLE `updateplacename` (
`PlaceID` int(11)
,`Name` varchar(255)
,`Description` text
,`Location` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatetouristandplace`
-- (See below for the actual view)
--
CREATE TABLE `updatetouristandplace` (
`touristID` int(11)
,`touristName` varchar(255)
,`touristPhone` varchar(15)
,`touristEmail` varchar(255)
,`placeid` int(11)
,`placeName` varchar(255)
,`placeDescription` text
,`placeLocation` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `updatetouristemail`
-- (See below for the actual view)
--
CREATE TABLE `updatetouristemail` (
`TouristID` int(11)
,`Name` varchar(255)
,`Phone` varchar(15)
,`Email` varchar(255)
);

-- --------------------------------------------------------

--
-- Structure for view `alldata`
--
DROP TABLE IF EXISTS `alldata`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `alldata`  AS SELECT `tourist`.`TouristID` AS `TouristID`, `tourist`.`Name` AS `Name`, `tourist`.`Phone` AS `Phone`, `tourist`.`Email` AS `Email` FROM `tourist`union all select `place`.`PlaceID` AS `PlaceID`,`place`.`Name` AS `Name`,`place`.`Description` AS `Description`,`place`.`Location` AS `Location` from `place` union all select `application`.`ApplicationID` AS `ApplicationID`,`application`.`TouristID` AS `TouristID`,`application`.`PlaceID` AS `PlaceID`,NULL AS `NULL` from `application` union all select `activity`.`ActivityID` AS `ActivityID`,`activity`.`Name` AS `Name`,`activity`.`Description` AS `Description`,`activity`.`PlaceID` AS `PlaceID` from `activity`  ;

-- --------------------------------------------------------

--
-- Structure for view `deletetourist`
--
DROP TABLE IF EXISTS `deletetourist`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deletetourist`  AS SELECT `tourist`.`TouristID` AS `TouristID`, `tourist`.`Name` AS `Name`, `tourist`.`Phone` AS `Phone`, `tourist`.`Email` AS `Email` FROM `tourist` WHERE `tourist`.`Name` = 'daniel' ;

-- --------------------------------------------------------

--
-- Structure for view `deletetouristandplace`
--
DROP TABLE IF EXISTS `deletetouristandplace`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `deletetouristandplace`  AS SELECT `t`.`TouristID` AS `touristID`, `t`.`Name` AS `touristName`, `t`.`Phone` AS `touristPhone`, `t`.`Email` AS `touristEmail`, `p`.`PlaceID` AS `placeid`, `p`.`Name` AS `placeName`, `p`.`Description` AS `placeDescription`, `p`.`Location` AS `placeLocation` FROM (`tourist` `t` join `place` `p` on(`t`.`TouristID` = `p`.`PlaceID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `insertactivitydata`
--
DROP TABLE IF EXISTS `insertactivitydata`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertactivitydata`  AS SELECT `activity`.`ActivityID` AS `ActivityID`, `activity`.`Name` AS `Name`, `activity`.`Description` AS `Description`, `activity`.`PlaceID` AS `PlaceID`, `activity`.`Price` AS `Price`, `activity`.`Date` AS `Date`, `activity`.`Duration` AS `Duration` FROM `activity` ;

-- --------------------------------------------------------

--
-- Structure for view `insertapplicationdata`
--
DROP TABLE IF EXISTS `insertapplicationdata`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertapplicationdata`  AS SELECT `application`.`ApplicationID` AS `ApplicationID`, `application`.`TouristID` AS `TouristID`, `application`.`PlaceID` AS `PlaceID` FROM `application` ;

-- --------------------------------------------------------

--
-- Structure for view `insertplacedata`
--
DROP TABLE IF EXISTS `insertplacedata`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `insertplacedata`  AS SELECT `place`.`PlaceID` AS `PlaceID`, `place`.`Name` AS `Name`, `place`.`Description` AS `Description`, `place`.`Location` AS `Location` FROM `place` ;

-- --------------------------------------------------------

--
-- Structure for view `inserttouristdata`
--
DROP TABLE IF EXISTS `inserttouristdata`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `inserttouristdata`  AS SELECT `tourist`.`TouristID` AS `TouristID`, `tourist`.`Name` AS `Name`, `tourist`.`Phone` AS `Phone`, `tourist`.`Email` AS `Email` FROM `tourist` ;

-- --------------------------------------------------------

--
-- Structure for view `touristwithapplications`
--
DROP TABLE IF EXISTS `touristwithapplications`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `touristwithapplications`  AS SELECT `t`.`TouristID` AS `touristID`, `t`.`Name` AS `touristName`, `t`.`Phone` AS `touristPhone`, `t`.`Email` AS `touristEmail`, `a`.`ApplicationID` AS `applicationId`, `a`.`PlaceID` AS `appliedPlaceId`, (select `p`.`Name` from `place` `p` where `p`.`PlaceID` = `a`.`PlaceID`) AS `appliedPlaceName` FROM (`tourist` `t` join `application` `a` on(`t`.`TouristID` = `a`.`TouristID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `updateplacename`
--
DROP TABLE IF EXISTS `updateplacename`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updateplacename`  AS SELECT `place`.`PlaceID` AS `PlaceID`, `place`.`Name` AS `Name`, `place`.`Description` AS `Description`, `place`.`Location` AS `Location` FROM `place` ;

-- --------------------------------------------------------

--
-- Structure for view `updatetouristandplace`
--
DROP TABLE IF EXISTS `updatetouristandplace`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatetouristandplace`  AS SELECT `t`.`TouristID` AS `touristID`, `t`.`Name` AS `touristName`, `t`.`Phone` AS `touristPhone`, `t`.`Email` AS `touristEmail`, `p`.`PlaceID` AS `placeid`, `p`.`Name` AS `placeName`, `p`.`Description` AS `placeDescription`, `p`.`Location` AS `placeLocation` FROM (`tourist` `t` join `place` `p` on(`t`.`TouristID` = `p`.`PlaceID`)) ;

-- --------------------------------------------------------

--
-- Structure for view `updatetouristemail`
--
DROP TABLE IF EXISTS `updatetouristemail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatetouristemail`  AS SELECT `tourist`.`TouristID` AS `TouristID`, `tourist`.`Name` AS `Name`, `tourist`.`Phone` AS `Phone`, `tourist`.`Email` AS `Email` FROM `tourist` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`ActivityID`),
  ADD KEY `PlaceID` (`PlaceID`);

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`ApplicationID`),
  ADD KEY `TouristID` (`TouristID`),
  ADD KEY `PlaceID` (`PlaceID`);

--
-- Indexes for table `place`
--
ALTER TABLE `place`
  ADD PRIMARY KEY (`PlaceID`);

--
-- Indexes for table `tourist`
--
ALTER TABLE `tourist`
  ADD PRIMARY KEY (`TouristID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity`
--
ALTER TABLE `activity`
  ADD CONSTRAINT `activity_ibfk_1` FOREIGN KEY (`PlaceID`) REFERENCES `place` (`PlaceID`);

--
-- Constraints for table `application`
--
ALTER TABLE `application`
  ADD CONSTRAINT `application_ibfk_1` FOREIGN KEY (`TouristID`) REFERENCES `tourist` (`TouristID`),
  ADD CONSTRAINT `application_ibfk_2` FOREIGN KEY (`PlaceID`) REFERENCES `place` (`PlaceID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
